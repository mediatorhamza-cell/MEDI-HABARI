#!/usr/bin/env bash
# Builds a Hostinger-ready bundle in ./deploy:
#   deploy/public_html/        -> upload contents to ~/domains/mediatorhamza.com/public_html
#   deploy/mediator_private/   -> upload to ~/domains/mediatorhamza.com/mediator_private (OUTSIDE public_html)
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/deploy"
rm -rf "$OUT"
mkdir -p "$OUT/public_html" "$OUT/mediator_private/storage"/{uploads,logs,sessions,backups}

echo "==> Building frontend"
(cd "$ROOT/web" && npm ci --no-audit --no-fund && npm run build)
cp -R "$ROOT/web/dist/." "$OUT/public_html/"

echo "==> Copying API"
mkdir -p "$OUT/public_html/api"
(cd "$ROOT/api" && tar --exclude='./.env' --exclude='./storage' --exclude='./tests' -cf - .) | (cd "$OUT/public_html/api" && tar -xf -)

echo "==> Private config template"
cp "$ROOT/api/.env.example" "$OUT/mediator_private/.env.example"
for d in uploads logs sessions backups; do printf 'Require all denied\n' > "$OUT/mediator_private/storage/$d/.htaccess"; done

( cd "$OUT" && zip -qr mediator-public_html.zip public_html && zip -qr mediator-private.zip mediator_private ) || true
echo "Done. See docs/DEPLOYMENT.md for the remaining steps."
ls -la "$OUT"
