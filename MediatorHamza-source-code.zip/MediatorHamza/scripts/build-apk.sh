#!/usr/bin/env bash
# Build the signed Android APK and place it where the website serves it (/downloads/MediatorHamza.apk).
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
export ANDROID_HOME="${ANDROID_HOME:-/opt/android-sdk}"
[ -f "$ROOT/android/keystore.properties" ] || { echo "Missing android/keystore.properties (signing key) — restore the owner's backup first." >&2; exit 1; }
echo "sdk.dir=$ANDROID_HOME" > "$ROOT/android/local.properties"
(cd "$ROOT/android" && gradle assembleRelease --no-daemon -q)
mkdir -p "$ROOT/web/public/downloads"
cp "$ROOT/android/app/build/outputs/apk/release/app-release.apk" "$ROOT/web/public/downloads/MediatorHamza.apk"
echo "==> web/public/downloads/MediatorHamza.apk updated"
