#!/usr/bin/env bash
# Builds the site and pushes a ready-to-serve copy of public_html to the
# `production` branch. Hostinger (hPanel → Advanced → Git, auto-deploy webhook)
# pulls that branch into public_html, so every publish goes live automatically.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BRANCH="${DEPLOY_BRANCH:-production}"
WT="$(mktemp -d)"
SRC_SHA="$(git -C "$ROOT" rev-parse --short HEAD)"

echo "==> Building frontend"
(cd "$ROOT/web" && { [ -d node_modules ] || npm ci --no-audit --no-fund; } && npm run build >/dev/null)

echo "==> Preparing $BRANCH worktree"
git -C "$ROOT" fetch -q origin "$BRANCH" 2>/dev/null || true
if git -C "$ROOT" rev-parse -q --verify "origin/$BRANCH" >/dev/null; then
  git -C "$ROOT" worktree add -q -B "$BRANCH" "$WT" "origin/$BRANCH"
else
  git -C "$ROOT" worktree add -q --detach "$WT"
  git -C "$WT" checkout -q --orphan "$BRANCH"
fi
trap 'git -C "$ROOT" worktree remove --force "$WT" >/dev/null 2>&1 || true' EXIT

# Replace everything with the fresh build (keep .git)
find "$WT" -mindepth 1 -maxdepth 1 ! -name .git -exec rm -rf {} +
cp -R "$ROOT/web/dist/." "$WT/"
mkdir -p "$WT/api"
(cd "$ROOT/api" && tar --exclude='./.env' --exclude='./storage' --exclude='./tests' -cf - .) | (cd "$WT/api" && tar -xf -)
mkdir -p "$WT/api/storage"
printf 'Require all denied\n' > "$WT/api/storage/.htaccess"
cat > "$WT/README.md" <<TXT
# Mediator — production build (auto-generated)
Do not edit. Generated from source commit $SRC_SHA by scripts/publish.sh.
Hostinger pulls this branch into public_html.
TXT

git -C "$WT" add -A
if git -C "$WT" diff --cached --quiet; then
  echo "No changes to publish."
  exit 0
fi
git -C "$WT" -c user.email="${GIT_AUTHOR_EMAIL:-noreply@anthropic.com}" -c user.name="${GIT_AUTHOR_NAME:-Mediator Deploy}" \
  commit -q -m "Deploy $SRC_SHA ($(date -u +%Y-%m-%dT%H:%MZ))"
for i in 1 2 3 4; do
  git -C "$WT" push -q -u origin "$BRANCH" && break
  sleep $((2 ** i))
done
echo "==> Published $SRC_SHA to $BRANCH"
