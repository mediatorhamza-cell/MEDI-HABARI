# Mediator Hamza — Android app (APK)

A Trusted Web Activity: the APK opens https://mediatorhamza.com full-screen, so every
website change appears in the app without rebuilding it. Rebuild only to change the
icon, name, colours or Android settings (bump `versionCode` in `app/build.gradle`).

Build (needs JDK 17+, Android SDK with platform 35 + build-tools, `dl.google.com` reachable):

```bash
bash scripts/build-apk.sh
```

The release signing key is **not** in git: `android/keystore/mediator-hamza-release.jks`
plus `android/keystore.properties`. Keep the owner's backup copy safe — Android only
accepts updates signed with the same key. Its SHA-256 fingerprint is published in
`web/public/.well-known/assetlinks.json` (needed so the app opens without a URL bar).
