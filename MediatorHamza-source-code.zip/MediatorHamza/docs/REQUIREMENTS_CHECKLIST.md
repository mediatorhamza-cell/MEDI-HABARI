# Requirements Checklist

Legend: ✅ implemented & tested · 🟡 implemented, needs owner input/verification · ⏳ not implemented (documented)

## Platform & architecture
- ✅ React + Vite + TypeScript frontend; PHP + MySQL backend; no localStorage DB, no fake APIs, no Firebase/Supabase
- ✅ Modular frontend/backend, deployable to Hostinger shared hosting
- 🟡 Hosting environment verification (no access — see PROJECT_AUDIT.md)

## Brand / UI
- ✅ Mediator Hamza wordmark, tagline, palette tokens (`web/src/styles/tokens.css`), Inter font, Lucide icons
- ✅ Buttons, fields, selects, date inputs, uploads, tables→cards on mobile, badges, modals, toasts, empty/loading/error states, pagination, confirmations, breadcrumbs, cards, sidebar/drawer
- ✅ Mobile-first, 44px touch targets, proper input types, bottom nav, sticky wizard footer
- 🟡 Official logo/favicon — upload in Admin → Mipangilio (text logo used meanwhile)

## Languages
- ✅ Kiswahili default + English; all UI strings in dictionaries; persisted per browser and per user; admin content bilingual fields; admin default language setting

## Public website
- ✅ Home (hero, CTAs, search, services grid with price/availability/Omba/Jifunze, how-it-works, deadlines, articles, institutions, guidebooks, FAQ, contact, footer)
- ✅ Services, service detail, Education (categories), article, Institutions (search/filter by type/region/ownership, official links), Guidebooks (category/year, outdated flag, view/download), Deadlines, Announcements, FAQ, About, Contact (call/WhatsApp/SMS/email/hours/social/form), Privacy, Terms, Search, 404, Login, Register, Forgot/Reset password
- ✅ "Omba Huduma" preserves the chosen service through login/registration

## Accounts & security
- ✅ Registration (first/second name, phone, password, confirm, terms), Tanzanian phone normalisation, unique phone
- ✅ Login by phone, show/hide password, generic errors, rate limiting
- ✅ Forgot password via SMS OTP (no account enumeration) + admin-assisted recovery code; passwords never visible
- ✅ Sessions: HttpOnly/Secure/SameSite cookies, regeneration, idle expiry, logout, CSRF, server-side role checks
- ✅ Separate admin login, roles (Super Admin/Admin/Support/Read-only/User), permissions, first Super Admin via CLI or one-time token installer, no default credentials
- ✅ Staff TOTP 2FA, audit log, encrypted sensitive fields, upload validation (MIME sniffing, size, random names, private storage)
- 🟡 SMS OTP delivery requires gateway credentials (`SMS_DRIVER`)
- ✅ Remember-me intentionally not implemented (session cookie + 4h idle) — safer on shared phones

## User dashboard
- ✅ Welcome, service cards, start application, my applications, status summary, pending actions, payment status, notifications, deadlines, admin messages, announcements, profile, help & support, history, WhatsApp groups, language, password/security, account activity

## Applications & tracking
- ✅ Unique collision-safe references `MED-YYYY-CODE-NNNNNN`
- ✅ 9 statuses with history (from/to, time, staff, public message, internal note, next action); timeline for users; internal notes hidden
- ✅ Corrections limited to admin-selected fields, audit of changes, resubmission
- ✅ Results/feedback (encrypted) + downloadable documents, visible only to the owner

## Forms
- ✅ Dedicated schema per service: HESLB, college, birth certificate, death certificate, NaPA, certificate verification
- ✅ Multi-step, progress, required/optional markers, autosave to backend, next/back, validation (client + server), review, confirmation, uploads, reference + timestamp success screen, duplicate-submission protection, data kept on errors
- 🟡 Identifier formats & district list to be confirmed against official sources

## Admin portal
- ✅ Dashboard (users, received/in-progress/completed/awaiting docs, deadlines, privacy-friendly visitors, most-used services, charts)
- ✅ Applications list/search (name, phone, service, status, reference, dates), detail, file downloads, status changes, notes, results, close/hold, history, print
- ✅ Exports XLSX/PDF/CSV with selectable columns & filters; phone list export for bulk SMS
- ✅ Notifications to one user / groups (service, status, payment) / all; history with read counts; deadline reminders (manual + cron)
- ✅ Deadlines, content (articles, institutions with link verification before publishing, guidebooks, announcements, FAQ, WhatsApp groups, categories), services & prices & packages, welcome messages, contacts, brand
- ✅ Users: list/search, history, suspend/disable/activate, correct details, message; staff management
- ✅ Backups (`bin/backup.php` + restore), activity logs

## Chat & assistant
- ✅ User-started conversations, admin replies, history, linked to reference, unanswered filter, timestamps, read ticks, notifications
- ✅ Optional assistant answering only from admin-managed FAQs/services/deadlines with disclaimer and hand-off

## PWA
- ✅ Manifest, icons (incl. maskable), standalone display, install prompt / iOS hint, offline page, app shortcuts
- ✅ Browser notifications while the app is open (polling)
- ⏳ Push notifications while the app is closed (needs VAPID/Web Push — future work)

## Payments
- ✅ Price shown before submission and snapshotted; payment statuses (Hujalipia, Umelipa stationery, Umelipa sehemu, Umelipa, Hakuna malipo) set by admin with history
- ⏳ Automatic mobile-money integration (not requested; manual confirmation implemented)
