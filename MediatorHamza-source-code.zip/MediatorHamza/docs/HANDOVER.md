# Makabidhiano ya Mfumo — Mediator Hamza

Hati hii inaeleza kila kitu kinachounda mfumo wa **Mediator Hamza** (website, dashibodi ya
mtumiaji, admin portal na App ya Android), mahali kila kitu kilipo, na hatua za kuhamisha
umiliki kamili kwa mmiliki mpya.

---

## 1. Vilivyomo kwenye kifurushi

| Faili | Maelezo |
|---|---|
| `MediatorHamza-source-code.zip` | **Source code yote**: frontend (`web/`), backend API (`api/`), App ya Android (`android/`), scripts na nyaraka (`docs/`). |
| `MediatorHamza-public_html.zip` | Toleo lililojengwa tayari (production build) — linaweza kupakiwa moja kwa moja kwenye `public_html` ya hosting yoyote ya PHP + MySQL. |
| `MediatorHamza-ufunguo-wa-App-SIRI.zip` | **Ufunguo wa kusaini App ya Android** (hukabidhiwa kando, kwa usiri). Unahitajika kwa kila toleo jipya la APK na kwa Google Play Store. |

Nyaraka nyingine ndani ya source code:
- `README.md` — muhtasari na jinsi ya kuendesha kwenye kompyuta (development).
- `docs/DEPLOYMENT.md` — kuweka mfumo kwenye Hostinger (Git auto-deploy).
- `docs/ADMIN_GUIDE.md` — mwongozo wa kutumia Admin Portal.
- `docs/SYSTEM_ARCHITECTURE.md`, `docs/FORMS.md` — muundo wa mfumo na fomu za huduma.
- `android/README.md` — App ya Android (APK).

## 2. Teknolojia

| Sehemu | Teknolojia |
|---|---|
| Frontend (website, user app, admin, PWA) | React 18 + TypeScript + Vite |
| Backend API | PHP 8.1+ (bila framework, bila Composer) |
| Database | MySQL 5.7+/8 au MariaDB 10.3+ |
| App ya Android | Trusted Web Activity (inafungua website ndani ya App) |
| Hosting inayotumika sasa | Hostinger (shared hosting) |

Hakuna huduma ya kulipia ya mtu wa tatu inayohitajika (hakuna Firebase/Supabase/Node server).

## 3. Mali (assets) za kuhamisha umiliki

### 3.1 Source code (GitHub)
Repo ya sasa: `github.com/mosh3ky-ai/Mediatorhamza` (private).
- **Njia A — Kuhamisha repo yote:** GitHub → repo → **Settings → General → Danger Zone → Transfer ownership** → andika username ya mmiliki mpya. Historia yote ya mabadiliko inahamia naye.
- **Njia B — Kumpa nakala:** mpe `MediatorHamza-source-code.zip`; afungue repo mpya kwenye akaunti yake na apakie code hiyo.

Branch muhimu:
- branch ya kazi (source code) — hapa ndipo mabadiliko yanafanywa;
- `production` — toleo lililojengwa ambalo Hostinger inavuta ndani ya `public_html`.

### 3.2 Domain na Hosting (Hostinger)
- Domain: `mediatorhamza.com`.
- Hosting: Hostinger (hPanel). Ili kuhamisha: mpe mmiliki mpya ufikiaji wa akaunti, au omba Hostinger (live chat/support) ihamishe hosting na domain kwenda akaunti yake ya Hostinger. Majina ya menyu za hPanel hubadilika mara kwa mara — support ya Hostinger itaelekeza hatua za sasa.
- Baada ya kuhamisha GitHub, sasisha hPanel → **Advanced → Git** (repo mpya) na **deploy key / webhook** kama ilivyoelezwa kwenye `docs/DEPLOYMENT.md`.

### 3.3 Faili za siri zilizo kwenye server (hazipo kwenye source code)
Kwenye server, nje ya `public_html`, kuna folda:

```
domains/mediatorhamza.com/mediator_private/
├── .env       ← mipangilio ya siri: database, APP_KEY, SMS n.k.
└── storage/   ← faili walizopakia watumiaji (viambatisho, picha) + sessions + logs
```

- **`APP_KEY` ndani ya `.env` ni muhimu sana:** ndiyo inayofunga (encrypt) taarifa nyeti za maombi (mf. password za akaunti za HESLB, NIDA). Ikipotea, taarifa hizo hazitaweza kusomwa tena. Hifadhi nakala ya `.env` mahali salama.
- **Usiweke `.env` kwenye GitHub** kamwe.
- Ukihamisha hosting: hamisha folda nzima ya `mediator_private/` pamoja na database.

### 3.4 Database
hPanel → **Databases → phpMyAdmin** → chagua database ya Mediator → **Export** (SQL). Hii ndiyo nakala ya watumiaji wote, maombi, malipo, ujumbe na maudhui ya website. Fanya backup mara kwa mara.

### 3.5 Akaunti za Admin
- Admin Portal: `https://mediatorhamza.com/admin/login` (au chagua **Staff Account** kwenye ukurasa wa kuingia).
- Mmiliki mpya ahakikishe: anaingia, kisha **Password & Usalama → Badilisha nenosiri**, na awashe **2FA** (uthibitisho wa hatua mbili).
- Akaunti za wahudumu wengine: **Admin → Wahudumu** (ongeza, ondoa, badilisha ruhusa).

### 3.6 App ya Android
- APK inapatikana kwenye website: `https://mediatorhamza.com/downloads/MediatorHamza.apk` (kitufe cha **Download App**).
- Package name: `com.mediatorhamza.app`.
- Ufunguo wa kusaini (`MediatorHamza-ufunguo-wa-App-SIRI.zip`) — mpe mmiliki mpya **kwa usiri**. Bila ufunguo huo, toleo jipya la APK halitaweza kusasisha App iliyopo kwenye simu za watu.
- Alama ya ufunguo (SHA-256) iko kwenye `web/public/.well-known/assetlinks.json`; inahitajika ili App ifunguke bila mstari wa anwani.

## 4. Kuweka mfumo kwenye hosting mpya (kwa ufupi)

1. Unda database ya MySQL na mtumiaji wake.
2. Pakia yaliyomo kwenye `MediatorHamza-public_html.zip` ndani ya `public_html`.
3. Fungua `https://domain-yako/setup` → jaza taarifa za database → mfumo utaunda `mediator_private/.env`, majedwali (tables) na akaunti ya kwanza ya Super Admin.
   - Ukihamisha mfumo uliopo: badala ya setup, rejesha (import) database na nakili `mediator_private/` ya zamani (pamoja na `.env` yenye `APP_KEY` ile ile).
4. Kwa maelezo kamili (pamoja na auto-deploy kupitia Git) soma `docs/DEPLOYMENT.md`.

## 5. Kufanya mabadiliko baadaye

```bash
# Kwenye kompyuta ya msanidi (developer)
cd web && npm install && npm run build      # frontend
php api/tests/api_test.php                  # majaribio ya API
bash scripts/publish.sh                     # jenga na sukuma kwenye branch ya production → Hostinger
bash scripts/build-apk.sh                   # (tu kama App ya Android inahitaji kubadilishwa)
```

## 6. Orodha ya ukaguzi wa makabidhiano

- [ ] Source code imekabidhiwa (repo imehamishwa au ZIP imetolewa)
- [ ] Mmiliki mpya ana ufikiaji wa Hostinger (hosting + domain)
- [ ] Nakala ya `mediator_private/.env` (pamoja na `APP_KEY`) imehifadhiwa salama na mmiliki mpya
- [ ] Backup ya database (SQL export) imetolewa
- [ ] Password za Super Admin zimebadilishwa na mmiliki mpya, na 2FA imewashwa
- [ ] Ufunguo wa kusaini App ya Android umekabidhiwa kwa usiri
- [ ] Namba za mawasiliano (Admin → Mipangilio → Mawasiliano) ni za mmiliki mpya
