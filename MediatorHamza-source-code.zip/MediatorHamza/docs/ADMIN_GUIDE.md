# Mwongozo wa Admin (matumizi ya kila siku)

Ingia: `https://mediatorhamza.com/admin/login` (akaunti za wahudumu pekee).

## Kushughulikia ombi
1. **Maombi** → tafuta kwa jina, simu, namba ya ombi au chuja kwa huduma/status/tarehe.
2. Fungua ombi: utaona taarifa zote kwa hatua, picha/nyaraka (bonyeza kufungua), na historia.
3. **Badilisha status** → chagua status, andika ujumbe kwa mwombaji (anapata arifa), maelezo ya ndani (hayaonekani kwa mwombaji) na hatua inayofuata.
4. Ukihitaji marekebisho: chagua **Rekebisha Taarifa**, weka ujumbe na uchague sehemu tu zinazopaswa kurekebishwa. Mwombaji atarekebisha hizo tu na kutuma upya.
5. Ombi likikamilika: **Ongeza mrejesho** (mf. username/password za OLAMS, maelekezo) na/au **Pakia nyaraka**. Vinahifadhiwa kwa usimbaji na vinaonekana kwa mwombaji husika pekee.
6. **Weka malipo** baada ya kupokea pesa kwenye namba yako (Hujalipia → Umelipa stationery → Umelipa…).

## Mawasiliano
- **Chat na Watumiaji**: yasiyojibiwa yanaonekana kwanza. Jibu hapo — mtumiaji anapata arifa.
- **Arifa & Matangazo**: tuma kwa wote au kwa kundi (huduma/status/malipo). Kwa Bulk SMS, pakua namba kwenye **Ripoti & Export**.
- **Ujumbe wa Mawasiliano**: ujumbe kutoka fomu ya Contact kwenye website.

## Maudhui
- **Huduma & Bei**: badilisha bei (haibadilishi maombi yaliyokwisha tumwa), funga/fungua huduma, ongeza vifurushi.
- **Elimu, Vyuo, Guidebooks, Deadlines, Matangazo, FAQ, Magroup**: ongeza/hariri/ficha/futa.
  - Vyuo: hifadhi → bonyeza 🛡 kuthibitisha links → chapisha.
  - Guidebooks za miaka iliyopita: weka "Imepitwa na wakati".
  - Deadlines: reminder hutumwa kiotomatiki (cron) au bonyeza 🔔.
  - FAQ: weka "maneno muhimu" ili msaidizi (assistant) ajibu vizuri.
- **Mipangilio**: logo, favicon, jina, kaulimbiu, maandishi ya homepage, namba za mawasiliano, mitandao ya kijamii, Kuhusu Sisi, Sera ya Faragha, Masharti, orodha ya benki, viwango vya mkopo.

## Watumiaji na wahudumu
- **Watumiaji**: tafuta, ona maombi yao, rekebisha taarifa, sitisha/zima akaunti, tuma ujumbe.
- Mtumiaji amesahau nenosiri na SMS haijawashwa: thibitisha utambulisho wake (mf. kwa simu), kisha **Namba ya kurejesha akaunti** → mpe namba; ataitumia `mediatorhamza.com/reset-password`.
- **Wahudumu** (Super Admin pekee): ongeza wahudumu, badilisha wadhifa, zima akaunti.
- **Usalama Wangu**: washa 2FA (inapendekezwa sana kwa kila mhudumu) na badilisha nenosiri.

## Ripoti
**Ripoti & Export** → chagua vichujio na safu → pakua Excel, PDF au CSV. Taarifa nyeti (NIDA n.k.) hazitolewi kamwe.
