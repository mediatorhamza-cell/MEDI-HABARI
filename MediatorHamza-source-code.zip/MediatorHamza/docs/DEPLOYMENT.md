# Kuweka Mediator kwenye Hostinger (Deployment)

## Njia inayotumika: GitHub → Hostinger Git Auto-Deploy (bure)

Haitumii GitHub Actions (hivyo "spending limit" haiathiri). Inafanya kazi hivi:

```
Claude anafanya mabadiliko → anaendesha scripts/publish.sh
   → toleo lililojengwa linasukumwa (push) kwenye branch ya `production`
   → GitHub inatuma webhook kwa Hostinger
   → Hostinger inavuta (git pull) branch hiyo ndani ya public_html
   → wewe unarefresh tu na kuona mabadiliko
```

### Hatua za mara moja tu (dakika ~10)

**1. Safisha public_html**
hPanel → Websites → mediatorhamza.com → **File Manager** → `public_html` → futa kila kitu ndani yake (mf. `default.php`). Hostinger Git inahitaji folda iwe tupu. *(Hii ndiyo sababu ya "403 Forbidden" unayoiona sasa — hakuna website iliyowekwa bado.)*

**2. Unganisha Git**
hPanel → Websites → mediatorhamza.com → **Advanced → Git**:
- Repository: `git@github.com:mosh3ky-ai/Mediatorhamza.git`
- Branch: `production`
- Directory: *(acha wazi — maana yake public_html)*

Repository ni **private**, kwa hiyo Hostinger itakuonyesha **SSH key** kwenye ukurasa huo huo. Inakili, kisha GitHub → repo `Mediatorhamza` → **Settings → Deploy keys → Add deploy key** → bandika (paste) → Save (usiweke "write access"). Rudi hPanel bonyeza **Create**, kisha **Deploy**.

**3. Washa Auto-Deployment**
Kwenye ukurasa wa Git (hPanel) bonyeza **Auto Deployment** → nakili **Webhook URL**.
GitHub → repo → **Settings → Webhooks → Add webhook**:
- Payload URL: *(bandika webhook URL)*
- Content type: `application/json`
- Events: *Just the push event* → **Add webhook**

Webhooks za GitHub ni bure kabisa.

**4. Database**
hPanel → **Databases → MySQL Databases** → unda database, user na nenosiri (andika taarifa hizi).

**5. Setup ya kwanza (kwenye kivinjari, hakuna SSH)**
Fungua `https://mediatorhamza.com` → utaona **"Sanidi Mediator"** → weka jina la DB, user na nenosiri → **Unganisha**.
Mfumo utatengeneza `APP_KEY`, kuandika `.env` kwa usalama **nje ya public_html** (`domains/mediatorhamza.com/mediator_private/.env`), kutengeneza tables zote na maudhui ya mwanzo.
Kisha utapelekwa ukurasa wa **Install** → weka jina, namba ya simu na nenosiri (herufi 12+) → Super Admin anaundwa → ingia `https://mediatorhamza.com/admin/login`.

> Setup inafanya kazi mara moja tu, na inakubali tu taarifa sahihi za database — hivyo mtu mwingine hawezi kuitumia.

**6. PHP version**: hPanel → Advanced → PHP Configuration → **PHP 8.2 au 8.3**.

### Baada ya hapo
- Kila mabadiliko unayoniomba: nayajenga, nayajaribu, na kuyachapisha kwenye `production` — Hostinger inayavuta yenyewe ndani ya sekunde chache. **Wewe unarefresh tu.**
- Migration mpya za database zinajiendesha zenyewe baada ya kila deploy.
- Faili za waombaji na `.env` hazijaguswa na deploy (ziko `mediator_private/`).

## Coming Soon
Website inaanza ikiwa kwenye **Coming Soon**: wageni wanaona ukurasa wa "Tunakuja Hivi Karibuni", wewe (admin uliyeingia) unaona mfumo kamili pamoja na ukanda wa njano wa onyo.
Kuifungua kwa wote: **Admin → Dashibodi → "Fungua website kwa wote"** (au Mipangilio → Brand). Unaweza kuirudisha Coming Soon wakati wowote na kuhariri ujumbe wake.

## Cron Jobs (hiari lakini zinapendekezwa) — hPanel → Advanced → Cron Jobs
| Ratiba | Command |
|---|---|
| Kila saa | `php /home/uXXXX/domains/mediatorhamza.com/public_html/api/bin/cron.php` |
| Kila siku | `php /home/uXXXX/domains/mediatorhamza.com/public_html/api/bin/backup.php` |

(`uXXXX` ni namba ya akaunti yako inayoonekana kwenye File Manager.)

## SMS (hiari)
Ongeza kwenye `mediator_private/.env` (File Manager):
```
SMS_DRIVER=beem            # au africastalking
SMS_API_KEY=...
SMS_SECRET_KEY=...         # Beem
SMS_USERNAME=...           # Africa's Talking
SMS_SENDER_ID=MEDIATOR
SMS_NOTIFY_STATUS=true
```

## Kuhakiki
- `https://mediatorhamza.com/api/health` → `{"ok":true,...}`
- `https://mediatorhamza.com/api/.env.example` → lazima iwe 403

## Njia mbadala (bila Git): `bash scripts/build-deploy.sh` kisha pakia `deploy/` kwa File Manager.
