# System Architecture

## Overview

```
Browser / installed PWA (React SPA)
        │  same origin: https://mediatorhamza.com
        ├── /            static files (index.html, assets, sw.js)      ← public_html/
        └── /api/*       PHP front controller (api/index.php)          ← public_html/api/
                              │
                              ├── MySQL/MariaDB (all data)
                              └── storage/ (uploads, sessions, logs, backups) ← mediator_private/ outside public_html
```

**Why this design:** Hostinger shared hosting serves static files and PHP with MySQL; it does not run Node servers reliably. The React app is built once (`npm run build`) and served as static files; all business logic, authorization and validation live in the PHP API. The API has **no Composer dependencies**, so deployment is a file upload.

## Backend (`api/`)

| Path | Purpose |
|---|---|
| `index.php` | Front controller: security headers, session start, CSRF check, routing, error handling |
| `src/routes.php` | All routes, grouped: public, auth, `/me`, `/applications`, `/admin` |
| `src/Core/*` | Env, DB (PDO), Router, Request/Response, Auth (sessions, roles, permissions, CSRF), RateLimiter (MySQL), Crypto (libsodium), FormSchema (server-side validation), Reference numbers, Uploads, Export (CSV/XLSX/PDF), Sms, Notifier, Audit, Totp |
| `src/Controllers/*` | Public, Auth, Profile, Applications, Messages, Notifications, Assistant, `Admin/*` |
| `forms/*.json` | **One schema per service** (HESLB, college, birth, death, NaPA, verification) — fields, steps, conditions, validation, document requirements |
| `data/tz_regions.json` | 31 regions & districts (editable without code) |
| `database/migrations/*.sql` | Schema, applied by `bin/migrate.php` |
| `bin/*` | CLI: migrate, seed, create-admin, generate-key, backup, restore, cron |

### Authentication & authorization
- PHP sessions in an HttpOnly, SameSite=Lax cookie (`Secure` on HTTPS); `session_regenerate_id` on login (anti-fixation); idle timeout (4 h users, 1 h staff).
- CSRF token (per session) required in `X-CSRF-Token` for every non-GET request.
- Passwords: `password_hash`/`password_verify` (bcrypt/argon per PHP default), rehash on login.
- **Separate portals**: `/api/auth/login` rejects staff; `/api/admin/auth/login` rejects users. Optional TOTP 2FA for staff.
- Roles: `super_admin`, `admin`, `support`, `readonly`, `user`. Permissions are resolved on the server from the DB role on every request (`Auth::PERMISSIONS`); the frontend only hides buttons.
- Ownership: every user query is scoped by `user_id` in SQL (`Applications::findOwned`, conversation queries…). Files are served only through authorized endpoints.
- `session_version` column: bumping it (password change/reset, suspension, role change) logs out all other sessions.
- Rate limits on login (per IP + per phone), registration, OTP, reset, uploads, submissions, chat, contact form, search, assistant.
- Password recovery: SMS OTP (configurable gateway) **or** admin-issued one-time code (staff never see passwords). Responses never reveal whether a phone is registered.

### Applications
- Draft → autosave (`PUT /applications/{id}`) → submit (`POST …/submit`, row-locked & idempotent).
- Reference `MED-YYYY-CODE-NNNNNN` from `reference_sequences` with `SELECT … FOR UPDATE` (collision-safe).
- Price & package name **snapshotted** at submission.
- Sensitive fields (`"sensitive": true` in the schema: NIDA numbers and verification answers, voter ID) are stored **encrypted** (AES-256-GCM via OpenSSL, `APP_KEY`) in `applications.sensitive_data`; never exported, never put in notifications/logs; only visible to the owner and staff with `applications.sensitive`.
- Results/feedback (may contain portal usernames/passwords) are encrypted too.
- Status history records from/to, public message, internal note, next action, staff member, time. Internal notes are stripped from user responses.
- Corrections: admin selects specific fields (or all); server only accepts changes to those fields; changes are logged in `application_changes`.

### Data model (main tables)
`users, login_events, otp_codes, rate_limits, settings, media, services, service_packages, reference_sequences, applications, application_status_history, application_files, application_changes, application_results, payment_records, notifications, notification_batches, conversations, messages, categories, articles, institutions, guidebooks, deadlines, announcements, faqs, whatsapp_groups, contact_messages, audit_logs, visitor_days`

### Analytics
`visitor_days` stores one row per (day, SHA-256 of salt+day+IP+UA). No raw IP, no cookies → counts unique daily visitors privately.

## Frontend (`web/`)

- React Router SPA: public routes (`/`, `/huduma`, `/elimu`, `/vyuo`, `/miongozo`, `/deadlines`, `/matangazo`, `/faq`, `/kuhusu`, `/mawasiliano`, `/faragha`, `/masharti`, `/tafuta`, auth pages), user app under `/app/*`, admin under `/admin/*` (code-split).
- `src/i18n/{sw,en,admin}.ts` — full Swahili/English dictionaries; TypeScript enforces that every key exists in both languages. Preference stored locally and on the user profile.
- `src/styles/tokens.css` — design tokens (brand colours from the brief).
- `components/form/*` — one generic, schema-driven multi-step renderer (progress, stepper, conditional fields, validation mirroring the server, autosave, uploads with progress, repeaters, review & confirm, success screen). The **fields per service come from each service's own schema**.
- PWA: `public/manifest.webmanifest`, `public/sw.js` (app-shell caching; API responses never cached), install prompt (Android) and iOS instructions, browser notifications while the app is open.

## Optional AI assistant
`/api/assistant` is a rule-based helper that only answers from admin-published FAQs, services/prices and deadlines, always shows a disclaimer and hands off to admin chat. It never claims to verify applications or payments. An LLM could be plugged in later behind the same endpoint.
