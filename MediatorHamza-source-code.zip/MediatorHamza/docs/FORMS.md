# Service forms

Each service has its **own** JSON schema in `api/forms/`:

| Service code | Schema | Steps |
|---|---|---|
| HESLB | `heslb.json` | Personal info (index numbers, AVN details, NIDA, level, photo) · NIDA verification · Birth (RITA code, NaPA) · Permanent residence · Parents' status (disability/DRN, guardian, TASAF) · Mother · Father · Guardian (only if any) · Disability · Education (sponsorship, first-year/continuing) · Guarantor (incl. NIDA answers, photo) · Bank |
| VYUO | `college.json` | Personal · Education history · Next of kin · Institutions & programmes (repeatable) |
| BIRTH | `birth_certificate.json` | Child · Father · Mother · 2-of-6 supporting documents + uploads · Collection office · NaPA phones |
| DEATH | `death_certificate.json` | Deceased (birth & last residence) · Death details · Informant · Collection office · NaPA phones |
| NAPA | `napa.json` | Applicant + phone numbers registered with the Executive Officer |
| VERIFY | `certificate_verification.json` | Certificate details + copy upload |

The **same file** is used by the server (`api/src/Core/FormSchema.php`, authoritative validation) and by the React form renderer, so the rules cannot drift apart.

## Field options
`key, type, label{sw,en}, help, placeholder, required, requiredIf, showIf, pattern, uppercase, minWords, minLength, maxLength, options[], optionsSource (banks|heslb_levels), regionField, sensitive, accept (image|document|image_or_document), minFiles, maxFiles, min/max (date "today"), after, minSelected/maxSelected, fields[] + minItems/maxItems (repeater), width (half)`

Types: `text textarea email tel date number year select radio yesno region district file checkboxes repeater heading`.

Conditions (`showIf`/`requiredIf`, also on whole steps): `{"field":"x","equals":"yes"}`, `{"field":"x","in":[...]}`, `{"field":"x","filled":true}`, `{"all":[...]}`, `{"any":[...]}`.

`"sensitive": true` → stored encrypted, excluded from exports, hidden from staff without `applications.sensitive`.

## Changing a form
1. Edit the JSON (keep keys unique). Removing a key keeps old answers in past applications but stops collecting it.
2. Bump `"version"` — it is stored on each submitted application.
3. Deploy the `api/forms/` folder; no frontend rebuild is needed.

Bank names and allowed HESLB levels are editable in **Admin → Mipangilio → Chaguo za fomu**; regions/districts in `api/data/tz_regions.json` (verify against the official TAMISEMI list).

## Notes on interpretation
- The master prompt's HESLB section was truncated at "Section G"; the remaining HESLB fields follow the owner's chat message (secondary sponsorship, applicant type, guarantor, bank).
- RITA code / NaPA / DRN / TASAF patterns are deliberately permissive (examples: `202608043191-BV`, `8707Q50302`); tighten them once official formats are confirmed.
- Birth certificate adds "gender" (required by RITA) in addition to the flyer's fields.
- Certificate verification had no field list in the inputs; a minimal form was designed — adjust as needed.
