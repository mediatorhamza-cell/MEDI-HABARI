# Development Plan & Progress

| Phase | Scope | Status |
|---|---|---|
| 0. Audit | Inspect repo, read brief/PDF/image/message, verify tooling, choose architecture | ✅ Done (`PROJECT_AUDIT.md`, `SYSTEM_ARCHITECTURE.md`) |
| 1. Backend core | Env/DB/router, sessions, CSRF, roles & permissions, rate limiting, encryption, uploads, audit log | ✅ Done |
| 2. Schema | MySQL migration (30 tables), seeding (settings, 6 services, categories, FAQs, starter articles, institutions) | ✅ Done |
| 3. Service forms | 6 dedicated JSON schemas + server validation engine | ✅ Done |
| 4. Application workflow | Drafts, autosave, uploads, submission (idempotent, references, price snapshot), statuses + history, corrections, results, payments | ✅ Done |
| 5. Communication | Chat with admin, notifications (single/group/all), deadline reminders (cron), contact form, rule-based assistant | ✅ Done |
| 6. Admin portal API | Dashboard stats, application mgmt & search, users, staff, services/prices/packages, generic content CRUD, link verification, exports XLSX/PDF/CSV, settings, audit, 2FA | ✅ Done |
| 7. Frontend | Design system, i18n SW/EN, public site (19 pages), auth, user app (dashboard, forms wizard, tracking, chat, notifications, groups, profile, help), admin portal | ✅ Done |
| 8. PWA | Manifest, icons, service worker, offline page, install prompt, browser notifications | ✅ Done |
| 9. QA | 82-check API test, TypeScript strict build, Playwright mobile/desktop smoke test, screenshots reviewed | ✅ Done |
| 10. Deployment prep | `scripts/build-deploy.sh`, `.htaccess`, `.user.ini`, CLI installer + web installer, backup/restore, cron, docs | ✅ Done |

## Next steps (need the owner)
1. Deploy to Hostinger following `DEPLOYMENT.md`; confirm PHP/MySQL versions there.
2. Set real prices, upload logo, review privacy policy/terms drafts, verify & publish institutions, add guidebooks/deadlines.
3. Open an SMS gateway account (Beem / Africa's Talking) and add credentials.
4. Verify regions/districts list and identifier formats (RITA, NaPA, DRN, TASAF) against official sources.

## Possible future work
- Web Push (VAPID) notifications when the app is closed (currently notifications show while the app/tab is open + optional SMS).
- Mobile-money payment API integration (currently admin records payments manually, as requested).
- LLM-backed assistant behind the existing `/api/assistant` endpoint.
- Rich-text editor for articles (currently plain text with line breaks).
