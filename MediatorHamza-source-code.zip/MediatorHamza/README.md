# Mediator Hamza

**Safari yako ya elimu inaanza hapa.** — Student services & application management platform for Tanzania (https://mediatorhamza.com).

Mfumo kamili wa kuomba na kufuatilia huduma: mikopo ya HESLB, maombi ya vyuo, vyeti vya kuzaliwa na vifo, NaPA na uhakiki wa vyeti — pamoja na website ya umma, dashibodi ya mtumiaji, admin portal na app ya kuinstall kwenye simu (PWA).

| Part | Tech | Folder |
|---|---|---|
| Frontend (public site, user app, admin portal, PWA) | React 18 + Vite + TypeScript | `web/` |
| Backend API | PHP 8.1+ (no framework, no Composer deps) | `api/` |
| Database | MySQL 5.7+/8 or MariaDB 10.3+ | `api/database/migrations` |

Designed for **Hostinger shared hosting**: static files + PHP + MySQL only. No Node.js, Firebase or Supabase needed in production.

## Quick start (local development)

```bash
# 1. Database (MySQL/MariaDB running locally)
mysql -e "CREATE DATABASE mediator CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"

# 2. API config
cp api/.env.example api/.env
php api/bin/generate-key.php          # paste output into APP_KEY
#   set DB_*; APP_ENV=development; SESSION_SECURE=false

# 3. Schema + starter content + first Super Admin
php api/bin/migrate.php
php api/bin/seed.php
php api/bin/create-admin.php --phone=07XXXXXXXX --first=Hamza --second=Msaji

# 4. Run
php -S 127.0.0.1:8000 api/tests/dev-router.php      # API on :8000
cd web && npm install && npm run dev                # site on http://127.0.0.1:5173 (proxies /api)
```

- Public site: `/` · User app: `/app` · Admin portal: `/admin/login`

## Tests

```bash
php api/tests/api_test.php                       # 82 end-to-end API checks (needs the API server running)
cd web && npm run typecheck && npm run build     # TypeScript + production build
ADMIN_PHONE=07.. ADMIN_PASSWORD=.. node web/e2e/smoke.mjs   # Playwright browser smoke test (both servers running)
```

## Deploy to Hostinger

`bash scripts/build-deploy.sh` → upload `deploy/` — full steps in **[docs/DEPLOYMENT.md](docs/DEPLOYMENT.md)**.

## Documentation

- [docs/PROJECT_AUDIT.md](docs/PROJECT_AUDIT.md) — initial state of the repository
- [docs/SYSTEM_ARCHITECTURE.md](docs/SYSTEM_ARCHITECTURE.md) — architecture, data model, security design
- [docs/DEVELOPMENT_PLAN.md](docs/DEVELOPMENT_PLAN.md) — phases and progress
- [docs/REQUIREMENTS_CHECKLIST.md](docs/REQUIREMENTS_CHECKLIST.md) — requirement-by-requirement status
- [docs/DEPLOYMENT.md](docs/DEPLOYMENT.md) — Hostinger deployment, cron jobs, backups (Kiswahili)
- [docs/ADMIN_GUIDE.md](docs/ADMIN_GUIDE.md) — how to run the system day-to-day (Kiswahili)
- [docs/FORMS.md](docs/FORMS.md) — how the service-specific forms work and how to change them
