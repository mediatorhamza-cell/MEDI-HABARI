export type Lang = 'sw' | 'en';
export type Bilingual = { sw: string; en: string };

export interface User {
  id: number;
  first_name: string;
  second_name: string;
  last_name: string | null;
  phone: string;
  email: string | null;
  role: 'user' | 'support' | 'readonly' | 'admin' | 'super_admin';
  language: Lang;
  is_staff: boolean;
  permissions: string[];
  totp_enabled: boolean;
  phone_verified: boolean;
  created_at: string;
}

export interface Package {
  id: number;
  name_sw: string;
  name_en: string | null;
  price: number;
}

export interface Service {
  id: number;
  code: string;
  slug: string;
  form_key: string;
  icon: string;
  name_sw: string;
  name_en: string | null;
  summary_sw: string | null;
  summary_en: string | null;
  price: number | null;
  price_note_sw: string | null;
  price_note_en: string | null;
  accepting: boolean;
  packages: Package[];
}

export interface SiteSettings {
  brand_name: string | null;
  tagline: string | null;
  tagline_en: string | null;
  description_sw: string | null;
  description_en: string | null;
  logo_file_id: number | null;
  favicon_file_id: number | null;
  contact_phone: string | null;
  contact_whatsapp: string | null;
  contact_sms: string | null;
  contact_email: string | null;
  working_hours_sw: string | null;
  working_hours_en: string | null;
  address: string | null;
  social_facebook: string | null;
  social_instagram: string | null;
  social_tiktok: string | null;
  social_linkedin: string | null;
  social_youtube: string | null;
  social_x: string | null;
  hero_title_sw: string | null;
  hero_title_en: string | null;
  hero_text_sw: string | null;
  hero_text_en: string | null;
  welcome_note_sw: string | null;
  welcome_note_en: string | null;
  about_sw: string | null;
  about_en: string | null;
  privacy_sw: string | null;
  privacy_en: string | null;
  terms_sw: string | null;
  terms_en: string | null;
  default_language: Lang | null;
  payment_instructions_sw: string | null;
  payment_instructions_en: string | null;
  dashboard_welcome_sw: string | null;
  dashboard_welcome_en: string | null;
  banks: Option[] | null;
  heslb_levels: Option[] | null;
  site_live: boolean | null;
  coming_soon_sw: string | null;
  coming_soon_en: string | null;
}

export interface Option {
  value: string;
  label: Bilingual;
}

export type AppStatus =
  | 'draft'
  | 'received'
  | 'in_progress'
  | 'awaiting_info'
  | 'correction_required'
  | 'completed'
  | 'on_hold'
  | 'closed'
  | 'cancelled';
export type PaymentStatus = 'unpaid' | 'stationery_paid' | 'partial' | 'paid' | 'waived';

export interface AppSummary {
  id: number;
  reference: string | null;
  service_code: string;
  service_slug: string | null;
  service_name_sw: string;
  service_name_en: string | null;
  service_icon: string | null;
  status: AppStatus;
  payment_status: PaymentStatus;
  price: number | null;
  package_name: string | null;
  applicant_name: string | null;
  applicant_phone: string | null;
  editable: boolean;
  submitted_at: string | null;
  updated_at: string;
  created_at: string;
  user_name?: string;
  user_phone?: string;
  /** Admin list: submitted but not yet opened by staff. */
  is_new?: boolean;
  /** Admin drafts list: how far the applicant got. */
  progress?: { percent: number; stopped_at: Bilingual | null } | null;
}

export interface AppFile {
  id: number;
  field_key: string;
  name: string;
  mime: string;
  size: number;
  created_at: string;
}

export interface TimelineItem {
  id: number;
  from_status: string | null;
  to_status: AppStatus;
  public_message: string | null;
  next_action: string | null;
  internal_note?: string | null;
  changed_by?: string | null;
  created_at: string;
}

export interface AppResult {
  id: number;
  title: string;
  body: string;
  created_at: string;
}

export type FormData_ = Record<string, unknown>;

export interface AppDetail extends AppSummary {
  form_key: string;
  data: FormData_;
  files: AppFile[];
  result_files: AppFile[];
  timeline: TimelineItem[];
  results: AppResult[];
  editable_fields: string[] | null;
  correction_message: string | null;
  next_action: string | null;
  package_id: number | null;
  packages: Package[];
  current_price: number | null;
}

// -------- form schema
export type Condition =
  | { field: string; equals?: string; notEquals?: string; in?: string[]; filled?: boolean; includes?: string }
  | { all: Condition[] }
  | { any: Condition[] };

export interface FieldDef {
  key: string;
  type:
    | 'text'
    | 'textarea'
    | 'email'
    | 'tel'
    | 'date'
    | 'number'
    | 'year'
    | 'select'
    | 'radio'
    | 'yesno'
    | 'region'
    | 'district'
    | 'file'
    | 'checkboxes'
    | 'repeater'
    | 'heading';
  label: Bilingual;
  help?: Bilingual;
  placeholder?: string;
  required?: boolean;
  requiredIf?: Condition;
  showIf?: Condition;
  pattern?: string;
  minLength?: number;
  maxLength?: number;
  minWords?: number;
  uppercase?: boolean;
  options?: Option[];
  optionsSource?: 'banks' | 'heslb_levels';
  regionField?: string;
  sensitive?: boolean;
  accept?: 'image' | 'document' | 'image_or_document';
  minFiles?: number;
  maxFiles?: number;
  min?: string | number;
  max?: string | number;
  maxOffset?: number;
  after?: string;
  /** Date must be strictly earlier than this other date field (e.g. a parent born before the child). */
  before?: string;
  /** Input mask: 9 = digit, A = letter, anything else is a literal inserted automatically. */
  mask?: string;
  /** When this choice changes, copy other fields' values: { optionValue: { targetKey: sourceKey } }. */
  prefill?: Record<string, Record<string, string>>;
  minSelected?: number;
  maxSelected?: number;
  fields?: FieldDef[];
  minItems?: number;
  maxItems?: number;
  addLabel?: Bilingual;
  width?: 'half' | 'full';
  inputMode?: string;
  suggest?: 'institutions';
}

export interface StepDef {
  key: string;
  title: Bilingual;
  description?: Bilingual;
  showIf?: Condition;
  fields: FieldDef[];
}

export interface FormSchemaDef {
  key: string;
  service: string;
  version: number;
  title: Bilingual;
  intro?: Bilingual;
  steps: StepDef[];
}

export interface Region {
  name: string;
  districts: string[];
}

export interface Paged<T> {
  items: T[];
  total: number;
  page: number;
  per_page: number;
}

export interface NotificationItem {
  id: number;
  type: string;
  title_sw: string;
  title_en: string | null;
  body_sw: string;
  body_en: string | null;
  link: string | null;
  read: boolean;
  created_at: string;
}

export interface Conversation {
  id: number;
  subject: string;
  status: 'open' | 'closed';
  application_id: number | null;
  application_reference: string | null;
  awaiting_reply: boolean;
  last_message_at: string;
  last_message: string | null;
  unread: number;
  user_name: string | null;
  user_phone: string | null;
  user_id: number;
  created_at: string;
}

export interface Message {
  id: number;
  body: string;
  from_staff: boolean;
  sender_name: string;
  read: boolean;
  created_at: string;
}

export interface Deadline {
  id: number;
  service_id: number | null;
  service_sw: string | null;
  service_en: string | null;
  service_code: string | null;
  title_sw: string;
  title_en: string | null;
  description_sw: string | null;
  description_en: string | null;
  opens_at: string | null;
  closes_at: string;
  days_left: number;
}

export interface Announcement {
  id: number;
  title_sw: string;
  title_en: string | null;
  body_sw: string | null;
  body_en: string | null;
  is_pinned: boolean;
  published_at: string;
}

export interface ArticleSummary {
  id: number;
  slug: string;
  title_sw: string;
  title_en: string | null;
  summary_sw: string | null;
  summary_en: string | null;
  image_id: number | null;
  attachment_id: number | null;
  category_sw: string | null;
  category_en: string | null;
  category_slug: string | null;
  published_at: string;
}

export interface Institution {
  id: number;
  name: string;
  short_name: string | null;
  category_id: number | null;
  type_sw: string | null;
  type_en: string | null;
  ownership: 'public' | 'private' | 'other' | null;
  region: string | null;
  location: string | null;
  logo_id: number | null;
  website_url: string | null;
  apply_url: string | null;
  login_url: string | null;
  description_sw: string | null;
  description_en: string | null;
  links_verified_at: string | null;
  is_featured: boolean;
}

export interface Guidebook {
  id: number;
  title_sw: string;
  title_en: string | null;
  category_sw: string | null;
  category_en: string | null;
  category_id: number | null;
  academic_year: string | null;
  description_sw: string | null;
  description_en: string | null;
  file_id: number | null;
  external_url: string | null;
  is_outdated: boolean;
  created_at: string;
}

export interface Testimonial {
  id: number;
  name: string;
  role_sw: string | null;
  role_en: string | null;
  location: string | null;
  body_sw: string;
  body_en: string | null;
  rating: number;
  year: number;
  photo_id: number | null;
}

export interface Faq {
  id: number;
  question_sw: string;
  question_en: string | null;
  answer_sw: string;
  answer_en: string | null;
  category_sw: string | null;
  category_en: string | null;
}

export interface Category {
  id: number;
  scope: string;
  slug: string;
  name_sw: string;
  name_en: string | null;
}
