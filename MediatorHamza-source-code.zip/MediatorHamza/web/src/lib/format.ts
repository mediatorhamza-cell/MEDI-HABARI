import type { Lang } from './types';

const MONTHS_SW = ['Jan', 'Feb', 'Mac', 'Apr', 'Mei', 'Jun', 'Jul', 'Ago', 'Sep', 'Okt', 'Nov', 'Des'];
const MONTHS_EN = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

/** Parse "YYYY-MM-DD HH:MM:SS" (server, East Africa Time) safely across browsers. */
export function parseDate(s: string | null | undefined): Date | null {
  if (!s) return null;
  const m = /^(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{2}):(\d{2})(?::(\d{2}))?)?/.exec(s);
  if (!m) return null;
  return new Date(+m[1], +m[2] - 1, +m[3], +(m[4] ?? 0), +(m[5] ?? 0), +(m[6] ?? 0));
}

export function fmtDate(s: string | null | undefined, lang: Lang = 'sw'): string {
  const d = parseDate(s);
  if (!d) return '—';
  const months = lang === 'en' ? MONTHS_EN : MONTHS_SW;
  return `${d.getDate()} ${months[d.getMonth()]} ${d.getFullYear()}`;
}

export function fmtDateTime(s: string | null | undefined, lang: Lang = 'sw'): string {
  const d = parseDate(s);
  if (!d) return '—';
  return `${fmtDate(s, lang)}, ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
}

export function fmtRelative(s: string | null | undefined, lang: Lang = 'sw'): string {
  const d = parseDate(s);
  if (!d) return '—';
  const diff = (Date.now() - d.getTime()) / 1000;
  if (diff < 60) return lang === 'en' ? 'just now' : 'sasa hivi';
  if (diff < 3600) {
    const m = Math.floor(diff / 60);
    return lang === 'en' ? `${m} min ago` : `dakika ${m} zilizopita`;
  }
  if (diff < 86400) {
    const h = Math.floor(diff / 3600);
    return lang === 'en' ? `${h} h ago` : `saa ${h} zilizopita`;
  }
  if (diff < 86400 * 7) {
    const dd = Math.floor(diff / 86400);
    return lang === 'en' ? `${dd} day${dd > 1 ? 's' : ''} ago` : `siku ${dd} zilizopita`;
  }
  return fmtDate(s, lang);
}

export function fmtMoney(n: number | null | undefined): string {
  if (n === null || n === undefined) return '—';
  return `TZS ${n.toLocaleString('en-US')}`;
}

export function fmtPhone(p: string | null | undefined): string {
  if (!p) return '—';
  if (p.startsWith('+255') && p.length === 13) return `0${p.slice(4, 7)} ${p.slice(7, 10)} ${p.slice(10)}`;
  return p;
}

export function fmtSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
}

export function initials(first?: string | null, second?: string | null): string {
  return `${(first ?? '').charAt(0)}${(second ?? '').charAt(0)}`.toUpperCase() || 'M';
}

/** Normalise a Tanzanian mobile number to +255XXXXXXXXX (mirrors api/src/Core/Phone.php). */
export function normalizePhone(input: string): string | null {
  const digits = input.replace(/\D+/g, '');
  let local: string;
  if (digits.startsWith('255') && digits.length === 12) local = digits.slice(3);
  else if (digits.startsWith('0') && digits.length === 10) local = digits.slice(1);
  else if (digits.length === 9) local = digits;
  else return null;
  return /^[67]\d{8}$/.test(local) ? `+255${local}` : null;
}

export function waLink(phone: string | null | undefined, text = ''): string {
  const n = (phone ?? '').replace(/\D/g, '');
  return `https://wa.me/${n}${text ? `?text=${encodeURIComponent(text)}` : ''}`;
}

export function daysLeft(dateStr: string): number {
  const d = parseDate(dateStr);
  if (!d) return 0;
  d.setHours(23, 59, 59);
  return Math.floor((d.getTime() - Date.now()) / 86400000);
}
