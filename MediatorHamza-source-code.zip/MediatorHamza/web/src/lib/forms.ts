// Client-side mirror of api/src/Core/FormSchema.php (server remains authoritative).
import type { Condition, FieldDef, FormSchemaDef, Option, Region, StepDef } from './types';
import { normalizePhone } from './format';

export type Values = Record<string, unknown>;
export type Errors = Record<string, string>;

export function isEmpty(v: unknown): boolean {
  return v === undefined || v === null || v === '' || (Array.isArray(v) && v.length === 0);
}

export function conditionMet(cond: Condition | undefined, data: Values): boolean {
  if (!cond) return true;
  if ('all' in cond) return cond.all.every((c) => conditionMet(c, data));
  if ('any' in cond) return cond.any.some((c) => conditionMet(c, data));
  const v = data[cond.field];
  if (cond.equals !== undefined) return String(v ?? '') === String(cond.equals);
  if (cond.notEquals !== undefined) return String(v ?? '') !== String(cond.notEquals);
  if (cond.in) return cond.in.map(String).includes(String(v ?? ''));
  if (cond.filled !== undefined) return cond.filled ? !isEmpty(v) : isEmpty(v);
  if (cond.includes !== undefined) return Array.isArray(v) && v.map(String).includes(cond.includes);
  return true;
}

/** Apply an input mask: 9 = digit, A = letter, other characters are literals that are inserted automatically. */
export function applyMask(mask: string, input: string): string {
  const chars = input.toUpperCase().replace(/[^A-Z0-9]/g, '');
  let out = '';
  let i = 0;
  for (const m of mask) {
    if (m === '9' || m === 'A') {
      // Skip characters that do not fit this slot (e.g. letters typed where a digit belongs).
      while (i < chars.length && !(m === '9' ? /[0-9]/ : /[A-Z]/).test(chars[i])) i++;
      if (i >= chars.length) break;
      out += chars[i++];
    } else {
      if (i >= chars.length) break;
      out += m;
      if (chars[i] === m) i++;
    }
  }
  return out;
}

export function visibleSteps(schema: FormSchemaDef, data: Values): StepDef[] {
  return schema.steps.filter((s) => conditionMet(s.showIf, data));
}

export function visibleFields(step: StepDef, data: Values): FieldDef[] {
  return step.fields.filter((f) => conditionMet(f.showIf, data));
}

export function isRequired(f: FieldDef, data: Values): boolean {
  return !!f.required || (!!f.requiredIf && conditionMet(f.requiredIf, data));
}

export function optionsFor(f: FieldDef, ctx: { banks: Option[]; heslb_levels: Option[] }): Option[] {
  if (f.optionsSource) return ctx[f.optionsSource] ?? [];
  return f.options ?? [];
}

const todayStr = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};

export function validateField(
  f: FieldDef,
  value: unknown,
  data: Values,
  ctx: { banks: Option[]; heslb_levels: Option[]; regions: Region[] },
): string | null {
  if (f.type === 'heading') return null;
  const required = isRequired(f, data);
  if (isEmpty(value)) return required ? 'required' : null;

  if (typeof value === 'string') {
    const v = f.uppercase ? value.toUpperCase().trim() : value.trim();
    if (f.minLength && v.length < f.minLength) return 'too_short';
    if (f.minWords && v.split(/\s+/).filter(Boolean).length < f.minWords) return 'min_words';
    if (f.mask && v.length !== f.mask.length) return 'pattern';
    if (f.pattern && f.type !== 'tel' && !new RegExp(`^(?:${f.pattern})$`, 'u').test(v.replace(/\s+/g, ' '))) return 'pattern';
  }
  switch (f.type) {
    case 'email':
      return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(String(value).trim()) ? null : 'email';
    case 'tel':
      return normalizePhone(String(value)) ? null : 'phone';
    case 'date': {
      const s = String(value);
      if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) return 'date';
      const dt = new Date(`${s}T00:00:00`);
      if (Number.isNaN(dt.getTime()) || dt.getDate() !== +s.slice(8, 10)) return 'date';
      if (f.max === 'today' && s > todayStr()) return 'date_future';
      if (f.after && typeof data[f.after] === 'string' && data[f.after] && s < String(data[f.after])) return 'date_order';
      if (f.before && typeof data[f.before] === 'string' && data[f.before] && s >= String(data[f.before])) return 'date_before';
      return null;
    }
    case 'year': {
      const s = String(value);
      if (!/^\d{4}$/.test(s)) return 'year';
      const y = +s;
      const max = new Date().getFullYear() + (f.maxOffset ?? 0);
      return y < Number(f.min ?? 1940) || y > max ? 'year' : null;
    }
    case 'number':
      return /^\d+$/.test(String(value)) ? null : 'number';
    case 'select':
    case 'radio':
      return optionsFor(f, ctx).some((o) => o.value === value) ? null : 'invalid_option';
    case 'yesno':
      return value === 'yes' || value === 'no' ? null : 'invalid_option';
    case 'region':
      return ctx.regions.some((r) => r.name === value) ? null : 'invalid_option';
    case 'district': {
      const region = ctx.regions.find((r) => r.name === data[f.regionField ?? '']);
      return region?.districts.includes(String(value)) ? null : 'invalid_option';
    }
    case 'checkboxes': {
      const arr = value as string[];
      if (f.minSelected && arr.length < f.minSelected) return 'min_selected';
      if (f.maxSelected && arr.length > f.maxSelected) return 'max_selected';
      return null;
    }
    case 'file': {
      const arr = value as number[];
      if (arr.length < (f.minFiles ?? 1)) return 'min_files';
      if (arr.length > (f.maxFiles ?? 1)) return 'max_files';
      return null;
    }
    case 'repeater': {
      const rows = value as Values[];
      if (rows.length < (f.minItems ?? 1)) return 'min_items';
      if (rows.length > (f.maxItems ?? 10)) return 'max_items';
      for (const row of rows) {
        for (const sub of f.fields ?? []) {
          const e = validateField(sub, row[sub.key], row, ctx);
          if (e) return e === 'required' ? 'items_incomplete' : 'items_invalid';
        }
      }
      return null;
    }
  }
  return null;
}

export function validateStep(
  step: StepDef,
  data: Values,
  ctx: { banks: Option[]; heslb_levels: Option[]; regions: Region[] },
  only?: string[] | null,
): Errors {
  const errors: Errors = {};
  for (const f of visibleFields(step, data)) {
    if (only && !only.includes('*') && !only.includes(f.key)) continue;
    const e = validateField(f, data[f.key], data, ctx);
    if (e) errors[f.key] = e;
  }
  return errors;
}

/** Normalise values the same way the server does (uppercase, trimming). */
export function normalizeValue(f: FieldDef, value: unknown): unknown {
  if (typeof value !== 'string') return value;
  let v = f.type === 'textarea' ? value : value.replace(/\s+/g, ' ');
  if (f.uppercase) v = v.toUpperCase();
  return v;
}
