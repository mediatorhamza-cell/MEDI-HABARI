// Thin fetch wrapper for the PHP API. Session cookie (HttpOnly) + CSRF header.

export class ApiError extends Error {
  status: number;
  code: string;
  fields: Record<string, string>;
  constructor(status: number, code: string, message: string, fields: Record<string, string> = {}) {
    super(message);
    this.status = status;
    this.code = code;
    this.fields = fields;
  }
}

const BASE = '/api';
let csrfToken = '';
let onUnauthenticated: (() => void) | null = null;

export function setCsrf(token: string) {
  csrfToken = token;
}
export function setUnauthenticatedHandler(fn: () => void) {
  onUnauthenticated = fn;
}

async function refreshCsrf() {
  const res = await fetch(`${BASE}/auth/session`, { credentials: 'same-origin' });
  const json = await res.json().catch(() => null);
  if (json?.data?.csrf) csrfToken = json.data.csrf;
}

type Body = Record<string, unknown> | unknown[] | FormData | undefined;

// Time of the last request made because of the user (not background polling); the
// server's idle timeout counts from the same moment, so the session timer mirrors it.
let lastActivity = Date.now();
export const getLastActivity = () => lastActivity;
export function setLastActivity(t: number) {
  lastActivity = t;
}

async function request<T>(method: string, path: string, body?: Body, retry = true, background = false): Promise<T> {
  const headers: Record<string, string> = { Accept: 'application/json' };
  if (background) headers['X-Background'] = '1';
  else lastActivity = Date.now();
  let payload: BodyInit | undefined;
  if (body instanceof FormData) {
    payload = body;
  } else if (body !== undefined) {
    headers['Content-Type'] = 'application/json';
    payload = JSON.stringify(body);
  }
  if (method !== 'GET' && csrfToken) headers['X-CSRF-Token'] = csrfToken;
  // Shared hosting often blocks PUT/DELETE: send them as POST with an override header.
  let httpMethod = method;
  if (method === 'PUT' || method === 'DELETE' || method === 'PATCH') {
    headers['X-HTTP-Method-Override'] = method;
    httpMethod = 'POST';
  }

  let res: Response;
  try {
    res = await fetch(`${BASE}${path}`, { method: httpMethod, headers, body: payload, credentials: 'same-origin' });
  } catch {
    throw new ApiError(0, 'network', 'network');
  }
  const json = await res.json().catch(() => null);
  if (res.ok && json?.ok) return json.data as T;

  if (!json) {
    // Not an API response: blocked by the web server / hosting firewall before reaching PHP.
    throw new ApiError(res.status, `http_${res.status}`, `HTTP ${res.status}`);
  }
  const err = json?.error ?? {};
  if ((res.status === 419 || err.code === 'csrf_mismatch') && retry) {
    await refreshCsrf();
    return request<T>(method, path, body, false, background);
  }
  if (res.status === 401 && err.code === 'unauthenticated' && onUnauthenticated) onUnauthenticated();
  throw new ApiError(res.status, err.code ?? 'server_error', err.message ?? 'Error', err.fields ?? {});
}

export const api = {
  get: <T>(path: string) => request<T>('GET', path),
  post: <T>(path: string, body?: Body) => request<T>('POST', path, body ?? {}),
  put: <T>(path: string, body?: Body) => request<T>('PUT', path, body ?? {}),
  del: <T>(path: string) => request<T>('DELETE', path),
  /** GET that does not count as user activity (polling). */
  poll: <T>(path: string) => request<T>('GET', path, undefined, true, true),
};

/** Upload with progress (XHR) */
export function uploadFile<T>(path: string, form: FormData, onProgress?: (pct: number) => void): Promise<T> {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    lastActivity = Date.now();
    xhr.open('POST', `${BASE}${path}`);
    xhr.withCredentials = true;
    xhr.setRequestHeader('X-CSRF-Token', csrfToken);
    xhr.setRequestHeader('Accept', 'application/json');
    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable && onProgress) onProgress(Math.round((e.loaded / e.total) * 100));
    };
    xhr.onload = () => {
      let json: { ok?: boolean; data?: T; error?: { code?: string; message?: string; fields?: Record<string, string> } } | null = null;
      try {
        json = JSON.parse(xhr.responseText);
      } catch {
        /* ignore */
      }
      if (xhr.status >= 200 && xhr.status < 300 && json?.ok) resolve(json.data as T);
      else {
        const e = json?.error ?? {};
        reject(new ApiError(xhr.status, e.code ?? (xhr.status === 413 ? 'payload_too_large' : 'upload_failed'), e.message ?? 'Upload failed', e.fields ?? {}));
      }
    };
    xhr.onerror = () => reject(new ApiError(0, 'network', 'network'));
    xhr.send(form);
  });
}

export function fileUrl(appId: number, fileId: number, inline = false, admin = false) {
  return `${BASE}${admin ? '/admin' : ''}/applications/${appId}/files/${fileId}${inline ? '?inline=1' : ''}`;
}
export function mediaUrl(id: number | null | undefined, download = false) {
  return id ? `${BASE}/media/${id}${download ? '?download=1' : ''}` : '';
}
export function query(params: Record<string, string | number | undefined | null | boolean>) {
  const q = new URLSearchParams();
  Object.entries(params).forEach(([k, v]) => {
    if (v !== undefined && v !== null && v !== '' && v !== false) q.set(k, String(v));
  });
  const s = q.toString();
  return s ? `?${s}` : '';
}
