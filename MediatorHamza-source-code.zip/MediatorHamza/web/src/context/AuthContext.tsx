import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from 'react';
import { api, setCsrf, setUnauthenticatedHandler } from '@/lib/api';
import type { User } from '@/lib/types';

interface SessionResponse {
  user: User | null;
  csrf: string;
  pending_2fa?: boolean;
}

interface AuthValue {
  user: User | null;
  ready: boolean;
  setSession: (s: { user: User | null; csrf?: string }) => void;
  refresh: () => Promise<void>;
  logout: () => Promise<void>;
  can: (permission: string) => boolean;
}

const AuthContext = createContext<AuthValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [ready, setReady] = useState(false);

  const refresh = useCallback(async () => {
    try {
      const s = await api.get<SessionResponse>('/auth/session');
      setCsrf(s.csrf);
      setUser(s.user);
    } catch {
      setUser(null);
    } finally {
      setReady(true);
    }
  }, []);

  useEffect(() => {
    void refresh();
    setUnauthenticatedHandler(() => setUser(null));
  }, [refresh]);

  const setSession = useCallback((s: { user: User | null; csrf?: string }) => {
    if (s.csrf) setCsrf(s.csrf);
    setUser(s.user);
  }, []);

  const logout = useCallback(async () => {
    try {
      await api.post('/auth/logout');
    } finally {
      setUser(null);
      await refresh();
    }
  }, [refresh]);

  const can = useCallback((p: string) => !!user?.permissions.includes(p), [user]);

  return <AuthContext.Provider value={{ user, ready, setSession, refresh, logout, can }}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth outside provider');
  return ctx;
}
