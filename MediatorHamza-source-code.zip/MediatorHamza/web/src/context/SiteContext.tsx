import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from 'react';
import { api, ApiError } from '@/lib/api';
import type { Service, SiteSettings } from '@/lib/types';

interface SiteValue {
  settings: SiteSettings | null;
  services: Service[];
  loading: boolean;
  error: boolean;
  notConfigured: boolean;
  reload: () => void;
  serviceByCode: (code: string) => Service | undefined;
}

const SiteContext = createContext<SiteValue | null>(null);

export function SiteProvider({ children }: { children: ReactNode }) {
  const [settings, setSettings] = useState<SiteSettings | null>(null);
  const [services, setServices] = useState<Service[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [notConfigured, setNotConfigured] = useState(false);

  const load = useCallback(() => {
    setLoading(true);
    api
      .get<{ settings: SiteSettings; services: Service[] }>('/bootstrap')
      .then((d) => {
        setSettings(d.settings);
        setServices(d.services);
        setError(false);
        setNotConfigured(false);
      })
      .catch((e) => {
        if (e instanceof ApiError && e.code === 'not_configured') setNotConfigured(true);
        else setError(true);
      })
      .finally(() => setLoading(false));
  }, []);

  useEffect(load, [load]);

  useEffect(() => {
    if (settings?.favicon_file_id) {
      const link = document.querySelector<HTMLLinkElement>('link[rel="icon"]');
      if (link) link.href = `/api/media/${settings.favicon_file_id}`;
    }
  }, [settings?.favicon_file_id]);

  return (
    <SiteContext.Provider
      value={{
        settings,
        services,
        loading,
        error,
        notConfigured,
        reload: load,
        serviceByCode: (code) => services.find((s) => s.code === code.toUpperCase()),
      }}
    >
      {children}
    </SiteContext.Provider>
  );
}

export function useSite() {
  const ctx = useContext(SiteContext);
  if (!ctx) throw new Error('useSite outside provider');
  return ctx;
}
