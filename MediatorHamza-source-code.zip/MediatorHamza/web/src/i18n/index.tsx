import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import sw from './sw';
import en from './en';
import { adminEn, adminSw } from './admin';
import type { Lang } from '@/lib/types';

const dictionaries = {
  sw: { ...sw, ...adminSw },
  en: { ...en, ...adminEn },
};
export type TKey = keyof typeof dictionaries.sw;
type Vars = Record<string, string | number>;

interface I18nValue {
  lang: Lang;
  setLang: (l: Lang) => void;
  t: (key: TKey, vars?: Vars) => string;
  /** Pick the right language from a bilingual pair, falling back to Swahili. */
  pick: (sw?: string | null, en?: string | null) => string;
  /** Translate a server error/validation code. */
  tv: (code: string, vars?: Vars) => string;
}

const I18nContext = createContext<I18nValue | null>(null);
// v2: everyone starts in English again (older builds stored the Swahili default for logged-in users).
const STORAGE_KEY = 'mediator.lang.v2';

function initialLang(): Lang {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored === 'sw' || stored === 'en') return stored;
  } catch {
    /* storage unavailable */
  }
  return 'en';
}

export function I18nProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>(initialLang);

  useEffect(() => {
    document.documentElement.lang = lang;
  }, [lang]);

  const setLang = useCallback((l: Lang) => {
    setLangState(l);
    try {
      localStorage.setItem(STORAGE_KEY, l);
    } catch {
      /* ignore */
    }
  }, []);

  const value = useMemo<I18nValue>(() => {
    const dict = dictionaries[lang];
    const interpolate = (s: string, vars?: Vars) =>
      vars ? s.replace(/\{(\w+)\}/g, (_, k) => (vars[k] !== undefined ? String(vars[k]) : `{${k}}`)) : s;
    const t = (key: TKey, vars?: Vars) => interpolate(dict[key] ?? dictionaries.sw[key] ?? key, vars);
    return {
      lang,
      setLang,
      t,
      pick: (s, e) => (lang === 'en' && e ? e : s ?? e ?? ''),
      tv: (code, vars) => {
        const key = `validation.${code}` as TKey;
        return key in dict ? t(key, vars) : t('validation.invalid');
      },
    };
  }, [lang, setLang]);

  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
}

export function useI18n() {
  const ctx = useContext(I18nContext);
  if (!ctx) throw new Error('useI18n outside provider');
  return ctx;
}

/** Remember the language on the server for logged-in users (best effort). */
export function hasStoredLang(): boolean {
  try {
    return localStorage.getItem(STORAGE_KEY) !== null;
  } catch {
    return false;
  }
}
