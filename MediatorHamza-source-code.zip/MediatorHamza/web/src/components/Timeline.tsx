import { CheckCircle2, Circle, Clock, Edit3, Lock, PauseCircle, XCircle } from 'lucide-react';
import { useI18n } from '@/i18n';
import { fmtDateTime } from '@/lib/format';
import type { TimelineItem } from '@/lib/types';
import { StatusBadge } from './ui';

const ICONS = {
  completed: CheckCircle2,
  correction_required: Edit3,
  awaiting_info: Clock,
  on_hold: PauseCircle,
  cancelled: XCircle,
  closed: Lock,
} as Record<string, typeof Circle>;

export function Timeline({ items, staff }: { items: TimelineItem[]; staff?: boolean }) {
  const { t, lang } = useI18n();
  return (
    <ol className="timeline">
      {[...items].reverse().map((h) => {
        const Icon = ICONS[h.to_status] ?? Circle;
        const noteOnly = h.from_status === h.to_status && !h.public_message;
        return (
          <li key={h.id}>
            <span className="tl-dot">
              <Icon />
            </span>
            <div className="row" style={{ gap: 8 }}>
              {!noteOnly && <StatusBadge status={h.to_status} />}
              <span className="xs muted">{fmtDateTime(h.created_at, lang)}</span>
              {staff && h.changed_by && <span className="xs muted">· {h.changed_by}</span>}
            </div>
            {h.public_message && <div className="small mt-2 pre">{h.public_message}</div>}
            {h.next_action && (
              <div className="xs mt-2">
                <strong>{t('apps.nextAction')}:</strong> {h.next_action}
              </div>
            )}
            {staff && h.internal_note && (
              <div className="tl-note">
                <Lock size={12} /> <strong>{t('admin.app.internalNote')}:</strong> <span className="pre">{h.internal_note}</span>
              </div>
            )}
          </li>
        );
      })}
    </ol>
  );
}
