import { useEffect, useId, useRef, useState, type DragEvent } from 'react';
import { CalendarDays, FileText, Lock, Plus, Trash2, UploadCloud, X } from 'lucide-react';
import { useI18n } from '@/i18n';
import { fileUrl, uploadFile, ApiError, api } from '@/lib/api';
import { fmtSize } from '@/lib/format';
import { applyMask, isRequired, optionsFor, type Values } from '@/lib/forms';
import type { AppFile, FieldDef, Option, Region } from '@/lib/types';
import { FieldShell } from '@/components/ui';
import { useToast } from '@/context/ToastContext';

export interface FieldCtx {
  banks: Option[];
  heslb_levels: Option[];
  regions: Region[];
  institutions: string[];
  appId: number;
  files: Record<number, AppFile>;
  onFileAdded: (f: AppFile) => void;
  onFileRemoved: (id: number) => void;
  uploadMb: number;
  /** Values the user entered in earlier applications, per field key. */
  history?: Record<string, string[]>;
}

interface Props {
  field: FieldDef;
  value: unknown;
  data: Values;
  error?: string | null;
  onChange: (v: unknown) => void;
  ctx: FieldCtx;
  locked?: boolean;
  unlocked?: boolean;
}

export function FormField({ field: f, value, data, error, onChange, ctx, locked, unlocked }: Props) {
  const { pick, tv, t } = useI18n();
  const id = useId();
  const required = isRequired(f, data);
  const label = pick(f.label.sw, f.label.en);
  const help = f.help ? pick(f.help.sw, f.help.en) : undefined;
  const errText = error ? tv(error, { n: f.minSelected ?? f.minFiles ?? 1 }) : null;
  const wide = f.width !== 'half' || ['textarea', 'radio', 'yesno', 'checkboxes', 'file', 'repeater'].includes(f.type);
  const cls = `${wide ? 'full' : ''} ${locked ? 'locked-field' : ''} ${unlocked ? 'unlocked-field' : ''}`;
  const extra = (
    <>
      {f.sensitive && (
        <span className="notice-sensitive" title={t('form.sensitive')} style={{ marginLeft: 8 }}>
          <Lock /> {t('form.sensitive').split('—')[0].trim()}
        </span>
      )}
    </>
  );

  if (f.type === 'heading') {
    return (
      <div className="form-heading">
        <h4>{label}</h4>
        {help && <p className="small muted mb-0 pre">{help}</p>}
      </div>
    );
  }

  const str = typeof value === 'string' ? value : value === undefined || value === null ? '' : String(value);
  const common = {
    id,
    disabled: locked,
    'aria-invalid': !!error,
    'aria-describedby': error ? `${id}-err` : help ? `${id}-help` : undefined,
  };

  let control: React.ReactNode;
  switch (f.type) {
    case 'textarea':
      control = <textarea className="textarea" {...common} value={str} maxLength={f.maxLength ?? 3000} onChange={(e) => onChange(e.target.value)} />;
      break;
    case 'select':
    case 'region':
    case 'district': {
      let options: { value: string; label: string }[];
      let placeholder = t('form.selectPlaceholder');
      if (f.type === 'region') options = ctx.regions.map((r) => ({ value: r.name, label: r.name }));
      else if (f.type === 'district') {
        const region = ctx.regions.find((r) => r.name === data[f.regionField ?? '']);
        options = (region?.districts ?? []).map((d) => ({ value: d, label: d }));
        if (!region) placeholder = t('form.selectRegionFirst');
      } else options = optionsFor(f, ctx).map((o) => ({ value: o.value, label: pick(o.label.sw, o.label.en) }));
      control = (
        <select className="select" {...common} value={str} onChange={(e) => onChange(e.target.value)} disabled={locked || (f.type === 'district' && options.length === 0)}>
          <option value="">{placeholder}</option>
          {options.map((o) => (
            <option key={o.value} value={o.value}>
              {o.label}
            </option>
          ))}
        </select>
      );
      break;
    }
    case 'radio':
    case 'yesno': {
      const options =
        f.type === 'yesno'
          ? [
              { value: 'yes', label: t('common.yes') },
              { value: 'no', label: t('common.no') },
            ]
          : optionsFor(f, ctx).map((o) => ({ value: o.value, label: pick(o.label.sw, o.label.en) }));
      control = (
        <div className={`choice-group ${options.length > 3 ? 'vertical' : ''}`} role="radiogroup" aria-labelledby={`${id}-l`}>
          {options.map((o) => (
            <label key={o.value} className={`choice ${str === o.value ? 'checked' : ''}`}>
              <input type="radio" name={`${id}-${f.key}`} value={o.value} checked={str === o.value} disabled={locked} onChange={() => onChange(o.value)} />
              {o.label}
            </label>
          ))}
        </div>
      );
      break;
    }
    case 'checkboxes': {
      const arr = Array.isArray(value) ? (value as string[]) : [];
      control = (
        <div className="choice-group vertical">
          {optionsFor(f, ctx).map((o) => {
            const checked = arr.includes(o.value);
            return (
              <label key={o.value} className={`choice ${checked ? 'checked' : ''}`}>
                <input type="checkbox" checked={checked} disabled={locked} onChange={() => onChange(checked ? arr.filter((x) => x !== o.value) : [...arr, o.value])} />
                {pick(o.label.sw, o.label.en)}
              </label>
            );
          })}
        </div>
      );
      break;
    }
    case 'file':
      control = <FileField field={f} value={Array.isArray(value) ? (value as number[]) : []} onChange={onChange} ctx={ctx} locked={locked} />;
      break;
    case 'date':
      control = <DateInput id={id} value={str} onChange={onChange} disabled={locked} invalid={!!error} max={f.max === 'today' ? todayIso() : undefined} describedBy={common['aria-describedby']} />;
      break;
    case 'repeater':
      control = <RepeaterField field={f} value={Array.isArray(value) ? (value as Values[]) : []} onChange={onChange} ctx={ctx} locked={locked} />;
      break;
    default: {
      const type = f.type === 'tel' ? 'tel' : f.type === 'email' ? 'email' : 'text';
      const digitsOnly = !!f.mask && !/A/.test(f.mask);
      const inputMode = f.type === 'tel' ? 'tel' : f.type === 'number' || f.type === 'year' ? 'numeric' : f.type === 'email' ? 'email' : (f.inputMode as 'numeric' | undefined);
      const past = (ctx.history?.[f.key] ?? []).filter((v) => v !== str).map((v) => (f.type === 'tel' && v.startsWith('+255') ? `0${v.slice(4)}` : v));
      const suggestions = f.suggest === 'institutions' ? ctx.institutions : past;
      const listId = suggestions.length ? `${id}-list` : undefined;
      control = (
        <>
          <input
            className="input"
            {...common}
            type={type}
            inputMode={digitsOnly ? 'numeric' : inputMode}
            value={str}
            placeholder={f.placeholder ?? f.mask?.replace(/9/g, '0')}
            maxLength={f.type === 'year' ? 4 : f.mask ? f.mask.length : f.maxLength ?? 200}
            autoComplete={f.type === 'email' ? 'email' : 'off'}
            list={listId}
            style={f.uppercase ? { textTransform: 'uppercase' } : undefined}
            onChange={(e) => onChange(f.mask ? applyMask(f.mask, e.target.value) : e.target.value)}
          />
          {listId && (
            <datalist id={listId}>
              {suggestions.map((n) => (
                <option key={n} value={n} />
              ))}
            </datalist>
          )}
        </>
      );
    }
  }

  return (
    <FieldShell id={id} label={<span id={`${id}-l`}>{label}</span>} required={required} optional={!required} help={locked ? t('form.lockedHint') : help} error={errText} className={cls} extra={extra}>
      {control}
    </FieldShell>
  );
}

const todayIso = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};
const isoToDmy = (v: string) => (/^\d{4}-\d{2}-\d{2}$/.test(v) ? `${v.slice(8, 10)}/${v.slice(5, 7)}/${v.slice(0, 4)}` : v);
const dmyToIso = (v: string) => (/^\d{2}\/\d{2}\/\d{4}$/.test(v) ? `${v.slice(6, 10)}-${v.slice(3, 5)}-${v.slice(0, 2)}` : v);

/** Date field the user can type (DD/MM/YYYY, slashes added automatically) or pick from a calendar. Stores YYYY-MM-DD. */
function DateInput({ id, value, onChange, disabled, invalid, max, describedBy }: { id: string; value: string; onChange: (v: unknown) => void; disabled?: boolean; invalid?: boolean; max?: string; describedBy?: string }) {
  const { t } = useI18n();
  const picker = useRef<HTMLInputElement>(null);
  const [text, setText] = useState(() => isoToDmy(value));
  useEffect(() => {
    // Follow outside changes (draft load, prefill) without fighting the user's typing.
    if (dmyToIso(text) !== value) setText(isoToDmy(value));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value]);
  const type = (raw: string) => {
    const masked = applyMask('99/99/9999', raw);
    setText(masked);
    onChange(masked.length === 10 ? dmyToIso(masked) : masked);
  };
  return (
    <div className="date-input">
      <input
        id={id}
        className="input"
        inputMode="numeric"
        placeholder={t('form.datePlaceholder')}
        value={text}
        maxLength={10}
        disabled={disabled}
        aria-invalid={invalid}
        aria-describedby={describedBy}
        autoComplete="off"
        onChange={(e) => type(e.target.value)}
      />
      <button
        type="button"
        className="date-btn"
        disabled={disabled}
        aria-label={t('form.pickDate')}
        onClick={() => {
          const el = picker.current;
          if (!el) return;
          try {
            el.showPicker();
          } catch {
            el.focus();
            el.click();
          }
        }}
      >
        <CalendarDays />
      </button>
      <input
        ref={picker}
        type="date"
        className="date-native"
        tabIndex={-1}
        aria-hidden
        max={max}
        value={/^\d{4}-\d{2}-\d{2}$/.test(value) ? value : ''}
        onChange={(e) => {
          setText(isoToDmy(e.target.value));
          onChange(e.target.value);
        }}
      />
    </div>
  );
}

function FileField({ field: f, value, onChange, ctx, locked }: { field: FieldDef; value: number[]; onChange: (v: unknown) => void; ctx: FieldCtx; locked?: boolean }) {
  const { t, tv } = useI18n();
  const { toast } = useToast();
  const input = useRef<HTMLInputElement>(null);
  const [progress, setProgress] = useState<number | null>(null);
  const [drag, setDrag] = useState(false);
  const max = f.maxFiles ?? 1;
  const accept = f.accept === 'image' ? 'image/jpeg,image/png,image/webp' : f.accept === 'document' ? 'application/pdf' : 'image/jpeg,image/png,image/webp,application/pdf';
  const valueRef = useRef(value);
  valueRef.current = value;

  const upload = async (files: FileList | null) => {
    if (!files || locked) return;
    for (const file of Array.from(files).slice(0, max === 1 ? 1 : max - valueRef.current.length)) {
      if (file.size > ctx.uploadMb * 1024 * 1024) {
        toast(tv('file_too_large'), 'error');
        continue;
      }
      const form = new FormData();
      form.append('field_key', f.key);
      form.append('file', file);
      setProgress(0);
      try {
        const res = await uploadFile<AppFile>(`/applications/${ctx.appId}/files`, form, setProgress);
        const meta = { ...res, created_at: new Date().toISOString() };
        ctx.onFileAdded(meta);
        if (max === 1) {
          const old = valueRef.current;
          onChange([res.id]);
          old.forEach((oldId) => void api.del(`/applications/${ctx.appId}/files/${oldId}`).then(() => ctx.onFileRemoved(oldId)).catch(() => undefined));
        } else {
          onChange([...valueRef.current, res.id]);
          valueRef.current = [...valueRef.current, res.id];
        }
      } catch (e) {
        toast(e instanceof ApiError && e.fields.file ? tv(e.fields.file) : t('common.unknownError'), 'error');
      } finally {
        setProgress(null);
      }
    }
    if (input.current) input.current.value = '';
  };

  const remove = async (fileId: number) => {
    try {
      await api.del(`/applications/${ctx.appId}/files/${fileId}`);
    } catch {
      /* already gone */
    }
    ctx.onFileRemoved(fileId);
    onChange(value.filter((x) => x !== fileId));
  };

  const onDrop = (e: DragEvent) => {
    e.preventDefault();
    setDrag(false);
    void upload(e.dataTransfer.files);
  };

  return (
    <div>
      {!locked && (value.length < max || max === 1) && (
        <div
          className={`dropzone ${drag ? 'drag' : ''}`}
          role="button"
          tabIndex={0}
          onClick={() => input.current?.click()}
          onKeyDown={(e) => (e.key === 'Enter' || e.key === ' ') && input.current?.click()}
          onDragOver={(e) => {
            e.preventDefault();
            setDrag(true);
          }}
          onDragLeave={() => setDrag(false)}
          onDrop={onDrop}
        >
          <UploadCloud />
          <strong style={{ color: 'var(--c-navy)' }}>{progress !== null ? t('form.uploading', { pct: progress }) : t('form.uploadHint')}</strong>
          <span className="xs">{f.accept === 'image' ? t('form.uploadTypesImage', { mb: ctx.uploadMb }) : t('form.uploadTypesAny', { mb: ctx.uploadMb })}</span>
          {progress !== null && (
            <div className="progress" style={{ width: '100%', maxWidth: 240 }}>
              <div style={{ width: `${progress}%` }} />
            </div>
          )}
          <input ref={input} type="file" accept={accept} multiple={max > 1} hidden onChange={(e) => void upload(e.target.files)} />
        </div>
      )}
      {value.length > 0 && (
        <div className="file-list">
          {value.map((fid) => {
            const meta = ctx.files[fid];
            const isImage = meta?.mime.startsWith('image/');
            return (
              <div key={fid} className="file-item">
                {isImage ? <img className="thumb" src={fileUrl(ctx.appId, fid, true)} alt="" /> : <span className="thumb"><FileText /></span>}
                <div className="grow" style={{ minWidth: 0 }}>
                  <a href={fileUrl(ctx.appId, fid, true)} target="_blank" rel="noopener noreferrer" className="break">
                    {meta?.name ?? `#${fid}`}
                  </a>
                  {meta && <div className="xs muted">{fmtSize(meta.size)}</div>}
                </div>
                {!locked && (
                  <button type="button" className="icon-btn" onClick={() => void remove(fid)} aria-label={t('form.removeFile')}>
                    <X />
                  </button>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function RepeaterField({ field: f, value, onChange, ctx, locked }: { field: FieldDef; value: Values[]; onChange: (v: unknown) => void; ctx: FieldCtx; locked?: boolean }) {
  const { t, pick } = useI18n();
  const rows = value.length ? value : [{}];
  const max = f.maxItems ?? 10;
  const update = (i: number, key: string, v: unknown) => onChange(rows.map((r, j) => (j === i ? { ...r, [key]: v } : r)));
  return (
    <div className="stack sm">
      {rows.map((row, i) => (
        <div key={i} className="card" style={{ padding: 16, background: 'var(--c-surface-2)' }}>
          <div className="row between mb-4">
            <strong className="small">{t('form.item', { n: i + 1 })}</strong>
            {!locked && rows.length > 1 && (
              <button type="button" className="btn btn-ghost btn-sm" onClick={() => onChange(rows.filter((_, j) => j !== i))}>
                <Trash2 /> {t('form.removeItem')}
              </button>
            )}
          </div>
          <div className="form-grid">
            {(f.fields ?? []).map((sub) => (
              <FormField key={sub.key} field={sub} value={row[sub.key]} data={row} onChange={(v) => update(i, sub.key, v)} ctx={ctx} locked={locked} />
            ))}
          </div>
        </div>
      ))}
      {!locked && rows.length < max && (
        <button type="button" className="btn btn-secondary" onClick={() => onChange([...rows, {}])}>
          <Plus /> {f.addLabel ? pick(f.addLabel.sw, f.addLabel.en) : t('form.addItem')}
        </button>
      )}
    </div>
  );
}

/** Human-readable value for the review screen / detail pages. */
export function displayValue(f: FieldDef, value: unknown, ctx: { banks: Option[]; heslb_levels: Option[] }, files: Record<number, AppFile>, pick: (a?: string | null, b?: string | null) => string, yesNo: (v: string) => string): string {
  if (value === undefined || value === null || value === '' || (Array.isArray(value) && value.length === 0)) return '';
  switch (f.type) {
    case 'yesno':
      return yesNo(String(value));
    case 'select':
    case 'radio': {
      const o = optionsFor(f, ctx).find((x) => x.value === value);
      return o ? pick(o.label.sw, o.label.en) : String(value);
    }
    case 'checkboxes':
      return (value as string[])
        .map((v) => {
          const o = optionsFor(f, ctx).find((x) => x.value === v);
          return o ? pick(o.label.sw, o.label.en) : v;
        })
        .join(', ');
    case 'file':
      return (value as number[]).map((id) => files[id]?.name ?? `#${id}`).join(', ');
    case 'repeater':
      return (value as Values[])
        .map((row, i) => `${i + 1}. ${(f.fields ?? []).map((s) => displayValue(s, row[s.key], ctx, files, pick, yesNo)).filter(Boolean).join(' — ')}`)
        .join('\n');
    case 'tel': {
      const s = String(value);
      return s.startsWith('+255') ? `0${s.slice(4)}` : s;
    }
    default:
      return String(value);
  }
}
