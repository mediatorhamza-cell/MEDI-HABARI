import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { AlertTriangle, ArrowLeft, ArrowRight, Check, CheckCircle2, CloudOff, Eye, FileText, MessageCircle, Pencil, Phone, Save, Send } from 'lucide-react';
import { useI18n } from '@/i18n';
import { api, ApiError, fileUrl } from '@/lib/api';
import { fmtDateTime, fmtMoney, waLink } from '@/lib/format';
import { useSite } from '@/context/SiteContext';
import { isEmpty, normalizeValue, validateStep, visibleFields, visibleSteps, type Errors, type Values } from '@/lib/forms';
import type { AppDetail, AppFile, FormSchemaDef, Option, Region } from '@/lib/types';
import { Alert, Button, Checkbox, LinkButton, Modal, useErrorText } from '@/components/ui';
import { useToast } from '@/context/ToastContext';
import { displayValue, FormField, type FieldCtx } from './Fields';

type SaveState = 'idle' | 'dirty' | 'saving' | 'saved' | 'error';

export default function FormWizard({
  app,
  schema,
  options,
  regions,
  institutions,
  paymentInstructions,
}: {
  app: AppDetail;
  schema: FormSchemaDef;
  options: { banks: Option[]; heslb_levels: Option[] };
  regions: Region[];
  institutions: string[];
  paymentInstructions?: string;
}) {
  const { t, pick, tv, lang } = useI18n();
  const { toast } = useToast();
  const { settings } = useSite();
  const navigate = useNavigate();
  const errText = useErrorText();
  const correction = app.status === 'correction_required';
  const editable = correction ? app.editable_fields ?? [] : null;
  const canEdit = useCallback((key: string) => !editable || editable.includes('*') || editable.includes(key), [editable]);

  const [values, setValues] = useState<Values>(() => ({ ...app.data }));
  const [errors, setErrors] = useState<Errors>({});
  const [files, setFiles] = useState<Record<number, AppFile>>(() => Object.fromEntries(app.files.map((f) => [f.id, f])));
  const [packageId, setPackageId] = useState<number | null>(app.package_id);
  const [save, setSave] = useState<SaveState>('idle');
  const [savedAt, setSavedAt] = useState<string | null>(null);
  const [confirmChecked, setConfirmChecked] = useState(false);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState<{ reference: string; submitted_at: string; resubmitted_at?: string } | null>(null);
  const [stepErrors, setStepErrors] = useState<Set<string>>(new Set());

  const steps = useMemo(() => visibleSteps(schema, values), [schema, values]);
  const stepsForMode = useMemo(
    () => (editable && !editable.includes('*') ? steps.filter((s) => s.fields.some((f) => editable.includes(f.key))) : steps),
    [steps, editable],
  );
  const total = stepsForMode.length + 1; // + review
  const [index, setIndex] = useState(0);
  const isReview = index >= stepsForMode.length;
  const step = stepsForMode[Math.min(index, stepsForMode.length - 1)];

  const vctx = useMemo(() => ({ ...options, regions }), [options, regions]);
  // Earlier answers become suggestions (datalist) on matching inputs.
  const [history, setHistory] = useState<Record<string, string[]>>({});
  useEffect(() => {
    api
      .get<Record<string, string[]>>('/applications/history')
      .then(setHistory)
      .catch(() => undefined);
  }, []);
  const fctx: FieldCtx = {
    ...options,
    regions,
    institutions,
    appId: app.id,
    files,
    uploadMb: 5,
    history,
    onFileAdded: (f) => setFiles((m) => ({ ...m, [f.id]: f })),
    onFileRemoved: (id) =>
      setFiles((m) => {
        const n = { ...m };
        delete n[id];
        return n;
      }),
  };

  // ---------------------------------------------------------------- autosave
  const valuesRef = useRef(values);
  valuesRef.current = values;
  const timer = useRef<number>();
  const persist = useCallback(async () => {
    setSave('saving');
    try {
      const res = await api.put<{ saved_at: string }>(`/applications/${app.id}`, { data: valuesRef.current, package_id: packageId });
      setSavedAt(res.saved_at);
      setSave('saved');
      return true;
    } catch {
      setSave('error');
      return false;
    }
  }, [app.id, packageId]);

  const setValue = (key: string, v: unknown, normalize?: (x: unknown) => unknown, prefill?: Record<string, string>) => {
    setValues((prev) => {
      const next = { ...prev, [key]: normalize ? normalize(v) : v };
      // Copy details the applicant already gave (e.g. choosing the father as guarantor fills the guarantor's name).
      if (prefill) for (const [target, source] of Object.entries(prefill)) if (!isEmpty(prev[source])) next[target] = prev[source];
      return next;
    });
    setErrors((e) => {
      if (!e[key]) return e;
      const n = { ...e };
      delete n[key];
      return n;
    });
    setSave('dirty');
    window.clearTimeout(timer.current);
    timer.current = window.setTimeout(() => void persist(), 1500);
  };

  useEffect(() => () => window.clearTimeout(timer.current), []);
  useEffect(() => {
    const warn = (e: BeforeUnloadEvent) => {
      if (save === 'dirty' || save === 'saving') {
        e.preventDefault();
        e.returnValue = '';
      }
    };
    window.addEventListener('beforeunload', warn);
    return () => window.removeEventListener('beforeunload', warn);
  }, [save]);

  // ---------------------------------------------------------------- navigation
  const validateCurrent = () => {
    if (isReview || !step) return true;
    const errs = validateStep(step, values, vctx, editable);
    setErrors(errs);
    setStepErrors((s) => {
      const n = new Set(s);
      if (Object.keys(errs).length) n.add(step.key);
      else n.delete(step.key);
      return n;
    });
    if (Object.keys(errs).length) {
      toast(t('validation.formHasErrors'), 'error');
      requestAnimationFrame(() => document.querySelector('[aria-invalid="true"]')?.scrollIntoView({ behavior: 'smooth', block: 'center' }));
      return false;
    }
    return true;
  };
  const go = (i: number) => {
    setIndex(Math.max(0, Math.min(total - 1, i)));
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };
  const next = () => {
    if (!validateCurrent()) return;
    if (save === 'dirty') void persist();
    go(index + 1);
  };

  // ---------------------------------------------------------------- submit
  const openConfirm = () => {
    // Validate every visible step before asking for confirmation.
    const all: Errors = {};
    const bad = new Set<string>();
    for (const s of stepsForMode) {
      const e = validateStep(s, values, vctx, editable);
      if (Object.keys(e).length) {
        Object.assign(all, e);
        bad.add(s.key);
      }
    }
    setStepErrors(bad);
    if (bad.size) {
      setErrors(all);
      toast(t('validation.formHasErrors'), 'error');
      go(stepsForMode.findIndex((s) => bad.has(s.key)));
      return;
    }
    if (!confirmChecked) {
      setErrors({ confirm: 'confirm_required' });
      return;
    }
    setConfirmOpen(true);
  };

  const submit = async () => {
    setSubmitting(true);
    window.clearTimeout(timer.current);
    try {
      const res = await api.post<{ reference: string; submitted_at: string; resubmitted_at?: string }>(`/applications/${app.id}/submit`, {
        data: values,
        confirm: true,
        package_id: packageId,
      });
      setSave('saved');
      setSuccess(res);
      window.scrollTo({ top: 0 });
    } catch (e) {
      if (e instanceof ApiError && e.status === 422) {
        setErrors(e.fields);
        const badStep = stepsForMode.findIndex((s) => s.fields.some((f) => e.fields[f.key]));
        if (badStep >= 0) {
          setStepErrors(new Set(stepsForMode.filter((s) => s.fields.some((f) => e.fields[f.key])).map((s) => s.key)));
          go(badStep);
        }
        toast(t('validation.formHasErrors'), 'error');
      } else toast(errText(e), 'error');
    } finally {
      setSubmitting(false);
      setConfirmOpen(false);
    }
  };

  if (success) {
    return (
      <div className="card pad-lg text-center stack" style={{ alignItems: 'center', maxWidth: 640, margin: '0 auto' }}>
        <span className="icon-tile" style={{ width: 72, height: 72, borderRadius: '50%', background: 'var(--c-success-50)', color: 'var(--c-success)' }}>
          <CheckCircle2 style={{ width: 40, height: 40 }} />
        </span>
        <h1 className="mb-0">{success.resubmitted_at ? t('form.successResubmitTitle') : t('form.successTitle')}</h1>
        <p className="muted mb-0">{t('form.successText')}</p>
        <div className="card" style={{ background: 'var(--c-surface-2)', width: '100%' }}>
          <div className="small muted">{t('form.successRef')}</div>
          <div className="mono" style={{ fontSize: '1.5rem', fontWeight: 800, color: 'var(--c-navy)' }}>
            {success.reference}
          </div>
          <div className="small muted mt-2">
            {t('form.successTime')}: {fmtDateTime(success.resubmitted_at ?? success.submitted_at, lang)}
          </div>
        </div>
        {paymentInstructions && !success.resubmitted_at && (
          <Alert kind="info" title={t('apps.paymentInstructions')}>
            {paymentInstructions}
          </Alert>
        )}
        <div className="row" style={{ justifyContent: 'center' }}>
          <LinkButton to={`/app/maombi/${app.id}`}>{t('form.goToApplication')}</LinkButton>
          <LinkButton to="/app" variant="secondary">
            {t('form.goToDashboard')}
          </LinkButton>
        </div>
      </div>
    );
  }

  const yesNo = (v: string) => (v === 'yes' ? t('common.yes') : v === 'no' ? t('common.no') : v);
  const selectedPkg = app.packages.find((p) => p.id === packageId);
  const price = selectedPkg ? selectedPkg.price : app.current_price;

  return (
    <div className="stack">
      {correction && (
        <Alert kind="warning" title={t('apps.correctionTitle')}>
          <div className="pre">{app.correction_message}</div>
        </Alert>
      )}
      {(settings?.contact_phone || settings?.contact_whatsapp) && (
        <div className="form-hotline">
          <span className="grow small">
            <strong>{t('form.hotline')}</strong> {t('form.hotlineText')}
          </span>
          {settings?.contact_phone && (
            <a className="hotline-btn call" href={`tel:${settings.contact_phone}`} aria-label={t('form.call')}>
              <Phone /> <span>{t('form.call')}</span>
            </a>
          )}
          {settings?.contact_whatsapp && (
            <a className="hotline-btn wa" href={waLink(settings.contact_whatsapp)} target="_blank" rel="noopener noreferrer" aria-label="WhatsApp">
              <MessageCircle /> <span>WhatsApp</span>
            </a>
          )}
        </div>
      )}
      {schema.intro && index === 0 && <Alert kind="info">{pick(schema.intro.sw, schema.intro.en)}</Alert>}

      <div className="stack sm">
        <div className="row between small">
          <strong>{isReview ? t('form.review') : pick(step?.title.sw, step?.title.en)}</strong>
          <span className="muted">{t('form.step', { n: index + 1, total })}</span>
        </div>
        <div className="progress" aria-hidden>
          <div style={{ width: `${((index + 1) / total) * 100}%` }} />
        </div>
        <div className="stepper" role="list">
          {stepsForMode.map((s, i) => (
            <button
              key={s.key}
              type="button"
              role="listitem"
              className={`stepper-item ${i === index ? 'current' : ''} ${stepErrors.has(s.key) ? 'error' : i < index ? 'done' : ''}`}
              onClick={() => (i < index || validateCurrent()) && go(i)}
              aria-current={i === index ? 'step' : undefined}
            >
              <span className="num">{stepErrors.has(s.key) ? '!' : i < index ? <Check size={12} /> : i + 1}</span>
              {pick(s.title.sw, s.title.en)}
            </button>
          ))}
          <button type="button" className={`stepper-item ${isReview ? 'current' : ''}`} onClick={() => (isReview || validateCurrent()) && go(stepsForMode.length)}>
            <span className="num">{total}</span>
            {t('form.review')}
          </button>
        </div>
      </div>

      <div className="card">
        {!isReview && step && (
          <>
            <div className="mb-4">
              <h2 className="mb-0">{pick(step.title.sw, step.title.en)}</h2>
              {step.description && <p className="small muted mb-0">{pick(step.description.sw, step.description.en)}</p>}
            </div>
            <div className="form-grid">
              {visibleFields(step, values).map((f) => (
                <FormField
                  key={f.key}
                  field={f}
                  value={values[f.key]}
                  data={values}
                  error={errors[f.key]}
                  ctx={fctx}
                  locked={!canEdit(f.key)}
                  unlocked={!!editable && !editable.includes('*') && canEdit(f.key)}
                  onChange={(v) => setValue(f.key, v, (x) => normalizeValue(f, x), f.prefill?.[String(v)])}
                />
              ))}
            </div>
          </>
        )}

        {isReview && (
          <div className="stack">
            <div>
              <h2 className="mb-0">{t('form.reviewTitle')}</h2>
              <p className="small muted mb-0">{t('form.reviewText')}</p>
            </div>
            {steps.map((s) => {
              const fields = visibleFields(s, values).filter((f) => f.type !== 'heading');
              const idx = stepsForMode.indexOf(s);
              return (
                <div key={s.key} className="review-section">
                  <div className="review-section-head">
                    <h4>{pick(s.title.sw, s.title.en)}</h4>
                    {idx >= 0 && (
                      <Button variant="ghost" size="sm" icon={Pencil} onClick={() => go(idx)}>
                        {t('common.edit')}
                      </Button>
                    )}
                  </div>
                  <dl className="kv">
                    {fields.map((f) => {
                      const dv = displayValue(f, values[f.key], options, files, pick, yesNo);
                      return (
                        <div key={f.key} style={{ display: 'contents' }}>
                          <dt>{pick(f.label.sw, f.label.en)}</dt>
                          <dd className="pre">
                            {f.type === 'file' && dv ? (
                              <span className="review-files">
                                {((values[f.key] as number[] | undefined) ?? []).map((fid) => (
                                  <a key={fid} className="review-file" href={fileUrl(app.id, fid, true)} target="_blank" rel="noopener noreferrer" title={t('form.openFile')}>
                                    {files[fid]?.mime.startsWith('image/') ? (
                                      <img src={fileUrl(app.id, fid, true)} alt={files[fid]?.name ?? ''} />
                                    ) : (
                                      <span className="review-pdf">
                                        <FileText />
                                        PDF
                                      </span>
                                    )}
                                    <span className="review-file-name">{files[fid]?.name ?? `#${fid}`}</span>
                                    <span className="review-file-open">
                                      <Eye /> {t('form.openFile')}
                                    </span>
                                  </a>
                                ))}
                              </span>
                            ) : (
                              dv || <span className="muted">{t('form.notProvided')}</span>
                            )}
                          </dd>
                        </div>
                      );
                    })}
                  </dl>
                </div>
              );
            })}

            {!correction && (
              <div className="card" style={{ background: 'var(--c-surface-2)' }}>
                {app.packages.length > 0 && (
                  <div className="field mb-4">
                    <span className="field-label">{t('form.package')}</span>
                    <div className="choice-group vertical">
                      {[{ id: null as number | null, name_sw: t('form.packageNone'), name_en: t('form.packageNone'), price: app.current_price ?? 0 }, ...app.packages].map((p) => (
                        <label key={String(p.id)} className={`choice ${packageId === p.id ? 'checked' : ''}`}>
                          <input type="radio" checked={packageId === p.id} onChange={() => setPackageId(p.id)} />
                          <span className="grow">{pick(p.name_sw, p.name_en)}</span>
                          <strong>{fmtMoney(p.price)}</strong>
                        </label>
                      ))}
                    </div>
                  </div>
                )}
                <div className="row between">
                  <span className="muted">{t('form.serviceFee')}</span>
                  <strong style={{ fontSize: '1.2rem', color: 'var(--c-navy)' }}>{price !== null ? fmtMoney(price) : t('common.priceTba')}</strong>
                </div>
              </div>
            )}

            <div>
              <Checkbox
                checked={confirmChecked}
                onChange={(v) => {
                  setConfirmChecked(v);
                  setErrors((e) => ({ ...e, confirm: '' }));
                }}
              >
                {t('form.confirmText')}
              </Checkbox>
              {errors.confirm && <div className="field-error mt-2">{tv(errors.confirm)}</div>}
            </div>
          </div>
        )}

        <div className="wizard-footer">
          {index > 0 ? (
            <Button variant="secondary" icon={ArrowLeft} onClick={() => go(index - 1)}>
              {t('common.previous')}
            </Button>
          ) : (
            <Button variant="ghost" icon={ArrowLeft} onClick={() => navigate('/app/maombi')}>
              {t('common.back')}
            </Button>
          )}
          <span className="save-indicator grow">
            {save === 'saving' && t('common.saving')}
            {save === 'saved' && savedAt && (
              <>
                <Check /> {t('form.autosaved', { time: fmtDateTime(savedAt, lang).split(', ')[1] ?? '' })}
              </>
            )}
            {save === 'dirty' && t('form.unsaved')}
            {save === 'error' && (
              <span style={{ color: 'var(--c-danger)' }} className="row">
                <CloudOff /> {t('form.saveFailed')}
              </span>
            )}
          </span>
          {!isReview && (
            <Button variant="ghost" size="sm" icon={Save} onClick={() => void persist().then((ok) => ok && toast(t('form.draftSaved')))}>
              <span className="sr-only">{t('form.saveDraft')}</span>
            </Button>
          )}
          {isReview ? (
            <Button icon={Send} onClick={openConfirm} loading={submitting}>
              {correction ? t('form.resubmit') : t('form.submitApplication')}
            </Button>
          ) : (
            <Button onClick={next}>
              {t('common.next')} <ArrowRight />
            </Button>
          )}
        </div>
      </div>

      <Modal
        open={confirmOpen}
        onClose={() => !submitting && setConfirmOpen(false)}
        title={t('form.confirmSubmitTitle')}
        footer={
          <>
            <Button variant="secondary" onClick={() => setConfirmOpen(false)} disabled={submitting}>
              {t('common.cancel')}
            </Button>
            <Button icon={Send} loading={submitting} onClick={() => void submit()}>
              {correction ? t('form.resubmit') : t('form.submitApplication')}
            </Button>
          </>
        }
      >
        <div className="stack sm">
          <p className="mb-0">{t('form.confirmSubmitText')}</p>
          {!correction && price !== null && (
            <p className="mb-0">
              <AlertTriangle size={14} /> {t('form.serviceFee')}: <strong>{fmtMoney(price)}</strong>
            </p>
          )}
        </div>
      </Modal>
    </div>
  );
}

