import { useEffect, useRef, useState, type FormEvent } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Bot, Download, MessageCircle, Send, X } from 'lucide-react';
import { useI18n } from '@/i18n';
import { api } from '@/lib/api';
import { useAuth } from '@/context/AuthContext';
import { Button, Modal } from './ui';

export function LangSwitch() {
  const { lang, setLang } = useI18n();
  const { user } = useAuth();
  const change = (l: 'sw' | 'en') => {
    setLang(l);
    if (user) void api.put('/me/language', { language: l }).catch(() => undefined);
  };
  return (
    <div className="lang-switch" role="group" aria-label="Language">
      <button className={lang === 'sw' ? 'active' : ''} onClick={() => change('sw')} aria-pressed={lang === 'sw'}>
        SW
      </button>
      <button className={lang === 'en' ? 'active' : ''} onClick={() => change('en')} aria-pressed={lang === 'en'}>
        EN
      </button>
    </div>
  );
}

/** Privacy-respecting page view tracking (no cookies, no IP stored server-side). */
export function PageTracker() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
    if (pathname.startsWith('/admin')) return;
    const id = setTimeout(() => void api.post('/track', { path: pathname }).catch(() => undefined), 400);
    return () => clearTimeout(id);
  }, [pathname]);
  return null;
}

interface AssistantAnswer {
  title: string;
  text: string;
  link: string;
}
interface AssistantReply {
  answers: AssistantAnswer[];
  disclaimer: string;
  handoff: boolean;
}
type Turn = { from: 'user'; text: string } | { from: 'bot'; reply: AssistantReply } | { from: 'intro' };

export function AssistantChat({ compact }: { compact?: boolean }) {
  const { t, lang } = useI18n();
  const { user } = useAuth();
  const [turns, setTurns] = useState<Turn[]>([{ from: 'intro' }]);
  const [q, setQ] = useState('');
  const [busy, setBusy] = useState(false);
  const bodyRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bodyRef.current?.scrollTo({ top: bodyRef.current.scrollHeight });
  }, [turns]);

  const ask = async (e: FormEvent) => {
    e.preventDefault();
    const question = q.trim();
    if (!question || busy) return;
    setQ('');
    setTurns((t) => [...t, { from: 'user', text: question }]);
    setBusy(true);
    try {
      const reply = await api.post<AssistantReply>('/assistant', { question, language: lang });
      setTurns((t) => [...t, { from: 'bot', reply }]);
    } catch {
      setTurns((prev) => [...prev, { from: 'bot', reply: { answers: [], disclaimer: t('common.unknownError'), handoff: true } }]);
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      <div className="assistant-body" ref={bodyRef} style={compact ? undefined : { minHeight: 320, maxHeight: 460, borderRadius: 12 }}>
        {turns.map((turn, i) => {
          if (turn.from === 'intro')
            return (
              <div key={i} className="bubble theirs">
                {t('help.assistantIntro')}
              </div>
            );
          if (turn.from === 'user')
            return (
              <div key={i} className="bubble mine">
                {turn.text}
              </div>
            );
          return (
            <div key={i} className="bubble theirs">
              {turn.reply.answers.map((a, j) => (
                <div key={j} style={{ marginBottom: 8 }}>
                  <strong>{a.title}</strong>
                  <div className="pre">{a.text}</div>
                  <Link to={a.link} className="xs">
                    {t('common.learnMore')} →
                  </Link>
                </div>
              ))}
              <div className="xs muted">{turn.reply.disclaimer}</div>
              {turn.reply.handoff && (
                <Link to={user && !user.is_staff ? '/app/ujumbe?new=1' : '/mawasiliano'} className="xs">
                  <MessageCircle size={12} /> {t('help.talkToAdmin')}
                </Link>
              )}
            </div>
          );
        })}
        {busy && <div className="bubble theirs">…</div>}
      </div>
      <form className="chat-compose" onSubmit={ask}>
        <input className="input" value={q} onChange={(e) => setQ(e.target.value)} placeholder={t('help.assistantPlaceholder')} maxLength={400} aria-label={t('help.assistantPlaceholder')} />
        <button className="btn btn-primary" type="submit" disabled={busy || !q.trim()} aria-label={t('common.send')}>
          <Send />
        </button>
      </form>
    </>
  );
}

export function AssistantWidget() {
  const { t } = useI18n();
  const [open, setOpen] = useState(false);
  return (
    <>
      {open && (
        <div className="assistant-panel" role="dialog" aria-label={t('help.assistant')}>
          <header>
            <strong className="row" style={{ gap: 8 }}>
              <Bot size={20} /> {t('help.assistant')}
            </strong>
            <button className="icon-btn" onClick={() => setOpen(false)} aria-label={t('common.close')}>
              <X />
            </button>
          </header>
          <AssistantChat compact />
        </div>
      )}
      <button className="assistant-fab no-print" onClick={() => setOpen((o) => !o)} aria-label={t('help.assistant')}>
        {open ? <X /> : <Bot />}
      </button>
    </>
  );
}

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: string }>;
}

// The browser fires `beforeinstallprompt` once, possibly before any React component
// mounts, so capture it at module load and share it with the banner and the hero button.
let deferredInstall: BeforeInstallPromptEvent | null = null;
const installSubs = new Set<() => void>();
if (typeof window !== 'undefined') {
  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredInstall = e as BeforeInstallPromptEvent;
    installSubs.forEach((f) => f());
  });
  window.addEventListener('appinstalled', () => {
    deferredInstall = null;
    installSubs.forEach((f) => f());
  });
}
const isStandalone = () => window.matchMedia('(display-mode: standalone)').matches || !!(navigator as unknown as { standalone?: boolean }).standalone;

function useInstallEvent(): [BeforeInstallPromptEvent | null, () => void] {
  const [, force] = useState(0);
  useEffect(() => {
    const f = () => force((n) => n + 1);
    installSubs.add(f);
    return () => {
      installSubs.delete(f);
    };
  }, []);
  return [
    deferredInstall,
    () => {
      deferredInstall = null;
      installSubs.forEach((f) => f());
    },
  ];
}

/** "Download App" button: native install prompt where supported, otherwise step-by-step instructions. */
export const APK_URL = '/downloads/MediatorHamza.apk';

export function DownloadAppButton({ className = '' }: { className?: string }) {
  const { t } = useI18n();
  const [evt, clear] = useInstallEvent();
  const [help, setHelp] = useState(false);
  // Stays visible inside the installed app too (so the layout never shows a gap); it then just says it is installed.
  const installed = isStandalone();
  const ios = /iphone|ipad|ipod/i.test(navigator.userAgent);
  return (
    <>
      <button type="button" className={`btn btn-lg btn-download ${className}`} onClick={() => setHelp(true)}>
        <Download /> {t('pwa.downloadApp')}
      </button>
      <Modal open={help} onClose={() => setHelp(false)} title={t('pwa.downloadApp')}>
        <div className="stack sm">
          {installed ? (
            <p className="mb-0">{t('pwa.alreadyInstalled')}</p>
          ) : ios ? (
            <>
              <p className="mb-0">{t('pwa.iosIntro')}</p>
              <ol className="small" style={{ margin: 0, paddingLeft: 20 }}>
                {[t('pwa.iosStep1'), t('pwa.iosStep2'), t('pwa.iosStep3')].map((x) => (
                  <li key={x} style={{ marginBottom: 6 }}>
                    {x}
                  </li>
                ))}
              </ol>
            </>
          ) : (
            <>
              <a className="btn btn-primary btn-lg btn-block" href={APK_URL} download="MediatorHamza.apk">
                <Download /> {t('pwa.downloadApk')}
              </a>
              <ol className="small" style={{ margin: 0, paddingLeft: 20 }}>
                {[t('pwa.apkStep1'), t('pwa.apkStep2'), t('pwa.apkStep3'), t('pwa.apkStep4')].map((x) => (
                  <li key={x} style={{ marginBottom: 6 }}>
                    {x}
                  </li>
                ))}
              </ol>
              {evt && (
                <Button
                  variant="secondary"
                  block
                  onClick={async () => {
                    await evt.prompt();
                    await evt.userChoice.catch(() => undefined);
                    clear();
                    setHelp(false);
                  }}
                >
                  {t('pwa.installViaChrome')}
                </Button>
              )}
            </>
          )}
        </div>
      </Modal>
    </>
  );
}

/** "Install app" banner (Android/desktop native prompt, iOS instructions). */
export function InstallPrompt() {
  const { t } = useI18n();
  const [evt, clearEvt] = useInstallEvent();
  const [ios, setIos] = useState(false);
  const [hidden, setHidden] = useState(() => {
    try {
      return localStorage.getItem('mediator.installDismissed') === '1';
    } catch {
      return false;
    }
  });

  useEffect(() => {
    if (isStandalone()) return;
    if (/iphone|ipad|ipod/i.test(navigator.userAgent)) {
      const id = setTimeout(() => setIos(true), 8000);
      return () => clearTimeout(id);
    }
  }, []);

  const dismiss = () => {
    setHidden(true);
    try {
      localStorage.setItem('mediator.installDismissed', '1');
    } catch {
      /* ignore */
    }
  };
  if (hidden || (!evt && !ios)) return null;
  return (
    <div className="install-banner no-print" role="region" aria-label={t('pwa.installTitle')}>
      <Download size={24} />
      <div className="grow">
        <strong className="small">{t('pwa.installTitle')}</strong>
        <div className="xs" style={{ opacity: 0.8 }}>
          {evt ? t('pwa.installText') : t('pwa.iosHint')}
        </div>
      </div>
      {evt && (
        <Button
          size="sm"
          onClick={async () => {
            await evt.prompt();
            await evt.userChoice.catch(() => undefined);
            clearEvt();
            dismiss();
          }}
        >
          {t('pwa.install')}
        </Button>
      )}
      <button className="icon-btn" style={{ color: '#fff' }} onClick={dismiss} aria-label={t('pwa.later')}>
        <X />
      </button>
    </div>
  );
}
