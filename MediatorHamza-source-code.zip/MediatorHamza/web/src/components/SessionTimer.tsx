import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { LogOut, Timer } from 'lucide-react';
import { useI18n } from '@/i18n';
import { useAuth } from '@/context/AuthContext';
import { api, getLastActivity, setLastActivity } from '@/lib/api';
import { Button, Modal } from '@/components/ui';

const WARN_AT = 120; // seconds before the idle timeout when we ask "continue?"

const mmss = (s: number) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;

/**
 * Shows how long the signed-in session has left before the server's idle timeout and,
 * shortly before it ends, asks whether to continue or log out — so nobody is signed out
 * without warning.
 */
export default function SessionTimer({ loginTo }: { loginTo: string }) {
  const { t } = useI18n();
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [timeout, setTimeoutSecs] = useState(0);
  const [left, setLeft] = useState<number | null>(null);
  const synced = useRef(false);

  // Learn the idle timeout (and true remaining time) from the server without counting as activity.
  const sync = async () => {
    const s = await api.poll<{ idle: { timeout: number; remaining: number } | null }>('/auth/session').catch(() => null);
    if (!s?.idle) return;
    setTimeoutSecs(s.idle.timeout);
    setLastActivity(Date.now() - (s.idle.timeout - s.idle.remaining) * 1000);
  };
  useEffect(() => {
    if (user) void sync();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  useEffect(() => {
    if (!timeout) return;
    const tick = () => {
      const remaining = Math.max(0, Math.round(timeout - (Date.now() - getLastActivity()) / 1000));
      // Another tab may have kept the session alive: re-check once before warning.
      if (remaining <= WARN_AT + 5 && !synced.current) {
        synced.current = true;
        void sync();
      }
      if (remaining > WARN_AT + 5) synced.current = false;
      setLeft(remaining);
    };
    tick();
    const id = window.setInterval(tick, 1000);
    return () => window.clearInterval(id);
  }, [timeout]);

  if (!user || left === null || !timeout) return null;
  const expired = left <= 0;
  const warn = left <= WARN_AT;

  const keepGoing = async () => {
    await api.get('/auth/session').catch(() => undefined);
    setLeft(timeout);
  };
  const leave = async () => {
    await logout().catch(() => undefined);
    navigate(loginTo, { replace: true });
  };

  return (
    <>
      <span className={`session-timer ${warn ? 'warn' : ''}`} title={t('session.remaining')} aria-label={`${t('session.remaining')}: ${mmss(left)}`}>
        <Timer /> {mmss(left)}
      </span>
      <Modal open={warn} onClose={() => (expired ? void leave() : void keepGoing())} title={expired ? t('session.expiredTitle') : t('session.warnTitle')}
        footer={
          expired ? (
            <Button onClick={() => void leave()}>{t('session.loginAgain')}</Button>
          ) : (
            <>
              <Button variant="secondary" icon={LogOut} onClick={() => void leave()}>
                {t('nav.logout')}
              </Button>
              <Button onClick={() => void keepGoing()}>{t('session.continue')}</Button>
            </>
          )
        }
      >
        <p className="mb-0">{expired ? t('session.expiredText') : t('session.warnText', { time: mmss(left) })}</p>
      </Modal>
    </>
  );
}
