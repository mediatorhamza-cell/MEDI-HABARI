import { Link } from 'react-router-dom';
import { ArrowRight, BookOpen, CalendarClock, Quote, ChevronDown, Download, ExternalLink, FileText, LogIn, Globe, ShieldCheck } from 'lucide-react';
import { useI18n } from '@/i18n';
import { fmtDate, fmtMoney, fmtRelative, parseDate } from '@/lib/format';
import { mediaUrl } from '@/lib/api';
import type { AppSummary, ArticleSummary, Deadline, Faq, Guidebook, Institution, Service, Testimonial } from '@/lib/types';
import { LinkButton, PaymentBadge, ServiceIcon, StatusBadge } from './ui';

export function PriceTag({ service }: { service: Service }) {
  const { t, pick, lang } = useI18n();
  if (service.price === null && service.packages.length === 0)
    return <span className="price">{pick(service.price_note_sw, service.price_note_en) || t('common.priceTba')}</span>;
  if (service.price === 0) return <span className="price">{t('common.free')}</span>;
  const min = Math.min(...[service.price ?? Infinity, ...service.packages.map((p) => p.price)]);
  return (
    <span className="price">
      {service.packages.length > 0 && service.price === null ? `${lang === 'en' ? 'From' : 'Kuanzia'} ` : ''}
      {fmtMoney(min)}
      {service.price_note_sw && <small> · {pick(service.price_note_sw, service.price_note_en)}</small>}
    </span>
  );
}

export function ServiceCard({ service, inApp }: { service: Service; inApp?: boolean }) {
  const { t, pick } = useI18n();
  return (
    <article className="card card-link service-card">
      <div className="row between">
        <ServiceIcon name={service.icon} />
        <span className={`badge ${service.accepting ? 'success' : 'neutral'}`}>{service.accepting ? t('common.available') : t('common.unavailable')}</span>
      </div>
      <div>
        <h3 style={{ marginBottom: 6 }}>{pick(service.name_sw, service.name_en)}</h3>
        <p className="muted small mb-0">{pick(service.summary_sw, service.summary_en)}</p>
      </div>
      <PriceTag service={service} />
      <div className="actions">
        {service.accepting ? (
          <LinkButton to={`/app/omba/${service.code}`} size="sm">
            {t('common.requestService')}
          </LinkButton>
        ) : null}
        <LinkButton to={inApp ? `/huduma/${service.slug}` : `/huduma/${service.slug}`} variant="secondary" size="sm">
          {t('common.learnMore')}
        </LinkButton>
      </div>
    </article>
  );
}

export function DeadlineItem({ d }: { d: Deadline }) {
  const { t, pick, lang } = useI18n();
  const date = parseDate(d.closes_at);
  const months = lang === 'en' ? ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'] : ['Jan', 'Feb', 'Mac', 'Apr', 'Mei', 'Jun', 'Jul', 'Ago', 'Sep', 'Okt', 'Nov', 'Des'];
  const left = d.days_left;
  return (
    <div className="row" style={{ alignItems: 'flex-start', flexWrap: 'nowrap' }}>
      <div className="deadline-date">
        <strong>{date?.getDate()}</strong>
        <span>{date ? months[date.getMonth()] : ''}</span>
      </div>
      <div className="grow">
        <div style={{ fontWeight: 600 }}>{pick(d.title_sw, d.title_en)}</div>
        {d.service_sw && <div className="xs muted">{pick(d.service_sw, d.service_en)}</div>}
        {(d.description_sw || d.description_en) && <div className="small muted pre">{pick(d.description_sw, d.description_en)}</div>}
        <div className="row xs mt-2" style={{ gap: 6 }}>
          {d.opens_at && (
            <span className="muted">
              {t('deadlines.opens')}: {fmtDate(d.opens_at, lang)}
            </span>
          )}
          <span className={`badge ${left <= 3 ? 'danger' : left <= 10 ? 'warning' : 'info'}`}>
            <CalendarClock size={12} /> {left < 0 ? t('common.closed') : left === 0 ? t('common.closesToday') : t('common.daysLeft', { n: left })}
          </span>
        </div>
      </div>
    </div>
  );
}

export function ArticleCard({ a }: { a: ArticleSummary }) {
  const { t, pick, lang } = useI18n();
  return (
    <Link to={`/elimu/${a.slug}`} className="article-card">
      <div className="article-cover">
        {a.image_id ? (
          <img src={mediaUrl(a.image_id)} alt="" loading="lazy" />
        ) : (
          <span className="ac-icon">
            <BookOpen />
          </span>
        )}
        {a.category_sw && <span className="ac-cat">{pick(a.category_sw, a.category_en)}</span>}
      </div>
      <div className="article-body">
        <h3>{pick(a.title_sw, a.title_en)}</h3>
        {a.summary_sw && <p className="small muted">{pick(a.summary_sw, a.summary_en)}</p>}
        <div className="article-foot xs">
          <span className="muted">{fmtDate(a.published_at, lang)}</span>
          <span className="read">
            {t('education.readMore')} <ArrowRight size={13} />
          </span>
        </div>
      </div>
    </Link>
  );
}

export function TestimonialCard({ x }: { x: Testimonial }) {
  const { pick } = useI18n();
  const role = pick(x.role_sw, x.role_en);
  return (
    <figure className="testimonial">
      <Quote className="tm-quote" aria-hidden />
      <div className="tm-stars" aria-label={`${x.rating}/5`}>
        {'★'.repeat(x.rating)}
        <span>{'★'.repeat(5 - x.rating)}</span>
      </div>
      <blockquote>{pick(x.body_sw, x.body_en)}</blockquote>
      <figcaption>
        {x.photo_id ? <img src={mediaUrl(x.photo_id)} alt="" className="tm-avatar" loading="lazy" /> : <span className="tm-avatar">{x.name.slice(0, 1).toUpperCase()}</span>}
        <span className="grow">
          <strong>{x.name}</strong>
          <span className="xs muted">{[role, x.location, x.year].filter(Boolean).join(' · ')}</span>
        </span>
      </figcaption>
    </figure>
  );
}

export function InstitutionCard({ i }: { i: Institution }) {
  const { t, pick, lang } = useI18n();
  return (
    <article className="card stack sm">
      <div className="row" style={{ flexWrap: 'nowrap', alignItems: 'flex-start' }}>
        <div className="inst-logo">{i.logo_id ? <img src={mediaUrl(i.logo_id)} alt="" loading="lazy" /> : i.short_name ?? i.name.slice(0, 3)}</div>
        <div className="grow">
          <h3 className="mb-0" style={{ fontSize: '1rem' }}>
            {i.name}
          </h3>
          <div className="xs muted">
            {[pick(i.type_sw, i.type_en), i.ownership ? t(`institutions.${i.ownership}`) : null, i.location ?? i.region].filter(Boolean).join(' · ')}
          </div>
        </div>
      </div>
      {(i.description_sw || i.description_en) && <p className="small muted mb-0">{pick(i.description_sw, i.description_en)}</p>}
      <div className="row" style={{ gap: 6, marginTop: 'auto' }}>
        {i.website_url && (
          <LinkButton to={i.website_url} external variant="secondary" size="sm" icon={Globe}>
            {t('institutions.website')}
          </LinkButton>
        )}
        {i.apply_url && (
          <LinkButton to={i.apply_url} external size="sm" icon={ExternalLink}>
            {t('institutions.apply')}
          </LinkButton>
        )}
        {i.login_url && (
          <LinkButton to={i.login_url} external variant="ghost" size="sm" icon={LogIn}>
            {t('institutions.login')}
          </LinkButton>
        )}
      </div>
      {i.links_verified_at && (
        <span className="xs muted row" style={{ gap: 4 }}>
          <ShieldCheck size={12} color="var(--c-success)" /> {t('institutions.verified', { date: fmtDate(i.links_verified_at, lang) })}
        </span>
      )}
    </article>
  );
}

export function GuideCard({ g }: { g: Guidebook }) {
  const { t, pick, lang } = useI18n();
  const href = g.file_id ? mediaUrl(g.file_id) : g.external_url;
  return (
    <article className="card stack sm" style={g.is_outdated ? { opacity: 0.75 } : undefined}>
      <div className="row" style={{ flexWrap: 'nowrap', alignItems: 'flex-start' }}>
        <span className="icon-tile">
          <FileText />
        </span>
        <div className="grow">
          <h3 className="mb-0" style={{ fontSize: '1rem' }}>
            {pick(g.title_sw, g.title_en)}
          </h3>
          <div className="row xs muted" style={{ gap: 6 }}>
            {g.category_sw && <span>{pick(g.category_sw, g.category_en)}</span>}
            {g.academic_year && <span className="badge plain info">{g.academic_year}</span>}
            {g.is_outdated && <span className="badge warning">{t('guides.outdated')}</span>}
          </div>
        </div>
      </div>
      {(g.description_sw || g.description_en) && <p className="small muted mb-0">{pick(g.description_sw, g.description_en)}</p>}
      {g.is_outdated && <p className="xs mb-0" style={{ color: 'var(--c-warning)' }}>{t('guides.outdatedWarning')}</p>}
      <div className="row between" style={{ marginTop: 'auto' }}>
        <span className="xs muted">
          {t('guides.uploaded')}: {fmtDate(g.created_at, lang)}
        </span>
        {href && (
          <div className="row" style={{ gap: 6 }}>
            <a className="btn btn-secondary btn-sm" href={href} target="_blank" rel="noopener noreferrer">
              {t('common.view')}
            </a>
            {g.file_id && (
              <a className="btn btn-primary btn-sm" href={mediaUrl(g.file_id, true)}>
                <Download /> {t('common.download')}
              </a>
            )}
          </div>
        )}
      </div>
    </article>
  );
}

export function FaqList({ items }: { items: Faq[] }) {
  const { pick } = useI18n();
  return (
    <div className="stack sm">
      {items.map((f) => (
        <details key={f.id} className="faq-item" id={`q${f.id}`}>
          <summary>
            {pick(f.question_sw, f.question_en)}
            <ChevronDown />
          </summary>
          <div className="faq-body">{pick(f.answer_sw, f.answer_en)}</div>
        </details>
      ))}
    </div>
  );
}

export function AppCard({ a, admin }: { a: AppSummary; admin?: boolean }) {
  const { t, pick, lang } = useI18n();
  const base = admin ? '/admin/maombi' : '/app/maombi';
  return (
    <article className="card app-card">
      <div className="row between" style={{ flexWrap: 'nowrap', alignItems: 'flex-start' }}>
        <div className="row" style={{ flexWrap: 'nowrap' }}>
          <ServiceIcon name={a.service_icon} />
          <div>
            <div style={{ fontWeight: 650 }}>{pick(a.service_name_sw, a.service_name_en)}</div>
            <div className="ref">{a.reference ?? t('status.draft')}</div>
          </div>
        </div>
        <StatusBadge status={a.status} />
      </div>
      <div className="meta">
        <div>
          {t('apps.submittedOn')}
          <strong>{a.submitted_at ? fmtDate(a.submitted_at, lang) : t('apps.notSubmitted')}</strong>
        </div>
        <div>
          {t('apps.lastUpdate')}
          <strong>{fmtRelative(a.updated_at, lang)}</strong>
        </div>
        <div>
          {t('payment.title')}
          <strong>{a.status === 'draft' ? '—' : <PaymentBadge status={a.payment_status} />}</strong>
        </div>
        <div>
          {t('common.price')}
          <strong>{a.price !== null ? fmtMoney(a.price) : '—'}</strong>
        </div>
      </div>
      <div className="row" style={{ gap: 8 }}>
        <LinkButton to={`${base}/${a.id}`} variant="secondary" size="sm">
          {t('apps.viewDetails')}
        </LinkButton>
        {!admin && a.editable && (
          <LinkButton to={`/app/maombi/${a.id}/jaza`} size="sm" variant={a.status === 'correction_required' ? 'danger' : 'primary'}>
            {a.status === 'correction_required' ? t('apps.correct') : t('apps.continue')}
          </LinkButton>
        )}
      </div>
    </article>
  );
}
