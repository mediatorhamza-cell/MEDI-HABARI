import {
  useCallback,
  useEffect,
  useId,
  useRef,
  useState,
  type ButtonHTMLAttributes,
  type InputHTMLAttributes,
  type ReactNode,
  type SelectHTMLAttributes,
  type TextareaHTMLAttributes,
} from 'react';
import { createPortal } from 'react-dom';
import { Link } from 'react-router-dom';
import {
  AlertCircle,
  AlertTriangle,
  BadgeCheck,
  Scale,
  Baby,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Eye,
  EyeOff,
  FileHeart,
  FileText,
  GraduationCap,
  Inbox,
  Info,
  MapPin,
  School,
  X,
  XCircle,
  type LucideIcon,
} from 'lucide-react';
import { useI18n } from '@/i18n';
import { useSite } from '@/context/SiteContext';
import { mediaUrl, ApiError } from '@/lib/api';
import type { AppStatus, PaymentStatus } from '@/lib/types';

// ------------------------------------------------------------------ data hook

export function useAsync<T>(fn: () => Promise<T>, deps: unknown[] = []) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<ApiError | null>(null);
  const [loading, setLoading] = useState(true);
  const fnRef = useRef(fn);
  fnRef.current = fn;
  const reload = useCallback(() => {
    setLoading(true);
    setError(null);
    return fnRef
      .current()
      .then((d) => setData(d))
      .catch((e) => setError(e instanceof ApiError ? e : new ApiError(0, 'unknown', String(e))))
      .finally(() => setLoading(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
  useEffect(() => {
    void reload();
  }, [reload]);
  return { data, error, loading, reload, setData };
}

export function useErrorText() {
  const { t } = useI18n();
  return (e: unknown) => {
    if (e instanceof ApiError) {
      if (e.status === 0) return t('common.networkError');
      if (e.code.startsWith('http_')) return `${t('common.unknownError')} (HTTP ${e.status} — hosting)`;
      if (e.status === 429) return t('validation.too_many_requests');
      if (e.status === 403) return t('common.forbidden');
      if (e.status === 404) return t('common.notFound');
      if (e.status === 422) return t('validation.formHasErrors');
      if (e.message && e.status < 500 && e.message !== 'Error') return e.message;
    }
    return t('common.unknownError');
  };
}

// ------------------------------------------------------------------ basics

type BtnVariant = 'primary' | 'secondary' | 'ghost' | 'danger' | 'navy' | 'success' | 'light';
export function Button({
  variant = 'primary',
  size,
  loading,
  block,
  icon: Icon,
  children,
  className = '',
  ...rest
}: ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: BtnVariant;
  size?: 'sm' | 'lg';
  loading?: boolean;
  block?: boolean;
  icon?: LucideIcon;
}) {
  return (
    <button
      type="button"
      className={`btn btn-${variant} ${size ? `btn-${size}` : ''} ${block ? 'btn-block' : ''} ${className}`}
      disabled={loading || rest.disabled}
      aria-busy={loading || undefined}
      {...rest}
    >
      {loading ? <span className="spinner" aria-hidden /> : Icon ? <Icon aria-hidden /> : null}
      {children}
    </button>
  );
}

export function LinkButton({
  to,
  variant = 'primary',
  size,
  block,
  icon: Icon,
  children,
  external,
  className = '',
}: {
  to: string;
  variant?: BtnVariant;
  size?: 'sm' | 'lg';
  block?: boolean;
  icon?: LucideIcon;
  children: ReactNode;
  external?: boolean;
  className?: string;
}) {
  const cls = `btn btn-${variant} ${size ? `btn-${size}` : ''} ${block ? 'btn-block' : ''} ${className}`;
  if (external)
    return (
      <a href={to} className={cls} target="_blank" rel="noopener noreferrer">
        {Icon && <Icon aria-hidden />}
        {children}
      </a>
    );
  return (
    <Link to={to} className={cls}>
      {Icon && <Icon aria-hidden />}
      {children}
    </Link>
  );
}

export function Spinner() {
  return <span className="spinner" role="status" aria-label="loading" />;
}

export function Loading({ text }: { text?: string }) {
  const { t } = useI18n();
  return (
    <div className="loading-block">
      <Spinner />
      <span>{text ?? t('common.loading')}</span>
    </div>
  );
}

export function SkeletonCards({ count = 3, height = 140 }: { count?: number; height?: number }) {
  return (
    <div className="grid grid-3">
      {Array.from({ length: count }).map((_, i) => (
        <div key={i} className="skeleton" style={{ height }} />
      ))}
    </div>
  );
}

export function EmptyState({ icon: Icon = Inbox, title, text, action }: { icon?: LucideIcon; title: string; text?: string; action?: ReactNode }) {
  return (
    <div className="empty">
      <div className="empty-icon">
        <Icon />
      </div>
      <h3>{title}</h3>
      {text && <p className="small">{text}</p>}
      {action}
    </div>
  );
}

export function ErrorState({ error, onRetry }: { error: unknown; onRetry?: () => void }) {
  const { t } = useI18n();
  const errText = useErrorText();
  return (
    <div className="empty">
      <div className="empty-icon" style={{ background: 'var(--c-danger-50)', color: 'var(--c-danger)' }}>
        <AlertTriangle />
      </div>
      <h3>{errText(error)}</h3>
      {onRetry && (
        <Button variant="secondary" onClick={onRetry}>
          {t('common.retry')}
        </Button>
      )}
    </div>
  );
}

export function Alert({ kind = 'info', title, children }: { kind?: 'info' | 'success' | 'warning' | 'danger'; title?: string; children?: ReactNode }) {
  const Icon = { info: Info, success: CheckCircle2, warning: AlertTriangle, danger: XCircle }[kind];
  return (
    <div className={`alert ${kind}`} role={kind === 'danger' ? 'alert' : undefined}>
      <Icon aria-hidden />
      <div>
        {title && <div className="alert-title">{title}</div>}
        {children}
      </div>
    </div>
  );
}

export function Card({ children, className = '', title, actions, id }: { children: ReactNode; className?: string; title?: ReactNode; actions?: ReactNode; id?: string }) {
  return (
    <section className={`card ${className}`} id={id}>
      {(title || actions) && (
        <div className="card-header">
          {typeof title === 'string' ? <h3>{title}</h3> : title}
          {actions && <div className="row page-actions">{actions}</div>}
        </div>
      )}
      {children}
    </section>
  );
}

export function PageHead({ title, subtitle, actions, crumbs }: { title: string; subtitle?: string; actions?: ReactNode; crumbs?: { to?: string; label: string }[] }) {
  return (
    <>
      {crumbs && <Breadcrumbs items={crumbs} />}
      <div className="page-head">
        <div className="grow">
          <h1>{title}</h1>
          {subtitle && <p>{subtitle}</p>}
        </div>
        {actions && <div className="row">{actions}</div>}
      </div>
    </>
  );
}

export function Breadcrumbs({ items }: { items: { to?: string; label: string }[] }) {
  return (
    <nav className="breadcrumbs" aria-label="breadcrumb">
      {items.map((it, i) => (
        <span key={i} className="row" style={{ gap: 6 }}>
          {i > 0 && <ChevronRight aria-hidden />}
          {it.to ? <Link to={it.to}>{it.label}</Link> : <span aria-current="page">{it.label}</span>}
        </span>
      ))}
    </nav>
  );
}

export function Pagination({ page, perPage, total, onPage }: { page: number; perPage: number; total: number; onPage: (p: number) => void }) {
  const { t } = useI18n();
  const pages = Math.max(1, Math.ceil(total / perPage));
  if (total <= perPage) return null;
  return (
    <div className="pagination">
      <span>{t('common.showing', { from: (page - 1) * perPage + 1, to: Math.min(total, page * perPage), total })}</span>
      <div className="row">
        <Button variant="secondary" size="sm" icon={ChevronLeft} disabled={page <= 1} onClick={() => onPage(page - 1)}>
          {t('common.previous')}
        </Button>
        <span>{t('common.page', { page, pages })}</span>
        <Button variant="secondary" size="sm" disabled={page >= pages} onClick={() => onPage(page + 1)}>
          {t('common.next')}
          <ChevronRight />
        </Button>
      </div>
    </div>
  );
}

export function Tabs<T extends string>({ value, onChange, items }: { value: T; onChange: (v: T) => void; items: { value: T; label: string; count?: number }[] }) {
  return (
    <div className="tabs" role="tablist">
      {items.map((it) => (
        <button key={it.value} role="tab" aria-selected={value === it.value} className={`tab ${value === it.value ? 'active' : ''}`} onClick={() => onChange(it.value)}>
          {it.label}
          {it.count !== undefined && it.count > 0 && <span className="badge plain neutral" style={{ marginLeft: 6 }}>{it.count}</span>}
        </button>
      ))}
    </div>
  );
}

// ------------------------------------------------------------------ badges

const STATUS_KIND: Record<AppStatus, string> = {
  draft: 'neutral',
  received: 'info',
  in_progress: 'violet',
  awaiting_info: 'warning',
  correction_required: 'danger',
  completed: 'success',
  on_hold: 'warning',
  closed: 'neutral',
  cancelled: 'neutral',
};
export function StatusBadge({ status }: { status: AppStatus }) {
  const { t } = useI18n();
  return <span className={`badge ${STATUS_KIND[status] ?? ''}`}>{t(`status.${status}`)}</span>;
}

const PAY_KIND: Record<PaymentStatus, string> = { unpaid: 'warning', stationery_paid: 'info', partial: 'info', paid: 'success', waived: 'neutral' };
export function PaymentBadge({ status }: { status: PaymentStatus }) {
  const { t } = useI18n();
  return <span className={`badge ${PAY_KIND[status] ?? ''}`}>{t(`payment.${status}`)}</span>;
}

// ------------------------------------------------------------------ modal & confirm

export function Modal({ open, onClose, title, children, footer, wide }: { open: boolean; onClose: () => void; title: string; children: ReactNode; footer?: ReactNode; wide?: boolean }) {
  const { t } = useI18n();
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    document.addEventListener('keydown', onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = prev;
    };
  }, [open, onClose]);
  if (!open) return null;
  // Portal to <body> so a modal opened inside a styled/animated section (e.g. the hero) is never clipped or re-coloured.
  return createPortal(
    <div className="modal-backdrop" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className={`modal ${wide ? 'wide' : ''}`} role="dialog" aria-modal="true" aria-label={title}>
        <div className="modal-header">
          <h2>{title}</h2>
          <button className="icon-btn" onClick={onClose} aria-label={t('common.close')}>
            <X />
          </button>
        </div>
        <div className="modal-body">{children}</div>
        {footer && <div className="modal-footer">{footer}</div>}
      </div>
    </div>,
    document.body,
  );
}

export function useConfirm() {
  const { t } = useI18n();
  const [state, setState] = useState<{ title: string; text?: string; danger?: boolean; confirmLabel?: string; resolve: (v: boolean) => void } | null>(null);
  const confirm = useCallback(
    (opts: { title: string; text?: string; danger?: boolean; confirmLabel?: string }) =>
      new Promise<boolean>((resolve) => setState({ ...opts, resolve })),
    [],
  );
  const close = (v: boolean) => {
    state?.resolve(v);
    setState(null);
  };
  const dialog = (
    <Modal
      open={!!state}
      onClose={() => close(false)}
      title={state?.title ?? ''}
      footer={
        <>
          <Button variant="secondary" onClick={() => close(false)}>
            {t('common.cancel')}
          </Button>
          <Button variant={state?.danger ? 'danger' : 'primary'} onClick={() => close(true)}>
            {state?.confirmLabel ?? t('common.confirm')}
          </Button>
        </>
      }
    >
      <p className="muted mb-0">{state?.text ?? t('common.areYouSure')}</p>
    </Modal>
  );
  return { confirm, dialog };
}

// ------------------------------------------------------------------ form controls

export function FieldShell({
  id,
  label,
  required,
  optional,
  help,
  error,
  children,
  className = '',
  extra,
}: {
  id: string;
  label?: ReactNode;
  required?: boolean;
  optional?: boolean;
  help?: ReactNode;
  error?: string | null;
  children: ReactNode;
  className?: string;
  extra?: ReactNode;
}) {
  const { t } = useI18n();
  return (
    <div className={`field ${className}`}>
      {label && (
        <label className="field-label" htmlFor={id}>
          {label}
          {required && <span className="req" aria-hidden>*</span>}
          {optional && <span className="opt">{t('common.optional')}</span>}
          {extra}
        </label>
      )}
      {children}
      {help && !error && (
        <span className="field-help" id={`${id}-help`}>
          {help}
        </span>
      )}
      {error && (
        <span className="field-error" id={`${id}-err`} role="alert">
          <AlertCircle size={14} aria-hidden />
          {error}
        </span>
      )}
    </div>
  );
}

type InputProps = InputHTMLAttributes<HTMLInputElement> & { label?: ReactNode; help?: ReactNode; error?: string | null; optional?: boolean; wrapClass?: string };
export function TextField({ label, help, error, optional, required, wrapClass, id, ...rest }: InputProps) {
  const auto = useId();
  const fid = id ?? auto;
  return (
    <FieldShell id={fid} label={label} help={help} error={error} required={required} optional={optional} className={wrapClass}>
      <input id={fid} className="input" aria-invalid={!!error} aria-describedby={error ? `${fid}-err` : help ? `${fid}-help` : undefined} required={required} {...rest} />
    </FieldShell>
  );
}

export function PasswordField({ label, help, error, required, wrapClass, id, ...rest }: InputProps) {
  const { t } = useI18n();
  const auto = useId();
  const fid = id ?? auto;
  const [show, setShow] = useState(false);
  return (
    <FieldShell id={fid} label={label} help={help} error={error} required={required} className={wrapClass}>
      <div className="input-group">
        <input id={fid} className="input" type={show ? 'text' : 'password'} aria-invalid={!!error} required={required} {...rest} />
        <button type="button" className="icon-btn" onClick={() => setShow((s) => !s)} aria-label={show ? t('auth.hidePassword') : t('auth.showPassword')}>
          {show ? <EyeOff /> : <Eye />}
        </button>
      </div>
    </FieldShell>
  );
}

type SelectProps = SelectHTMLAttributes<HTMLSelectElement> & { label?: ReactNode; help?: ReactNode; error?: string | null; optional?: boolean; wrapClass?: string; placeholder?: string };
export function SelectField({ label, help, error, optional, required, wrapClass, id, children, placeholder, ...rest }: SelectProps) {
  const auto = useId();
  const fid = id ?? auto;
  return (
    <FieldShell id={fid} label={label} help={help} error={error} required={required} optional={optional} className={wrapClass}>
      <select id={fid} className="select" aria-invalid={!!error} required={required} {...rest}>
        {placeholder !== undefined && <option value="">{placeholder}</option>}
        {children}
      </select>
    </FieldShell>
  );
}

type TextareaProps = TextareaHTMLAttributes<HTMLTextAreaElement> & { label?: ReactNode; help?: ReactNode; error?: string | null; optional?: boolean; wrapClass?: string };
export function TextareaField({ label, help, error, optional, required, wrapClass, id, ...rest }: TextareaProps) {
  const auto = useId();
  const fid = id ?? auto;
  return (
    <FieldShell id={fid} label={label} help={help} error={error} required={required} optional={optional} className={wrapClass}>
      <textarea id={fid} className="textarea" aria-invalid={!!error} required={required} {...rest} />
    </FieldShell>
  );
}

export function Checkbox({ checked, onChange, children, id }: { checked: boolean; onChange: (v: boolean) => void; children: ReactNode; id?: string }) {
  return (
    <label className="checkbox-line" htmlFor={id}>
      <input id={id} type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} />
      <span>{children}</span>
    </label>
  );
}

// ------------------------------------------------------------------ brand

export function Logo({ light, to = '/', compact }: { light?: boolean; to?: string; compact?: boolean }) {
  const { settings } = useSite();
  const name = settings?.brand_name || 'Mediator Hamza';
  return (
    <Link to={to} className={`logo ${light ? 'light' : ''}`} aria-label={name}>
      <img className="logo-img" src={settings?.logo_file_id ? mediaUrl(settings.logo_file_id) : '/brand/logo-160.png'} alt="" width={40} height={40} />
      {!compact && (
        <span className="logo-text">
          <strong>{name}</strong>
        </span>
      )}
    </Link>
  );
}

const SERVICE_ICONS: Record<string, LucideIcon> = {
  'graduation-cap': GraduationCap,
  school: School,
  baby: Baby,
  'file-heart': FileHeart,
  'map-pin': MapPin,
  'badge-check': BadgeCheck,
  scale: Scale,
};
export function ServiceIcon({ name, className = 'icon-tile' }: { name?: string | null; className?: string }) {
  const Icon = SERVICE_ICONS[name ?? ''] ?? FileText;
  return (
    <span className={className} aria-hidden>
      <Icon />
    </span>
  );
}

export type StatColor = 'blue' | 'yellow' | 'green' | 'red' | 'purple' | 'navy' | 'teal' | 'orange';
const TONE_COLOR: Record<string, StatColor> = { success: 'green', warning: 'yellow', danger: 'red', navy: 'navy' };

/** Coloured KPI card; pass `to` to make it a link (e.g. to a filtered list). */
export function Stat({ icon: Icon, label, value, tone, color, to }: { icon: LucideIcon; label: string; value: ReactNode; tone?: 'success' | 'warning' | 'danger' | 'navy'; color?: StatColor; to?: string }) {
  const c = color ?? (tone ? TONE_COLOR[tone] : 'blue');
  const body = (
    <>
      <span className="stat-icon">
        <Icon />
      </span>
      <div style={{ minWidth: 0 }}>
        <div className="stat-value">{value}</div>
        <div className="stat-label">{label}</div>
      </div>
    </>
  );
  return to ? (
    <Link to={to} className={`card stat stat-${c} stat-link`}>
      {body}
    </Link>
  ) : (
    <div className={`card stat stat-${c}`}>{body}</div>
  );
}

export function useDocumentTitle(title: string) {
  const { settings } = useSite();
  useEffect(() => {
    const brand = settings?.brand_name || 'Mediator Hamza';
    document.title = title ? `${title} · ${brand}` : brand;
  }, [title, settings?.brand_name]);
}
