import { useCallback, useEffect, useState } from 'react';
import { Navigate, Outlet, useLocation } from 'react-router-dom';
import {
  Bell,
  BookOpen,
  Briefcase,
  Building2,
  CalendarClock,
  FileDown,
  FilePen,
  FileText,
  HelpCircle,
  Inbox,
  LayoutDashboard,
  Megaphone,
  MessageCircle,
  ScrollText,
  Settings,
  Shield,
  ShieldCheck,
  Star,
  Tags,
  UserCog,
  Users,
} from 'lucide-react';
import { useI18n } from '@/i18n';
import { useAuth } from '@/context/AuthContext';
import { api } from '@/lib/api';
import { Loading } from '@/components/ui';
import Shell, { usePoll, type NavItem } from './Shell';

export default function AdminLayout() {
  const { user, ready, can } = useAuth();
  const { t } = useI18n();
  const location = useLocation();
  const [badges, setBadges] = useState({ messages: 0, contact: 0, newApps: 0, drafts: 0 });

  const refresh = useCallback(() => {
    if (!user?.is_staff || !can('dashboard.view')) return;
    api
      .poll<{ unanswered_messages: number; contact_unhandled: number; new_applications: number; drafts: number }>('/admin/dashboard')
      .then((d) => setBadges({ messages: d.unanswered_messages, contact: d.contact_unhandled, newApps: d.new_applications, drafts: d.drafts }))
      .catch(() => undefined);
  }, [user, can]);
  usePoll(refresh, 60000);
  // Opening an application marks it seen: refresh the badge when navigating.
  useEffect(() => {
    if (location.pathname.startsWith('/admin/maombi')) refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [location.pathname]);

  if (!ready) return <Loading />;
  if (!user || !user.is_staff) return <Navigate to={`/admin/login?next=${encodeURIComponent(location.pathname)}`} replace />;

  const main = t('admin.nav.sectionMain');
  const content = t('admin.nav.sectionContent');
  const system = t('admin.nav.sectionSystem');
  const all: (NavItem & { perm?: string })[] = [
    { to: '/admin', label: t('admin.nav.dashboard'), icon: LayoutDashboard, end: true, section: main, perm: 'dashboard.view' },
    { to: '/admin/maombi', label: t('admin.nav.applications'), icon: FileText, section: main, perm: 'applications.view', count: badges.newApps },
    { to: '/admin/rasimu', label: t('admin.nav.drafts'), icon: FilePen, section: main, perm: 'applications.view', count: badges.drafts, countTone: 'muted' },
    { to: '/admin/ujumbe', label: t('admin.nav.messages'), icon: MessageCircle, section: main, perm: 'messages.manage', count: badges.messages },
    { to: '/admin/watumiaji', label: t('admin.nav.users'), icon: Users, section: main, perm: 'users.view' },
    { to: '/admin/arifa', label: t('admin.nav.notifications'), icon: Bell, section: main, perm: 'notifications.send' },
    { to: '/admin/ripoti', label: t('admin.nav.reports'), icon: FileDown, section: main, perm: 'reports.export' },
    { to: '/admin/mawasiliano', label: t('admin.nav.contact'), icon: Inbox, section: main, perm: 'contact.view', count: badges.contact },
    { to: '/admin/huduma', label: t('admin.nav.services'), icon: Briefcase, section: content, perm: 'services.manage' },
    { to: '/admin/maudhui/articles', label: t('admin.nav.articles'), icon: BookOpen, section: content, perm: 'content.manage' },
    { to: '/admin/maudhui/institutions', label: t('admin.nav.institutions'), icon: Building2, section: content, perm: 'content.manage' },
    { to: '/admin/maudhui/guidebooks', label: t('admin.nav.guidebooks'), icon: ScrollText, section: content, perm: 'content.manage' },
    { to: '/admin/maudhui/deadlines', label: t('admin.nav.deadlines'), icon: CalendarClock, section: content, perm: 'content.manage' },
    { to: '/admin/maudhui/announcements', label: t('admin.nav.announcements'), icon: Megaphone, section: content, perm: 'content.manage' },
    { to: '/admin/maudhui/faqs', label: t('admin.nav.faqs'), icon: HelpCircle, section: content, perm: 'content.manage' },
    { to: '/admin/maudhui/testimonials', label: t('admin.nav.testimonials'), icon: Star, section: content, perm: 'content.manage' },
    { to: '/admin/maudhui/whatsapp_groups', label: t('admin.nav.groups'), icon: MessageCircle, section: content, perm: 'content.manage' },
    { to: '/admin/maudhui/categories', label: t('admin.nav.categories'), icon: Tags, section: content, perm: 'content.manage' },
    { to: '/admin/mipangilio', label: t('admin.nav.settings'), icon: Settings, section: system, perm: 'settings.manage' },
    { to: '/admin/wahudumu', label: t('admin.nav.staff'), icon: UserCog, section: system, perm: 'staff.manage' },
    { to: '/admin/audit', label: t('admin.nav.audit'), icon: Shield, section: system, perm: 'audit.view' },
    { to: '/admin/usalama', label: t('admin.nav.security'), icon: ShieldCheck, section: system },
  ];
  const nav = all.filter((n) => !n.perm || can(n.perm));
  const pickNav = (to: string, label: string) => nav.filter((n) => n.to === to).map((n) => ({ ...n, label }));
  const bottom = [
    ...pickNav('/admin', t('nav.home')),
    ...pickNav('/admin/maombi', t('admin.nav.applications')),
    ...pickNav('/admin/ujumbe', 'Chat'),
    ...pickNav('/admin/watumiaji', t('admin.nav.users')),
    ...pickNav('/admin/mipangilio', t('bottom.settings')),
  ];

  return (
    <Shell nav={nav} bottomNav={bottom.length ? bottom : undefined} dark homeTo="/admin" passwordTo="/admin/usalama" subtitle={t(`admin.role.${user.role}` as 'admin.role.admin')}>
      <Outlet />
    </Shell>
  );
}

