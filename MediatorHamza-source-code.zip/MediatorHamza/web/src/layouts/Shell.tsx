import { useEffect, useRef, useState, type ReactNode } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import { Bell, Globe, KeyRound, LogOut, Menu, X, type LucideIcon } from 'lucide-react';
import { useI18n } from '@/i18n';
import { useAuth } from '@/context/AuthContext';
import { Logo } from '@/components/ui';
import { LangSwitch } from '@/components/Shared';
import SessionTimer from '@/components/SessionTimer';
import { initials } from '@/lib/format';

export interface NavItem {
  to: string;
  label: string;
  icon: LucideIcon;
  count?: number;
  end?: boolean;
  section?: string;
  /** muted = informational count (grey) instead of an alert (red). */
  countTone?: 'muted';
}

/** Sidebar + topbar shell used by both the applicant app and the admin portal. */
export default function Shell({
  nav,
  bottomNav,
  dark,
  homeTo,
  passwordTo,
  bellTo,
  bellCount,
  children,
  subtitle,
}: {
  nav: NavItem[];
  bottomNav?: NavItem[];
  dark?: boolean;
  homeTo: string;
  passwordTo?: string;
  bellTo?: string;
  bellCount?: number;
  children: ReactNode;
  subtitle?: string;
}) {
  const { t } = useI18n();
  const { user, logout } = useAuth();
  const [open, setOpen] = useState(false);
  const { pathname } = useLocation();
  useEffect(() => setOpen(false), [pathname]);
  // Lock the page behind the mobile drawer so it never scrolls or shifts.
  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = prev;
    };
  }, [open]);

  const navList = (
    <nav className="side-nav">
      {nav.map((n, i) => (
        <div key={n.to} style={{ display: 'contents' }}>
          {n.section && (i === 0 || nav[i - 1].section !== n.section) && <div className="nav-section">{n.section}</div>}
          <NavLink to={n.to} end={n.end}>
            <n.icon />
            <span className="grow">{n.label}</span>
            {!!n.count && <span className={`count ${n.countTone ?? ''}`}>{n.count}</span>}
          </NavLink>
        </div>
      ))}
    </nav>
  );

  const userBox = (
    <div className="user-chip">
      <span className="avatar">{initials(user?.first_name, user?.second_name)}</span>
      <div className="grow" style={{ minWidth: 0 }}>
        <div className="small" style={{ fontWeight: 600, color: dark ? '#fff' : undefined }}>
          {user?.first_name} {user?.second_name}
        </div>
        {subtitle && <div className="xs" style={{ color: dark ? 'rgba(255,255,255,.6)' : 'var(--c-muted)' }}>{subtitle}</div>}
      </div>
      {passwordTo && (
        <Link to={passwordTo} className="icon-btn" aria-label={t('profile.changePassword')} title={t('profile.changePassword')} style={dark ? { color: '#fff' } : undefined}>
          <KeyRound />
        </Link>
      )}
      <button className="icon-btn" onClick={() => void logout()} aria-label={t('nav.logout')} title={t('nav.logout')} style={dark ? { color: '#fff' } : undefined}>
        <LogOut />
      </button>
    </div>
  );

  const siteLink = (
    <Link to="/" className={`site-link ${dark ? 'dark' : ''}`}>
      <Globe /> {t('nav.website')}
    </Link>
  );

  return (
    <div className={`shell ${bottomNav ? 'has-bottom-nav' : ''}`}>
      <aside className={`sidebar ${dark ? 'dark' : ''}`}>
        <div className="sidebar-head">
          <Logo light={dark} to={homeTo} />
        </div>
        {navList}
        <div className="sidebar-foot">
          <div className="side-lang">
            <LangSwitch />
          </div>
          {siteLink}
          {userBox}
        </div>
      </aside>

      {open && (
        <>
          <div className="drawer-backdrop" onClick={() => setOpen(false)} />
          <aside className={`drawer sidebar ${dark ? 'dark' : ''}`} style={{ display: 'flex' }}>
            <div className="drawer-head" style={dark ? { borderColor: 'rgba(255,255,255,.12)' } : undefined}>
              <Logo light={dark} to={homeTo} />
              <button className="icon-btn" onClick={() => setOpen(false)} aria-label={t('common.close')} style={dark ? { color: '#fff' } : undefined}>
                <X />
              </button>
            </div>
            {navList}
            <div className="sidebar-foot">
              <div className="side-lang">
                <LangSwitch />
              </div>
              {siteLink}
              {userBox}
            </div>
          </aside>
        </>
      )}

      <div className="shell-main">
        <header className="topbar">
          <button className="icon-btn menu-toggle" onClick={() => setOpen(true)} aria-label={t('common.menu')}>
            <Menu />
          </button>
          <div className="grow-space" />
          <SessionTimer loginTo={dark ? '/admin/login' : '/login'} />
          <Link to="/" className="icon-btn" aria-label={t('nav.website')} title={t('nav.website')}>
            <Globe />
          </Link>
          {bellTo && (
            <Link to={bellTo} className="icon-btn" aria-label={t('nav.notifications')}>
              <Bell />
              {!!bellCount && <span className="dot-badge">{bellCount > 99 ? '99+' : bellCount}</span>}
            </Link>
          )}
        </header>
        <div className="page">{children}</div>
      </div>

      {bottomNav && (
        <nav className="bottom-nav no-print" aria-label="Quick">
          {bottomNav.map((n) => (
            <NavLink key={n.to} to={n.to} end={n.end}>
              <n.icon />
              {n.label}
              {!!n.count && <span className="dot-badge">{n.count}</span>}
            </NavLink>
          ))}
        </nav>
      )}
    </div>
  );
}

/** Poll an endpoint periodically while the tab is visible. */
export function usePoll(fn: () => void, ms: number) {
  const ref = useRef(fn);
  ref.current = fn;
  useEffect(() => {
    ref.current();
    const id = setInterval(() => {
      if (document.visibilityState === 'visible') ref.current();
    }, ms);
    const onVis = () => document.visibilityState === 'visible' && ref.current();
    document.addEventListener('visibilitychange', onVis);
    return () => {
      clearInterval(id);
      document.removeEventListener('visibilitychange', onVis);
    };
  }, [ms]);
}
