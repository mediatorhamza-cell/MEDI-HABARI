import { createContext, useCallback, useContext, useRef, useState } from 'react';
import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { Bell, Shield, FileText, HelpCircle, History, LayoutDashboard, MessageCircle, PlusCircle, User, Users } from 'lucide-react';
import { useI18n } from '@/i18n';
import { useAuth } from '@/context/AuthContext';
import { api } from '@/lib/api';
import { Loading } from '@/components/ui';
import { AssistantWidget, InstallPrompt } from '@/components/Shared';
import Shell, { usePoll } from './Shell';

interface Counts {
  unread: number;
  unread_messages: number;
  latest_id: number;
  new: { id: number; title_sw: string; title_en: string | null; body_sw: string; body_en: string | null; link: string | null }[];
}

const CountsContext = createContext<{ unread: number; messages: number; refresh: () => void }>({ unread: 0, messages: 0, refresh: () => undefined });
export const useCounts = () => useContext(CountsContext);

export default function AppLayout() {
  const { user, ready } = useAuth();
  const { t, pick } = useI18n();
  const location = useLocation();
  const [counts, setCounts] = useState({ unread: 0, messages: 0 });
  const lastId = useRef(0);

  const refresh = useCallback(() => {
    if (!user) return;
    api
      .poll<Counts>(`/me/notifications/counts?since=${lastId.current}`)
      .then((c) => {
        setCounts({ unread: c.unread, messages: c.unread_messages });
        // Show browser notifications for new items when the user allowed them.
        if (lastId.current > 0 && 'Notification' in window && Notification.permission === 'granted') {
          c.new.forEach((n) => {
            const notif = new Notification(pick(n.title_sw, n.title_en), { body: pick(n.body_sw, n.body_en), icon: '/icons/icon-192.png', tag: `n${n.id}` });
            notif.onclick = () => {
              window.focus();
              if (n.link) window.location.href = n.link;
            };
          });
        }
        lastId.current = c.latest_id;
      })
      .catch(() => undefined);
  }, [user, pick]);
  usePoll(refresh, 45000);

  if (!ready) return <Loading />;
  if (!user) return <Navigate to={`/login?next=${encodeURIComponent(location.pathname + location.search)}`} replace />;

  const nav = [
    { to: '/app', label: t('nav.dashboard'), icon: LayoutDashboard, end: true },
    { to: '/app/omba', label: t('nav.newApplication'), icon: PlusCircle },
    { to: '/app/maombi', label: t('nav.myApplications'), icon: FileText },
    { to: '/app/ujumbe', label: t('nav.messages'), icon: MessageCircle, count: counts.messages },
    { to: '/app/arifa', label: t('nav.notifications'), icon: Bell, count: counts.unread },
    { to: '/app/historia', label: t('nav.history'), icon: History },
    { to: '/app/makundi', label: t('nav.groups'), icon: Users },
    { to: '/app/wasifu', label: t('nav.profile'), icon: User },
    { to: '/app/msaada', label: t('nav.help'), icon: HelpCircle },
    ...(user.is_staff ? [{ to: '/admin', label: t('admin.portal'), icon: Shield }] : []),
  ];
  const bottom = [nav[0], nav[2], nav[1], nav[3], nav[7]].map((n) => ({ ...n, label: n === nav[1] ? t('common.requestService').split(' ')[0] : n.label.split(' ')[0] }));

  return (
    <CountsContext.Provider value={{ ...counts, refresh }}>
      <Shell nav={nav} bottomNav={bottom} homeTo="/app" passwordTo="/app/wasifu" bellTo="/app/arifa" bellCount={counts.unread} subtitle={user.phone}>
        <Outlet />
        {!/\/jaza$|\/ujumbe\/\d+$/.test(location.pathname) && <AssistantWidget />}
        <InstallPrompt />
      </Shell>
    </CountsContext.Provider>
  );
}
