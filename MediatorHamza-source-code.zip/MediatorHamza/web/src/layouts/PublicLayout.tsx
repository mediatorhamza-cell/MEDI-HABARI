import { useEffect, useState } from 'react';
import { Link, NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import {
  Bell,
  BookOpen,
  UserCog,
  Building2,
  CalendarClock,
  FileText,
  Shield,
  User,
  HelpCircle,
  Home,
  Info,
  LayoutDashboard,
  Megaphone,
  Menu,
  Phone,
  Search,
  Briefcase,
  Star,
  X,
} from 'lucide-react';
import { useI18n, type TKey } from '@/i18n';
import { useAuth } from '@/context/AuthContext';
import { Logo, LinkButton, useAsync } from '@/components/ui';
import { api } from '@/lib/api';
import type { Announcement } from '@/lib/types';
import { AssistantWidget, InstallPrompt, LangSwitch } from '@/components/Shared';
import { PreviewBanner } from '@/pages/public/Launch';

export const PUBLIC_NAV: { to: string; key: TKey; icon: typeof Home }[] = [
  { to: '/', key: 'nav.home', icon: Home },
  { to: '/huduma', key: 'nav.services', icon: Briefcase },
  { to: '/elimu', key: 'nav.education', icon: BookOpen },
  { to: '/vyuo', key: 'nav.institutions', icon: Building2 },
  { to: '/miongozo', key: 'nav.guides', icon: FileText },
  { to: '/deadlines', key: 'nav.deadlines', icon: CalendarClock },
  { to: '/matangazo', key: 'nav.announcements', icon: Megaphone },
  { to: '/shuhuda', key: 'nav.testimonials', icon: Star },
  { to: '/faq', key: 'nav.faq', icon: HelpCircle },
  { to: '/kuhusu', key: 'nav.about', icon: Info },
  { to: '/mawasiliano', key: 'nav.contact', icon: Phone },
];

export function AccountButtons({ block }: { block?: boolean }) {
  const { t } = useI18n();
  const { user } = useAuth();
  if (user)
    return (
      <LinkButton to={user.is_staff ? '/admin' : '/app'} icon={LayoutDashboard} block={block} size={block ? undefined : 'sm'}>
        {t('nav.goToDashboard')}
      </LinkButton>
    );
  return (
    <>
      {!block && (
        <Link to="/admin/login" className="icon-btn" aria-label={t('nav.staffAccount')} title={t('nav.staffAccount')}>
          <UserCog />
        </Link>
      )}
      <LinkButton to="/login" variant="secondary" block={block} size={block ? undefined : 'sm'}>
        {t('nav.login')}
      </LinkButton>
      <LinkButton to="/register" block={block} size={block ? undefined : 'sm'}>
        {t('nav.register')}
      </LinkButton>
    </>
  );
}

export default function PublicLayout() {
  const { t } = useI18n();
  const { user } = useAuth();
  const [open, setOpen] = useState(false);
  const { pathname } = useLocation();
  const navigate = useNavigate();

  useEffect(() => setOpen(false), [pathname]);
  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = prev;
    };
  }, [open]);

  // Public notices: the bell shows how many announcements are newer than the last visit to /matangazo.
  const { data: notices } = useAsync(() => api.get<Announcement[]>('/announcements'));
  const [seen, setSeen] = useState(() => {
    try {
      return localStorage.getItem('mediator.noticesSeen') ?? '';
    } catch {
      return '';
    }
  });
  useEffect(() => {
    if (pathname !== '/matangazo' || !notices?.length) return;
    const latest = notices.map((n) => n.published_at).sort().pop() ?? '';
    setSeen(latest);
    try {
      localStorage.setItem('mediator.noticesSeen', latest);
    } catch {
      /* ignore */
    }
  }, [pathname, notices]);
  const unseen = (notices ?? []).filter((n) => n.published_at > seen).length;

  const mainLinks = PUBLIC_NAV.filter((n) => ['/', '/huduma', '/elimu', '/vyuo', '/miongozo', '/deadlines', '/mawasiliano'].includes(n.to));

  return (
    <div className="has-bottom-nav public-shell">
      <a href="#main" className="sr-only">
        Skip to content
      </a>
      <PreviewBanner />
      <header className="site-header">
        <div className="container">
          <button className="icon-btn menu-toggle" onClick={() => setOpen(true)} aria-label={t('common.menu')} aria-expanded={open}>
            <Menu />
          </button>
          <span className="header-logo">
            <Logo />
          </span>
          <nav className="main-nav" aria-label="Main">
            {mainLinks.map((n) => (
              <NavLink key={n.to} to={n.to} end={n.to === '/'}>
                {t(n.key)}
              </NavLink>
            ))}
          </nav>
          <div className="header-actions">
            <button className="icon-btn" onClick={() => navigate('/tafuta')} aria-label={t('nav.search')}>
              <Search />
            </button>
            <Link to="/matangazo" className="icon-btn" aria-label={t('nav.announcements')} title={t('nav.announcements')}>
              <Bell />
              {unseen > 0 && <span className="dot-badge">{unseen > 9 ? '9+' : unseen}</span>}
            </Link>
            <span className="header-lang">
              <LangSwitch />
            </span>
            <span className="desktop-only row" style={{ gap: 8 }}>
              <AccountButtons />
            </span>
          </div>
        </div>
      </header>

      {open && (
        <>
          <div className="drawer-backdrop" onClick={() => setOpen(false)} />
          <aside className="drawer drawer-dark" aria-label={t('common.menu')}>
            <div className="drawer-head">
              <Logo light />
              <button className="icon-btn" onClick={() => setOpen(false)} aria-label={t('common.close')}>
                <X />
              </button>
            </div>
            <nav>
              {[...PUBLIC_NAV, { to: '/faragha', key: 'nav.privacy' as TKey, icon: Shield }, { to: '/masharti', key: 'nav.terms' as TKey, icon: FileText }].map((n) => (
                <NavLink key={n.to} to={n.to} end={n.to === '/'}>
                  <n.icon />
                  {t(n.key)}
                </NavLink>
              ))}
              <NavLink to="/admin/login">
                <UserCog />
                {t('nav.staffAccount')}
              </NavLink>
            </nav>
            <div className="drawer-foot">
              <div className="side-lang">
                <LangSwitch />
              </div>
              <AccountButtons block />
            </div>
          </aside>
        </>
      )}

      <main id="main">
        <Outlet />
      </main>

      <nav className="bottom-nav no-print" aria-label="Quick">
        <NavLink to="/" end>
          <Home />
          {t('nav.home')}
        </NavLink>
        <NavLink to="/huduma">
          <Briefcase />
          {t('bottom.services')}
        </NavLink>
        <NavLink to="/elimu">
          <BookOpen />
          {t('bottom.education')}
        </NavLink>
        <NavLink to="/vyuo">
          <Building2 />
          {t('bottom.institutions')}
        </NavLink>
        <NavLink to={user ? (user.is_staff ? '/admin' : '/app') : '/login'}>
          {user ? <LayoutDashboard /> : <User />}
          {user ? t('bottom.account') : t('nav.login')}
        </NavLink>
      </nav>
      <AssistantWidget />
      <InstallPrompt />
    </div>
  );
}
