import { lazy, Suspense, type ReactNode } from 'react';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { I18nProvider } from '@/i18n';
import { AuthProvider } from '@/context/AuthContext';
import { SiteProvider } from '@/context/SiteContext';
import { ToastProvider } from '@/context/ToastContext';
import { Loading } from '@/components/ui';
import { PageTracker } from '@/components/Shared';
import { SiteGate } from '@/pages/public/Launch';
import PublicLayout from '@/layouts/PublicLayout';
import Home from '@/pages/public/Home';
import {
  AnnouncementsPage,
  ArticlePage,
  ContactPage,
  DeadlinesPage,
  EducationPage,
  FaqPage,
  TestimonialsPage,
  GuidesPage,
  InstitutionsPage,
  NotFoundPage,
  SearchPage,
  ServiceDetailPage,
  ServicesPage,
  TextPage,
} from '@/pages/public/Content';
import { AdminLoginPage, ForgotPasswordPage, InstallPage, LoginPage, RegisterPage, ResetPasswordPage } from '@/pages/public/Auth';

// Authenticated areas are code-split so the public site stays light on mobile data.
const AppLayout = lazy(() => import('@/layouts/AppLayout'));
const Dashboard = lazy(() => import('@/pages/app/Dashboard'));
const AppPages = {
  Applications: lazy(() => import('@/pages/app/Applications').then((m) => ({ default: m.ApplicationsPage }))),
  History: lazy(() => import('@/pages/app/Applications').then((m) => ({ default: () => <m.ApplicationsPage history /> }))),
  New: lazy(() => import('@/pages/app/Applications').then((m) => ({ default: m.NewApplicationPage }))),
  Start: lazy(() => import('@/pages/app/Applications').then((m) => ({ default: m.StartApplicationPage }))),
  Form: lazy(() => import('@/pages/app/Applications').then((m) => ({ default: m.ApplicationFormPage }))),
  Detail: lazy(() => import('@/pages/app/Applications').then((m) => ({ default: m.ApplicationDetailPage }))),
  Notifications: lazy(() => import('@/pages/app/Other').then((m) => ({ default: m.NotificationsPage }))),
  Conversations: lazy(() => import('@/pages/app/Other').then((m) => ({ default: m.ConversationsPage }))),
  Thread: lazy(() => import('@/pages/app/Other').then((m) => ({ default: () => <m.ChatThread base="/me/conversations" /> }))),
  Groups: lazy(() => import('@/pages/app/Other').then((m) => ({ default: m.GroupsPage }))),
  Profile: lazy(() => import('@/pages/app/Other').then((m) => ({ default: m.ProfilePage }))),
  Help: lazy(() => import('@/pages/app/Other').then((m) => ({ default: m.HelpPage }))),
};

const AdminLayout = lazy(() => import('@/layouts/AdminLayout'));
const Admin = {
  Dashboard: lazy(() => import('@/pages/admin/Dashboard')),
  Applications: lazy(() => import('@/pages/admin/Applications').then((m) => ({ default: m.AdminApplicationsPage }))),
  Drafts: lazy(() => import('@/pages/admin/Applications').then((m) => ({ default: m.AdminDraftsPage }))),
  Application: lazy(() => import('@/pages/admin/Applications').then((m) => ({ default: m.AdminApplicationDetailPage }))),
  Users: lazy(() => import('@/pages/admin/Users').then((m) => ({ default: m.UsersPage }))),
  User: lazy(() => import('@/pages/admin/Users').then((m) => ({ default: m.UserDetailPage }))),
  Staff: lazy(() => import('@/pages/admin/Users').then((m) => ({ default: m.StaffPage }))),
  Messages: lazy(() => import('@/pages/admin/Messages').then((m) => ({ default: m.AdminConversationsPage }))),
  Thread: lazy(() => import('@/pages/app/Other').then((m) => ({ default: () => <m.ChatThread base="/admin/conversations" admin /> }))),
  Notifications: lazy(() => import('@/pages/admin/Messages').then((m) => ({ default: m.AdminNotificationsPage }))),
  Contact: lazy(() => import('@/pages/admin/Messages').then((m) => ({ default: m.ContactMessagesPage }))),
  Services: lazy(() => import('@/pages/admin/Services')),
  Content: lazy(() => import('@/pages/admin/Content')),
  Reports: lazy(() => import('@/pages/admin/Reports')),
  Settings: lazy(() => import('@/pages/admin/Settings').then((m) => ({ default: m.SettingsPage }))),
  Audit: lazy(() => import('@/pages/admin/Settings').then((m) => ({ default: m.AuditPage }))),
  Security: lazy(() => import('@/pages/admin/Settings').then((m) => ({ default: m.SecurityPage }))),
};

const S = ({ children }: { children: ReactNode }) => <Suspense fallback={<Loading />}>{children}</Suspense>;

export default function App() {
  return (
    <I18nProvider>
      <ToastProvider>
        <SiteProvider>
          <AuthProvider>
            <BrowserRouter>
              <PageTracker />
              <Suspense fallback={<Loading />}>
                <SiteGate>
                <Routes>
                  <Route element={<PublicLayout />}>
                    <Route index element={<Home />} />
                    <Route path="huduma" element={<ServicesPage />} />
                    <Route path="huduma/:slug" element={<ServiceDetailPage />} />
                    <Route path="elimu" element={<EducationPage />} />
                    <Route path="elimu/:slug" element={<ArticlePage />} />
                    <Route path="vyuo" element={<InstitutionsPage />} />
                    <Route path="miongozo" element={<GuidesPage />} />
                    <Route path="deadlines" element={<DeadlinesPage />} />
                    <Route path="matangazo" element={<AnnouncementsPage />} />
                    <Route path="faq" element={<FaqPage />} />
                    <Route path="shuhuda" element={<TestimonialsPage />} />
                    <Route path="kuhusu" element={<TextPage kind="about" />} />
                    <Route path="faragha" element={<TextPage kind="privacy" />} />
                    <Route path="masharti" element={<TextPage kind="terms" />} />
                    <Route path="mawasiliano" element={<ContactPage />} />
                    <Route path="tafuta" element={<SearchPage />} />
                    <Route path="login" element={<LoginPage />} />
                    <Route path="register" element={<RegisterPage />} />
                    <Route path="forgot-password" element={<ForgotPasswordPage />} />
                    <Route path="reset-password" element={<ResetPasswordPage />} />
                    <Route path="*" element={<NotFoundPage />} />
                  </Route>

                  <Route path="app" element={<AppLayout />}>
                    <Route index element={<S><Dashboard /></S>} />
                    <Route path="omba" element={<S><AppPages.New /></S>} />
                    <Route path="omba/:code" element={<S><AppPages.Start /></S>} />
                    <Route path="maombi" element={<S><AppPages.Applications /></S>} />
                    <Route path="maombi/:id" element={<S><AppPages.Detail /></S>} />
                    <Route path="maombi/:id/jaza" element={<S><AppPages.Form /></S>} />
                    <Route path="historia" element={<S><AppPages.History /></S>} />
                    <Route path="arifa" element={<S><AppPages.Notifications /></S>} />
                    <Route path="ujumbe" element={<S><AppPages.Conversations /></S>} />
                    <Route path="ujumbe/:id" element={<S><AppPages.Thread /></S>} />
                    <Route path="makundi" element={<S><AppPages.Groups /></S>} />
                    <Route path="wasifu" element={<S><AppPages.Profile /></S>} />
                    <Route path="msaada" element={<S><AppPages.Help /></S>} />
                  </Route>

                  <Route path="admin/login" element={<AdminLoginPage />} />
                  <Route path="install" element={<InstallPage />} />
                  <Route path="admin" element={<AdminLayout />}>
                    <Route index element={<S><Admin.Dashboard /></S>} />
                    <Route path="maombi" element={<S><Admin.Applications /></S>} />
                    <Route path="rasimu" element={<S><Admin.Drafts /></S>} />
                    <Route path="maombi/:id" element={<S><Admin.Application /></S>} />
                    <Route path="watumiaji" element={<S><Admin.Users /></S>} />
                    <Route path="watumiaji/:id" element={<S><Admin.User /></S>} />
                    <Route path="wahudumu" element={<S><Admin.Staff /></S>} />
                    <Route path="ujumbe" element={<S><Admin.Messages /></S>} />
                    <Route path="ujumbe/:id" element={<S><Admin.Thread /></S>} />
                    <Route path="arifa" element={<S><Admin.Notifications /></S>} />
                    <Route path="mawasiliano" element={<S><Admin.Contact /></S>} />
                    <Route path="huduma" element={<S><Admin.Services /></S>} />
                    <Route path="maudhui/:type" element={<S><Admin.Content /></S>} />
                    <Route path="ripoti" element={<S><Admin.Reports /></S>} />
                    <Route path="mipangilio" element={<S><Admin.Settings /></S>} />
                    <Route path="audit" element={<S><Admin.Audit /></S>} />
                    <Route path="usalama" element={<S><Admin.Security /></S>} />
                  </Route>
                </Routes>
                </SiteGate>
              </Suspense>
            </BrowserRouter>
          </AuthProvider>
        </SiteProvider>
      </ToastProvider>
    </I18nProvider>
  );
}
