import { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { Download, FileText, MessageCircle, Lock, XCircle, Trash2, Info, Search } from 'lucide-react';
import { useI18n } from '@/i18n';
import { useSite } from '@/context/SiteContext';
import { useToast } from '@/context/ToastContext';
import { api, ApiError, fileUrl } from '@/lib/api';
import { fmtDateTime, fmtMoney } from '@/lib/format';
import { visibleFields, visibleSteps } from '@/lib/forms';
import type { AppDetail, AppSummary, FormSchemaDef, Option, Region } from '@/lib/types';
import {
  Alert,
  Button,
  Card,
  EmptyState,
  ErrorState,
  LinkButton,
  Loading,
  PageHead,
  PaymentBadge,
  SkeletonCards,
  StatusBadge,
  Tabs,
  useAsync,
  useConfirm,
  useDocumentTitle,
  useErrorText,
} from '@/components/ui';
import { AppCard, ServiceCard } from '@/components/Cards';
import FormWizard from '@/components/form/FormWizard';
import { displayValue } from '@/components/form/Fields';
import { Timeline } from '@/components/Timeline';

// ------------------------------------------------------------------ list

export function ApplicationsPage({ history }: { history?: boolean }) {
  const { t } = useI18n();
  const { data, loading, error, reload } = useAsync(() => api.get<AppSummary[]>('/applications'));
  type TabKey = 'active' | 'done' | 'drafts' | 'unpaid' | 'all';
  const [params, setParams] = useSearchParams();
  const urlTab = params.get('tab') as TabKey | null;
  const tab: TabKey = history ? 'done' : urlTab && ['active', 'done', 'drafts', 'unpaid', 'all'].includes(urlTab) ? urlTab : 'all';
  const setTab = (v: TabKey) => setParams(v === 'all' ? {} : { tab: v }, { replace: true });
  useDocumentTitle(history ? t('apps.historyTitle') : t('apps.title'));
  const groups = useMemo(() => {
    const items = data ?? [];
    return {
      all: items,
      active: items.filter((a) => ['received', 'in_progress', 'awaiting_info', 'correction_required', 'on_hold'].includes(a.status)),
      done: items.filter((a) => ['completed', 'closed', 'cancelled'].includes(a.status)),
      drafts: items.filter((a) => a.status === 'draft'),
      unpaid: items.filter((a) => a.status !== 'draft' && a.status !== 'cancelled' && ['unpaid', 'partial'].includes(a.payment_status)),
    };
  }, [data]);

  return (
    <>
      <PageHead
        title={history ? t('apps.historyTitle') : t('apps.title')}
        subtitle={history ? t('apps.historySubtitle') : t('apps.subtitle')}
        actions={<LinkButton to="/app/omba">{t('nav.newApplication')}</LinkButton>}
      />
      {!history && (
        <Tabs
          value={tab}
          onChange={setTab}
          items={[
            { value: 'all', label: t('common.all'), count: groups.all.length },
            { value: 'active', label: t('apps.filterActive'), count: groups.active.length },
            { value: 'done', label: t('apps.filterDone'), count: groups.done.length },
            { value: 'drafts', label: t('apps.filterDrafts'), count: groups.drafts.length },
            { value: 'unpaid', label: t('dash.unpaid'), count: groups.unpaid.length },
          ]}
        />
      )}
      {!history && data && <TrackStatus apps={data} />}
      {loading ? (
        <SkeletonCards count={4} height={200} />
      ) : error ? (
        <ErrorState error={error} onRetry={reload} />
      ) : groups[tab].length === 0 ? (
        <Card>
          <EmptyState icon={FileText} title={t('apps.empty')} text={t('dash.noAppsText')} action={<LinkButton to="/app/omba">{t('nav.newApplication')}</LinkButton>} />
        </Card>
      ) : (
        <div className="grid grid-2">
          {groups[tab].map((a) => (
            <AppCard key={a.id} a={a} />
          ))}
        </div>
      )}
    </>
  );
}

/** Look up one of the user's applications by its reference number and show only its status. */
function TrackStatus({ apps }: { apps: AppSummary[] }) {
  const { t, pick } = useI18n();
  const [ref, setRef] = useState('');
  const [result, setResult] = useState<AppSummary | null | undefined>(undefined);
  const find = (e: React.FormEvent) => {
    e.preventDefault();
    const q = ref.trim().toUpperCase();
    if (!q) return;
    setResult(apps.find((a) => (a.reference ?? '').toUpperCase() === q || (a.reference ?? '').toUpperCase().endsWith(q)) ?? null);
  };
  return (
    <div className="card mb-4">
      <h3 style={{ fontSize: '1.05rem' }}>{t('apps.trackTitle')}</h3>
      <form className="track-box" onSubmit={find}>
        <label className="field">
          <span className="sr-only">{t('apps.trackLabel')}</span>
          <input className="input mono" value={ref} onChange={(e) => setRef(e.target.value)} placeholder="MED-2026-HESLB-000001" aria-label={t('apps.trackLabel')} />
        </label>
        <Button type="submit" icon={Search}>
          {t('apps.trackButton')}
        </Button>
      </form>
      {result === null && (
        <div className="mt-2">
          <Alert kind="warning">{t('apps.trackNotFound')}</Alert>
        </div>
      )}
      {result && (
        <div className="row between mt-4" style={{ gap: 8 }}>
          <div>
            <div className="mono small" style={{ fontWeight: 700 }}>{result.reference}</div>
            <div className="xs muted">{pick(result.service_name_sw, result.service_name_en)}</div>
          </div>
          <StatusBadge status={result.status} />
        </div>
      )}
    </div>
  );
}

// ------------------------------------------------------------------ choose service / start

export function NewApplicationPage() {
  const { t } = useI18n();
  const { services } = useSite();
  useDocumentTitle(t('nav.newApplication'));
  return (
    <>
      <PageHead title={t('nav.newApplication')} subtitle={t('home.servicesText')} />
      <div className="grid grid-3">
        {services.map((s) => (
          <ServiceCard key={s.id} service={s} inApp />
        ))}
      </div>
    </>
  );
}

/** /app/omba/:code — create or resume a draft, then open the form. */
export function StartApplicationPage() {
  const { code } = useParams();
  const { t } = useI18n();
  const navigate = useNavigate();
  const [error, setError] = useState<unknown>(null);
  useEffect(() => {
    let cancelled = false;
    api
      .post<{ id: number }>('/applications', { service_code: code })
      .then((r) => !cancelled && navigate(`/app/maombi/${r.id}/jaza`, { replace: true }))
      .catch((e) => !cancelled && setError(e));
    return () => {
      cancelled = true;
    };
  }, [code, navigate]);
  if (error) {
    if (error instanceof ApiError && error.code === 'service_closed') return <Alert kind="warning">{t('form.closed')}</Alert>;
    return <ErrorState error={error} />;
  }
  return <Loading text={t('form.starting')} />;
}

// ------------------------------------------------------------------ fill / correct

export function ApplicationFormPage() {
  const { id } = useParams();
  const { t, pick } = useI18n();
  const { settings } = useSite();
  const { data, loading, error, reload } = useAsync(async () => {
    const app = await api.get<AppDetail>(`/applications/${id}`);
    const [form, regions] = await Promise.all([
      api.get<{ schema: FormSchemaDef; options: { banks: Option[]; heslb_levels: Option[] } }>(`/form-schemas/${app.form_key}`),
      api.get<Region[]>('/regions'),
    ]);
    const needsInst = form.schema.steps.some((s) => s.fields.some((f) => f.fields?.some((x) => x.suggest === 'institutions')));
    const institutions = needsInst ? await api.get<string[]>('/institution-names').catch(() => []) : [];
    return { app, ...form, regions, institutions };
  }, [id]);
  useDocumentTitle(data ? pick(data.schema.title.sw, data.schema.title.en) : t('nav.newApplication'));

  if (loading) return <Loading text={t('form.starting')} />;
  if (error || !data) return <ErrorState error={error} onRetry={reload} />;
  if (!data.app.editable)
    return (
      <Alert kind="info">
        {t('form.lockedHint')} <Link to={`/app/maombi/${data.app.id}`}>{t('apps.viewDetails')}</Link>
      </Alert>
    );
  return (
    <>
      <PageHead
        title={pick(data.schema.title.sw, data.schema.title.en)}
        crumbs={[{ to: '/app', label: t('nav.dashboard') }, { to: '/app/maombi', label: t('nav.myApplications') }, { label: data.app.reference ?? t('status.draft') }]}
      />
      <FormWizard
        app={data.app}
        schema={data.schema}
        options={data.options}
        regions={data.regions}
        institutions={data.institutions}
        paymentInstructions={pick(settings?.payment_instructions_sw, settings?.payment_instructions_en) || undefined}
      />
    </>
  );
}

// ------------------------------------------------------------------ detail

export function ApplicationDetailPage() {
  const { id } = useParams();
  const { t, pick, lang } = useI18n();
  const { settings } = useSite();
  const { toast } = useToast();
  const navigate = useNavigate();
  const errText = useErrorText();
  const { confirm, dialog } = useConfirm();
  const { data, loading, error, reload } = useAsync(async () => {
    const app = await api.get<AppDetail>(`/applications/${id}`);
    const form = await api.get<{ schema: FormSchemaDef; options: { banks: Option[]; heslb_levels: Option[] } }>(`/form-schemas/${app.form_key}`);
    return { app, ...form };
  }, [id]);
  useDocumentTitle(data?.app.reference ?? t('apps.title'));

  if (loading && !data) return <Loading />;
  if (error || !data) return <ErrorState error={error} onRetry={reload} />;
  const { app, schema, options } = data;
  const files = Object.fromEntries(app.files.map((f) => [f.id, f]));
  const yesNo = (v: string) => (v === 'yes' ? t('common.yes') : v === 'no' ? t('common.no') : v);
  const fieldLabel = (key: string) => {
    for (const s of schema.steps) for (const f of s.fields) if (f.key === key) return pick(f.label.sw, f.label.en);
    return key;
  };

  const cancel = async () => {
    const isDraft = app.status === 'draft';
    if (!(await confirm({ title: isDraft ? t('apps.deleteDraft') : t('apps.cancel'), text: isDraft ? t('apps.deleteDraftConfirm') : t('apps.cancelConfirm'), danger: true }))) return;
    try {
      await api.post(`/applications/${app.id}/cancel`);
      toast(isDraft ? t('apps.draftDeleted') : t('apps.cancelled'));
      if (isDraft) navigate('/app/maombi');
      else void reload();
    } catch (e) {
      toast(errText(e), 'error');
    }
  };

  return (
    <>
      {dialog}
      <PageHead
        title={pick(app.service_name_sw, app.service_name_en)}
        subtitle={app.reference ?? t('status.draft')}
        crumbs={[{ to: '/app', label: t('nav.dashboard') }, { to: '/app/maombi', label: t('nav.myApplications') }, { label: app.reference ?? t('status.draft') }]}
        actions={
          <>
            {app.editable && (
              <LinkButton to={`/app/maombi/${app.id}/jaza`} variant={app.status === 'correction_required' ? 'danger' : 'primary'}>
                {app.status === 'correction_required' ? t('apps.correct') : t('apps.continue')}
              </LinkButton>
            )}
            {app.status !== 'draft' && (
              <LinkButton to={`/app/ujumbe?new=1&app=${app.id}`} variant="secondary" icon={MessageCircle}>
                {t('apps.chatAbout')}
              </LinkButton>
            )}
          </>
        }
      />

      <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(min(100%, 360px), 1fr))', alignItems: 'start' }}>
        <div className="stack">
          {app.status === 'correction_required' && (
            <Alert kind="warning" title={t('apps.correctionTitle')}>
              <div className="pre">{app.correction_message}</div>
              {app.editable_fields && (
                <div className="mt-2">
                  <strong>{t('apps.correctionFields')}</strong>{' '}
                  {app.editable_fields.includes('*') ? t('apps.allFields') : app.editable_fields.map(fieldLabel).join(', ')}
                </div>
              )}
            </Alert>
          )}
          <Card>
            <dl className="kv">
              <dt>{t('common.status')}</dt>
              <dd>
                <StatusBadge status={app.status} />
              </dd>
              <dt>{t('common.reference')}</dt>
              <dd className="mono">{app.reference ?? '—'}</dd>
              <dt>{t('apps.submittedOn')}</dt>
              <dd>{app.submitted_at ? fmtDateTime(app.submitted_at, lang) : t('apps.notSubmitted')}</dd>
              <dt>{t('apps.lastUpdate')}</dt>
              <dd>{fmtDateTime(app.updated_at, lang)}</dd>
              {app.status !== 'draft' && (
                <>
                  <dt>{t('apps.priceAtSubmission')}</dt>
                  <dd>
                    {app.price !== null ? fmtMoney(app.price) : '—'} {app.package_name && <span className="muted small">({app.package_name})</span>}
                  </dd>
                  <dt>{t('payment.title')}</dt>
                  <dd>
                    <PaymentBadge status={app.payment_status} />
                  </dd>
                </>
              )}
            </dl>
            {app.next_action && (
              <Alert kind="info" title={t('apps.nextAction')}>
                {app.next_action}
              </Alert>
            )}
            {app.status !== 'draft' && app.payment_status === 'unpaid' && (app.price ?? 0) > 0 && settings?.payment_instructions_sw && (
              <div className="mt-4">
                <Alert kind="warning" title={t('apps.paymentInstructions')}>
                  {pick(settings.payment_instructions_sw, settings.payment_instructions_en)}
                </Alert>
              </div>
            )}
          </Card>

          <Card title={t('apps.results')}>
            {app.results.length === 0 && app.result_files.length === 0 ? (
              <p className="muted small mb-0">{t('apps.resultsEmpty')}</p>
            ) : (
              <div className="stack">
                {app.results.map((r) => (
                  <div key={r.id} className="card" style={{ background: 'var(--c-success-50)', borderColor: '#b5ebc8' }}>
                    <div className="row between">
                      <strong>{r.title}</strong>
                      <span className="xs muted">{fmtDateTime(r.created_at, lang)}</span>
                    </div>
                    <div className="pre small mt-2 break" style={{ userSelect: 'all' }}>
                      {r.body}
                    </div>
                  </div>
                ))}
                {app.result_files.length > 0 && (
                  <div>
                    <div className="small" style={{ fontWeight: 600 }}>
                      {t('apps.resultFiles')}
                    </div>
                    <div className="file-list">
                      {app.result_files.map((f) => (
                        <a key={f.id} className="file-item" href={fileUrl(app.id, f.id)}>
                          <span className="thumb">
                            <Download />
                          </span>
                          <span className="grow break">{f.name}</span>
                        </a>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </Card>

          <Card title={t('apps.timeline')}>
            {app.timeline.length ? <Timeline items={app.timeline} /> : <p className="muted small mb-0">{t('apps.notSubmitted')}</p>}
          </Card>
        </div>

        <div className="stack">
          <Card title={t('apps.yourDetails')} actions={<span className="xs muted row" style={{ gap: 4 }}><Lock size={12} /> {t('form.sensitive')}</span>}>
            <div className="stack">
              {visibleSteps(schema, app.data).map((s) => {
                const fields = visibleFields(s, app.data).filter((f) => f.type !== 'heading' && f.type !== 'file');
                if (!fields.length) return null;
                return (
                  <div key={s.key} className="review-section">
                    <div className="review-section-head">
                      <h4>{pick(s.title.sw, s.title.en)}</h4>
                    </div>
                    <dl className="kv">
                      {fields.map((f) => (
                        <div key={f.key} style={{ display: 'contents' }}>
                          <dt>{pick(f.label.sw, f.label.en)}</dt>
                          <dd className="pre">{displayValue(f, app.data[f.key], options, files, pick, yesNo) || <span className="muted">—</span>}</dd>
                        </div>
                      ))}
                    </dl>
                  </div>
                );
              })}
            </div>
          </Card>
          {app.files.length > 0 && (
            <Card title={t('apps.yourFiles')}>
              <div className="file-list">
                {app.files.map((f) => (
                  <a key={f.id} className="file-item" href={fileUrl(app.id, f.id, true)} target="_blank" rel="noopener noreferrer">
                    {f.mime.startsWith('image/') ? <img className="thumb" src={fileUrl(app.id, f.id, true)} alt="" /> : <span className="thumb"><FileText /></span>}
                    <span className="grow break">
                      <span className="file-label">{fieldLabel(f.field_key)}</span>
                      {f.name}
                    </span>
                  </a>
                ))}
              </div>
            </Card>
          )}
          {(app.status === 'draft' || app.status === 'received') && (
            <Button variant="ghost" icon={app.status === 'draft' ? Trash2 : XCircle} onClick={() => void cancel()} style={{ color: 'var(--c-danger)' }}>
              {app.status === 'draft' ? t('apps.deleteDraft') : t('apps.cancel')}
            </Button>
          )}
          <p className="xs muted row" style={{ gap: 4 }}>
            <Info size={12} /> ID #{app.id}
          </p>
        </div>
      </div>
    </>
  );
}
