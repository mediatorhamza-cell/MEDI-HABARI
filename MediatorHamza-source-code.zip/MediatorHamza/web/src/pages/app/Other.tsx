import { Fragment, useEffect, useRef, useState, type FormEvent } from 'react';
import { Link, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { ArrowLeft, Bell, BellRing, Trash2, Check, CheckCheck, ExternalLink, KeyRound, Lock, LockOpen, MessageCircle, Phone, Plus, Send, Users } from 'lucide-react';
import { useI18n } from '@/i18n';
import { useAuth } from '@/context/AuthContext';
import { useSite } from '@/context/SiteContext';
import { useToast } from '@/context/ToastContext';
import { api, ApiError } from '@/lib/api';
import { fmtDate, fmtPhone, fmtRelative, initials, parseDate, waLink } from '@/lib/format';
import type { AppSummary, Conversation, Message, NotificationItem, Paged, User } from '@/lib/types';
import {
  Alert,
  Button,
  Card,
  EmptyState,
  ErrorState,
  LinkButton,
  Loading,
  Modal,
  PageHead,
  Pagination,
  PasswordField,
  SelectField,
  TextField,
  TextareaField,
  useAsync,
  useConfirm,
  useDocumentTitle,
  useErrorText,
} from '@/components/ui';
import { AssistantChat, LangSwitch } from '@/components/Shared';
import { FaqList } from '@/components/Cards';
import { useCounts } from '@/layouts/AppLayout';
import { usePoll } from '@/layouts/Shell';
import type { Faq } from '@/lib/types';

// ------------------------------------------------------------------ notifications

export function NotificationsPage() {
  const { t, pick, lang } = useI18n();
  const { refresh } = useCounts();
  const [page, setPage] = useState(1);
  const { data, loading, error, reload } = useAsync(() => api.get<Paged<NotificationItem> & { unread: number }>(`/me/notifications?page=${page}`), [page]);
  const [perm, setPerm] = useState(() => ('Notification' in window ? Notification.permission : 'denied'));
  const navigate = useNavigate();
  useDocumentTitle(t('notif.title'));

  const open = async (n: NotificationItem) => {
    if (!n.read) {
      await api.post(`/me/notifications/${n.id}/read`).catch(() => undefined);
      refresh();
    }
    if (n.link) navigate(n.link);
    else void reload();
  };
  const markAll = async () => {
    await api.post('/me/notifications/read-all');
    refresh();
    void reload();
  };
  const { confirm, dialog } = useConfirm();
  const remove = async (n: NotificationItem) => {
    await api.del(`/me/notifications/${n.id}`).catch(() => undefined);
    refresh();
    void reload();
  };
  const clearAll = async () => {
    if (!(await confirm({ title: t('notif.clearAll'), text: t('notif.clearConfirm'), danger: true, confirmLabel: t('common.delete') }))) return;
    await api.del('/me/notifications');
    setPage(1);
    refresh();
    void reload();
  };
  const enable = async () => {
    if (!('Notification' in window)) return;
    setPerm(await Notification.requestPermission());
  };

  return (
    <>
      <PageHead
        title={t('notif.title')}
        subtitle={t('notif.subtitle')}
        actions={
          <>
            {'Notification' in window && perm === 'default' && (
              <Button variant="secondary" icon={BellRing} onClick={() => void enable()}>
                {t('notif.enableBrowser')}
              </Button>
            )}
            {!!data?.unread && (
              <Button variant="secondary" icon={CheckCheck} onClick={() => void markAll()}>
                {t('notif.markAll')}
              </Button>
            )}
            {!!data?.total && (
              <Button variant="danger" icon={Trash2} onClick={() => void clearAll()}>
                {t('notif.clearAll')}
              </Button>
            )}
          </>
        }
      />
      {perm === 'granted' && <p className="xs muted">{t('notif.enabled')}</p>}
      <div className="card flush">
        {loading ? (
          <Loading />
        ) : error ? (
          <ErrorState error={error} onRetry={reload} />
        ) : !data?.items.length ? (
          <EmptyState icon={Bell} title={t('notif.empty')} />
        ) : (
          <>
            {data.items.map((n) => (
              <div key={n.id} className={`list-item ${n.read ? '' : 'unread'}`}>
                <button className="notif-main" onClick={() => void open(n)}>
                  <span className="icon-tile" style={{ width: 38, height: 38 }}>
                    <Bell size={18} />
                  </span>
                  <div className="grow">
                    <div className="li-title">
                      {pick(n.title_sw, n.title_en)} {!n.read && <span className="badge info plain">{t('common.new')}</span>}
                    </div>
                    <div className="small muted pre">{pick(n.body_sw, n.body_en)}</div>
                    <div className="xs muted mt-2">{fmtRelative(n.created_at, lang)}</div>
                  </div>
                </button>
                <button className="icon-btn" onClick={() => void remove(n)} aria-label={t('common.delete')} title={t('common.delete')}>
                  <Trash2 />
                </button>
              </div>
            ))}
            <Pagination page={data.page} perPage={data.per_page} total={data.total} onPage={setPage} />
          </>
        )}
      </div>
      {dialog}
    </>
  );
}

// ------------------------------------------------------------------ chat

export function ConversationsPage() {
  const { t, lang } = useI18n();
  const [params, setParams] = useSearchParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const errText = useErrorText();
  const { data, loading, error, reload } = useAsync(() => api.get<Conversation[]>('/me/conversations'));
  const { data: apps } = useAsync(() => api.get<AppSummary[]>('/applications'));
  const [open, setOpen] = useState(params.get('new') === '1');
  const [form, setForm] = useState({ subject: '', body: '', application_id: params.get('app') ?? '' });
  const [busy, setBusy] = useState(false);
  useDocumentTitle(t('chat.title'));

  useEffect(() => {
    if (form.application_id && apps && !form.subject) {
      const a = apps.find((x) => String(x.id) === form.application_id);
      if (a?.reference) setForm((f) => ({ ...f, subject: a.reference! }));
    }
  }, [apps, form.application_id, form.subject]);

  const create = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try {
      const res = await api.post<{ id: number }>('/me/conversations', { ...form, application_id: form.application_id || null });
      navigate(`/app/ujumbe/${res.id}`);
    } catch (err) {
      toast(errText(err), 'error');
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      <PageHead title={t('chat.title')} subtitle={t('chat.subtitle')} actions={<Button icon={Plus} onClick={() => setOpen(true)}>{t('chat.new')}</Button>} />
      <div className="card flush">
        {loading ? (
          <Loading />
        ) : error ? (
          <ErrorState error={error} onRetry={reload} />
        ) : !data?.length ? (
          <EmptyState icon={MessageCircle} title={t('chat.empty')} text={t('chat.emptyText')} action={<Button onClick={() => setOpen(true)}>{t('chat.new')}</Button>} />
        ) : (
          data.map((c) => (
            <Link key={c.id} to={`/app/ujumbe/${c.id}`} className={`list-item ${c.unread ? 'unread' : ''}`}>
              <span className="icon-tile" style={{ width: 38, height: 38 }}>
                <MessageCircle size={18} />
              </span>
              <div className="grow" style={{ minWidth: 0 }}>
                <div className="row between">
                  <span className="li-title">{c.subject}</span>
                  <span className="xs muted">{fmtRelative(c.last_message_at, lang)}</span>
                </div>
                <div className="small muted" style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                  {c.last_message}
                </div>
                <div className="row xs mt-2" style={{ gap: 6 }}>
                  {c.application_reference && <span className="badge plain neutral mono">{c.application_reference}</span>}
                  <span className={`badge ${c.status === 'closed' ? 'neutral' : c.awaiting_reply ? 'warning' : 'success'}`}>
                    {c.status === 'closed' ? t('chat.closed') : c.awaiting_reply ? t('chat.awaiting') : t('chat.answered')}
                  </span>
                  {c.unread > 0 && <span className="badge danger plain">{c.unread}</span>}
                </div>
              </div>
            </Link>
          ))
        )}
      </div>
      <Modal
        open={open}
        onClose={() => {
          setOpen(false);
          setParams({});
        }}
        title={t('chat.new')}
      >
        <form className="stack" onSubmit={create}>
          <SelectField label={t('chat.relatedApp')} value={form.application_id} onChange={(e) => setForm({ ...form, application_id: e.target.value })}>
            <option value="">{t('chat.noApp')}</option>
            {apps
              ?.filter((a) => a.reference)
              .map((a) => (
                <option key={a.id} value={a.id}>
                  {a.reference} — {a.service_name_sw}
                </option>
              ))}
          </SelectField>
          <TextField label={t('chat.subject')} required maxLength={200} value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })} />
          <TextareaField label={t('common.message')} required maxLength={4000} value={form.body} onChange={(e) => setForm({ ...form, body: e.target.value })} />
          <Button type="submit" icon={Send} loading={busy} disabled={!form.subject.trim() || !form.body.trim()}>
            {t('common.send')}
          </Button>
        </form>
      </Modal>
    </>
  );
}

export function ChatThread({ base, admin }: { base: string; admin?: boolean }) {
  const { id } = useParams();
  const { t, lang } = useI18n();
  const { toast } = useToast();
  const errText = useErrorText();
  const [data, setData] = useState<{ conversation: Conversation; messages: Message[] } | null>(null);
  const [error, setError] = useState<unknown>(null);
  const [body, setBody] = useState('');
  const [busy, setBusy] = useState(false);
  const scroller = useRef<HTMLDivElement>(null);
  const count = useRef(0);

  const load = () =>
    api
      .poll<{ conversation: Conversation; messages: Message[] }>(`${base}/${id}`)
      .then((d) => {
        setData(d);
        if (d.messages.length !== count.current) {
          count.current = d.messages.length;
          requestAnimationFrame(() => scroller.current?.scrollTo({ top: scroller.current.scrollHeight }));
        }
      })
      .catch(setError);
  usePoll(() => void load(), 15000);

  const send = async (e?: FormEvent) => {
    e?.preventDefault();
    if (!body.trim()) return;
    setBusy(true);
    try {
      await api.post(`${base}/${id}/messages`, { body });
      setBody('');
      await load();
    } catch (err) {
      toast(errText(err), 'error');
    } finally {
      setBusy(false);
    }
  };
  const setStatus = async (status: 'open' | 'closed') => {
    await api.post(`${base}/${id}/status`, { status });
    void load();
  };

  if (error) return <ErrorState error={error} />;
  if (!data) return <Loading />;
  const c = data.conversation;
  const listTo = admin ? '/admin/ujumbe' : '/app/ujumbe';
  const [first, second] = (c.user_name ?? '').split(' ');
  const now = new Date();
  const today = fmtDate(`${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`, lang);
  let lastDay = '';
  return (
    <div className="chat-wrap">
      <header className="chat-head">
        <Link to={listTo} className="chat-back" aria-label={t('common.back')}>
          <ArrowLeft />
        </Link>
        {admin ? (
          <span className="chat-avatar">{initials(first, second)}</span>
        ) : (
          <img className="chat-avatar" src="/brand/logo-160.png" alt="" />
        )}
        <div className="chat-who">
          <div className="chat-name">{admin ? c.user_name ?? fmtPhone(c.user_phone) : `${t('chat.admin')} Hamza`}</div>
          <div className="chat-sub">
            <span className={`chat-dot ${c.status === 'closed' ? 'off' : ''}`} />
            {admin && c.user_phone ? fmtPhone(c.user_phone) : c.status === 'closed' ? t('chat.closed') : t('admin.chat.open')}
          </div>
        </div>
        {admin && c.user_phone && (
          <a className="chat-icon wa" href={waLink(c.user_phone)} target="_blank" rel="noopener noreferrer" aria-label="WhatsApp" title="WhatsApp">
            <Phone />
          </a>
        )}
        {admin && (
          <button
            type="button"
            className="chat-icon"
            onClick={() => void setStatus(c.status === 'open' ? 'closed' : 'open')}
            aria-label={c.status === 'open' ? t('admin.chat.close') : t('admin.chat.reopen')}
            title={c.status === 'open' ? t('admin.chat.close') : t('admin.chat.reopen')}
          >
            {c.status === 'open' ? <Lock /> : <LockOpen />}
          </button>
        )}
      </header>
      <div className="chat-topic">
        <span className="chat-subject">{c.subject}</span>
        {c.application_id && (
          <Link to={admin ? `/admin/maombi/${c.application_id}` : `/app/maombi/${c.application_id}`} className="chat-ref mono">
            {c.application_reference}
          </Link>
        )}
      </div>
      <div className="chat-messages" ref={scroller}>
        {data.messages.map((m) => {
          const mine = admin ? m.from_staff : !m.from_staff;
          const day = fmtDate(m.created_at, lang);
          const showDay = day !== lastDay;
          lastDay = day;
          const d = parseDate(m.created_at);
          const time = d ? `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}` : '';
          return (
            <Fragment key={m.id}>
              {showDay && <div className="chat-day">{day === today ? (lang === 'en' ? 'Today' : 'Leo') : day}</div>}
              <div className={`bubble ${mine ? 'mine' : 'theirs'}`}>
                {admin && m.from_staff && <div className="bubble-name">{m.sender_name}</div>}
                {m.body}
                <div className="bubble-meta">
                  {time}
                  {mine && (m.read ? <CheckCheck aria-label={t('chat.read')} /> : <Check aria-label={t('chat.sent')} />)}
                </div>
              </div>
            </Fragment>
          );
        })}
      </div>
      {c.status === 'closed' && <div className="chat-closed">{t('chat.closed')}</div>}
      <form className="chat-compose" onSubmit={send}>
        <textarea
          className="chat-input"
          rows={1}
          value={body}
          maxLength={4000}
          placeholder={t('chat.placeholder')}
          aria-label={t('chat.placeholder')}
          onChange={(e) => setBody(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && !e.shiftKey && window.matchMedia('(min-width: 760px)').matches) {
              e.preventDefault();
              void send();
            }
          }}
        />
        <button type="submit" className="chat-send" disabled={busy || !body.trim()} aria-label={t('common.send')}>
          <Send />
        </button>
      </form>
    </div>
  );
}

// ------------------------------------------------------------------ groups

export function GroupsPage() {
  const { t, pick } = useI18n();
  const { data, loading, error, reload } = useAsync(() => api.get<{ id: number; name: string; description_sw: string | null; description_en: string | null; invite_url: string }[]>('/me/groups'));
  useDocumentTitle(t('groups.title'));
  return (
    <>
      <PageHead title={t('groups.title')} subtitle={t('groups.subtitle')} />
      {loading ? (
        <Loading />
      ) : error ? (
        <ErrorState error={error} onRetry={reload} />
      ) : !data?.length ? (
        <Card>
          <EmptyState icon={Users} title={t('groups.empty')} />
        </Card>
      ) : (
        <div className="grid grid-2">
          {data.map((g) => (
            <div key={g.id} className="card stack sm">
              <div className="row" style={{ flexWrap: 'nowrap' }}>
                <span className="icon-tile" style={{ background: '#e7f8ee', color: '#16803c' }}>
                  <MessageCircle />
                </span>
                <h3 className="mb-0">{g.name}</h3>
              </div>
              <p className="small muted mb-0 pre">{pick(g.description_sw, g.description_en)}</p>
              <a className="btn btn-success" href={g.invite_url} target="_blank" rel="noopener noreferrer">
                <ExternalLink /> {t('groups.join')}
              </a>
            </div>
          ))}
        </div>
      )}
    </>
  );
}

// ------------------------------------------------------------------ profile

export function ProfilePage() {
  const { t, tv, lang } = useI18n();
  const { user, setSession } = useAuth();
  const { toast } = useToast();
  const errText = useErrorText();
  const [f, setF] = useState({ first_name: user?.first_name ?? '', second_name: user?.second_name ?? '', last_name: user?.last_name ?? '', email: user?.email ?? '' });
  const [pw, setPw] = useState({ current_password: '', password: '', password_confirmation: '' });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState<'p' | 'w' | null>(null);
  useDocumentTitle(t('profile.title'));
  const e = (k: string) => (errors[k] ? tv(errors[k]) : null);

  const saveProfile = async (ev: FormEvent) => {
    ev.preventDefault();
    setBusy('p');
    setErrors({});
    try {
      const u = await api.put<User>('/me/profile', { ...f, language: lang });
      setSession({ user: u });
      toast(t('profile.updated'));
    } catch (err) {
      if (err instanceof ApiError && err.status === 422) setErrors(err.fields);
      else toast(errText(err), 'error');
    } finally {
      setBusy(null);
    }
  };
  const savePw = async (ev: FormEvent) => {
    ev.preventDefault();
    setBusy('w');
    setErrors({});
    try {
      const r = await api.post<{ csrf: string }>('/me/password', pw);
      setSession({ user: user!, csrf: r.csrf });
      setPw({ current_password: '', password: '', password_confirmation: '' });
      toast(t('profile.passwordChanged'));
    } catch (err) {
      if (err instanceof ApiError && err.status === 422) setErrors(err.fields);
      else toast(errText(err), 'error');
    } finally {
      setBusy(null);
    }
  };

  return (
    <>
      <PageHead title={t('profile.title')} subtitle={t('profile.subtitle')} />
      <div className="grid grid-2" style={{ alignItems: 'start' }}>
        <div className="stack">
          <Card title={t('profile.basic')}>
            <form className="stack" onSubmit={saveProfile}>
              <div className="form-grid">
                <TextField label={t('auth.firstName')} required value={f.first_name} onChange={(ev) => setF({ ...f, first_name: ev.target.value })} error={e('first_name')} />
                <TextField label={t('auth.secondName')} required value={f.second_name} onChange={(ev) => setF({ ...f, second_name: ev.target.value })} error={e('second_name')} />
                <TextField label={t('auth.lastName')} optional value={f.last_name} onChange={(ev) => setF({ ...f, last_name: ev.target.value })} error={e('last_name')} />
                <TextField label={t('common.email')} optional type="email" value={f.email} onChange={(ev) => setF({ ...f, email: ev.target.value })} error={e('email')} />
              </div>
              <TextField label={t('auth.phone')} value={fmtPhone(user?.phone)} disabled help={t('profile.phoneLocked')} />
              <p className="xs muted mb-0">
                {t('profile.memberSince')}: {fmtDate(user?.created_at, lang)}
              </p>
              <Button type="submit" loading={busy === 'p'}>
                {t('common.save')}
              </Button>
            </form>
          </Card>
          <Card title={t('common.language')}>
            <div className="row between">
              <span className="small muted">{t('profile.languageText')}</span>
              <LangSwitch />
            </div>
          </Card>
        </div>
        <div className="stack">
          <Card title={t('profile.changePassword')}>
            <form className="stack" onSubmit={savePw}>
              <PasswordField label={t('profile.currentPassword')} autoComplete="current-password" required value={pw.current_password} onChange={(ev) => setPw({ ...pw, current_password: ev.target.value })} error={e('current_password')} />
              <PasswordField label={t('auth.newPassword')} autoComplete="new-password" required help={t('auth.passwordHelp')} value={pw.password} onChange={(ev) => setPw({ ...pw, password: ev.target.value })} error={e('password')} />
              <PasswordField label={t('auth.passwordConfirm')} autoComplete="new-password" required value={pw.password_confirmation} onChange={(ev) => setPw({ ...pw, password_confirmation: ev.target.value })} error={e('password_confirmation')} />
              <Button type="submit" icon={KeyRound} loading={busy === 'w'}>
                {t('profile.changePassword')}
              </Button>
            </form>
          </Card>
        </div>
      </div>
    </>
  );
}

// ------------------------------------------------------------------ help

export function HelpPage() {
  const { t } = useI18n();
  const { settings } = useSite();
  const { data: faqs } = useAsync(() => api.get<Faq[]>('/faqs'));
  useDocumentTitle(t('help.title'));
  return (
    <>
      <PageHead title={t('help.title')} subtitle={t('help.subtitle')} actions={<LinkButton to="/app/ujumbe?new=1" icon={MessageCircle}>{t('help.talkToAdmin')}</LinkButton>} />
      <div className="grid grid-2" style={{ alignItems: 'start' }}>
        <Card title={t('help.assistant')}>
          <div className="card flush">
            <AssistantChat />
          </div>
          <p className="xs muted mt-2 mb-0">{t('help.assistantDisclaimer')}</p>
        </Card>
        <div className="stack">
          <Card title={t('help.contactOptions')}>
            <div className="row">
              {settings?.contact_phone && (
                <a className="btn btn-secondary" href={`tel:${settings.contact_phone}`}>
                  <Phone /> {fmtPhone(settings.contact_phone)}
                </a>
              )}
              {settings?.contact_whatsapp && (
                <a className="btn btn-success" href={waLink(settings.contact_whatsapp)} target="_blank" rel="noopener noreferrer">
                  <MessageCircle /> WhatsApp
                </a>
              )}
            </div>
          </Card>
          <Card title={t('nav.faq')}>{faqs ? <FaqList items={faqs} /> : <Loading />}</Card>
          <Alert kind="info">{t('help.assistantDisclaimer')}</Alert>
        </div>
      </div>
    </>
  );
}
