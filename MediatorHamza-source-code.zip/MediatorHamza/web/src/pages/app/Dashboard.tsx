import { Link } from 'react-router-dom';
import { AlertTriangle, Bell, CheckCircle2, FileText, HelpCircle, Loader, MessageCircle, Users, Wallet } from 'lucide-react';
import { useI18n } from '@/i18n';
import { useAuth } from '@/context/AuthContext';
import { useSite } from '@/context/SiteContext';
import { api } from '@/lib/api';
import { fmtRelative } from '@/lib/format';
import type { Announcement, AppSummary, Deadline, NotificationItem } from '@/lib/types';
import { Alert, Card, EmptyState, ErrorState, LinkButton, ServiceIcon, SkeletonCards, Stat, useAsync, useDocumentTitle } from '@/components/ui';
import { AppCard, DeadlineItem } from '@/components/Cards';

interface DashData {
  applications: AppSummary[];
  status_counts: Record<string, number>;
  total_applications: number;
  needs_action: AppSummary[];
  unpaid: AppSummary[];
  notifications: NotificationItem[];
  unread_notifications: number;
  unread_messages: number;
  deadlines: Deadline[];
  announcements: Announcement[];
}

export default function Dashboard() {
  const { t, pick, lang } = useI18n();
  const { user } = useAuth();
  const { services, settings } = useSite();
  const { data, loading, error, reload } = useAsync(() => api.get<DashData>('/me/dashboard'));
  useDocumentTitle(t('nav.dashboard'));
  const c = data?.status_counts ?? {};
  const active = (c.received ?? 0) + (c.in_progress ?? 0) + (c.awaiting_info ?? 0) + (c.correction_required ?? 0) + (c.on_hold ?? 0);

  return (
    <div className="stack" style={{ gap: 24 }}>
      <div className="welcome">
        <h1>{t('dash.welcome', { name: user?.first_name ?? '' })}</h1>
        <p>{pick(settings?.dashboard_welcome_sw, settings?.dashboard_welcome_en)}</p>
      </div>

      <section className="stack sm">
        <h2 className="dash-title">{t('nav.dashboard')}</h2>
        {loading ? (
          <SkeletonCards count={4} height={90} />
        ) : error ? (
          <ErrorState error={error} onRetry={reload} />
        ) : data ? (
          <div className="grid grid-4 stat-grid">
            <Stat icon={FileText} label={t('dash.total')} value={data.total_applications} color="blue" to="/app/maombi?tab=all" />
            <Stat icon={Loader} label={t('dash.active')} value={active} color="yellow" to="/app/maombi?tab=active" />
            <Stat icon={CheckCircle2} label={t('dash.completed')} value={c.completed ?? 0} color="green" to="/app/maombi?tab=done" />
            <Stat icon={Wallet} label={t('dash.unpaid')} value={data.unpaid.length} color="red" to="/app/maombi?tab=unpaid" />
          </div>
        ) : null}
      </section>

      {data && data.unread_messages > 0 && (
        <Alert kind="info" title={t('dash.unreadMessages', { n: data.unread_messages })}>
          <Link to="/app/ujumbe">{t('dash.openChat')} →</Link>
        </Alert>
      )}

      {data && data.needs_action.length > 0 && (
        <Card title={<h3 className="row" style={{ gap: 8 }}><AlertTriangle size={20} color="var(--c-danger)" /> {t('dash.needsAction')}</h3>}>
          <p className="small muted">{t('dash.needsActionText')}</p>
          <div className="grid grid-2">
            {data.needs_action.map((a) => (
              <AppCard key={a.id} a={a} />
            ))}
          </div>
        </Card>
      )}

      <section className="card">
        <div className="section-title" style={{ marginBottom: 12 }}>
          <h2 style={{ fontSize: '1.15rem' }}>{t('dash.startNew')}</h2>
          <Link to="/app/omba" className="small">
            {t('common.viewAll')} →
          </Link>
        </div>
        <div className="grid grid-4">
          {services.map((s) => (
            <Link key={s.id} to={s.accepting ? `/app/omba/${s.code}` : `/huduma/${s.slug}`} className="card card-link stack sm start-tile">
              <ServiceIcon name={s.icon} />
              <strong className="small">{pick(s.name_sw, s.name_en)}</strong>
              <span className="xs muted">{s.price !== null ? `TZS ${s.price.toLocaleString()}` : pick(s.price_note_sw, s.price_note_en) || t('common.priceTba')}</span>
            </Link>
          ))}
        </div>
      </section>

      {data ? (
        <>
          <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(min(100%, 380px), 1fr))', alignItems: 'start' }}>
            <Card title={t('dash.recentApps')} actions={<Link to="/app/maombi" className="small">{t('common.viewAll')} →</Link>}>
              {data.applications.length === 0 ? (
                <EmptyState icon={FileText} title={t('dash.noApps')} text={t('dash.noAppsText')} />
              ) : (
                <div className="stack sm">
                  {data.applications.slice(0, 4).map((a) => (
                    <AppCard key={a.id} a={a} />
                  ))}
                </div>
              )}
            </Card>
            <div className="stack">
              <Card title={t('dash.recentNotifications')} actions={<Link to="/app/arifa" className="small">{t('common.viewAll')} →</Link>}>
                {data.notifications.length === 0 ? (
                  <p className="small muted mb-0">{t('dash.noNotifications')}</p>
                ) : (
                  <div className="stack sm">
                    {data.notifications.map((n) => (
                      <Link key={n.id} to={n.link ?? '/app/arifa'} className="row" style={{ flexWrap: 'nowrap', alignItems: 'flex-start', color: 'inherit', textDecoration: 'none' }}>
                        <Bell size={16} color={n.read ? 'var(--c-muted)' : 'var(--c-blue)'} style={{ marginTop: 3, flexShrink: 0 }} />
                        <div className="grow">
                          <div className="small" style={{ fontWeight: n.read ? 500 : 700 }}>
                            {pick(n.title_sw, n.title_en)}
                          </div>
                          <div className="xs muted">{fmtRelative(n.created_at, lang)}</div>
                        </div>
                      </Link>
                    ))}
                  </div>
                )}
              </Card>
              <Card title={t('dash.upcomingDeadlines')}>
                {data.deadlines.length === 0 ? <p className="small muted mb-0">{t('home.noDeadlines')}</p> : <div className="stack">{data.deadlines.map((d) => <DeadlineItem key={d.id} d={d} />)}</div>}
              </Card>
              {data.announcements.length > 0 && (
                <Card title={t('dash.latestAnnouncements')}>
                  <div className="stack sm">
                    {data.announcements.map((a) => (
                      <Link key={a.id} to={`/matangazo#a${a.id}`} className="small">
                        {pick(a.title_sw, a.title_en)}
                      </Link>
                    ))}
                  </div>
                </Card>
              )}
              <Card title={t('dash.help')}>
                <p className="small muted">{t('dash.helpText')}</p>
                <div className="row">
                  <LinkButton to="/app/msaada" variant="secondary" size="sm" icon={HelpCircle}>
                    {t('nav.help')}
                  </LinkButton>
                  <LinkButton to="/app/ujumbe" size="sm" icon={MessageCircle}>
                    {t('nav.messages')}
                  </LinkButton>
                  <LinkButton to="/app/makundi" variant="ghost" size="sm" icon={Users}>
                    {t('nav.groups')}
                  </LinkButton>
                </div>
              </Card>
            </div>
          </div>
        </>
      ) : null}
    </div>
  );
}
