import { Children, useEffect, useRef, useState, type FormEvent, type ReactNode } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  ArrowRight,
  BookOpen,
  CalendarClock,
  ChevronLeft,
  ChevronRight,
  ClipboardList,
  FileText,
  Megaphone,
  MessageCircle,
  Phone,
  Rocket,
  Search,
  Sparkles,
  UserPlus,
  LayoutGrid,
  BadgeCheck,
  ShieldCheck,
  Headphones,
} from 'lucide-react';
import { useI18n } from '@/i18n';
import { useSite } from '@/context/SiteContext';
import { useAuth } from '@/context/AuthContext';
import { api } from '@/lib/api';
import { fmtPhone, waLink } from '@/lib/format';
import type { Announcement, ArticleSummary, Deadline, Faq, Guidebook, Institution, Testimonial } from '@/lib/types';
import { DownloadAppButton } from '@/components/Shared';
import { LinkButton, ServiceIcon, SkeletonCards, useAsync, useDocumentTitle } from '@/components/ui';
import { ArticleCard, DeadlineItem, FaqList, InstitutionCard, ServiceCard, TestimonialCard } from '@/components/Cards';

interface HomeData {
  deadlines: Deadline[];
  articles: ArticleSummary[];
  institutions: Institution[];
  guidebooks: Guidebook[];
  faqs: Faq[];
  announcements: Announcement[];
}

const HERO_VIDEO_ID = 'kPv0bfTuW4M';

/** Fades/slides children in when they scroll into view. */
function Reveal({ children, delay = 0, className = '' }: { children: ReactNode; delay?: number; className?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const [shown, setShown] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el || !('IntersectionObserver' in window)) return setShown(true);
    const io = new IntersectionObserver(
      (entries) => {
        if (entries.some((e) => e.isIntersecting)) {
          setShown(true);
          io.disconnect();
        }
      },
      { threshold: 0.12, rootMargin: '0px 0px -40px 0px' },
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return (
    <div ref={ref} className={`reveal ${shown ? 'in' : ''} ${className}`} style={{ transitionDelay: `${delay}ms` }}>
      {children}
    </div>
  );
}

/** Horizontal swipe slider on mobile (scroll-snap), regular grid on desktop. */
function Slider({ children, className = '' }: { children: ReactNode; className?: string }) {
  const { t } = useI18n();
  const ref = useRef<HTMLDivElement>(null);
  const [active, setActive] = useState(0);
  const count = Children.count(children);
  const onScroll = () => {
    const el = ref.current;
    if (!el) return;
    const item = el.firstElementChild as HTMLElement | null;
    const w = item ? item.offsetWidth + 14 : el.clientWidth;
    setActive(Math.min(count - 1, Math.round(el.scrollLeft / w)));
  };
  const go = (i: number) => {
    const el = ref.current;
    const item = el?.children[i] as HTMLElement | undefined;
    if (el && item) el.scrollTo({ left: item.offsetLeft - el.offsetLeft - 16, behavior: 'smooth' });
  };
  return (
    <div className={`slider ${className}`}>
      <div className="slider-track" ref={ref} onScroll={onScroll}>
        {children}
      </div>
      <div className="slider-controls">
        <button className="slider-arrow" onClick={() => go(Math.max(0, active - 1))} aria-label={t('common.previous')} disabled={active === 0}>
          <ChevronLeft />
        </button>
        <div className="slider-dots" aria-hidden>
          {Array.from({ length: count }).map((_, i) => (
            <span key={i} className={i === active ? 'on' : ''} />
          ))}
        </div>
        <button className="slider-arrow" onClick={() => go(Math.min(count - 1, active + 1))} aria-label={t('common.next')} disabled={active >= count - 1}>
          <ChevronRight />
        </button>
      </div>
    </div>
  );
}

const VIDEO_START = 18; // seconds skipped at the beginning
const VIDEO_TRIM_END = 20; // seconds cut from the end

interface YTPlayer {
  playVideo(): void;
  mute(): void;
  seekTo(s: number, allow: boolean): void;
  getCurrentTime(): number;
  getDuration(): number;
  destroy(): void;
}
type YTNamespace = { Player: new (el: HTMLElement, opts: Record<string, unknown>) => YTPlayer; PlayerState: { ENDED: number; PLAYING: number } };
declare global {
  interface Window {
    YT?: YTNamespace;
    onYouTubeIframeAPIReady?: () => void;
  }
}

function loadYouTubeApi(): Promise<YTNamespace> {
  return new Promise((resolve) => {
    if (window.YT?.Player) return resolve(window.YT);
    const prev = window.onYouTubeIframeAPIReady;
    window.onYouTubeIframeAPIReady = () => {
      prev?.();
      if (window.YT) resolve(window.YT);
    };
    if (!document.querySelector('script[data-yt-api]')) {
      const tag = document.createElement('script');
      tag.src = 'https://www.youtube.com/iframe_api';
      tag.async = true;
      tag.dataset.ytApi = '1';
      document.head.appendChild(tag);
    }
  });
}

/**
 * Muted background video behind the hero. Starts at VIDEO_START and loops back
 * before the last VIDEO_TRIM_END seconds. Fades in only once it is playing.
 */
function HeroVideo() {
  const host = useRef<HTMLDivElement>(null);
  const [playing, setPlaying] = useState(false);
  useEffect(() => {
    const conn = (navigator as unknown as { connection?: { saveData?: boolean } }).connection;
    if (conn?.saveData || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    let player: YTPlayer | null = null;
    let timer = 0;
    let cancelled = false;
    const start = window.setTimeout(() => {
      void loadYouTubeApi().then((YT) => {
        if (cancelled || !host.current) return;
        const el = document.createElement('div');
        host.current.appendChild(el);
        player = new YT.Player(el, {
          videoId: HERO_VIDEO_ID,
          host: 'https://www.youtube-nocookie.com',
          playerVars: { autoplay: 1, mute: 1, controls: 0, start: VIDEO_START, playsinline: 1, rel: 0, modestbranding: 1, iv_load_policy: 3, disablekb: 1, fs: 0 },
          events: {
            onReady: () => {
              player?.mute();
              player?.playVideo();
            },
            onStateChange: (e: { data: number }) => {
              if (e.data === YT.PlayerState.PLAYING) setPlaying(true);
              if (e.data === YT.PlayerState.ENDED) player?.seekTo(VIDEO_START, true);
            },
          },
        });
        timer = window.setInterval(() => {
          try {
            const d = player?.getDuration() ?? 0;
            if (d > VIDEO_START + VIDEO_TRIM_END && (player?.getCurrentTime() ?? 0) >= d - VIDEO_TRIM_END) player?.seekTo(VIDEO_START, true);
          } catch {
            /* player not ready */
          }
        }, 400);
      });
    }, 500);
    return () => {
      cancelled = true;
      window.clearTimeout(start);
      window.clearInterval(timer);
      try {
        player?.destroy();
      } catch {
        /* ignore */
      }
    };
  }, []);
  return <div className={`hero-video ${playing ? 'on' : ''}`} ref={host} aria-hidden />;
}

export default function Home() {
  const { t, pick } = useI18n();
  const { settings, services, loading } = useSite();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [q, setQ] = useState('');
  const { data } = useAsync(() => api.get<HomeData>('/home'));
  const { data: testimonials } = useAsync(() => api.get<Testimonial[]>('/testimonials'));
  useDocumentTitle('');

  const onSearch = (e: FormEvent) => {
    e.preventDefault();
    if (q.trim()) navigate(`/tafuta?q=${encodeURIComponent(q.trim())}`);
  };
  const startTo = user ? (user.is_staff ? '/admin' : '/app') : '/register';

  const steps = [
    { icon: UserPlus, title: t('home.how1'), text: t('home.how1Text') },
    { icon: LayoutGrid, title: t('home.how2'), text: t('home.how2Text') },
    { icon: ClipboardList, title: t('home.how3'), text: t('home.how3Text') },
    { icon: Rocket, title: t('home.how4'), text: t('home.how4Text') },
  ];

  return (
    <div className="home">
      {/* ------------------------------------------------ HERO */}
      <section className="hero3">
        <HeroVideo />
        <div className="hero3-overlay" />
        <div className="container hero3-inner">
          <div className="hero3-copy">
            <img src="/brand/logo-160.png" alt="" className="hero3-mark anim-up" width={76} height={76} />
            <span className="hero-badge anim-up" style={{ animationDelay: '.05s' }}>
              <Sparkles /> {t('home.heroBadge')}
            </span>
            <h1>
              {pick(settings?.hero_title_sw, settings?.hero_title_en) || t('brand.tagline')}
            </h1>
            <p className="lead anim-up" style={{ animationDelay: '.25s' }}>
              {pick(settings?.hero_text_sw, settings?.hero_text_en)}
            </p>
            <div className="hero3-ctas anim-up" style={{ animationDelay: '.35s' }}>
              <LinkButton to={startTo} size="lg" icon={ArrowRight} className="btn-glow">
                {t('home.heroCtaPrimary')}
              </LinkButton>
              <a href="#huduma" className="btn btn-light btn-lg hero3-m">
                <LayoutGrid /> {t('home.exploreServices')}
              </a>
              <LinkButton to="/elimu" size="lg" variant="light" className="hero3-d">
                {t('home.heroCtaSecondary')}
              </LinkButton>
              <DownloadAppButton />
            </div>
            <form className="hero-search anim-up" style={{ animationDelay: '.45s' }} onSubmit={onSearch} role="search">
              <Search className="search-ico" aria-hidden />
              <input className="input" value={q} onChange={(e) => setQ(e.target.value)} placeholder={t('common.searchPlaceholder')} aria-label={t('common.search')} />
              <button className="btn btn-navy" type="submit" aria-label={t('common.search')}>
                <ArrowRight className="hero3-m" />
                <Search className="hero3-d" />
              </button>
            </form>
            <div className="hero-trust anim-up" style={{ animationDelay: '.55s' }}>
              <span>
                <BadgeCheck /> {t('services.pillPrices')}
              </span>
              <span>
                <ShieldCheck /> {t('services.pillSafe')}
              </span>
              <span>
                <Headphones /> {t('services.pillSupport')}
              </span>
            </div>
          </div>
          <div className="hero-panel anim-up" style={{ animationDelay: '.3s' }}>
            <div className="small" style={{ fontWeight: 700, marginBottom: 12, opacity: 0.9 }}>
              {t('home.quickTitle')}
            </div>
            {services.slice(0, 6).map((s) => (
              <Link key={s.id} to={`/huduma/${s.slug}`} className="hp-item">
                <ServiceIcon name={s.icon} className="hp-icon" />
                <span className="grow small" style={{ fontWeight: 600 }}>
                  {pick(s.name_sw, s.name_en)}
                </span>
                <ArrowRight size={16} />
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ------------------------------------------------ SERVICE MARQUEE */}
      {services.length > 0 && (
        <div className="marquee" aria-hidden>
          <div className="marquee-track">
            {[...services, ...services].map((s, i) => (
              <span key={i} className="marquee-item">
                <ServiceIcon name={s.icon} className="mq-icon" /> {pick(s.name_sw, s.name_en)}
              </span>
            ))}
          </div>
        </div>
      )}

      {data && data.announcements.length > 0 && (
        <div className="container" style={{ marginTop: 20 }}>
          {data.announcements.slice(0, 1).map((a) => (
            <Link key={a.id} to={`/matangazo#a${a.id}`} className="announce-bar">
              <span className="pulse-dot" />
              <Megaphone size={18} />
              <strong className="grow">{pick(a.title_sw, a.title_en)}</strong>
              <ArrowRight size={16} />
            </Link>
          ))}
        </div>
      )}

      {/* ------------------------------------------------ SERVICES */}
      <section className="section" id="huduma">
        <div className="container">
          <Reveal>
            <div className="section-head">
              <span className="eyebrow">{t('home.servicesEyebrow')}</span>
              <h2>{t('home.servicesTitle')}</h2>
              <p>{t('home.servicesText')}</p>
            </div>
          </Reveal>
          {loading ? (
            <SkeletonCards count={6} height={240} />
          ) : (
            <div className="grid grid-3">
              {services.map((s, i) => (
                <Reveal key={s.id} delay={i * 70}>
                  <ServiceCard service={s} />
                </Reveal>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* ------------------------------------------------ HOW IT WORKS */}
      <section className="section how">
        <div className="container">
          <Reveal>
            <div className="section-head light">
              <span className="eyebrow">{t('home.howEyebrow')}</span>
              <h2>{t('home.howTitle')}</h2>
              <p className="swipe-hint">{t('home.swipeHint')} →</p>
            </div>
          </Reveal>
          <Slider className="steps-slider">
            {steps.map((s, i) => (
              <div key={i} className="step2">
                <span className="step2-num">{String(i + 1).padStart(2, '0')}</span>
                <span className="step2-icon">
                  <s.icon />
                </span>
                <h3>{s.title}</h3>
                <p>{s.text}</p>
              </div>
            ))}
          </Slider>
        </div>
      </section>

      {/* ------------------------------------------------ DEADLINES + GUIDES */}
      <section className="section">
        <div className="container grid grid-2" style={{ alignItems: 'start' }}>
          <Reveal>
            <div className="card glass-card">
              <div className="card-header">
                <h3 className="row" style={{ gap: 8 }}>
                  <CalendarClock size={20} color="var(--c-blue)" /> {t('home.deadlinesTitle')}
                </h3>
                <Link to="/deadlines" className="small">
                  {t('common.viewAll')} →
                </Link>
              </div>
              <div className="stack">
                {data?.deadlines.length ? data.deadlines.map((d) => <DeadlineItem key={d.id} d={d} />) : <p className="muted small mb-0">{t('home.noDeadlines')}</p>}
              </div>
            </div>
          </Reveal>
          <Reveal delay={120}>
            <div className="card glass-card">
              <div className="card-header">
                <h3 className="row" style={{ gap: 8 }}>
                  <FileText size={20} color="var(--c-blue)" /> {t('home.guidesTitle')}
                </h3>
                <Link to="/miongozo" className="small">
                  {t('common.viewAll')} →
                </Link>
              </div>
              <div className="stack sm">
                {data?.guidebooks.length ? (
                  data.guidebooks.map((g) => (
                    <Link key={g.id} to={`/miongozo?q=${encodeURIComponent(g.title_sw)}`} className="guide-row">
                      <span className="badge plain info">{g.academic_year ?? 'PDF'}</span>
                      <span className="small grow">{pick(g.title_sw, g.title_en)}</span>
                      <ArrowRight size={14} />
                    </Link>
                  ))
                ) : (
                  <p className="muted small mb-0">{t('guides.empty')}</p>
                )}
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      {/* ------------------------------------------------ LATEST GUIDANCE */}
      {data && data.articles.length > 0 && (
        <section className="section alt">
          <div className="container">
            <Reveal>
              <div className="section-head row-head">
                <div>
                  <span className="eyebrow">
                    <BookOpen size={12} /> {t('nav.education')}
                  </span>
                  <h2>{t('home.articlesTitle')}</h2>
                  <p className="swipe-hint">{t('home.swipeHint')} →</p>
                </div>
                <Link to="/elimu" className="btn btn-secondary btn-sm">
                  {t('common.viewAll')} <ArrowRight />
                </Link>
              </div>
            </Reveal>
            <Slider className="articles-slider">
              {data.articles.map((a) => (
                <ArticleCard key={a.id} a={a} />
              ))}
            </Slider>
          </div>
        </section>
      )}

      {/* ------------------------------------------------ INSTITUTIONS */}
      {data && data.institutions.length > 0 && (
        <section className="section">
          <div className="container">
            <Reveal>
              <div className="section-head row-head">
                <div>
                  <span className="eyebrow">{t('nav.institutions')}</span>
                  <h2>{t('home.institutionsTitle')}</h2>
                </div>
                <Link to="/vyuo" className="btn btn-secondary btn-sm">
                  {t('common.viewAll')} <ArrowRight />
                </Link>
              </div>
            </Reveal>
            <div className="grid grid-3">
              {data.institutions.slice(0, 6).map((i, n) => (
                <Reveal key={i.id} delay={n * 60}>
                  <InstitutionCard i={i} />
                </Reveal>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* ------------------------------------------------ TESTIMONIALS */}
      {testimonials && testimonials.length > 0 && (
        <section className="section alt">
          <div className="container">
            <Reveal>
              <div className="section-head row-head">
                <div>
                  <span className="eyebrow">{t('testimonials.eyebrow')}</span>
                  <h2>{t('testimonials.title')}</h2>
                  <p className="swipe-hint">{t('home.swipeHint')} →</p>
                </div>
                <Link to="/shuhuda" className="btn btn-secondary btn-sm">
                  {t('testimonials.viewAll')} <ArrowRight />
                </Link>
              </div>
            </Reveal>
            <Slider className="articles-slider">
              {testimonials.slice(0, 6).map((x) => (
                <TestimonialCard key={x.id} x={x} />
              ))}
            </Slider>
          </div>
        </section>
      )}

      {/* ------------------------------------------------ FAQ */}
      {data && data.faqs.length > 0 && (
        <section className="section alt">
          <div className="container" style={{ maxWidth: 860 }}>
            <Reveal>
              <div className="section-head">
                <span className="eyebrow">FAQ</span>
                <h2>{t('home.faqTitle')}</h2>
              </div>
            </Reveal>
            <Reveal delay={100}>
              <FaqList items={data.faqs} />
            </Reveal>
          </div>
        </section>
      )}

      {/* ------------------------------------------------ CTA */}
      <section className="section">
        <div className="container">
          <Reveal>
            <div className="cta-band">
              <div className="blob b1" />
              <div className="blob b2" />
              <img src="/brand/logo-160.png" alt="" className="cta-logo" />
              <h2>{t('home.ctaTitle')}</h2>
              <p>{t('home.ctaText')}</p>
              <div className="cta-actions">
                <LinkButton to={startTo} size="lg" icon={ArrowRight} className="btn-glow">
                  {t('home.heroCtaPrimary')}
                </LinkButton>
                {settings?.contact_whatsapp && (
                  <a className="btn btn-success btn-lg" href={waLink(settings.contact_whatsapp)} target="_blank" rel="noopener noreferrer">
                    <MessageCircle /> WhatsApp
                  </a>
                )}
                {settings?.contact_phone && (
                  <a className="btn btn-light btn-lg" href={`tel:${settings.contact_phone}`}>
                    <Phone /> {fmtPhone(settings.contact_phone)}
                  </a>
                )}
              </div>
              <div className="cta-legal">
                <Link to="/kuhusu">{t('nav.about')}</Link>
                <Link to="/mawasiliano">{t('nav.contact')}</Link>
                <Link to="/faragha">{t('nav.privacy')}</Link>
                <Link to="/masharti">{t('nav.terms')}</Link>
                <span>© {new Date().getFullYear()} {settings?.brand_name || 'Mediator Hamza'}</span>
              </div>
            </div>
          </Reveal>
        </div>
      </section>
    </div>
  );
}
