import { useState, type FormEvent } from 'react';
import { Link, Navigate, useLocation, useNavigate, useSearchParams } from 'react-router-dom';
import { KeyRound, LogIn, ShieldCheck, User as UserIcon, UserCog, UserPlus } from 'lucide-react';
import { useI18n } from '@/i18n';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/context/ToastContext';
import { api, ApiError } from '@/lib/api';
import type { User } from '@/lib/types';
import { Alert, Button, Checkbox, Loading, Logo, PasswordField, TextField, useDocumentTitle, useErrorText } from '@/components/ui';
import { LangSwitch } from '@/components/Shared';

/** Only allow in-app relative redirects (prevents open redirects). */
function safeNext(next: string | null, fallback: string) {
  return next && next.startsWith('/') && !next.startsWith('//') ? next : fallback;
}

function useFieldErrors() {
  const { tv } = useI18n();
  const [errors, setErrors] = useState<Record<string, string>>({});
  return { errors, setErrors, e: (k: string) => (errors[k] ? tv(errors[k]) : null) };
}

export function LoginPage() {
  const { t } = useI18n();
  const { user, ready, setSession } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const next = safeNext(params.get('next'), '/app');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const errText = useErrorText();
  useDocumentTitle(t('nav.login'));

  if (!ready) return <Loading />;
  if (user) return <Navigate to={user.is_staff ? '/admin' : next} replace />;

  const submit = async (ev: FormEvent) => {
    ev.preventDefault();
    setBusy(true);
    setError('');
    try {
      const res = await api.post<{ user: User; csrf: string }>('/auth/login', { phone, password });
      setSession(res);
      toast(t('auth.welcomeBack', { name: res.user.first_name }));
      navigate(next, { replace: true });
    } catch (err) {
      setError(err instanceof ApiError && err.status === 401 ? err.message : errText(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="auth-wrap">
      <div className="card pad-lg auth-card">
        <AccountTypeSwitch active="user" />
        <h1>{t('auth.loginTitle')}</h1>
        <p className="muted">{t('auth.loginSubtitle')}</p>
        {params.get('next')?.startsWith('/app/omba') && <Alert kind="info">{t('auth.loginToContinue')}</Alert>}
        <form className="stack mt-4" onSubmit={submit} noValidate>
          {error && <Alert kind="danger">{error}</Alert>}
          <TextField label={t('auth.phone')} type="tel" inputMode="tel" autoComplete="tel" placeholder="07XX XXX XXX" required value={phone} onChange={(e) => setPhone(e.target.value)} />
          <PasswordField label={t('auth.password')} autoComplete="current-password" required value={password} onChange={(e) => setPassword(e.target.value)} />
          <div className="row between small">
            <Link to="/forgot-password">{t('auth.forgot')}</Link>
          </div>
          <Button type="submit" size="lg" block loading={busy} icon={LogIn}>
            {t('auth.loginButton')}
          </Button>
        </form>
        <p className="text-center small mt-6 mb-0">
          {t('auth.noAccount')} <Link to={`/register${params.get('next') ? `?next=${encodeURIComponent(next)}` : ''}`}>{t('nav.register')}</Link>
        </p>
      </div>
    </div>
  );
}

export function RegisterPage() {
  const { t, lang } = useI18n();
  const { user, ready, setSession } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [params] = useSearchParams();
  const next = safeNext(params.get('next'), '/app');
  const [f, setF] = useState({ first_name: '', second_name: '', phone: '', password: '', password_confirmation: '', accept_terms: false });
  const { errors, setErrors, e } = useFieldErrors();
  const [busy, setBusy] = useState(false);
  const errText = useErrorText();
  useDocumentTitle(t('nav.register'));

  if (!ready) return <Loading />;
  if (user) return <Navigate to={user.is_staff ? '/admin' : next} replace />;

  const submit = async (ev: FormEvent) => {
    ev.preventDefault();
    const local: Record<string, string> = {};
    if (f.password !== f.password_confirmation) local.password_confirmation = 'password_mismatch';
    if (!f.accept_terms) local.accept_terms = 'accept_terms';
    if (Object.keys(local).length) return setErrors(local);
    setBusy(true);
    setErrors({});
    try {
      const res = await api.post<{ user: User; csrf: string }>('/auth/register', { ...f, language: lang });
      setSession(res);
      toast(t('auth.welcomeBack', { name: res.user.first_name }));
      navigate(next, { replace: true });
    } catch (err) {
      if (err instanceof ApiError && err.status === 422) setErrors(err.fields);
      else toast(errText(err), 'error');
    } finally {
      setBusy(false);
    }
  };
  const termsLabel = t('auth.acceptTerms', { terms: '§T§', privacy: '§P§' }).split(/(§T§|§P§)/);

  return (
    <div className="auth-wrap">
      <div className="card pad-lg auth-card">
        <h1>{t('auth.registerTitle')}</h1>
        <p className="muted">{t('auth.registerSubtitle')}</p>
        {params.get('next')?.startsWith('/app/omba') && <Alert kind="info">{t('auth.loginToContinue')}</Alert>}
        <form className="stack mt-4" onSubmit={submit} noValidate>
          <div className="form-grid">
            <TextField label={t('auth.firstName')} required autoComplete="given-name" value={f.first_name} onChange={(ev) => setF({ ...f, first_name: ev.target.value })} error={e('first_name')} />
            <TextField label={t('auth.secondName')} required autoComplete="family-name" value={f.second_name} onChange={(ev) => setF({ ...f, second_name: ev.target.value })} error={e('second_name')} />
          </div>
          <TextField label={t('auth.phone')} type="tel" inputMode="tel" autoComplete="tel" placeholder="07XX XXX XXX" required help={t('auth.phoneHelp')} value={f.phone} onChange={(ev) => setF({ ...f, phone: ev.target.value })} error={e('phone')} />
          <PasswordField label={t('auth.password')} autoComplete="new-password" required help={t('auth.passwordHelp')} value={f.password} onChange={(ev) => setF({ ...f, password: ev.target.value })} error={e('password')} />
          <PasswordField label={t('auth.passwordConfirm')} autoComplete="new-password" required value={f.password_confirmation} onChange={(ev) => setF({ ...f, password_confirmation: ev.target.value })} error={e('password_confirmation')} />
          <div>
            <Checkbox checked={f.accept_terms} onChange={(v) => setF({ ...f, accept_terms: v })}>
              {termsLabel.map((part, i) =>
                part === '§T§' ? (
                  <Link key={i} to="/masharti" target="_blank">
                    {t('nav.terms')}
                  </Link>
                ) : part === '§P§' ? (
                  <Link key={i} to="/faragha" target="_blank">
                    {t('nav.privacy')}
                  </Link>
                ) : (
                  <span key={i}>{part}</span>
                ),
              )}
            </Checkbox>
            {errors.accept_terms && <div className="field-error mt-2">{e('accept_terms')}</div>}
          </div>
          <Button type="submit" size="lg" block loading={busy} icon={UserPlus}>
            {t('auth.registerButton')}
          </Button>
        </form>
        <p className="text-center small mt-6 mb-0">
          {t('auth.haveAccount')} <Link to={`/login${params.get('next') ? `?next=${encodeURIComponent(next)}` : ''}`}>{t('nav.login')}</Link>
        </p>
      </div>
    </div>
  );
}

export function ForgotPasswordPage() {
  const { t } = useI18n();
  const navigate = useNavigate();
  const [phone, setPhone] = useState('');
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<{ sms_enabled: boolean } | null>(null);
  const [error, setError] = useState('');
  const errText = useErrorText();
  useDocumentTitle(t('auth.forgotTitle'));

  const submit = async (ev: FormEvent) => {
    ev.preventDefault();
    setBusy(true);
    setError('');
    try {
      setResult(await api.post<{ sms_enabled: boolean }>('/auth/forgot-password', { phone }));
    } catch (err) {
      setError(errText(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="auth-wrap">
      <div className="card pad-lg auth-card">
        <h1>{t('auth.forgotTitle')}</h1>
        <p className="muted">{t('auth.forgotSubtitle')}</p>
        {result ? (
          <div className="stack">
            <Alert kind="success">{t('auth.codeSent')}</Alert>
            {!result.sms_enabled && <Alert kind="warning">{t('auth.smsNotLive')}</Alert>}
            <Button onClick={() => navigate(`/reset-password?phone=${encodeURIComponent(phone)}`)} icon={KeyRound} block>
              {t('auth.haveCode')}
            </Button>
          </div>
        ) : (
          <form className="stack mt-4" onSubmit={submit} noValidate>
            {error && <Alert kind="danger">{error}</Alert>}
            <TextField label={t('auth.phone')} type="tel" inputMode="tel" autoComplete="tel" required value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="07XX XXX XXX" />
            <Button type="submit" size="lg" block loading={busy}>
              {t('auth.sendCode')}
            </Button>
            <Link to="/reset-password" className="small text-center">
              {t('auth.haveCode')}
            </Link>
          </form>
        )}
        <p className="text-center small mt-6 mb-0">
          <Link to="/login">← {t('nav.login')}</Link>
        </p>
      </div>
    </div>
  );
}

export function ResetPasswordPage() {
  const { t } = useI18n();
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [f, setF] = useState({ phone: params.get('phone') ?? '', code: '', password: '', password_confirmation: '' });
  const { setErrors, e } = useFieldErrors();
  const [busy, setBusy] = useState(false);
  const errText = useErrorText();
  useDocumentTitle(t('auth.resetTitle'));

  const submit = async (ev: FormEvent) => {
    ev.preventDefault();
    setBusy(true);
    setErrors({});
    try {
      await api.post('/auth/reset-password', f);
      toast(t('auth.resetDone'));
      navigate('/login', { replace: true });
    } catch (err) {
      if (err instanceof ApiError && err.status === 422) setErrors(err.fields);
      else toast(errText(err), 'error');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="auth-wrap">
      <div className="card pad-lg auth-card">
        <h1>{t('auth.resetTitle')}</h1>
        <p className="muted">{t('auth.resetSubtitle')}</p>
        <form className="stack mt-4" onSubmit={submit} noValidate>
          <TextField label={t('auth.phone')} type="tel" inputMode="tel" required value={f.phone} onChange={(ev) => setF({ ...f, phone: ev.target.value })} error={e('phone')} />
          <TextField label={t('auth.code')} required autoComplete="one-time-code" value={f.code} onChange={(ev) => setF({ ...f, code: ev.target.value })} error={e('code')} style={{ letterSpacing: '0.2em', textTransform: 'uppercase' }} />
          <PasswordField label={t('auth.newPassword')} autoComplete="new-password" required help={t('auth.passwordHelp')} value={f.password} onChange={(ev) => setF({ ...f, password: ev.target.value })} error={e('password')} />
          <PasswordField label={t('auth.passwordConfirm')} autoComplete="new-password" required value={f.password_confirmation} onChange={(ev) => setF({ ...f, password_confirmation: ev.target.value })} error={e('password_confirmation')} />
          <Button type="submit" size="lg" block loading={busy} icon={KeyRound}>
            {t('auth.resetButton')}
          </Button>
        </form>
      </div>
    </div>
  );
}

export function AdminLoginPage() {
  const { t } = useI18n();
  const { user, ready, setSession } = useAuth();
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const next = safeNext(params.get('next'), '/admin');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [code, setCode] = useState('');
  const [needs2fa, setNeeds2fa] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const errText = useErrorText();
  useDocumentTitle(t('auth.adminTitle'));

  if (!ready) return <Loading />;
  if (user?.is_staff) return <Navigate to={next.startsWith('/admin') ? next : '/admin'} replace />;

  const submit = async (ev: FormEvent) => {
    ev.preventDefault();
    setBusy(true);
    setError('');
    try {
      if (needs2fa) {
        const res = await api.post<{ user: User; csrf: string }>('/admin/auth/2fa', { code });
        setSession(res);
        navigate(next, { replace: true });
        return;
      }
      const res = await api.post<{ user?: User; csrf: string; requires_2fa?: boolean }>('/admin/auth/login', { phone, password });
      if (res.requires_2fa) {
        setSession({ user: null, csrf: res.csrf });
        setNeeds2fa(true);
      } else if (res.user) {
        setSession({ user: res.user, csrf: res.csrf });
        navigate(next, { replace: true });
      }
    } catch (err) {
      if (err instanceof ApiError && err.status === 422) setError(t('validation.code_invalid'));
      else setError(err instanceof ApiError && err.status === 401 ? err.message : errText(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="admin-auth">
      <div className="card pad-lg auth-card">
        <div className="row between mb-4">
          <Logo />
          <LangSwitch />
        </div>
        {!needs2fa && <AccountTypeSwitch active="staff" />}
        <h1>{needs2fa ? t('auth.twoFactorTitle') : t('auth.adminTitle')}</h1>
        <p className="muted">{needs2fa ? t('auth.twoFactorText') : t('auth.adminSubtitle')}</p>
        <form className="stack mt-4" onSubmit={submit} noValidate>
          {error && <Alert kind="danger">{error}</Alert>}
          {needs2fa ? (
            <TextField label={t('auth.code')} inputMode="numeric" autoComplete="one-time-code" maxLength={6} required autoFocus value={code} onChange={(e) => setCode(e.target.value)} style={{ letterSpacing: '0.4em', fontSize: 22, textAlign: 'center' }} />
          ) : (
            <>
              <TextField label={t('auth.phone')} type="tel" inputMode="tel" autoComplete="username" required value={phone} onChange={(e) => setPhone(e.target.value)} />
              <PasswordField label={t('auth.password')} autoComplete="current-password" required value={password} onChange={(e) => setPassword(e.target.value)} />
            </>
          )}
          <Button type="submit" variant="navy" size="lg" block loading={busy} icon={ShieldCheck}>
            {needs2fa ? t('auth.verify') : t('auth.loginButton')}
          </Button>
        </form>
      </div>
    </div>
  );
}

/** One-time installer UI for hosts without SSH: creates the first Super Admin (requires INSTALL_TOKEN in .env). */
export function InstallPage() {
  const location = useLocation();
  const navigate = useNavigate();
  const [f, setF] = useState({ install_token: location.hash.replace(/^#/, ''), first_name: '', second_name: '', phone: '', password: '' });
  const [msg, setMsg] = useState<{ kind: 'success' | 'danger'; text: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const submit = async (ev: FormEvent) => {
    ev.preventDefault();
    setBusy(true);
    try {
      const r = await api.post<{ message: string }>('/install', f);
      setMsg({ kind: 'success', text: r.message });
      setTimeout(() => navigate('/admin/login'), 1500);
    } catch (err) {
      const e = err as ApiError;
      setMsg({ kind: 'danger', text: `${e.message} ${Object.entries(e.fields ?? {}).map(([k, v]) => `${k}: ${v}`).join(', ')}` });
    } finally {
      setBusy(false);
    }
  };
  return (
    <div className="admin-auth">
      <div className="card pad-lg auth-card">
        <h1>Mediator — Install</h1>
        <p className="muted small">Create the first Super Admin. Works only once, and only while INSTALL_TOKEN is set in .env.</p>
        <form className="stack" onSubmit={submit}>
          {msg && <Alert kind={msg.kind}>{msg.text}</Alert>}
          <PasswordField label="INSTALL_TOKEN" value={f.install_token} onChange={(e) => setF({ ...f, install_token: e.target.value })} />
          <TextField label="First name" value={f.first_name} onChange={(e) => setF({ ...f, first_name: e.target.value })} />
          <TextField label="Second name" value={f.second_name} onChange={(e) => setF({ ...f, second_name: e.target.value })} />
          <TextField label="Phone" type="tel" value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} />
          <PasswordField label="Password (min 12, letters + digits)" autoComplete="new-password" value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} />
          <Button type="submit" variant="navy" loading={busy}>
            Create Super Admin
          </Button>
        </form>
      </div>
    </div>
  );
}

/** Lets visitors pick which account they are signing in to: applicant or staff/admin. */
function AccountTypeSwitch({ active }: { active: 'user' | 'staff' }) {
  const { t } = useI18n();
  return (
    <div className="acct-switch" role="tablist" aria-label={t('auth.accountType')}>
      <Link to="/login" role="tab" aria-selected={active === 'user'} className={active === 'user' ? 'active' : ''}>
        <UserIcon /> {t('auth.userAccount')}
      </Link>
      <Link to="/admin/login" role="tab" aria-selected={active === 'staff'} className={active === 'staff' ? 'active' : ''}>
        <UserCog /> {t('nav.staffAccount')}
      </Link>
    </div>
  );
}
