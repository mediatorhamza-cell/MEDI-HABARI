import { useState, type FormEvent, type ReactNode } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Database, Eye, MessageCircle, Phone, Rocket } from 'lucide-react';
import { useI18n } from '@/i18n';
import { useAuth } from '@/context/AuthContext';
import { useSite } from '@/context/SiteContext';
import { useToast } from '@/context/ToastContext';
import { api, ApiError } from '@/lib/api';
import { fmtPhone, waLink } from '@/lib/format';
import { Alert, Button, Loading, Logo, PasswordField, TextField, useDocumentTitle, useErrorText } from '@/components/ui';
import { LangSwitch } from '@/components/Shared';

/** Shown to everyone except staff while the admin keeps the site in "coming soon" mode. */
export function ComingSoonPage() {
  const { t, pick } = useI18n();
  const { settings } = useSite();
  useDocumentTitle(t('launch.title'));
  return (
    <div className="admin-auth" style={{ alignContent: 'center' }}>
      <div className="stack text-center" style={{ maxWidth: 560, color: '#fff', alignItems: 'center' }}>
        <div className="row" style={{ justifyContent: 'space-between', width: '100%' }}>
          <Logo light />
          <LangSwitch />
        </div>
        <span className="icon-tile" style={{ width: 72, height: 72, borderRadius: '50%', background: 'rgba(37,99,235,.35)', color: '#fff', marginTop: 32 }}>
          <Rocket style={{ width: 34, height: 34 }} />
        </span>
        <h1 style={{ color: '#fff', fontSize: 'clamp(2rem,7vw,3rem)', margin: 0 }}>{t('launch.title')}</h1>
        <p style={{ fontSize: '1.1rem', opacity: 0.85, margin: 0 }}>{pick(settings?.coming_soon_sw, settings?.coming_soon_en) || t('launch.text')}</p>
        <p style={{ opacity: 0.7, margin: 0 }}>{t('brand.tagline')}</p>
        <div className="row" style={{ justifyContent: 'center', marginTop: 8 }}>
          {settings?.contact_whatsapp && (
            <a className="btn btn-success" href={waLink(settings.contact_whatsapp)} target="_blank" rel="noopener noreferrer">
              <MessageCircle /> WhatsApp
            </a>
          )}
          {settings?.contact_phone && (
            <a className="btn btn-light" href={`tel:${settings.contact_phone}`}>
              <Phone /> {fmtPhone(settings.contact_phone)}
            </a>
          )}
        </div>
        <Link to="/admin/login" className="xs" style={{ color: 'rgba(255,255,255,.45)', marginTop: 48 }}>
          Admin
        </Link>
      </div>
    </div>
  );
}

/** Thin banner telling staff the public currently sees "coming soon". */
export function PreviewBanner() {
  const { t } = useI18n();
  const { settings, reload } = useSite();
  const { user, can } = useAuth();
  const { toast } = useToast();
  const [busy, setBusy] = useState(false);
  if (!user?.is_staff || !settings || settings.site_live) return null;
  const open = async () => {
    setBusy(true);
    try {
      await api.put('/admin/settings', { settings: { site_live: true } });
      toast(t('launch.opened'));
      reload();
    } catch {
      toast(t('common.unknownError'), 'error');
    } finally {
      setBusy(false);
    }
  };
  return (
    <div className="alert warning no-print" style={{ borderRadius: 0, border: 0, justifyContent: 'center', alignItems: 'center', flexWrap: 'wrap' }}>
      <Eye />
      <span>{t('launch.previewBanner')}</span>
      {can('settings.manage') && (
        <Button size="sm" variant="success" loading={busy} onClick={() => void open()}>
          {t('launch.openNow')}
        </Button>
      )}
    </div>
  );
}

/** Decides whether to show the real site, the coming-soon page or the first-run setup. */
export function SiteGate({ children }: { children: ReactNode }) {
  const { settings, loading, notConfigured } = useSite();
  const { user, ready } = useAuth();
  const { pathname } = useLocation();
  if (notConfigured) return pathname === '/install' ? <>{children}</> : <SetupPage />;
  if (pathname === '/setup') return <SetupPage />;
  if (loading && !settings) return <Loading />;
  const bypass = pathname.startsWith('/admin') || pathname === '/install';
  if (settings && !settings.site_live && !bypass) {
    if (!ready) return <Loading />;
    if (!user?.is_staff) return <ComingSoonPage />;
  }
  return <>{children}</>;
}

/** First-run setup: connects the database and writes the private configuration. */
export function SetupPage() {
  const { t } = useI18n();
  const errText = useErrorText();
  const [f, setF] = useState({ db_host: 'localhost', db_database: '', db_username: '', db_password: '' });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  useDocumentTitle('Setup');
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      const r = await api.post<{ install_token: string }>('/setup', f);
      // Full reload so the app picks up the new configuration; token travels in the URL hash (never sent to the server).
      window.location.replace(`/install#${r.install_token}`);
    } catch (err) {
      if (err instanceof ApiError && ['db_connection_failed', 'setup_failed', 'already_installed', 'already_configured', 'too_many_requests'].includes(err.code)) setError(err.message);
      else if (err instanceof ApiError) setError(`${errText(err)} (HTTP ${err.status} ${err.code})`);
      else setError(errText(err));
    } finally {
      setBusy(false);
    }
  };
  return (
    <div className="admin-auth">
      <div className="card pad-lg auth-card">
        <div className="row between mb-4">
          <Logo />
          <LangSwitch />
        </div>
        <h1>{t('launch.setupTitle')}</h1>
        <p className="muted small">{t('launch.setupText')}</p>
        <form className="stack" onSubmit={submit}>
          {error && <Alert kind="danger">{error}</Alert>}
          <TextField label="DB host" value={f.db_host} onChange={(e) => setF({ ...f, db_host: e.target.value })} />
          <TextField label={t('launch.dbName')} required placeholder="u123456789_mediator" value={f.db_database} onChange={(e) => setF({ ...f, db_database: e.target.value })} />
          <TextField label={t('launch.dbUser')} required placeholder="u123456789_mediator" value={f.db_username} onChange={(e) => setF({ ...f, db_username: e.target.value })} />
          <PasswordField label={t('launch.dbPassword')} required value={f.db_password} onChange={(e) => setF({ ...f, db_password: e.target.value })} />
          <Button type="submit" variant="navy" icon={Database} loading={busy}>
            {t('launch.connect')}
          </Button>
        </form>
      </div>
    </div>
  );
}

/** Admin control to open the site or put it back in "coming soon" mode. */
export function SiteStatusCard() {
  const { t, pick } = useI18n();
  const { settings, reload } = useSite();
  const { can } = useAuth();
  const { toast } = useToast();
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ sw: string; en: string } | null>(null);
  if (!settings) return null;
  const live = !!settings.site_live;
  const save = async (patch: Record<string, unknown>, ok: string) => {
    setBusy(true);
    try {
      await api.put('/admin/settings', { settings: patch });
      toast(ok);
      reload();
    } catch {
      toast(t('common.unknownError'), 'error');
    } finally {
      setBusy(false);
    }
  };
  return (
    <div className="card" style={{ borderLeft: `5px solid ${live ? 'var(--c-success)' : 'var(--c-warning)'}` }}>
      <div className="row between">
        <div className="grow">
          <h3 className="mb-0">{t('launch.cardTitle')}</h3>
          <p className="small mb-0" style={{ color: live ? 'var(--c-success)' : '#b45309', fontWeight: 600 }}>
            {live ? t('launch.isLive') : t('launch.isComingSoon')}
          </p>
        </div>
        {can('settings.manage') && (
          <div className="row">
            {live ? (
              <Button variant="secondary" loading={busy} onClick={() => void save({ site_live: false }, t('launch.closed'))}>
                {t('launch.backToComingSoon')}
              </Button>
            ) : (
              <Button variant="success" icon={Rocket} loading={busy} onClick={() => void save({ site_live: true }, t('launch.opened'))}>
                {t('launch.openNow')}
              </Button>
            )}
            {!live && (
              <Button variant="ghost" size="sm" onClick={() => setMsg({ sw: settings.coming_soon_sw ?? '', en: settings.coming_soon_en ?? '' })}>
                {t('common.edit')}
              </Button>
            )}
          </div>
        )}
      </div>
      {msg && (
        <div className="stack mt-4">
          <TextField label={t('launch.messageSw')} value={msg.sw} onChange={(e) => setMsg({ ...msg, sw: e.target.value })} />
          <TextField label={t('launch.messageEn')} value={msg.en} onChange={(e) => setMsg({ ...msg, en: e.target.value })} />
          <div className="row">
            <Button loading={busy} onClick={() => void save({ coming_soon_sw: msg.sw, coming_soon_en: msg.en }, t('common.saved')).then(() => setMsg(null))}>
              {t('common.save')}
            </Button>
            <span className="xs muted">{pick(settings.coming_soon_sw, settings.coming_soon_en)}</span>
          </div>
        </div>
      )}
    </div>
  );
}
