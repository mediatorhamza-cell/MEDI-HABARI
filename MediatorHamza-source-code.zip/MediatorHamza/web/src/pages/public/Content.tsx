import { useEffect, useState, type FormEvent, type ReactNode } from 'react';
import { Link, useParams, useSearchParams } from 'react-router-dom';
import { BadgeCheck, CalendarClock, Download, Headphones, ShieldCheck, Mail, MessageCircle, Paperclip, Phone, Pin, Search as SearchIcon, Send, Clock } from 'lucide-react';
import { useI18n } from '@/i18n';
import { useSite } from '@/context/SiteContext';
import { api, mediaUrl, query } from '@/lib/api';
import { fmtDate, fmtPhone, waLink } from '@/lib/format';
import type { Announcement, ArticleSummary, Category, Deadline, Faq, FormSchemaDef, Guidebook, Institution, Service, Testimonial } from '@/lib/types';
import {
  Alert,
  Breadcrumbs,
  Button,
  Card,
  Checkbox,
  EmptyState,
  ErrorState,
  LinkButton,
  Loading,
  Pagination,
  ServiceIcon,
  SkeletonCards,
  TextField,
  TextareaField,
  useAsync,
  useDocumentTitle,
  useErrorText,
} from '@/components/ui';
import { ArticleCard, DeadlineItem, FaqList, GuideCard, InstitutionCard, PriceTag, ServiceCard, TestimonialCard } from '@/components/Cards';
import { useToast } from '@/context/ToastContext';
import { ApiError } from '@/lib/api';

export function PageHero({ title, subtitle, children }: { title: string; subtitle?: string; children?: ReactNode }) {
  return (
    <div className="page-hero">
      <div className="container">
        <h1>{title}</h1>
        {subtitle && <p>{subtitle}</p>}
        {children}
      </div>
    </div>
  );
}

// ------------------------------------------------------------------ services

export function ServicesPage() {
  const { t } = useI18n();
  const { services, loading } = useSite();
  useDocumentTitle(t('services.title'));
  return (
    <>
      <PageHero title={t('services.title')} subtitle={t('services.subtitle')}>
        <div className="hero-pills">
          <span>
            <BadgeCheck /> {t('services.pillPrices')}
          </span>
          <span>
            <ShieldCheck /> {t('services.pillSafe')}
          </span>
          <span>
            <Headphones /> {t('services.pillSupport')}
          </span>
        </div>
      </PageHero>
      <div className="container section services-page">
        {loading ? (
          <SkeletonCards count={6} height={240} />
        ) : (
          <div className="grid grid-3">
            {services.map((s) => (
              <ServiceCard key={s.id} service={s} />
            ))}
          </div>
        )}
      </div>
    </>
  );
}

interface ServiceDetail extends Service {
  details_sw: string | null;
  details_en: string | null;
  requirements_sw: string | null;
  requirements_en: string | null;
  deadlines: Deadline[];
}

export function ServiceDetailPage() {
  const { slug } = useParams();
  const { t, pick } = useI18n();
  const { data, loading, error, reload } = useAsync(() => api.get<ServiceDetail>(`/services/${slug}`), [slug]);
  const s = data;
  const { data: form } = useAsync(
    () => (s ? api.get<{ schema: FormSchemaDef }>(`/form-schemas/${s.form_key}`) : Promise.resolve(null)),
    [s?.form_key],
  );
  useDocumentTitle(s ? pick(s.name_sw, s.name_en) : t('services.title'));
  if (loading && !data) return <Loading />;
  if (error || !s) return <ErrorState error={error} onRetry={reload} />;
  return (
    <>
      <PageHero title={pick(s.name_sw, s.name_en)} subtitle={pick(s.summary_sw, s.summary_en)}>
        <Breadcrumbs items={[{ to: '/', label: t('nav.home') }, { to: '/huduma', label: t('nav.services') }, { label: pick(s.name_sw, s.name_en) }]} />
      </PageHero>
      <div className="container section grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(min(100%, 340px), 1fr))', alignItems: 'start' }}>
        <div className="stack">
          {!s.accepting && <Alert kind="warning">{t('services.closedNotice')}</Alert>}
          {(s.details_sw || s.details_en) && (
            <Card>
              <div className="prose">{pick(s.details_sw, s.details_en)}</div>
            </Card>
          )}
          {(s.requirements_sw || s.requirements_en) && (
            <Card title={t('services.requirements')}>
              <div className="prose">{pick(s.requirements_sw, s.requirements_en)}</div>
            </Card>
          )}
          {form && (
            <Card title={t('services.formPreview')}>
              <ol className="small" style={{ margin: 0, paddingLeft: 20 }}>
                {form.schema.steps.map((st) => (
                  <li key={st.key} style={{ marginBottom: 4 }}>
                    {pick(st.title.sw, st.title.en)}
                  </li>
                ))}
              </ol>
            </Card>
          )}
        </div>
        <div className="stack">
          <Card>
            <div className="stack">
              <ServiceIcon name={s.icon} />
              <div>
                <div className="muted small">{t('form.serviceFee')}</div>
                <PriceTag service={s} />
              </div>
              {s.packages.length > 0 && (
                <div>
                  <div className="small" style={{ fontWeight: 600 }}>
                    {t('services.packages')}
                  </div>
                  {s.packages.map((p) => (
                    <div key={p.id} className="row between small">
                      <span>{pick(p.name_sw, p.name_en)}</span>
                      <strong>TZS {p.price.toLocaleString()}</strong>
                    </div>
                  ))}
                </div>
              )}
              {s.accepting && (
                <LinkButton to={`/app/omba/${s.code}`} size="lg" block>
                  {t('common.requestService')}
                </LinkButton>
              )}
            </div>
          </Card>
          {s.deadlines.length > 0 && (
            <Card title={t('services.relatedDeadlines')}>
              <div className="stack">
                {s.deadlines.map((d) => (
                  <DeadlineItem key={d.id} d={d} />
                ))}
              </div>
            </Card>
          )}
        </div>
      </div>
    </>
  );
}

// ------------------------------------------------------------------ education

export function EducationPage() {
  const { t, pick } = useI18n();
  const [params, setParams] = useSearchParams();
  const category = params.get('category') ?? '';
  const page = Number(params.get('page') ?? 1);
  const { data: cats } = useAsync(() => api.get<Category[]>('/categories?scope=article'));
  const { data, loading, error, reload } = useAsync(
    () => api.get<{ items: ArticleSummary[]; total: number; page: number; per_page: number }>(`/articles${query({ category, page })}`),
    [category, page],
  );
  useDocumentTitle(t('education.title'));
  return (
    <>
      <PageHero title={t('education.title')} subtitle={t('education.subtitle')} />
      <div className="container section education-page">
        <div className="chips" style={{ marginBottom: 20 }}>
          <button className={`chip ${!category ? 'active' : ''}`} onClick={() => setParams({})}>
            {t('common.all')}
          </button>
          {cats?.map((c) => (
            <button key={c.id} className={`chip ${category === c.slug ? 'active' : ''}`} onClick={() => setParams({ category: c.slug })}>
              {pick(c.name_sw, c.name_en)}
            </button>
          ))}
        </div>
        {loading ? (
          <SkeletonCards count={6} />
        ) : error ? (
          <ErrorState error={error} onRetry={reload} />
        ) : !data?.items.length ? (
          <EmptyState title={t('education.empty')} />
        ) : (
          <>
            <div className="grid grid-3">
              {data.items.map((a) => (
                <ArticleCard key={a.id} a={a} />
              ))}
            </div>
            <Pagination page={data.page} perPage={data.per_page} total={data.total} onPage={(p) => setParams({ ...(category ? { category } : {}), page: String(p) })} />
          </>
        )}
      </div>
    </>
  );
}

interface ArticleFull {
  id: number;
  title_sw: string;
  title_en: string | null;
  summary_sw: string | null;
  summary_en: string | null;
  body_sw: string | null;
  body_en: string | null;
  image_id: number | null;
  attachment_id: number | null;
  category_sw: string | null;
  category_en: string | null;
  published_at: string | null;
  created_at: string;
}

export function ArticlePage() {
  const { slug } = useParams();
  const { t, pick, lang } = useI18n();
  const { data, loading, error, reload } = useAsync(() => api.get<ArticleFull>(`/articles/${slug}`), [slug]);
  const a = data;
  useDocumentTitle(a ? pick(a.title_sw, a.title_en) : t('education.title'));
  if (loading && !data) return <Loading />;
  if (error || !a) return <ErrorState error={error} onRetry={reload} />;
  return (
    <div className="container section" style={{ maxWidth: 820 }}>
      <Breadcrumbs items={[{ to: '/', label: t('nav.home') }, { to: '/elimu', label: t('nav.education') }, { label: pick(a.title_sw, a.title_en) }]} />
      <article className="card pad-lg">
        {a.category_sw && <span className="eyebrow">{pick(a.category_sw, a.category_en)}</span>}
        <h1>{pick(a.title_sw, a.title_en)}</h1>
        <p className="muted small">{fmtDate(a.published_at ?? a.created_at, lang)}</p>
        {a.image_id && <img src={mediaUrl(a.image_id)} alt="" style={{ borderRadius: 12, margin: '16px 0', width: '100%' }} />}
        {(a.summary_sw || a.summary_en) && <p style={{ fontWeight: 500 }}>{pick(a.summary_sw, a.summary_en)}</p>}
        <div className="prose">{pick(a.body_sw, a.body_en)}</div>
        {a.attachment_id && (
          <div className="mt-6">
            <a className="btn btn-secondary" href={mediaUrl(a.attachment_id, true)}>
              <Paperclip /> {t('education.attachment')} — {t('common.download')}
            </a>
          </div>
        )}
      </article>
    </div>
  );
}

// ------------------------------------------------------------------ institutions

export function InstitutionsPage() {
  const { t, pick } = useI18n();
  const [params, setParams] = useSearchParams();
  const [q, setQ] = useState(params.get('q') ?? '');
  const filters = { q: params.get('q') ?? '', type: params.get('type') ?? '', region: params.get('region') ?? '', ownership: params.get('ownership') ?? '', page: Number(params.get('page') ?? 1) };
  const { data: types } = useAsync(() => api.get<Category[]>('/categories?scope=institution_type'));
  const { data, loading, error, reload } = useAsync(
    () => api.get<{ items: Institution[]; total: number; page: number; per_page: number; regions: string[] }>(`/institutions${query(filters)}`),
    [params.toString()],
  );
  useDocumentTitle(t('institutions.title'));
  const set = (k: string, v: string) => {
    const next = new URLSearchParams(params);
    if (v) next.set(k, v);
    else next.delete(k);
    next.delete('page');
    setParams(next);
  };
  useEffect(() => {
    const id = setTimeout(() => q !== filters.q && set('q', q), 350);
    return () => clearTimeout(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [q]);

  return (
    <>
      <PageHero title={t('institutions.title')} subtitle={t('institutions.subtitle')} />
      <div className="container section">
        <div className="toolbar">
          <input className="input search-input" value={q} onChange={(e) => setQ(e.target.value)} placeholder={t('institutions.searchPlaceholder')} aria-label={t('common.search')} />
          <select className="select" value={filters.type} onChange={(e) => set('type', e.target.value)} aria-label={t('institutions.allTypes')}>
            <option value="">{t('institutions.allTypes')}</option>
            {types?.map((c) => (
              <option key={c.id} value={c.slug}>
                {pick(c.name_sw, c.name_en)}
              </option>
            ))}
          </select>
          <select className="select" value={filters.region} onChange={(e) => set('region', e.target.value)} aria-label={t('institutions.allRegions')}>
            <option value="">{t('institutions.allRegions')}</option>
            {data?.regions.map((r) => (
              <option key={r}>{r}</option>
            ))}
          </select>
          <select className="select" value={filters.ownership} onChange={(e) => set('ownership', e.target.value)} aria-label={t('institutions.allOwnership')}>
            <option value="">{t('institutions.allOwnership')}</option>
            <option value="public">{t('institutions.public')}</option>
            <option value="private">{t('institutions.private')}</option>
          </select>
        </div>
        {loading && !data ? (
          <SkeletonCards count={6} />
        ) : error ? (
          <ErrorState error={error} onRetry={reload} />
        ) : !data?.items.length ? (
          <EmptyState title={t('institutions.empty')} />
        ) : (
          <>
            <p className="small muted">{t('common.results', { count: data.total })}</p>
            <div className="grid grid-3">
              {data.items.map((i) => (
                <InstitutionCard key={i.id} i={i} />
              ))}
            </div>
            <Pagination page={data.page} perPage={data.per_page} total={data.total} onPage={(p) => set('page', String(p))} />
          </>
        )}
      </div>
    </>
  );
}

// ------------------------------------------------------------------ guidebooks

export function GuidesPage() {
  const { t, pick } = useI18n();
  const [params, setParams] = useSearchParams();
  const filters = { category: params.get('category') ?? '', year: params.get('year') ?? '', q: params.get('q') ?? '', include_outdated: params.get('include_outdated') === '1' ? '1' : '' };
  const { data: cats } = useAsync(() => api.get<Category[]>('/categories?scope=guide'));
  const { data, loading, error, reload } = useAsync(() => api.get<{ items: Guidebook[]; years: string[] }>(`/guidebooks${query(filters)}`), [params.toString()]);
  useDocumentTitle(t('guides.title'));
  const set = (k: string, v: string) => {
    const next = new URLSearchParams(params);
    if (v) next.set(k, v);
    else next.delete(k);
    setParams(next);
  };
  return (
    <>
      <PageHero title={t('guides.title')} subtitle={t('guides.subtitle')} />
      <div className="container section">
        <div className="toolbar">
          <input className="input search-input" defaultValue={filters.q} onKeyDown={(e) => e.key === 'Enter' && set('q', (e.target as HTMLInputElement).value)} onBlur={(e) => set('q', e.target.value)} placeholder={t('common.search')} aria-label={t('common.search')} />
          <select className="select" value={filters.category} onChange={(e) => set('category', e.target.value)} aria-label={t('guides.allCategories')}>
            <option value="">{t('guides.allCategories')}</option>
            {cats?.map((c) => (
              <option key={c.id} value={c.slug}>
                {pick(c.name_sw, c.name_en)}
              </option>
            ))}
          </select>
          <select className="select" value={filters.year} onChange={(e) => set('year', e.target.value)} aria-label={t('guides.year')}>
            <option value="">{t('guides.allYears')}</option>
            {data?.years.map((y) => (
              <option key={y}>{y}</option>
            ))}
          </select>
          <Checkbox checked={filters.include_outdated === '1'} onChange={(v) => set('include_outdated', v ? '1' : '')}>
            {t('guides.showOutdated')}
          </Checkbox>
        </div>
        {loading && !data ? (
          <SkeletonCards count={6} />
        ) : error ? (
          <ErrorState error={error} onRetry={reload} />
        ) : !data?.items.length ? (
          <EmptyState icon={Download} title={t('guides.empty')} />
        ) : (
          <div className="grid grid-3">
            {data.items.map((g) => (
              <GuideCard key={g.id} g={g} />
            ))}
          </div>
        )}
      </div>
    </>
  );
}

// ------------------------------------------------------------------ deadlines / announcements / faq

export function DeadlinesPage() {
  const { t } = useI18n();
  const { data, loading, error, reload } = useAsync(() => api.get<{ upcoming: Deadline[] }>('/deadlines'));
  useDocumentTitle(t('deadlines.title'));
  return (
    <>
      <PageHero title={t('deadlines.title')} subtitle={t('deadlines.subtitle')} />
      <div className="container section" style={{ maxWidth: 860 }}>
        {loading ? (
          <Loading />
        ) : error ? (
          <ErrorState error={error} onRetry={reload} />
        ) : !data?.upcoming.length ? (
          <EmptyState icon={CalendarClock} title={t('deadlines.empty')} />
        ) : (
          <div className="stack">
            {data.upcoming.map((d) => (
              <div key={d.id} className="card">
                <DeadlineItem d={d} />
              </div>
            ))}
          </div>
        )}
      </div>
    </>
  );
}

export function AnnouncementsPage() {
  const { t, pick, lang } = useI18n();
  const { data, loading, error, reload } = useAsync(() => api.get<Announcement[]>('/announcements'));
  useDocumentTitle(t('announcements.title'));
  return (
    <>
      <PageHero title={t('announcements.title')} subtitle={t('announcements.subtitle')} />
      <div className="container section" style={{ maxWidth: 860 }}>
        {loading ? (
          <Loading />
        ) : error ? (
          <ErrorState error={error} onRetry={reload} />
        ) : !data?.length ? (
          <EmptyState title={t('announcements.empty')} />
        ) : (
          <div className="stack">
            {data.map((a) => (
              <article key={a.id} id={`a${a.id}`} className="card">
                <div className="row between">
                  <h3 className="mb-0">{pick(a.title_sw, a.title_en)}</h3>
                  {a.is_pinned && (
                    <span className="badge warning">
                      <Pin size={12} /> {t('announcements.pinned')}
                    </span>
                  )}
                </div>
                <p className="xs muted">{fmtDate(a.published_at, lang)}</p>
                <div className="prose small">{pick(a.body_sw, a.body_en)}</div>
              </article>
            ))}
          </div>
        )}
      </div>
    </>
  );
}

export function TestimonialsPage() {
  const { t } = useI18n();
  const { data, loading, error, reload } = useAsync(() => api.get<Testimonial[]>('/testimonials'));
  const years = [...new Set((data ?? []).map((x) => x.year))].sort((a, b) => b - a);
  const [year, setYear] = useState<number | null>(null);
  const active = year ?? years[0] ?? null;
  useDocumentTitle(t('testimonials.title'));
  return (
    <>
      <PageHero title={t('testimonials.title')} subtitle={t('testimonials.subtitle')} />
      <div className="container section education-page">
        {loading ? (
          <SkeletonCards count={3} />
        ) : error ? (
          <ErrorState error={error} onRetry={reload} />
        ) : !data?.length ? (
          <EmptyState title={t('testimonials.empty')} />
        ) : (
          <>
            <div className="chips" style={{ marginBottom: 20 }}>
              {years.map((y) => (
                <button key={y} className={`chip ${active === y ? 'active' : ''}`} onClick={() => setYear(y)}>
                  {y}
                </button>
              ))}
            </div>
            <div className="grid grid-3">
              {data
                .filter((x) => x.year === active)
                .map((x) => (
                  <TestimonialCard key={x.id} x={x} />
                ))}
            </div>
          </>
        )}
      </div>
    </>
  );
}

export function FaqPage() {
  const { t } = useI18n();
  const { data, loading, error, reload } = useAsync(() => api.get<Faq[]>('/faqs'));
  useDocumentTitle(t('faq.title'));
  return (
    <>
      <PageHero title={t('faq.title')} subtitle={t('faq.subtitle')} />
      <div className="container section" style={{ maxWidth: 860 }}>
        {loading ? <Loading /> : error ? <ErrorState error={error} onRetry={reload} /> : !data?.length ? <EmptyState title={t('faq.empty')} /> : <FaqList items={data} />}
        <Card className="mt-6">
          <div className="row between">
            <strong>{t('faq.stillNeedHelp')}</strong>
            <LinkButton to="/mawasiliano" variant="secondary">
              {t('nav.contact')}
            </LinkButton>
          </div>
        </Card>
      </div>
    </>
  );
}

// ------------------------------------------------------------------ static text pages

export function TextPage({ kind }: { kind: 'about' | 'privacy' | 'terms' }) {
  const { t, pick } = useI18n();
  const { settings } = useSite();
  const title = kind === 'about' ? t('about.title') : kind === 'privacy' ? t('legal.privacy') : t('legal.terms');
  const body = settings ? pick(settings[`${kind}_sw`], settings[`${kind}_en`]) : '';
  useDocumentTitle(title);
  return (
    <>
      <PageHero title={title} />
      <div className="container section" style={{ maxWidth: 860 }}>
        <Card className="pad-lg">{body ? <div className="prose">{body}</div> : <Loading />}</Card>
      </div>
    </>
  );
}

export function ContactPage() {
  const { t, pick, tv } = useI18n();
  const { settings } = useSite();
  const { toast } = useToast();
  const errText = useErrorText();
  const [form, setForm] = useState({ name: '', phone: '', email: '', message: '', website: '' });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  const [sent, setSent] = useState(false);
  useDocumentTitle(t('contact.title'));

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setErrors({});
    try {
      await api.post('/contact', form);
      setSent(true);
      setForm({ name: '', phone: '', email: '', message: '', website: '' });
    } catch (err) {
      if (err instanceof ApiError && err.status === 422) setErrors(err.fields);
      else toast(errText(err), 'error');
    } finally {
      setBusy(false);
    }
  };

  const items = [
    settings?.contact_phone && { icon: Phone, label: t('common.call'), value: fmtPhone(settings.contact_phone), href: `tel:${settings.contact_phone}` },
    settings?.contact_whatsapp && { icon: MessageCircle, label: 'WhatsApp', value: fmtPhone(settings.contact_whatsapp), href: waLink(settings.contact_whatsapp) },
    settings?.contact_sms && { icon: Send, label: 'SMS', value: fmtPhone(settings.contact_sms), href: `sms:${settings.contact_sms}` },
    settings?.contact_email && { icon: Mail, label: t('common.email'), value: settings.contact_email, href: `mailto:${settings.contact_email}` },
  ].filter(Boolean) as { icon: typeof Phone; label: string; value: string; href: string }[];

  return (
    <>
      <PageHero title={t('contact.title')} subtitle={t('contact.subtitle')} />
      <div className="container section grid grid-2" style={{ alignItems: 'start' }}>
        <div className="stack">
          {items.map((it) => (
            <a key={it.label} href={it.href} className="card card-link row" style={{ color: 'inherit', textDecoration: 'none', flexWrap: 'nowrap' }} target={it.href.startsWith('http') ? '_blank' : undefined} rel="noopener noreferrer">
              <span className="icon-tile">
                <it.icon />
              </span>
              <div>
                <div className="small muted">{it.label}</div>
                <strong>{it.value}</strong>
              </div>
            </a>
          ))}
          {settings?.working_hours_sw && (
            <div className="card row" style={{ flexWrap: 'nowrap' }}>
              <span className="icon-tile">
                <Clock />
              </span>
              <div>
                <div className="small muted">{t('contact.workingHours')}</div>
                <strong>{pick(settings.working_hours_sw, settings.working_hours_en)}</strong>
              </div>
            </div>
          )}
        </div>
        <Card title={t('contact.formTitle')}>
          {sent ? (
            <Alert kind="success">{t('contact.sent')}</Alert>
          ) : (
            <form className="stack" onSubmit={submit} noValidate>
              <TextField label={t('common.name')} required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} error={errors.name && tv(errors.name)} autoComplete="name" />
              <TextField label={t('common.phone')} type="tel" inputMode="tel" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} error={errors.phone && tv(errors.phone)} help={t('contact.phoneOrEmail')} autoComplete="tel" />
              <TextField label={t('common.email')} type="email" optional value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} error={errors.email && tv(errors.email)} autoComplete="email" />
              <TextareaField label={t('common.message')} required value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} error={errors.message && tv(errors.message)} />
              <input type="text" name="website" value={form.website} onChange={(e) => setForm({ ...form, website: e.target.value })} tabIndex={-1} autoComplete="off" style={{ display: 'none' }} aria-hidden />
              <Button type="submit" loading={busy} icon={Send}>
                {t('common.send')}
              </Button>
            </form>
          )}
        </Card>
      </div>
    </>
  );
}

// ------------------------------------------------------------------ search & 404

interface SearchResult {
  type: 'service' | 'article' | 'institution' | 'guidebook' | 'announcement' | 'faq';
  title_sw: string;
  title_en: string | null;
  excerpt_sw: string | null;
  excerpt_en: string | null;
  url: string;
}

export function SearchPage() {
  const { t, pick } = useI18n();
  const [params, setParams] = useSearchParams();
  const q = params.get('q') ?? '';
  const [input, setInput] = useState(q);
  const { data, loading } = useAsync(
    () => (q.length >= 2 ? api.get<{ results: SearchResult[] }>(`/search?q=${encodeURIComponent(q)}`) : Promise.resolve({ results: [] })),
    [q],
  );
  useDocumentTitle(t('search.title'));
  return (
    <>
      <PageHero title={t('search.title')}>
        <form
          className="hero-search mt-4"
          role="search"
          onSubmit={(e) => {
            e.preventDefault();
            setParams({ q: input.trim() });
          }}
        >
          <input className="input" value={input} onChange={(e) => setInput(e.target.value)} placeholder={t('common.searchPlaceholder')} autoFocus aria-label={t('common.search')} />
          <button className="btn btn-navy" type="submit" aria-label={t('common.search')}>
            <SearchIcon />
          </button>
        </form>
      </PageHero>
      <div className="container section" style={{ maxWidth: 860 }}>
        {q.length < 2 ? (
          <p className="muted">{t('search.minChars')}</p>
        ) : loading ? (
          <Loading />
        ) : !data?.results.length ? (
          <EmptyState icon={SearchIcon} title={t('search.empty', { q })} />
        ) : (
          <div className="card flush search-results">
            {data.results.map((r, i) => (
              <Link key={i} to={r.url} className="result">
                <span className="badge plain info">{t(`search.type.${r.type}`)}</span>
                <div style={{ fontWeight: 600, marginTop: 6 }}>{pick(r.title_sw, r.title_en)}</div>
                {r.excerpt_sw && <div className="small muted">{pick(r.excerpt_sw, r.excerpt_en)}</div>}
              </Link>
            ))}
          </div>
        )}
      </div>
    </>
  );
}

export function NotFoundPage() {
  const { t } = useI18n();
  useDocumentTitle(t('notFound.title'));
  return (
    <div className="container section text-center" style={{ maxWidth: 560 }}>
      <div style={{ fontSize: '4rem', fontWeight: 800, color: 'var(--c-navy)' }}>404</div>
      <h1>{t('notFound.title')}</h1>
      <p className="muted">{t('notFound.text')}</p>
      <LinkButton to="/">{t('notFound.home')}</LinkButton>
    </div>
  );
}

