import { useEffect, useRef, useState } from 'react';
import { Copy, KeyRound, ShieldCheck, ShieldOff, Upload } from 'lucide-react';
import { useI18n, type TKey } from '@/i18n';
import { useAuth } from '@/context/AuthContext';
import { useSite } from '@/context/SiteContext';
import { useToast } from '@/context/ToastContext';
import { api, ApiError, mediaUrl, uploadFile } from '@/lib/api';
import { fmtDateTime } from '@/lib/format';
import type { Option, Paged, SiteSettings } from '@/lib/types';
import { SiteStatusCard } from '@/pages/public/Launch';
import { Alert, Button, Card, ErrorState, LinkButton, Loading, PageHead, Pagination, PasswordField, SelectField, Tabs, TextField, TextareaField, useAsync, useDocumentTitle, useErrorText } from '@/components/ui';

type Tab = 'brand' | 'home' | 'contact' | 'pages' | 'forms' | 'system';
const GROUPS: Record<Exclude<Tab, 'system'>, { key: keyof SiteSettings; label: TKey; area?: boolean }[]> = {
  brand: [
    { key: 'brand_name', label: 'admin.set.brandName' },
    { key: 'tagline', label: 'admin.set.tagline' },
    { key: 'tagline_en', label: 'admin.set.taglineEn' },
    { key: 'description_sw', label: 'admin.set.descriptionSw', area: true },
    { key: 'description_en', label: 'admin.set.descriptionEn', area: true },
  ],
  home: [
    { key: 'hero_title_sw', label: 'admin.set.heroTitleSw' },
    { key: 'hero_title_en', label: 'admin.set.heroTitleEn' },
    { key: 'hero_text_sw', label: 'admin.set.heroTextSw', area: true },
    { key: 'hero_text_en', label: 'admin.set.heroTextEn', area: true },
    { key: 'welcome_note_sw', label: 'admin.set.welcomeSw', area: true },
    { key: 'welcome_note_en', label: 'admin.set.welcomeEn', area: true },
    { key: 'dashboard_welcome_sw', label: 'admin.set.dashWelcomeSw', area: true },
    { key: 'dashboard_welcome_en', label: 'admin.set.dashWelcomeEn', area: true },
    { key: 'payment_instructions_sw', label: 'admin.set.paymentSw', area: true },
    { key: 'payment_instructions_en', label: 'admin.set.paymentEn', area: true },
  ],
  contact: [
    { key: 'contact_phone', label: 'admin.set.phone' },
    { key: 'contact_whatsapp', label: 'admin.set.whatsapp' },
    { key: 'contact_sms', label: 'admin.set.sms' },
    { key: 'contact_email', label: 'common.email' },
    { key: 'working_hours_sw', label: 'admin.set.hoursSw' },
    { key: 'working_hours_en', label: 'admin.set.hoursEn' },
    { key: 'address', label: 'admin.set.address' },
    { key: 'social_facebook', label: 'admin.set.facebook' },
    { key: 'social_instagram', label: 'admin.set.instagram' },
    { key: 'social_tiktok', label: 'admin.set.tiktok' },
    { key: 'social_linkedin', label: 'admin.set.linkedin' },
    { key: 'social_youtube', label: 'admin.set.youtube' },
  ],
  pages: [
    { key: 'about_sw', label: 'admin.set.aboutSw', area: true },
    { key: 'about_en', label: 'admin.set.aboutEn', area: true },
    { key: 'privacy_sw', label: 'admin.set.privacySw', area: true },
    { key: 'privacy_en', label: 'admin.set.privacyEn', area: true },
    { key: 'terms_sw', label: 'admin.set.termsSw', area: true },
    { key: 'terms_en', label: 'admin.set.termsEn', area: true },
  ],
  forms: [],
};

const optionsToText = (o: Option[] | null) => (o ?? []).map((x) => (x.label.sw === x.value && x.label.en === x.value ? x.value : `${x.value} | ${x.label.sw} | ${x.label.en}`)).join('\n');
const textToOptions = (s: string): Option[] =>
  s
    .split('\n')
    .map((l) => l.trim())
    .filter(Boolean)
    .map((l) => {
      const [v, sw, en] = l.split('|').map((x) => x.trim());
      return { value: v, label: { sw: sw || v, en: en || sw || v } };
    });

export function SettingsPage() {
  const { t, tv } = useI18n();
  const { reload: reloadSite } = useSite();
  const { toast } = useToast();
  const errText = useErrorText();
  const { data, loading, error, reload } = useAsync(() => api.get<{ settings: SiteSettings; system: Record<string, string | number | boolean | null> }>('/admin/settings'));
  const [tab, setTab] = useState<Tab>('brand');
  const [form, setForm] = useState<Partial<SiteSettings>>({});
  const [banks, setBanks] = useState('');
  const [levels, setLevels] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  const logoRef = useRef<HTMLInputElement>(null);
  const favRef = useRef<HTMLInputElement>(null);
  useDocumentTitle(t('admin.nav.settings'));

  useEffect(() => {
    if (data) {
      setForm(data.settings);
      setBanks(optionsToText(data.settings.banks));
      setLevels(optionsToText(data.settings.heslb_levels));
    }
  }, [data]);

  const save = async (extra: Partial<SiteSettings> = {}) => {
    setBusy(true);
    setErrors({});
    try {
      const { site_live: _live, coming_soon_sw: _csw, coming_soon_en: _cen, ...rest } = form;
      void _live; void _csw; void _cen;
      const payload = { ...rest, ...extra, banks: textToOptions(banks), heslb_levels: textToOptions(levels) };
      await api.put('/admin/settings', { settings: payload });
      toast(t('common.saved'));
      reloadSite();
      void reload();
    } catch (e) {
      if (e instanceof ApiError && e.status === 422) setErrors(e.fields);
      toast(errText(e), 'error');
    } finally {
      setBusy(false);
    }
  };
  const uploadBrand = async (file: File | undefined, key: 'logo_file_id' | 'favicon_file_id') => {
    if (!file) return;
    const fd = new FormData();
    fd.append('file', file);
    try {
      const r = await uploadFile<{ id: number }>('/admin/media', fd);
      setForm((f) => ({ ...f, [key]: r.id }));
      await save({ [key]: r.id });
    } catch (e) {
      toast(errText(e), 'error');
    }
  };

  if (loading && !data) return <Loading />;
  if (error || !data) return <ErrorState error={error} onRetry={reload} />;

  return (
    <>
      <PageHead title={t('admin.nav.settings')} subtitle={t('admin.set.subtitle')} actions={
          <>
            <LinkButton to="/admin/usalama" variant="secondary" icon={KeyRound}>
              {t('profile.changePassword')}
            </LinkButton>
            {tab !== 'system' && (
              <Button loading={busy} onClick={() => void save()}>
                {t('common.save')}
              </Button>
            )}
          </>
        }
      />
      <Tabs
        value={tab}
        onChange={setTab}
        items={[
          { value: 'brand', label: t('admin.set.tabBrand') },
          { value: 'home', label: t('admin.set.tabHome') },
          { value: 'contact', label: t('admin.set.tabContact') },
          { value: 'pages', label: t('admin.set.tabPages') },
          { value: 'forms', label: t('admin.set.tabForms') },
          { value: 'system', label: t('admin.set.tabSystem') },
        ]}
      />
      {tab === 'brand' && (
        <div className="mb-4">
          <SiteStatusCard />
        </div>
      )}
      <div className="card">
        {tab === 'brand' && (
          <div className="row mb-4" style={{ gap: 24 }}>
            <div className="stack sm">
              <span className="field-label">{t('admin.set.logo')}</span>
              <div className="row">
                <img className="logo-img" style={{ width: 64, height: 64 }} src={form.logo_file_id ? mediaUrl(form.logo_file_id) : '/brand/logo-160.png'} alt="" />
                <Button size="sm" variant="secondary" icon={Upload} onClick={() => logoRef.current?.click()}>
                  {t('admin.f.upload')}
                </Button>
                {form.logo_file_id && (
                  <Button size="sm" variant="ghost" onClick={() => void save({ logo_file_id: null })}>
                    {t('common.delete')}
                  </Button>
                )}
              </div>
              <input ref={logoRef} type="file" hidden accept="image/png,image/jpeg,image/webp" onChange={(e) => void uploadBrand(e.target.files?.[0], 'logo_file_id')} />
            </div>
            <div className="stack sm">
              <span className="field-label">Favicon</span>
              <div className="row">
                {form.favicon_file_id && <img src={mediaUrl(form.favicon_file_id)} alt="" width={32} height={32} />}
                <Button size="sm" variant="secondary" icon={Upload} onClick={() => favRef.current?.click()}>
                  {t('admin.f.upload')}
                </Button>
              </div>
              <input ref={favRef} type="file" hidden accept="image/png,image/x-icon" onChange={(e) => void uploadBrand(e.target.files?.[0], 'favicon_file_id')} />
            </div>
          </div>
        )}
        {tab !== 'system' && tab !== 'forms' && (
          <div className="form-grid">
            {GROUPS[tab].map((g) =>
              g.area ? (
                <TextareaField key={g.key} label={t(g.label)} wrapClass="full" rows={g.key.startsWith('privacy') || g.key.startsWith('terms') || g.key.startsWith('about') ? 10 : 3} value={(form[g.key] as string) ?? ''} onChange={(e) => setForm({ ...form, [g.key]: e.target.value })} error={errors[g.key] && tv(errors[g.key])} />
              ) : (
                <TextField key={g.key} label={t(g.label)} value={(form[g.key] as string) ?? ''} onChange={(e) => setForm({ ...form, [g.key]: e.target.value })} error={errors[g.key] && tv(errors[g.key])} placeholder={g.key.startsWith('social_') ? 'https://' : undefined} />
              ),
            )}
            {tab === 'brand' && (
              <SelectField label={t('admin.set.defaultLanguage')} value={form.default_language ?? 'sw'} onChange={(e) => setForm({ ...form, default_language: e.target.value as 'sw' | 'en' })}>
                <option value="sw">Kiswahili</option>
                <option value="en">English</option>
              </SelectField>
            )}
          </div>
        )}
        {tab === 'forms' && (
          <div className="stack">
            <Alert kind="info">{t('admin.set.optionsHelp')}</Alert>
            <TextareaField label={t('admin.set.banks')} rows={10} value={banks} onChange={(e) => setBanks(e.target.value)} />
            <TextareaField label={t('admin.set.heslbLevels')} rows={4} value={levels} onChange={(e) => setLevels(e.target.value)} help="degree | Shahada (Degree) | Degree" />
          </div>
        )}
        {tab === 'system' && (
          <div className="stack">
            <dl className="kv">
              {Object.entries(data.system).map(([k, v]) => (
                <div key={k} style={{ display: 'contents' }}>
                  <dt className="mono">{k}</dt>
                  <dd>{v === null ? '—' : String(v)}</dd>
                </div>
              ))}
            </dl>
            {!data.system.sms_live && <Alert kind="warning">{t('admin.set.smsWarning')}</Alert>}
            <Alert kind="info">{t('admin.set.backupHelp')}</Alert>
          </div>
        )}
      </div>
    </>
  );
}

export function AuditPage() {
  const { t, lang } = useI18n();
  const [page, setPage] = useState(1);
  const [action, setAction] = useState('');
  const { data, loading, error, reload } = useAsync(
    () => api.get<Paged<{ id: number; action: string; entity_type: string | null; entity_id: number | null; details: Record<string, unknown> | null; ip_address: string | null; created_at: string; first_name: string | null; second_name: string | null; role: string | null }>>(`/admin/audit?page=${page}&action=${encodeURIComponent(action)}`),
    [page],
  );
  useDocumentTitle(t('admin.nav.audit'));
  return (
    <>
      <PageHead title={t('admin.nav.audit')} subtitle={t('admin.audit.subtitle')} />
      <form
        className="toolbar"
        onSubmit={(e) => {
          e.preventDefault();
          setPage(1);
          void reload();
        }}
      >
        <input className="input search-input" value={action} onChange={(e) => setAction(e.target.value)} placeholder="application.status, report.export, user..." aria-label={t('common.filter')} />
        <Button type="submit" variant="navy">
          {t('common.filter')}
        </Button>
      </form>
      <div className="card flush">
        {loading ? (
          <Loading />
        ) : error ? (
          <ErrorState error={error} onRetry={reload} />
        ) : (
          <>
            <div className="table-wrap">
              <table className="table responsive">
                <thead>
                  <tr>
                    <th>{t('common.date')}</th>
                    <th>{t('admin.audit.who')}</th>
                    <th>{t('admin.audit.action')}</th>
                    <th>{t('common.details')}</th>
                  </tr>
                </thead>
                <tbody>
                  {data?.items.map((l) => (
                    <tr key={l.id}>
                      <td data-label={t('common.date')} className="nowrap">
                        {fmtDateTime(l.created_at, lang)}
                      </td>
                      <td data-label={t('admin.audit.who')}>{l.first_name ? `${l.first_name} ${l.second_name ?? ''}` : 'system'}</td>
                      <td data-label={t('admin.audit.action')}>
                        <span className="mono">{l.action}</span>
                        {l.entity_type && <span className="xs muted"> · {l.entity_type} #{l.entity_id}</span>}
                      </td>
                      <td data-label={t('common.details')} className="xs mono break" style={{ maxWidth: 360 }}>
                        {l.details ? JSON.stringify(l.details) : ''}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {data && <Pagination page={data.page} perPage={data.per_page} total={data.total} onPage={setPage} />}
          </>
        )}
      </div>
    </>
  );
}

export function SecurityPage() {
  const { t, tv } = useI18n();
  const { user, refresh, setSession } = useAuth();
  const { toast } = useToast();
  const errText = useErrorText();
  const [setup, setSetup] = useState<{ secret: string; otpauth_uri: string } | null>(null);
  const [code, setCode] = useState('');
  const [pw, setPw] = useState('');
  const [pwForm, setPwForm] = useState({ current_password: '', password: '', password_confirmation: '' });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  useDocumentTitle(t('admin.nav.security'));

  const act = async (fn: () => Promise<unknown>, ok: string) => {
    setBusy(true);
    setErrors({});
    try {
      await fn();
      toast(ok);
      await refresh();
      return true;
    } catch (e) {
      if (e instanceof ApiError && e.status === 422) setErrors(e.fields);
      toast(errText(e), 'error');
      return false;
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      <PageHead title={t('admin.nav.security')} subtitle={t('admin.sec.subtitle')} />
      <div className="grid grid-2" style={{ alignItems: 'start' }}>
        <Card title={t('profile.changePassword')}>
          <form
            className="stack"
            onSubmit={(e) => {
              e.preventDefault();
              void act(async () => {
                const r = await api.post<{ csrf: string }>('/me/password', pwForm);
                setSession({ user: user!, csrf: r.csrf });
                setPwForm({ current_password: '', password: '', password_confirmation: '' });
              }, t('profile.passwordChanged'));
            }}
          >
            <PasswordField label={t('profile.currentPassword')} autoComplete="current-password" required value={pwForm.current_password} onChange={(e) => setPwForm({ ...pwForm, current_password: e.target.value })} error={errors.current_password && tv(errors.current_password)} />
            <PasswordField label={t('auth.newPassword')} autoComplete="new-password" required help={t('admin.staff.passwordHelp')} value={pwForm.password} onChange={(e) => setPwForm({ ...pwForm, password: e.target.value })} error={errors.password && tv(errors.password)} />
            <PasswordField label={t('auth.passwordConfirm')} autoComplete="new-password" required value={pwForm.password_confirmation} onChange={(e) => setPwForm({ ...pwForm, password_confirmation: e.target.value })} error={errors.password_confirmation && tv(errors.password_confirmation)} />
            <Button type="submit" icon={KeyRound} loading={busy}>
              {t('profile.changePassword')}
            </Button>
          </form>
        </Card>
        <Card title={t('admin.sec.twoFactor')}>
          {user?.totp_enabled ? (
            <div className="stack">
              <Alert kind="success">{t('admin.sec.enabled')}</Alert>
              <PasswordField label={t('profile.currentPassword')} value={pw} onChange={(e) => setPw(e.target.value)} error={errors.password && tv(errors.password)} />
              <Button variant="danger" icon={ShieldOff} loading={busy} onClick={() => void act(() => api.post('/admin/security/2fa/disable', { password: pw }), t('common.saved'))}>
                {t('admin.sec.disable')}
              </Button>
            </div>
          ) : setup ? (
            <div className="stack">
              <p className="small">{t('admin.sec.step1')}</p>
              <div className="card mono break" style={{ background: 'var(--c-surface-2)', fontSize: 18, letterSpacing: '0.1em' }}>
                {setup.secret}
              </div>
              <Button variant="secondary" size="sm" icon={Copy} onClick={() => void navigator.clipboard?.writeText(setup.secret).then(() => toast(t('common.copied')))}>
                {t('common.copy')}
              </Button>
              <a href={setup.otpauth_uri} className="small">
                {t('admin.sec.openApp')}
              </a>
              <TextField label={t('admin.sec.step2')} inputMode="numeric" maxLength={6} value={code} onChange={(e) => setCode(e.target.value)} error={errors.code && tv(errors.code)} />
              <Button icon={ShieldCheck} loading={busy} onClick={() => void act(() => api.post('/admin/security/2fa/enable', { code }), t('admin.sec.enabled')).then((ok) => ok && setSetup(null))}>
                {t('admin.sec.enable')}
              </Button>
            </div>
          ) : (
            <div className="stack">
              <p className="small muted">{t('admin.sec.intro')}</p>
              <Button icon={ShieldCheck} loading={busy} onClick={() => void api.post<{ secret: string; otpauth_uri: string }>('/admin/security/2fa/setup').then(setSetup).catch((e) => toast(errText(e), 'error'))}>
                {t('admin.sec.start')}
              </Button>
            </div>
          )}
        </Card>
      </div>
    </>
  );
}
