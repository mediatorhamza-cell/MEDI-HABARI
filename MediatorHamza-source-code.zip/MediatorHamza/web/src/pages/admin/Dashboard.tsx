import { Link } from 'react-router-dom';
import { AlertTriangle, CheckCircle2, Eye, FileText, Inbox, Loader, MessageCircle, Users, Wallet } from 'lucide-react';
import { useI18n } from '@/i18n';
import { api } from '@/lib/api';
import { fmtDate, fmtRelative } from '@/lib/format';
import type { AppStatus, Deadline } from '@/lib/types';
import { Card, ErrorState, Loading, PageHead, Stat, StatusBadge, useAsync, useDocumentTitle } from '@/components/ui';
import { DeadlineItem } from '@/components/Cards';

interface Stats {
  users_total: number;
  users_new_7d: number;
  applications_total: number;
  applications_received: number;
  applications_in_progress: number;
  applications_completed: number;
  applications_awaiting_docs: number;
  by_status: Record<string, number>;
  by_service: { code: string; name_sw: string; name_en: string | null; total: number; active: number }[];
  unpaid: number;
  unanswered_messages: number;
  contact_unhandled: number;
  visitors_today: number;
  visitors_30d: number;
  visitors_series: { day: string; visitors: number; views: number }[];
  applications_series: { day: string; count: number }[];
  deadlines: Deadline[];
  recent: { id: number; reference: string; applicant_name: string; service_code: string; status: AppStatus; submitted_at: string }[];
}

function Bars({ series, label }: { series: { day: string; value: number }[]; label: string }) {
  const { lang } = useI18n();
  const days: { day: string; value: number }[] = [];
  const map = Object.fromEntries(series.map((s) => [s.day, s.value]));
  for (let i = 29; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    days.push({ day: key, value: map[key] ?? 0 });
  }
  const max = Math.max(1, ...days.map((d) => d.value));
  return (
    <div>
      <div className="bar-chart" role="img" aria-label={label}>
        {days.map((d) => (
          <div key={d.day} className="bar" style={{ height: `${(d.value / max) * 100}%` }} title={`${fmtDate(d.day, lang)}: ${d.value}`} />
        ))}
      </div>
      <div className="row between xs muted mt-2">
        <span>{fmtDate(days[0].day, lang)}</span>
        <span>{fmtDate(days[days.length - 1].day, lang)}</span>
      </div>
    </div>
  );
}

export default function AdminDashboard() {
  const { t, pick, lang } = useI18n();
  const { data, loading, error, reload } = useAsync(() => api.get<Stats>('/admin/dashboard'));
  useDocumentTitle(t('admin.nav.dashboard'));
  if (loading && !data) return <Loading />;
  if (error || !data) return <ErrorState error={error} onRetry={reload} />;
  const maxService = Math.max(1, ...data.by_service.map((s) => s.total));
  return (
    <>
      <PageHead title={t('admin.nav.dashboard')} subtitle={t('admin.dash.subtitle')} />
      <div className="stack" style={{ gap: 20 }}>
        <div className="grid grid-4">
          <Stat icon={Users} label={t('admin.dash.users')} value={data.users_total} color="navy" to="/admin/watumiaji" />
          <Stat icon={FileText} label={t('admin.dash.received')} value={data.applications_total} color="blue" to="/admin/maombi" />
          <Stat icon={Loader} label={t('admin.dash.inProgress')} value={data.applications_received + data.applications_in_progress} color="yellow" to="/admin/maombi?status=in_progress" />
          <Stat icon={CheckCircle2} label={t('admin.dash.completed')} value={data.applications_completed} color="green" to="/admin/maombi?status=completed" />
          <Stat icon={AlertTriangle} label={t('admin.dash.awaitingDocs')} value={data.applications_awaiting_docs} color="red" to="/admin/maombi?status=awaiting_info" />
          <Stat icon={Wallet} label={t('admin.dash.unpaid')} value={data.unpaid} color="orange" to="/admin/maombi?payment_status=unpaid" />
          <Stat icon={MessageCircle} label={t('admin.dash.unanswered')} value={data.unanswered_messages} color="purple" to="/admin/ujumbe" />
          <Stat icon={Eye} label={t('admin.dash.visitors')} value={`${data.visitors_today} / ${data.visitors_30d}`} color="teal" />
        </div>
        <div className="grid grid-2" style={{ alignItems: 'start' }}>
          <Card title={t('admin.dash.appsChart')}>
            <Bars series={data.applications_series.map((s) => ({ day: s.day, value: s.count }))} label={t('admin.dash.appsChart')} />
          </Card>
          <Card title={t('admin.dash.visitorsChart')}>
            <Bars series={data.visitors_series.map((s) => ({ day: s.day, value: s.visitors }))} label={t('admin.dash.visitorsChart')} />
            <p className="xs muted mt-2 mb-0">{t('admin.dash.privacyNote')}</p>
          </Card>
          <Card title={t('admin.dash.byService')}>
            {data.by_service.map((s) => (
              <div key={s.code} className="hbar">
                <span className="small">{pick(s.name_sw, s.name_en)}</span>
                <div className="track">
                  <div className="fill" style={{ width: `${(s.total / maxService) * 100}%` }} />
                </div>
                <strong className="small">{s.total}</strong>
              </div>
            ))}
          </Card>
          <Card title={t('admin.dash.recent')} actions={<Link to="/admin/maombi" className="small">{t('common.viewAll')} →</Link>}>
            <div className="stack sm">
              {data.recent.length === 0 && <p className="small muted mb-0">{t('admin.apps.empty')}</p>}
              {data.recent.map((a) => (
                <Link key={a.id} to={`/admin/maombi/${a.id}`} className="row between" style={{ color: 'inherit', textDecoration: 'none', flexWrap: 'nowrap' }}>
                  <div style={{ minWidth: 0 }}>
                    <div className="small" style={{ fontWeight: 600 }}>{a.applicant_name ?? '—'}</div>
                    <div className="xs muted mono">{a.reference}</div>
                  </div>
                  <div className="text-center">
                    <StatusBadge status={a.status} />
                    <div className="xs muted">{fmtRelative(a.submitted_at, lang)}</div>
                  </div>
                </Link>
              ))}
            </div>
          </Card>
          <Card title={t('dash.upcomingDeadlines')} actions={<Link to="/admin/maudhui/deadlines" className="small">{t('common.edit')} →</Link>}>
            {data.deadlines.length === 0 ? <p className="small muted mb-0">{t('home.noDeadlines')}</p> : <div className="stack">{data.deadlines.map((d) => <DeadlineItem key={d.id} d={d} />)}</div>}
          </Card>
          <Card title={t('admin.nav.contact')}>
            <Link to="/admin/mawasiliano" className="row">
              <Inbox size={18} /> {t('admin.dash.contactUnhandled', { n: data.contact_unhandled })}
            </Link>
          </Card>
        </div>
      </div>
    </>
  );
}
