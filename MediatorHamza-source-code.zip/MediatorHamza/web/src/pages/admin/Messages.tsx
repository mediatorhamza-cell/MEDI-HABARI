import { useEffect, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { Bell, Check, Inbox, MessageCircle, Send } from 'lucide-react';
import { useI18n } from '@/i18n';
import { useAuth } from '@/context/AuthContext';
import { useSite } from '@/context/SiteContext';
import { useToast } from '@/context/ToastContext';
import { api, ApiError } from '@/lib/api';
import { fmtDateTime, fmtPhone, fmtRelative } from '@/lib/format';
import type { Conversation, Paged } from '@/lib/types';
import { Alert, Button, Card, EmptyState, ErrorState, Loading, PageHead, Pagination, SelectField, Tabs, TextField, TextareaField, useAsync, useDocumentTitle, useErrorText } from '@/components/ui';
import { STATUSES, PAYMENTS } from './Applications';

export function AdminConversationsPage() {
  const { t, lang } = useI18n();
  const [params, setParams] = useSearchParams();
  const filter = (params.get('filter') ?? 'unanswered') as 'unanswered' | 'open' | 'closed' | 'all';
  const [q, setQ] = useState('');
  const { data, loading, error, reload } = useAsync(() => api.get<{ items: Conversation[]; unanswered: number }>(`/admin/conversations?filter=${filter}&q=${encodeURIComponent(q)}`), [filter]);
  useDocumentTitle(t('admin.nav.messages'));
  return (
    <>
      <PageHead title={t('admin.nav.messages')} subtitle={t('admin.chat.subtitle')} />
      <Tabs
        value={filter}
        onChange={(v) => setParams({ filter: v })}
        items={[
          { value: 'unanswered', label: t('admin.chat.unanswered'), count: data?.unanswered },
          { value: 'open', label: t('admin.chat.open') },
          { value: 'closed', label: t('chat.closed') },
          { value: 'all', label: t('common.all') },
        ]}
      />
      <form
        className="toolbar"
        onSubmit={(e) => {
          e.preventDefault();
          void reload();
        }}
      >
        <input className="input search-input" value={q} onChange={(e) => setQ(e.target.value)} placeholder={t('admin.chat.searchPlaceholder')} aria-label={t('common.search')} />
        <Button type="submit" variant="navy">
          {t('common.search')}
        </Button>
      </form>
      <div className="card flush">
        {loading ? (
          <Loading />
        ) : error ? (
          <ErrorState error={error} onRetry={reload} />
        ) : !data?.items.length ? (
          <EmptyState icon={MessageCircle} title={t('chat.empty')} />
        ) : (
          data.items.map((c) => (
            <Link key={c.id} to={`/admin/ujumbe/${c.id}`} className={`list-item ${c.unread ? 'unread' : ''}`}>
              <span className="avatar">{(c.user_name ?? '?').charAt(0)}</span>
              <div className="grow" style={{ minWidth: 0 }}>
                <div className="row between">
                  <span className="li-title">
                    {c.user_name} <span className="xs muted">{fmtPhone(c.user_phone)}</span>
                  </span>
                  <span className="xs muted">{fmtRelative(c.last_message_at, lang)}</span>
                </div>
                <div className="small">{c.subject}</div>
                <div className="small muted" style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                  {c.last_message}
                </div>
                <div className="row xs mt-2" style={{ gap: 6 }}>
                  {c.application_reference && <span className="badge plain neutral mono">{c.application_reference}</span>}
                  {c.awaiting_reply && c.status === 'open' && <span className="badge warning">{t('chat.awaiting')}</span>}
                  {c.unread > 0 && <span className="badge danger plain">{c.unread}</span>}
                </div>
              </div>
            </Link>
          ))
        )}
      </div>
    </>
  );
}

// ------------------------------------------------------------------ notifications

interface Batch {
  id: number;
  title: string;
  body: string;
  audience: { type: string; service?: string; status?: string; deadline_id?: number };
  recipients: number;
  read_count: number;
  sent_by_name: string | null;
  created_at: string;
}

export function AdminNotificationsPage() {
  const { t, pick, tv, lang } = useI18n();
  const { services } = useSite();
  const { can } = useAuth();
  const { toast } = useToast();
  const errText = useErrorText();
  const [page, setPage] = useState(1);
  const { data, loading, error, reload } = useAsync(() => api.get<Paged<Batch>>(`/admin/notifications?page=${page}`), [page]);
  const [f, setF] = useState({ title: '', body: '', title_en: '', body_en: '', link: '' });
  const [aud, setAud] = useState({ type: can('content.manage') ? 'all' : 'service', service: '', status: '', payment_status: '' });
  const [count, setCount] = useState<number | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  useDocumentTitle(t('admin.nav.notifications'));

  useEffect(() => {
    const id = setTimeout(() => {
      api
        .post<{ recipients: number }>('/admin/notifications/preview', { audience: aud })
        .then((r) => setCount(r.recipients))
        .catch(() => setCount(null));
    }, 300);
    return () => clearTimeout(id);
  }, [aud]);

  const send = async () => {
    setBusy(true);
    setErrors({});
    try {
      const r = await api.post<{ recipients: number }>('/admin/notifications', { ...f, audience: aud });
      toast(t('admin.notif.sent', { n: r.recipients }));
      setF({ title: '', body: '', title_en: '', body_en: '', link: '' });
      void reload();
    } catch (e) {
      if (e instanceof ApiError && e.status === 422) setErrors(e.fields);
      toast(errText(e), 'error');
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      <PageHead title={t('admin.nav.notifications')} subtitle={t('admin.notif.subtitle')} />
      <div className="grid grid-2" style={{ alignItems: 'start' }}>
        <Card title={t('admin.notif.compose')}>
          <div className="stack">
            <SelectField label={t('admin.notif.audience')} value={aud.type} onChange={(e) => setAud({ ...aud, type: e.target.value })}>
              {can('content.manage') && <option value="all">{t('admin.notif.allUsers')}</option>}
              <option value="service">{t('admin.notif.byService')}</option>
            </SelectField>
            {aud.type === 'service' && (
              <div className="form-grid">
                <SelectField label={t('common.service')} value={aud.service} onChange={(e) => setAud({ ...aud, service: e.target.value })}>
                  <option value="">{t('admin.apps.allServices')}</option>
                  {services.map((s) => (
                    <option key={s.code} value={s.code}>
                      {pick(s.name_sw, s.name_en)}
                    </option>
                  ))}
                </SelectField>
                <SelectField label={t('common.status')} value={aud.status} onChange={(e) => setAud({ ...aud, status: e.target.value })}>
                  <option value="">{t('admin.apps.allStatuses')}</option>
                  {STATUSES.map((s) => (
                    <option key={s} value={s}>
                      {t(`status.${s}`)}
                    </option>
                  ))}
                </SelectField>
                <SelectField label={t('payment.title')} value={aud.payment_status} onChange={(e) => setAud({ ...aud, payment_status: e.target.value })}>
                  <option value="">{t('admin.apps.allPayments')}</option>
                  {PAYMENTS.map((s) => (
                    <option key={s} value={s}>
                      {t(`payment.${s}`)}
                    </option>
                  ))}
                </SelectField>
              </div>
            )}
            {count !== null && <Alert kind={count ? 'info' : 'warning'}>{t('admin.notif.recipients', { n: count })}</Alert>}
            {errors.audience && <Alert kind="danger">{tv(errors.audience)}</Alert>}
            <TextField label={`${t('admin.notif.title')} (SW)`} value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} error={errors.title && tv(errors.title)} />
            <TextareaField label={`${t('common.message')} (SW)`} value={f.body} onChange={(e) => setF({ ...f, body: e.target.value })} error={errors.body && tv(errors.body)} />
            <TextField label={`${t('admin.notif.title')} (EN)`} optional value={f.title_en} onChange={(e) => setF({ ...f, title_en: e.target.value })} />
            <TextareaField label={`${t('common.message')} (EN)`} optional value={f.body_en} onChange={(e) => setF({ ...f, body_en: e.target.value })} />
            <TextField label={t('admin.notif.link')} optional placeholder="/deadlines" help={t('admin.notif.linkHelp')} value={f.link} onChange={(e) => setF({ ...f, link: e.target.value })} error={errors.link && tv(errors.link)} />
            <Button icon={Send} loading={busy} disabled={!count} onClick={() => void send()}>
              {t('admin.notif.send')}
            </Button>
            <p className="xs muted mb-0">{t('admin.notif.smsHint')}</p>
          </div>
        </Card>
        <Card title={t('admin.notif.history')}>
          {loading ? (
            <Loading />
          ) : error ? (
            <ErrorState error={error} onRetry={reload} />
          ) : !data?.items.length ? (
            <EmptyState icon={Bell} title={t('admin.notif.noHistory')} />
          ) : (
            <div className="stack sm">
              {data.items.map((b) => (
                <div key={b.id} className="card" style={{ padding: 14 }}>
                  <div className="row between">
                    <strong className="small">{b.title}</strong>
                    <span className="xs muted">{fmtDateTime(b.created_at, lang)}</span>
                  </div>
                  <div className="small muted pre">{b.body}</div>
                  <div className="row xs mt-2" style={{ gap: 6 }}>
                    <span className="badge plain info">
                      <Send size={11} /> {b.recipients}
                    </span>
                    <span className="badge plain success">
                      <Check size={11} /> {b.read_count}
                    </span>
                    <span className="muted">
                      {b.audience.type === 'all' ? t('admin.notif.allUsers') : [b.audience.service, b.audience.status && t(`status.${b.audience.status}` as 'status.received')].filter(Boolean).join(' · ') || t('admin.notif.byService')}
                    </span>
                    {b.sent_by_name && <span className="muted">· {b.sent_by_name}</span>}
                  </div>
                </div>
              ))}
              <Pagination page={data.page} perPage={data.per_page} total={data.total} onPage={setPage} />
            </div>
          )}
        </Card>
      </div>
    </>
  );
}

// ------------------------------------------------------------------ contact form inbox

export function ContactMessagesPage() {
  const { t, lang } = useI18n();
  const { data, loading, error, reload } = useAsync(() => api.get<{ id: number; name: string; phone: string | null; email: string | null; message: string; is_handled: number; created_at: string }[]>('/admin/contact-messages'));
  useDocumentTitle(t('admin.nav.contact'));
  const toggle = async (id: number, handled: boolean) => {
    await api.post(`/admin/contact-messages/${id}`, { handled });
    void reload();
  };
  return (
    <>
      <PageHead title={t('admin.nav.contact')} subtitle={t('admin.contact.subtitle')} />
      {loading ? (
        <Loading />
      ) : error ? (
        <ErrorState error={error} onRetry={reload} />
      ) : !data?.length ? (
        <Card>
          <EmptyState icon={Inbox} title={t('admin.contact.empty')} />
        </Card>
      ) : (
        <div className="stack">
          {data.map((m) => (
            <div key={m.id} className="card" style={m.is_handled ? { opacity: 0.65 } : undefined}>
              <div className="row between">
                <strong>{m.name}</strong>
                <span className="xs muted">{fmtDateTime(m.created_at, lang)}</span>
              </div>
              <div className="small muted row" style={{ gap: 12 }}>
                {m.phone && <a href={`tel:${m.phone}`}>{fmtPhone(m.phone)}</a>}
                {m.email && <a href={`mailto:${m.email}`}>{m.email}</a>}
              </div>
              <p className="pre mt-2">{m.message}</p>
              <Button size="sm" variant={m.is_handled ? 'secondary' : 'success'} icon={Check} onClick={() => void toggle(m.id, !m.is_handled)}>
                {m.is_handled ? t('admin.contact.markOpen') : t('admin.contact.markHandled')}
              </Button>
            </div>
          ))}
        </div>
      )}
    </>
  );
}
