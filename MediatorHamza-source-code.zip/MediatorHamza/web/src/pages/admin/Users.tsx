import { useState } from 'react';
import { Link, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { Ban, Bell, KeyRound, Pencil, Plus, ShieldCheck, UserCheck, Users } from 'lucide-react';
import { useI18n } from '@/i18n';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/context/ToastContext';
import { api, ApiError, query } from '@/lib/api';
import { fmtDate, fmtDateTime, fmtPhone } from '@/lib/format';
import type { AppSummary, Paged } from '@/lib/types';
import {
  Alert,
  Button,
  Card,
  EmptyState,
  ErrorState,
  Loading,
  Modal,
  PageHead,
  Pagination,
  PasswordField,
  SelectField,
  TextField,
  TextareaField,
  useAsync,
  useDocumentTitle,
  useErrorText,
} from '@/components/ui';
import { AppCard } from '@/components/Cards';

interface AdminUser {
  id: number;
  first_name: string;
  second_name: string;
  last_name: string | null;
  phone: string;
  email: string | null;
  role: string;
  status: 'active' | 'suspended' | 'disabled';
  suspended_until: string | null;
  suspension_reason: string | null;
  last_login_at: string | null;
  created_at: string;
  applications_count: number | null;
  totp_enabled: boolean;
}

function UserStatus({ s }: { s: AdminUser['status'] }) {
  const { t } = useI18n();
  return <span className={`badge ${s === 'active' ? 'success' : s === 'suspended' ? 'warning' : 'danger'}`}>{t(`admin.users.status.${s}`)}</span>;
}

export function UsersPage() {
  const { t, lang } = useI18n();
  const navigate = useNavigate();
  const [params, setParams] = useSearchParams();
  const f = { q: params.get('q') ?? '', status: params.get('status') ?? '', page: Number(params.get('page') ?? 1) };
  const [q, setQ] = useState(f.q);
  const { data, loading, error, reload } = useAsync(() => api.get<Paged<AdminUser>>(`/admin/users${query(f)}`), [params.toString()]);
  useDocumentTitle(t('admin.nav.users'));
  return (
    <>
      <PageHead title={t('admin.nav.users')} subtitle={data ? t('common.results', { count: data.total }) : undefined} />
      <form
        className="toolbar"
        onSubmit={(e) => {
          e.preventDefault();
          setParams(q ? { q } : {});
        }}
      >
        <input className="input search-input" value={q} onChange={(e) => setQ(e.target.value)} placeholder={t('admin.users.searchPlaceholder')} aria-label={t('common.search')} />
        <select className="select" value={f.status} onChange={(e) => setParams({ ...(f.q ? { q: f.q } : {}), ...(e.target.value ? { status: e.target.value } : {}) })} aria-label={t('common.status')}>
          <option value="">{t('common.all')}</option>
          {(['active', 'suspended', 'disabled'] as const).map((s) => (
            <option key={s} value={s}>
              {t(`admin.users.status.${s}`)}
            </option>
          ))}
        </select>
        <Button type="submit" variant="navy">
          {t('common.search')}
        </Button>
      </form>
      <div className="card flush">
        {loading && !data ? (
          <Loading />
        ) : error ? (
          <ErrorState error={error} onRetry={reload} />
        ) : !data?.items.length ? (
          <EmptyState icon={Users} title={t('admin.users.empty')} />
        ) : (
          <>
            <div className="table-wrap">
              <table className="table responsive">
                <thead>
                  <tr>
                    <th>{t('common.name')}</th>
                    <th>{t('common.phone')}</th>
                    <th>{t('admin.nav.applications')}</th>
                    <th>{t('common.status')}</th>
                    <th>{t('admin.users.registered')}</th>
                  </tr>
                </thead>
                <tbody>
                  {data.items.map((u) => (
                    <tr key={u.id} className="clickable" onClick={() => navigate(`/admin/watumiaji/${u.id}`)}>
                      <td data-label={t('common.name')}>
                        <Link to={`/admin/watumiaji/${u.id}`} onClick={(e) => e.stopPropagation()} style={{ fontWeight: 600 }}>
                          {u.first_name} {u.second_name} {u.last_name ?? ''}
                        </Link>
                      </td>
                      <td data-label={t('common.phone')}>{fmtPhone(u.phone)}</td>
                      <td data-label={t('admin.nav.applications')}>{u.applications_count}</td>
                      <td data-label={t('common.status')}>
                        <UserStatus s={u.status} />
                      </td>
                      <td data-label={t('admin.users.registered')}>{fmtDate(u.created_at, lang)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <Pagination page={data.page} perPage={data.per_page} total={data.total} onPage={(p) => setParams({ ...(f.q ? { q: f.q } : {}), page: String(p) })} />
          </>
        )}
      </div>
    </>
  );
}

export function UserDetailPage() {
  const { id } = useParams();
  const { t, tv, lang } = useI18n();
  const { can } = useAuth();
  const { toast } = useToast();
  const errText = useErrorText();
  const { data, loading, error, reload } = useAsync(
    () => api.get<{ user: AdminUser; applications: AppSummary[]; logins: { event: string; ip_address: string; user_agent: string; created_at: string }[]; conversations: { id: number; subject: string; status: string; last_message_at: string }[] }>(`/admin/users/${id}`),
    [id],
  );
  const [modal, setModal] = useState<'edit' | 'status' | 'notify' | 'code' | null>(null);
  const [edit, setEdit] = useState({ first_name: '', second_name: '', last_name: '', email: '', phone: '' });
  const [status, setStatus] = useState({ action: 'suspend', until: '', reason: '' });
  const [notify, setNotify] = useState({ title: '', body: '' });
  const [code, setCode] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  useDocumentTitle(data ? `${data.user.first_name} ${data.user.second_name}` : t('admin.nav.users'));

  if (loading && !data) return <Loading />;
  if (error || !data) return <ErrorState error={error} onRetry={reload} />;
  const u = data.user;

  const run = async (fn: () => Promise<unknown>, ok: string) => {
    setBusy(true);
    setErrors({});
    try {
      await fn();
      toast(ok);
      setModal(null);
      void reload();
    } catch (e) {
      if (e instanceof ApiError && e.status === 422) setErrors(e.fields);
      toast(errText(e), 'error');
    } finally {
      setBusy(false);
    }
  };
  const issueCode = async () => {
    setBusy(true);
    try {
      const r = await api.post<{ code: string }>(`/admin/users/${u.id}/reset-code`);
      setCode(r.code);
      setModal('code');
    } catch (e) {
      toast(errText(e), 'error');
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      <PageHead
        title={`${u.first_name} ${u.second_name} ${u.last_name ?? ''}`}
        subtitle={fmtPhone(u.phone)}
        crumbs={[{ to: '/admin/watumiaji', label: t('admin.nav.users') }, { label: u.first_name }]}
        actions={
          <>
            {can('notifications.send') && (
              <Button variant="secondary" icon={Bell} onClick={() => setModal('notify')}>
                {t('admin.users.sendMessage')}
              </Button>
            )}
            {can('users.manage') && (
              <>
                <Button variant="secondary" icon={Pencil} onClick={() => { setEdit({ first_name: u.first_name, second_name: u.second_name, last_name: u.last_name ?? '', email: u.email ?? '', phone: u.phone }); setModal('edit'); }}>
                  {t('common.edit')}
                </Button>
                <Button variant="secondary" icon={KeyRound} loading={busy && modal === null} onClick={() => void issueCode()}>
                  {t('admin.users.resetCode')}
                </Button>
                <Button variant={u.status === 'active' ? 'danger' : 'success'} icon={u.status === 'active' ? Ban : UserCheck} onClick={() => { setStatus({ action: u.status === 'active' ? 'suspend' : 'activate', until: '', reason: '' }); setModal('status'); }}>
                  {u.status === 'active' ? t('admin.users.suspend') : t('admin.users.activate')}
                </Button>
              </>
            )}
          </>
        }
      />
      <div className="grid grid-2" style={{ alignItems: 'start' }}>
        <div className="stack">
          <Card>
            <dl className="kv">
              <dt>{t('common.status')}</dt>
              <dd>
                <UserStatus s={u.status} /> {u.suspended_until && <span className="xs muted">→ {fmtDate(u.suspended_until, lang)}</span>}
              </dd>
              {u.suspension_reason && (
                <>
                  <dt>{t('admin.users.reason')}</dt>
                  <dd>{u.suspension_reason}</dd>
                </>
              )}
              <dt>{t('common.phone')}</dt>
              <dd>{fmtPhone(u.phone)}</dd>
              <dt>{t('common.email')}</dt>
              <dd>{u.email ?? '—'}</dd>
              <dt>{t('admin.users.registered')}</dt>
              <dd>{fmtDateTime(u.created_at, lang)}</dd>
              <dt>{t('admin.users.lastLogin')}</dt>
              <dd>{fmtDateTime(u.last_login_at, lang)}</dd>
            </dl>
          </Card>
          <Card title={t('admin.users.loginHistory')}>
            <div className="stack sm">
              {data.logins.map((l, i) => (
                <div key={i} className="row between xs" style={{ flexWrap: 'nowrap' }}>
                  <span>{t(`profile.event.${l.event}` as 'profile.event.login')}</span>
                  <span className="muted nowrap">{fmtDateTime(l.created_at, lang)}</span>
                </div>
              ))}
            </div>
          </Card>
          {data.conversations.length > 0 && (
            <Card title={t('admin.nav.messages')}>
              {data.conversations.map((c) => (
                <div key={c.id}>
                  <Link to={`/admin/ujumbe/${c.id}`} className="small">
                    {c.subject}
                  </Link>
                </div>
              ))}
            </Card>
          )}
        </div>
        <Card title={t('apps.historyTitle')}>
          {data.applications.length === 0 ? (
            <p className="small muted mb-0">{t('apps.empty')}</p>
          ) : (
            <div className="stack sm">
              {data.applications.map((a) => (
                <AppCard key={a.id} a={a} admin />
              ))}
            </div>
          )}
        </Card>
      </div>

      <Modal open={modal === 'edit'} onClose={() => setModal(null)} title={t('admin.users.editTitle')} footer={<Button loading={busy} onClick={() => void run(() => api.put(`/admin/users/${u.id}`, edit), t('common.saved'))}>{t('common.save')}</Button>}>
        <div className="form-grid">
          <TextField label={t('auth.firstName')} value={edit.first_name} onChange={(e) => setEdit({ ...edit, first_name: e.target.value })} error={errors.first_name && tv(errors.first_name)} />
          <TextField label={t('auth.secondName')} value={edit.second_name} onChange={(e) => setEdit({ ...edit, second_name: e.target.value })} error={errors.second_name && tv(errors.second_name)} />
          <TextField label={t('auth.lastName')} optional value={edit.last_name} onChange={(e) => setEdit({ ...edit, last_name: e.target.value })} />
          <TextField label={t('common.email')} optional value={edit.email} onChange={(e) => setEdit({ ...edit, email: e.target.value })} error={errors.email && tv(errors.email)} />
          <TextField label={t('common.phone')} wrapClass="full" value={edit.phone} onChange={(e) => setEdit({ ...edit, phone: e.target.value })} error={errors.phone && tv(errors.phone)} />
        </div>
      </Modal>

      <Modal open={modal === 'status'} onClose={() => setModal(null)} title={t('admin.users.statusTitle')} footer={<Button loading={busy} variant={status.action === 'activate' ? 'success' : 'danger'} onClick={() => void run(() => api.post(`/admin/users/${u.id}/status`, status), t('common.saved'))}>{t('common.confirm')}</Button>}>
        <div className="stack">
          <SelectField label={t('common.actions')} value={status.action} onChange={(e) => setStatus({ ...status, action: e.target.value })}>
            <option value="suspend">{t('admin.users.suspend')}</option>
            <option value="disable">{t('admin.users.disable')}</option>
            <option value="activate">{t('admin.users.activate')}</option>
          </SelectField>
          {status.action === 'suspend' && <TextField type="date" label={t('admin.users.until')} optional value={status.until} onChange={(e) => setStatus({ ...status, until: e.target.value })} />}
          {status.action !== 'activate' && <TextField label={t('admin.users.reason')} optional value={status.reason} onChange={(e) => setStatus({ ...status, reason: e.target.value })} />}
        </div>
      </Modal>

      <Modal open={modal === 'notify'} onClose={() => setModal(null)} title={t('admin.users.sendMessage')} footer={<Button loading={busy} onClick={() => void run(() => api.post(`/admin/users/${u.id}/notify`, notify), t('admin.notif.sent', { n: 1 }))}>{t('common.send')}</Button>}>
        <div className="stack">
          <TextField label={t('admin.notif.title')} value={notify.title} onChange={(e) => setNotify({ ...notify, title: e.target.value })} error={errors.title && tv(errors.title)} />
          <TextareaField label={t('common.message')} value={notify.body} onChange={(e) => setNotify({ ...notify, body: e.target.value })} error={errors.body && tv(errors.body)} />
        </div>
      </Modal>

      <Modal open={modal === 'code'} onClose={() => setModal(null)} title={t('admin.users.resetCode')}>
        <div className="stack text-center">
          <Alert kind="warning">{t('admin.users.resetCodeHelp')}</Alert>
          <div className="mono" style={{ fontSize: 32, fontWeight: 800, letterSpacing: '0.2em', color: 'var(--c-navy)' }}>
            {code}
          </div>
          <p className="small muted mb-0">{t('admin.users.resetCodeExpiry')}</p>
        </div>
      </Modal>
    </>
  );
}

// ------------------------------------------------------------------ staff (super admin)

interface Staff {
  id: number;
  first_name: string;
  second_name: string;
  phone: string;
  email: string | null;
  role: string;
  status: string;
  totp_enabled: number;
  last_login_at: string | null;
}

export function StaffPage() {
  const { t, tv, lang } = useI18n();
  const { user } = useAuth();
  const { toast } = useToast();
  const errText = useErrorText();
  const { data, loading, error, reload } = useAsync(() => api.get<Staff[]>('/admin/staff'));
  const [open, setOpen] = useState(false);
  const [f, setF] = useState({ first_name: '', second_name: '', phone: '', email: '', role: 'support', password: '' });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  useDocumentTitle(t('admin.nav.staff'));
  const roles = ['super_admin', 'admin', 'support', 'readonly'] as const;

  const create = async () => {
    setBusy(true);
    setErrors({});
    try {
      await api.post('/admin/staff', f);
      toast(t('common.saved'));
      setOpen(false);
      setF({ first_name: '', second_name: '', phone: '', email: '', role: 'support', password: '' });
      void reload();
    } catch (e) {
      if (e instanceof ApiError && e.status === 422) setErrors(e.fields);
      toast(errText(e), 'error');
    } finally {
      setBusy(false);
    }
  };
  const update = async (s: Staff, patch: Partial<Pick<Staff, 'role' | 'status'>>) => {
    try {
      await api.put(`/admin/staff/${s.id}`, { role: s.role, status: s.status, ...patch });
      toast(t('common.saved'));
      void reload();
    } catch (e) {
      toast(errText(e), 'error');
    }
  };

  return (
    <>
      <PageHead title={t('admin.nav.staff')} subtitle={t('admin.staff.subtitle')} actions={<Button icon={Plus} onClick={() => setOpen(true)}>{t('admin.staff.add')}</Button>} />
      <Alert kind="info">{t('admin.staff.rolesHelp')}</Alert>
      <div className="card flush mt-4">
        {loading ? (
          <Loading />
        ) : error ? (
          <ErrorState error={error} onRetry={reload} />
        ) : (
          <div className="table-wrap">
            <table className="table responsive">
              <thead>
                <tr>
                  <th>{t('common.name')}</th>
                  <th>{t('common.phone')}</th>
                  <th>{t('admin.staff.role')}</th>
                  <th>{t('common.status')}</th>
                  <th>2FA</th>
                  <th>{t('admin.users.lastLogin')}</th>
                </tr>
              </thead>
              <tbody>
                {data?.map((s) => (
                  <tr key={s.id}>
                    <td data-label={t('common.name')} style={{ fontWeight: 600 }}>
                      {s.first_name} {s.second_name}
                    </td>
                    <td data-label={t('common.phone')}>{fmtPhone(s.phone)}</td>
                    <td data-label={t('admin.staff.role')}>
                      <select className="select" style={{ minHeight: 36, padding: '4px 30px 4px 8px' }} value={s.role} disabled={s.id === user?.id} onChange={(e) => void update(s, { role: e.target.value })}>
                        {roles.map((r) => (
                          <option key={r} value={r}>
                            {t(`admin.role.${r}`)}
                          </option>
                        ))}
                      </select>
                    </td>
                    <td data-label={t('common.status')}>
                      <select className="select" style={{ minHeight: 36, padding: '4px 30px 4px 8px' }} value={s.status} disabled={s.id === user?.id} onChange={(e) => void update(s, { status: e.target.value })}>
                        <option value="active">{t('admin.users.status.active')}</option>
                        <option value="disabled">{t('admin.users.status.disabled')}</option>
                      </select>
                    </td>
                    <td data-label="2FA">{s.totp_enabled ? <ShieldCheck size={18} color="var(--c-success)" /> : '—'}</td>
                    <td data-label={t('admin.users.lastLogin')}>{fmtDateTime(s.last_login_at, lang)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
      <Modal open={open} onClose={() => setOpen(false)} title={t('admin.staff.add')} footer={<Button loading={busy} onClick={() => void create()}>{t('common.save')}</Button>}>
        <div className="form-grid">
          <TextField label={t('auth.firstName')} value={f.first_name} onChange={(e) => setF({ ...f, first_name: e.target.value })} error={errors.first_name && tv(errors.first_name)} />
          <TextField label={t('auth.secondName')} value={f.second_name} onChange={(e) => setF({ ...f, second_name: e.target.value })} error={errors.second_name && tv(errors.second_name)} />
          <TextField label={t('common.phone')} type="tel" value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} error={errors.phone && tv(errors.phone)} />
          <TextField label={t('common.email')} optional value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} error={errors.email && tv(errors.email)} />
          <SelectField label={t('admin.staff.role')} value={f.role} onChange={(e) => setF({ ...f, role: e.target.value })}>
            {roles.map((r) => (
              <option key={r} value={r}>
                {t(`admin.role.${r}`)}
              </option>
            ))}
          </SelectField>
          <PasswordField label={t('admin.staff.initialPassword')} help={t('admin.staff.passwordHelp')} autoComplete="new-password" value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} error={errors.password && tv(errors.password)} />
        </div>
      </Modal>
    </>
  );
}
