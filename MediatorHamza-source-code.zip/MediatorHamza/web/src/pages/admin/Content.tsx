import { useEffect, useRef, useState } from 'react';
import { useParams } from 'react-router-dom';
import { BellRing, Eye, EyeOff, FileText, Pencil, Plus, ShieldCheck, Trash2, Upload, X } from 'lucide-react';
import { useI18n, type TKey } from '@/i18n';
import { useSite } from '@/context/SiteContext';
import { useToast } from '@/context/ToastContext';
import { api, ApiError, mediaUrl, uploadFile } from '@/lib/api';
import { fmtDate } from '@/lib/format';
import type { Category, Paged, Region } from '@/lib/types';
import {
  Alert,
  Button,
  Checkbox,
  EmptyState,
  ErrorState,
  FieldShell,
  Loading,
  Modal,
  PageHead,
  Pagination,
  SelectField,
  TextField,
  TextareaField,
  useAsync,
  useConfirm,
  useDocumentTitle,
  useErrorText,
} from '@/components/ui';

type FType = 'text' | 'textarea' | 'longtext' | 'bool' | 'date' | 'datetime' | 'url' | 'int' | 'category' | 'service' | 'media' | 'ownership' | 'region' | 'scope';
interface FDef {
  key: string;
  label: TKey;
  type: FType;
  required?: boolean;
  full?: boolean;
  accept?: string;
  help?: TKey;
}
interface TypeDef {
  title: TKey;
  subtitle: TKey;
  scope?: string;
  primary: string;
  secondary?: (row: Row, ctx: { lang: 'sw' | 'en' }) => string;
  fields: FDef[];
  defaults: Row;
}
type Row = Record<string, unknown>;

const bilingual = (base: string, label: TKey, type: FType, required = false, full = true): FDef[] => [
  { key: `${base}_sw`, label, type, required, full },
  { key: `${base}_en`, label, type, full },
];

const TYPES: Record<string, TypeDef> = {
  articles: {
    title: 'admin.nav.articles',
    subtitle: 'admin.content.articlesSub',
    scope: 'article',
    primary: 'title_sw',
    secondary: (r, c) => fmtDate((r.published_at as string) ?? (r.created_at as string), c.lang),
    fields: [
      ...bilingual('title', 'admin.f.title', 'text', true),
      { key: 'category_id', label: 'admin.f.category', type: 'category' },
      { key: 'is_published', label: 'admin.f.published', type: 'bool' },
      ...bilingual('summary', 'admin.f.summary', 'textarea'),
      ...bilingual('body', 'admin.f.body', 'longtext'),
      { key: 'image_id', label: 'admin.f.image', type: 'media', accept: 'image/*' },
      { key: 'attachment_id', label: 'admin.f.attachment', type: 'media', accept: 'application/pdf,image/*' },
      { key: 'published_at', label: 'admin.f.publishedAt', type: 'datetime' },
      { key: 'sort_order', label: 'admin.f.sort', type: 'int', help: 'admin.f.sortHelp' },
    ],
    defaults: { is_published: true, sort_order: 0 },
  },
  institutions: {
    title: 'admin.nav.institutions',
    subtitle: 'admin.content.institutionsSub',
    scope: 'institution_type',
    primary: 'name',
    secondary: (r) => [r.short_name, r.region].filter(Boolean).join(' · '),
    fields: [
      { key: 'name', label: 'admin.f.name', type: 'text', required: true, full: true },
      { key: 'short_name', label: 'admin.f.shortName', type: 'text' },
      { key: 'category_id', label: 'admin.f.institutionType', type: 'category' },
      { key: 'ownership', label: 'admin.f.ownership', type: 'ownership' },
      { key: 'region', label: 'admin.f.region', type: 'region' },
      { key: 'location', label: 'admin.f.location', type: 'text' },
      { key: 'website_url', label: 'institutions.website', type: 'url' },
      { key: 'apply_url', label: 'institutions.apply', type: 'url' },
      { key: 'login_url', label: 'institutions.login', type: 'url' },
      { key: 'logo_id', label: 'admin.f.logo', type: 'media', accept: 'image/*' },
      ...bilingual('description', 'admin.f.description', 'textarea'),
      { key: 'is_featured', label: 'admin.f.featured', type: 'bool' },
      { key: 'is_published', label: 'admin.f.published', type: 'bool', help: 'admin.f.publishInstitutionHelp' },
      { key: 'sort_order', label: 'admin.f.sort', type: 'int' },
    ],
    defaults: { is_published: false, is_featured: false, sort_order: 0 },
  },
  guidebooks: {
    title: 'admin.nav.guidebooks',
    subtitle: 'admin.content.guidebooksSub',
    scope: 'guide',
    primary: 'title_sw',
    secondary: (r) => [r.academic_year, r.is_outdated ? '⚠' : ''].filter(Boolean).join(' '),
    fields: [
      ...bilingual('title', 'admin.f.title', 'text', true),
      { key: 'category_id', label: 'admin.f.category', type: 'category' },
      { key: 'academic_year', label: 'guides.year', type: 'text' },
      { key: 'file_id', label: 'admin.f.file', type: 'media', accept: 'application/pdf,image/*' },
      { key: 'external_url', label: 'admin.f.externalUrl', type: 'url' },
      ...bilingual('description', 'admin.f.description', 'textarea'),
      { key: 'is_outdated', label: 'guides.outdated', type: 'bool', help: 'admin.f.outdatedHelp' },
      { key: 'is_published', label: 'admin.f.published', type: 'bool' },
      { key: 'sort_order', label: 'admin.f.sort', type: 'int' },
    ],
    defaults: { is_published: true, is_outdated: false, sort_order: 0 },
  },
  deadlines: {
    title: 'admin.nav.deadlines',
    subtitle: 'admin.content.deadlinesSub',
    primary: 'title_sw',
    secondary: (r, c) => `${fmtDate(r.opens_at as string, c.lang)} → ${fmtDate(r.closes_at as string, c.lang)}`,
    fields: [
      ...bilingual('title', 'admin.f.title', 'text', true),
      { key: 'service_id', label: 'common.service', type: 'service' },
      { key: 'opens_at', label: 'deadlines.opens', type: 'date' },
      { key: 'closes_at', label: 'deadlines.closes', type: 'date', required: true },
      { key: 'remind_days_before', label: 'admin.f.remindDays', type: 'int', help: 'admin.f.remindHelp' },
      { key: 'is_published', label: 'admin.f.published', type: 'bool' },
      ...bilingual('description', 'admin.f.description', 'textarea'),
    ],
    defaults: { is_published: true, remind_days_before: 3 },
  },
  announcements: {
    title: 'admin.nav.announcements',
    subtitle: 'admin.content.announcementsSub',
    primary: 'title_sw',
    secondary: (r, c) => fmtDate((r.published_at as string) ?? (r.created_at as string), c.lang),
    fields: [
      ...bilingual('title', 'admin.f.title', 'text', true),
      ...bilingual('body', 'admin.f.body', 'longtext'),
      { key: 'is_pinned', label: 'announcements.pinned', type: 'bool' },
      { key: 'is_published', label: 'admin.f.published', type: 'bool' },
      { key: 'published_at', label: 'admin.f.publishedAt', type: 'datetime' },
    ],
    defaults: { is_published: true, is_pinned: false },
  },
  faqs: {
    title: 'admin.nav.faqs',
    subtitle: 'admin.content.faqsSub',
    scope: 'faq',
    primary: 'question_sw',
    fields: [
      ...bilingual('question', 'admin.f.question', 'text', true),
      ...bilingual('answer', 'admin.f.answer', 'textarea', true),
      { key: 'keywords', label: 'admin.f.keywords', type: 'text', full: true, help: 'admin.f.keywordsHelp' },
      { key: 'category_id', label: 'admin.f.category', type: 'category' },
      { key: 'sort_order', label: 'admin.f.sort', type: 'int' },
      { key: 'is_published', label: 'admin.f.published', type: 'bool' },
    ],
    defaults: { is_published: true, sort_order: 0 },
  },
  whatsapp_groups: {
    title: 'admin.nav.groups',
    subtitle: 'admin.content.groupsSub',
    primary: 'name',
    secondary: (r) => String(r.invite_url ?? ''),
    fields: [
      { key: 'name', label: 'admin.f.name', type: 'text', required: true, full: true },
      { key: 'invite_url', label: 'admin.f.inviteUrl', type: 'url', required: true, full: true },
      ...bilingual('description', 'admin.f.description', 'textarea'),
      { key: 'sort_order', label: 'admin.f.sort', type: 'int' },
      { key: 'is_published', label: 'admin.f.published', type: 'bool' },
    ],
    defaults: { is_published: true, sort_order: 0 },
  },
  testimonials: {
    title: 'admin.nav.testimonials',
    subtitle: 'admin.content.testimonialsSub',
    primary: 'name',
    secondary: (r) => `${r.year ?? ''} · ${'★'.repeat(Number(r.rating ?? 5))}`,
    fields: [
      { key: 'name', label: 'admin.f.name', type: 'text', required: true },
      { key: 'location', label: 'admin.f.location', type: 'text' },
      ...bilingual('role', 'admin.f.role', 'text', false, false),
      ...bilingual('body', 'admin.f.testimony', 'textarea', true),
      { key: 'year', label: 'admin.f.year', type: 'int', required: true },
      { key: 'rating', label: 'admin.f.rating', type: 'int' },
      { key: 'photo_id', label: 'admin.f.photo', type: 'media', accept: 'image/*' },
      { key: 'sort_order', label: 'admin.f.sort', type: 'int' },
      { key: 'is_published', label: 'admin.f.published', type: 'bool' },
    ],
    defaults: { is_published: true, sort_order: 0, rating: 5, year: new Date().getFullYear() },
  },
  categories: {
    title: 'admin.nav.categories',
    subtitle: 'admin.content.categoriesSub',
    primary: 'name_sw',
    secondary: (r) => String(r.scope ?? ''),
    fields: [
      { key: 'scope', label: 'admin.f.scope', type: 'scope', required: true },
      { key: 'slug', label: 'admin.f.slug', type: 'text' },
      { key: 'name_sw', label: 'admin.f.name', type: 'text', required: true },
      { key: 'name_en', label: 'admin.f.name', type: 'text' },
      { key: 'sort_order', label: 'admin.f.sort', type: 'int' },
    ],
    defaults: { scope: 'article', sort_order: 0 },
  },
};

function MediaInput({ value, onChange, accept }: { value: number | null; onChange: (v: number | null) => void; accept?: string }) {
  const { t, tv } = useI18n();
  const { toast } = useToast();
  const ref = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const upload = async (file?: File) => {
    if (!file) return;
    const form = new FormData();
    form.append('file', file);
    setBusy(true);
    try {
      const r = await uploadFile<{ id: number }>('/admin/media', form);
      onChange(r.id);
    } catch (e) {
      toast(e instanceof ApiError && e.fields.file ? tv(e.fields.file) : t('common.unknownError'), 'error');
    } finally {
      setBusy(false);
    }
  };
  return (
    <div className="row">
      {value ? (
        <>
          <a href={mediaUrl(value)} target="_blank" rel="noopener noreferrer" className="file-item grow" style={{ textDecoration: 'none' }}>
            <span className="thumb">
              <FileText />
            </span>
            #{value}
          </a>
          <button type="button" className="icon-btn" onClick={() => onChange(null)} aria-label={t('form.removeFile')}>
            <X />
          </button>
        </>
      ) : (
        <Button variant="secondary" size="sm" icon={Upload} loading={busy} onClick={() => ref.current?.click()}>
          {t('admin.f.upload')}
        </Button>
      )}
      <input ref={ref} type="file" hidden accept={accept} onChange={(e) => void upload(e.target.files?.[0])} />
    </div>
  );
}

export default function ContentPage() {
  const { type = 'articles' } = useParams();
  const def = TYPES[type];
  const { t, tv, pick, lang } = useI18n();
  const { services } = useSite();
  const { toast } = useToast();
  const errText = useErrorText();
  const { confirm, dialog } = useConfirm();
  const [q, setQ] = useState('');
  const [page, setPage] = useState(1);
  const { data, loading, error, reload } = useAsync(() => api.get<Paged<Row>>(`/admin/content/${type}?page=${page}&q=${encodeURIComponent(q)}`), [type, page]);
  const { data: cats } = useAsync(() => (def?.scope ? api.get<Paged<Category>>(`/admin/content/categories?scope=${def.scope}&per_page=200`) : Promise.resolve(null)), [type]);
  const { data: regions } = useAsync(() => (type === 'institutions' ? api.get<Region[]>('/regions') : Promise.resolve([] as Region[])), [type]);
  const [editing, setEditing] = useState<Row | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  useDocumentTitle(def ? t(def.title) : '');
  useEffect(() => {
    setPage(1);
    setQ('');
  }, [type]);

  if (!def) return <ErrorState error={new ApiError(404, 'not_found', '')} />;

  const save = async () => {
    if (!editing) return;
    setBusy(true);
    setErrors({});
    const payload: Row = {};
    for (const f of def.fields) {
      let v = editing[f.key];
      if (f.type === 'bool') v = !!v;
      if (v === undefined) continue;
      if (f.type === 'datetime' && typeof v === 'string') v = v.replace('T', ' ');
      payload[f.key] = v === '' ? null : v;
    }
    try {
      if (editing.id) await api.put(`/admin/content/${type}/${editing.id}`, payload);
      else await api.post(`/admin/content/${type}`, payload);
      toast(t('common.saved'));
      setEditing(null);
      void reload();
    } catch (e) {
      if (e instanceof ApiError && e.status === 422) setErrors(e.fields);
      toast(errText(e), 'error');
    } finally {
      setBusy(false);
    }
  };
  const remove = async (row: Row) => {
    if (!(await confirm({ title: t('common.delete'), text: String(row[def.primary] ?? ''), danger: true }))) return;
    try {
      await api.del(`/admin/content/${type}/${row.id}`);
      toast(t('common.saved'));
      void reload();
    } catch (e) {
      toast(errText(e), 'error');
    }
  };
  const togglePublish = async (row: Row) => {
    try {
      await api.put(`/admin/content/${type}/${row.id}`, { is_published: !row.is_published });
      void reload();
    } catch (e) {
      toast(e instanceof ApiError && e.fields.is_published ? tv(e.fields.is_published) : errText(e), 'error');
    }
  };
  const verifyLinks = async (row: Row, manual = false) => {
    try {
      const r = await api.post<{ verified: boolean; results: Record<string, { url: string; status: number; ok: boolean }> }>(`/admin/content/institutions/${row.id}/verify-links`, { manual });
      if (r.verified) toast(t('admin.content.linksVerified'));
      else {
        const bad = Object.values(r.results).filter((x) => !x.ok).map((x) => `${x.url} (HTTP ${x.status || '—'})`).join(', ');
        if (await confirm({ title: t('admin.content.linksFailed'), text: `${bad}\n\n${t('admin.content.manualVerify')}`, confirmLabel: t('admin.content.markVerified') })) await verifyLinks(row, true);
      }
      void reload();
    } catch (e) {
      toast(errText(e), 'error');
    }
  };
  const remind = async (row: Row) => {
    if (!(await confirm({ title: t('admin.content.sendReminder'), text: String(row.title_sw) }))) return;
    try {
      const r = await api.post<{ recipients: number }>(`/admin/deadlines/${row.id}/remind`);
      toast(t('admin.notif.sent', { n: r.recipients }));
      void reload();
    } catch (e) {
      toast(errText(e), 'error');
    }
  };

  const fieldControl = (f: FDef) => {
    const v = editing?.[f.key];
    const set = (val: unknown) => setEditing((e) => ({ ...(e ?? {}), [f.key]: val }));
    const err = errors[f.key] ? tv(errors[f.key]) : null;
    const lbl = `${t(f.label)}${f.key.endsWith('_en') ? ' (EN)' : f.key.endsWith('_sw') ? ' (SW)' : ''}`;
    const help = f.help ? t(f.help) : undefined;
    const wrap = f.full || f.type === 'textarea' || f.type === 'longtext' ? 'full' : '';
    switch (f.type) {
      case 'textarea':
      case 'longtext':
        return <TextareaField key={f.key} label={lbl} required={f.required} wrapClass={wrap} rows={f.type === 'longtext' ? 10 : 4} value={(v as string) ?? ''} onChange={(e) => set(e.target.value)} error={err} help={help} />;
      case 'bool':
        return (
          <div key={f.key} className="field" style={{ justifyContent: 'flex-end' }}>
            <Checkbox checked={!!v} onChange={set}>
              {lbl}
            </Checkbox>
            {help && <span className="field-help">{help}</span>}
            {err && <span className="field-error">{err}</span>}
          </div>
        );
      case 'category':
        return (
          <SelectField key={f.key} label={lbl} value={String(v ?? '')} onChange={(e) => set(e.target.value ? Number(e.target.value) : null)} placeholder="—" error={err}>
            {cats?.items.map((c) => (
              <option key={c.id} value={c.id}>
                {pick(c.name_sw, c.name_en)}
              </option>
            ))}
          </SelectField>
        );
      case 'service':
        return (
          <SelectField key={f.key} label={lbl} value={String(v ?? '')} onChange={(e) => set(e.target.value ? Number(e.target.value) : null)} placeholder="—" error={err}>
            {services.map((s) => (
              <option key={s.id} value={s.id}>
                {pick(s.name_sw, s.name_en)}
              </option>
            ))}
          </SelectField>
        );
      case 'ownership':
        return (
          <SelectField key={f.key} label={lbl} value={String(v ?? '')} onChange={(e) => set(e.target.value || null)} placeholder="—">
            <option value="public">{t('institutions.public')}</option>
            <option value="private">{t('institutions.private')}</option>
            <option value="other">{t('institutions.other')}</option>
          </SelectField>
        );
      case 'region':
        return (
          <SelectField key={f.key} label={lbl} value={String(v ?? '')} onChange={(e) => set(e.target.value || null)} placeholder="—">
            {regions?.map((r) => (
              <option key={r.name}>{r.name}</option>
            ))}
          </SelectField>
        );
      case 'scope':
        return (
          <SelectField key={f.key} label={lbl} value={String(v ?? 'article')} onChange={(e) => set(e.target.value)} required>
            {['article', 'guide', 'institution_type', 'faq'].map((s) => (
              <option key={s} value={s}>
                {t(`admin.scope.${s}` as TKey)}
              </option>
            ))}
          </SelectField>
        );
      case 'media':
        return (
          <FieldShell key={f.key} id={f.key} label={lbl} error={err} className={wrap}>
            <MediaInput value={(v as number) ?? null} onChange={set} accept={f.accept} />
          </FieldShell>
        );
      default: {
        const type = f.type === 'date' ? 'date' : f.type === 'datetime' ? 'datetime-local' : f.type === 'url' ? 'url' : 'text';
        let val = v === null || v === undefined ? '' : String(v);
        if (f.type === 'datetime') val = val.replace(' ', 'T').slice(0, 16);
        return (
          <TextField
            key={f.key}
            label={lbl}
            type={type}
            required={f.required}
            wrapClass={wrap}
            inputMode={f.type === 'int' ? 'numeric' : undefined}
            placeholder={f.type === 'url' ? 'https://' : undefined}
            value={val}
            onChange={(e) => set(f.type === 'int' ? (e.target.value === '' ? null : Number(e.target.value.replace(/\D/g, ''))) : e.target.value)}
            error={err}
            help={help}
          />
        );
      }
    }
  };

  return (
    <>
      {dialog}
      <PageHead
        title={t(def.title)}
        subtitle={t(def.subtitle)}
        actions={
          <Button icon={Plus} onClick={() => { setErrors({}); setEditing({ ...def.defaults }); }}>
            {t('common.add')}
          </Button>
        }
      />
      {type === 'institutions' && <Alert kind="info">{t('admin.content.institutionsHelp')}</Alert>}
      <form
        className="toolbar mt-4"
        onSubmit={(e) => {
          e.preventDefault();
          setPage(1);
          void reload();
        }}
      >
        <input className="input search-input" value={q} onChange={(e) => setQ(e.target.value)} placeholder={t('common.search')} aria-label={t('common.search')} />
        <Button type="submit" variant="navy">
          {t('common.search')}
        </Button>
      </form>
      <div className="card flush">
        {loading && !data ? (
          <Loading />
        ) : error ? (
          <ErrorState error={error} onRetry={reload} />
        ) : !data?.items.length ? (
          <EmptyState title={t('admin.content.empty')} action={<Button icon={Plus} onClick={() => setEditing({ ...def.defaults })}>{t('common.add')}</Button>} />
        ) : (
          <>
            {data.items.map((row) => (
              <div key={String(row.id)} className="list-item" style={{ alignItems: 'center' }}>
                <div className="grow" style={{ minWidth: 0 }}>
                  <div className="li-title break">{String(row[def.primary] ?? '')}</div>
                  <div className="row xs muted" style={{ gap: 6 }}>
                    {def.secondary && <span className="break">{def.secondary(row, { lang })}</span>}
                    {'is_published' in row && <span className={`badge ${row.is_published ? 'success' : 'neutral'}`}>{row.is_published ? t('admin.f.published') : t('admin.f.hidden')}</span>}
                    {type === 'institutions' && (row.links_verified_at ? <span className="badge success plain"><ShieldCheck size={11} /> {t('admin.content.verified')}</span> : <span className="badge warning plain">{t('admin.content.notVerified')}</span>)}
                    {type === 'deadlines' && Boolean(row.last_reminder_at) && <span className="badge plain info">{t('admin.content.lastReminder')}: {fmtDate(row.last_reminder_at as string, lang)}</span>}
                  </div>
                </div>
                <div className="row" style={{ gap: 2, flexWrap: 'nowrap' }}>
                  {type === 'institutions' && (
                    <button className="icon-btn" title={t('admin.content.verifyLinks')} aria-label={t('admin.content.verifyLinks')} onClick={() => void verifyLinks(row)}>
                      <ShieldCheck />
                    </button>
                  )}
                  {type === 'deadlines' && (
                    <button className="icon-btn" title={t('admin.content.sendReminder')} aria-label={t('admin.content.sendReminder')} onClick={() => void remind(row)}>
                      <BellRing />
                    </button>
                  )}
                  {'is_published' in row && (
                    <button className="icon-btn" title={row.is_published ? t('admin.f.hide') : t('admin.f.publish')} aria-label={row.is_published ? t('admin.f.hide') : t('admin.f.publish')} onClick={() => void togglePublish(row)}>
                      {row.is_published ? <EyeOff /> : <Eye />}
                    </button>
                  )}
                  <button className="icon-btn" aria-label={t('common.edit')} onClick={() => { setErrors({}); setEditing({ ...row }); }}>
                    <Pencil />
                  </button>
                  <button className="icon-btn" aria-label={t('common.delete')} onClick={() => void remove(row)} style={{ color: 'var(--c-danger)' }}>
                    <Trash2 />
                  </button>
                </div>
              </div>
            ))}
            <Pagination page={data.page} perPage={data.per_page} total={data.total} onPage={setPage} />
          </>
        )}
      </div>
      <Modal
        open={!!editing}
        onClose={() => setEditing(null)}
        title={editing?.id ? t('common.edit') : t('common.add')}
        wide
        footer={
          <>
            <Button variant="secondary" onClick={() => setEditing(null)}>
              {t('common.cancel')}
            </Button>
            <Button loading={busy} onClick={() => void save()}>
              {t('common.save')}
            </Button>
          </>
        }
      >
        <div className="form-grid">{def.fields.map(fieldControl)}</div>
      </Modal>
    </>
  );
}
