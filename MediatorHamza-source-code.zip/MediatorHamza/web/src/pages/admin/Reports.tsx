import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { FileDown, FileSpreadsheet, FileText, Phone } from 'lucide-react';
import { useI18n } from '@/i18n';
import { useSite } from '@/context/SiteContext';
import { api, query } from '@/lib/api';
import { fmtMoney } from '@/lib/format';
import { Alert, Card, Checkbox, PageHead, SelectField, TextField, useAsync, useDocumentTitle } from '@/components/ui';
import { STATUSES, PAYMENTS } from './Applications';

interface Col {
  key: string;
  label: string;
}

export default function ReportsPage() {
  const { t, pick } = useI18n();
  const { services } = useSite();
  const [params] = useSearchParams();
  const [f, setF] = useState({ service: params.get('service') ?? '', status: params.get('status') ?? '', payment_status: '', from: params.get('from') ?? '', to: params.get('to') ?? '' });
  const { data: cols } = useAsync(() => api.get<{ base: Col[]; form: Col[] }>(`/admin/reports/columns${query({ service: f.service })}`), [f.service]);
  const [selected, setSelected] = useState<string[]>(['reference', 'service', 'applicant_name', 'applicant_phone', 'status', 'payment_status', 'price', 'submitted_at']);
  const { data: summary } = useAsync(() => api.get<{ code: string; name_sw: string; status: string; n: number; value: number; paid_value: number }[]>(`/admin/reports/summary${query(f)}`), [JSON.stringify(f)]);
  useDocumentTitle(t('admin.nav.reports'));
  useEffect(() => setSelected((s) => s.filter((k) => !k.startsWith('f:'))), [f.service]);

  const toggle = (k: string) => setSelected((s) => (s.includes(k) ? s.filter((x) => x !== k) : [...s, k]));
  const href = (format: string) => `/api/admin/reports/applications${query({ ...f, format, columns: selected.join(',') })}`;
  const phonesHref = (format: string) => `/api/admin/reports/phones${query({ service: f.service, status: f.status, format })}`;
  const totals = (summary ?? []).reduce((a, r) => ({ n: a.n + Number(r.n), value: a.value + Number(r.value), paid: a.paid + Number(r.paid_value) }), { n: 0, value: 0, paid: 0 });

  return (
    <>
      <PageHead title={t('admin.nav.reports')} subtitle={t('admin.reports.subtitle')} />
      <div className="grid grid-2" style={{ alignItems: 'start' }}>
        <div className="stack">
          <Card title={t('admin.reports.filters')}>
            <div className="form-grid">
              <SelectField label={t('common.service')} value={f.service} onChange={(e) => setF({ ...f, service: e.target.value })}>
                <option value="">{t('admin.apps.allServices')}</option>
                {services.map((s) => (
                  <option key={s.code} value={s.code}>
                    {pick(s.name_sw, s.name_en)}
                  </option>
                ))}
              </SelectField>
              <SelectField label={t('common.status')} value={f.status} onChange={(e) => setF({ ...f, status: e.target.value })}>
                <option value="">{t('admin.apps.allStatuses')}</option>
                {STATUSES.map((s) => (
                  <option key={s} value={s}>
                    {t(`status.${s}`)}
                  </option>
                ))}
              </SelectField>
              <SelectField label={t('payment.title')} value={f.payment_status} onChange={(e) => setF({ ...f, payment_status: e.target.value })}>
                <option value="">{t('admin.apps.allPayments')}</option>
                {PAYMENTS.map((s) => (
                  <option key={s} value={s}>
                    {t(`payment.${s}`)}
                  </option>
                ))}
              </SelectField>
              <div />
              <TextField type="date" label={t('admin.reports.from')} value={f.from} onChange={(e) => setF({ ...f, from: e.target.value })} />
              <TextField type="date" label={t('admin.reports.to')} value={f.to} onChange={(e) => setF({ ...f, to: e.target.value })} />
            </div>
          </Card>
          <Card title={t('admin.reports.columns')}>
            <div className="grid grid-2" style={{ gap: 6 }}>
              {cols?.base.map((c) => (
                <Checkbox key={c.key} checked={selected.includes(c.key)} onChange={() => toggle(c.key)}>
                  {c.label}
                </Checkbox>
              ))}
            </div>
            {!!cols?.form.length && (
              <>
                <hr className="divider" />
                <div className="small" style={{ fontWeight: 600, marginBottom: 6 }}>
                  {t('admin.reports.formColumns')}
                </div>
                <div className="grid grid-2" style={{ gap: 6, maxHeight: 280, overflow: 'auto' }}>
                  {cols.form.map((c) => (
                    <Checkbox key={c.key} checked={selected.includes(c.key)} onChange={() => toggle(c.key)}>
                      <span className="small">{c.label}</span>
                    </Checkbox>
                  ))}
                </div>
              </>
            )}
            {!f.service && <p className="xs muted mt-2 mb-0">{t('admin.reports.pickService')}</p>}
            <p className="xs muted mt-2 mb-0">{t('admin.reports.sensitiveNote')}</p>
          </Card>
        </div>
        <div className="stack">
          <Card title={t('admin.reports.export')}>
            <div className="row">
              <a className="btn btn-primary" href={href('xlsx')}>
                <FileSpreadsheet /> Excel (XLSX)
              </a>
              <a className="btn btn-secondary" href={href('pdf')}>
                <FileText /> PDF
              </a>
              <a className="btn btn-secondary" href={href('csv')}>
                <FileDown /> CSV
              </a>
            </div>
          </Card>
          <Card title={t('admin.reports.phones')}>
            <p className="small muted">{t('admin.reports.phonesHelp')}</p>
            <div className="row">
              <a className="btn btn-secondary" href={phonesHref('xlsx')}>
                <Phone /> Excel
              </a>
              <a className="btn btn-secondary" href={phonesHref('pdf')}>
                PDF
              </a>
              <a className="btn btn-secondary" href={phonesHref('csv')}>
                CSV
              </a>
            </div>
          </Card>
          <Card title={t('admin.reports.summary')}>
            {summary && summary.length > 0 ? (
              <>
                <div className="table-wrap">
                  <table className="table">
                    <thead>
                      <tr>
                        <th>{t('common.service')}</th>
                        <th>{t('common.status')}</th>
                        <th>#</th>
                        <th>{t('common.price')}</th>
                      </tr>
                    </thead>
                    <tbody>
                      {summary.map((r, i) => (
                        <tr key={i}>
                          <td>{r.code}</td>
                          <td>{t(`status.${r.status}` as 'status.received')}</td>
                          <td>{r.n}</td>
                          <td>{fmtMoney(Number(r.value))}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <Alert kind="info">
                  {t('admin.reports.totals', { n: totals.n, value: fmtMoney(totals.value), paid: fmtMoney(totals.paid) })}
                </Alert>
              </>
            ) : (
              <p className="small muted mb-0">{t('admin.apps.empty')}</p>
            )}
          </Card>
        </div>
      </div>
    </>
  );
}
