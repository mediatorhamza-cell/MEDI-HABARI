import { useState } from 'react';
import { Pencil, Plus, Trash2 } from 'lucide-react';
import { useI18n } from '@/i18n';
import { useSite } from '@/context/SiteContext';
import { useToast } from '@/context/ToastContext';
import { api, ApiError } from '@/lib/api';
import { fmtMoney } from '@/lib/format';
import { Alert, Button, Checkbox, ErrorState, Loading, Modal, PageHead, ServiceIcon, TextField, TextareaField, useAsync, useConfirm, useDocumentTitle, useErrorText } from '@/components/ui';

interface AdminService {
  id: number;
  code: string;
  icon: string;
  name_sw: string;
  name_en: string | null;
  summary_sw: string | null;
  summary_en: string | null;
  details_sw: string | null;
  details_en: string | null;
  requirements_sw: string | null;
  requirements_en: string | null;
  price: number | null;
  price_note_sw: string | null;
  price_note_en: string | null;
  is_active: number;
  accepting: number;
  sort_order: number;
  packages: { id: number; name_sw: string; name_en: string | null; price: number; is_active: number; sort_order: number }[];
}

const TEXT_KEYS = ['name_sw', 'name_en', 'summary_sw', 'summary_en', 'details_sw', 'details_en', 'requirements_sw', 'requirements_en', 'price_note_sw', 'price_note_en'] as const;

export default function ServicesAdminPage() {
  const { t, tv, pick } = useI18n();
  const { reload: reloadSite } = useSite();
  const { toast } = useToast();
  const errText = useErrorText();
  const { confirm, dialog } = useConfirm();
  const { data, loading, error, reload } = useAsync(() => api.get<AdminService[]>('/admin/services'));
  const [edit, setEdit] = useState<AdminService | null>(null);
  const [pkg, setPkg] = useState<{ serviceId: number; id?: number; name_sw: string; name_en: string; price: string; is_active: boolean } | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  useDocumentTitle(t('admin.nav.services'));

  const after = () => {
    toast(t('common.saved'));
    void reload();
    reloadSite();
  };

  const save = async () => {
    if (!edit) return;
    setBusy(true);
    setErrors({});
    const body: Record<string, unknown> = { price: edit.price, icon: edit.icon, is_active: !!edit.is_active, accepting: !!edit.accepting, sort_order: edit.sort_order };
    TEXT_KEYS.forEach((k) => (body[k] = edit[k] ?? ''));
    try {
      await api.put(`/admin/services/${edit.id}`, body);
      setEdit(null);
      after();
    } catch (e) {
      if (e instanceof ApiError && e.status === 422) setErrors(e.fields);
      toast(errText(e), 'error');
    } finally {
      setBusy(false);
    }
  };
  const savePkg = async () => {
    if (!pkg) return;
    setBusy(true);
    try {
      await api.post(`/admin/services/${pkg.serviceId}/packages`, { id: pkg.id, name_sw: pkg.name_sw, name_en: pkg.name_en, price: pkg.price || 0, is_active: pkg.is_active });
      setPkg(null);
      after();
    } catch (e) {
      toast(errText(e), 'error');
    } finally {
      setBusy(false);
    }
  };
  const quickToggle = async (s: AdminService, key: 'accepting' | 'is_active') => {
    await api.put(`/admin/services/${s.id}`, { [key]: !s[key] }).catch((e) => toast(errText(e), 'error'));
    after();
  };

  if (loading && !data) return <Loading />;
  if (error || !data) return <ErrorState error={error} onRetry={reload} />;
  const field = (k: (typeof TEXT_KEYS)[number], label: string, area = false) =>
    area ? (
      <TextareaField key={k} label={label} wrapClass="full" rows={4} value={edit?.[k] ?? ''} onChange={(e) => setEdit((x) => x && { ...x, [k]: e.target.value })} error={errors[k] && tv(errors[k])} />
    ) : (
      <TextField key={k} label={label} value={edit?.[k] ?? ''} onChange={(e) => setEdit((x) => x && { ...x, [k]: e.target.value })} error={errors[k] && tv(errors[k])} />
    );

  return (
    <>
      {dialog}
      <PageHead title={t('admin.nav.services')} subtitle={t('admin.services.subtitle')} />
      <Alert kind="info">{t('admin.services.priceNote')}</Alert>
      <div className="grid grid-2 mt-4">
        {data.map((s) => (
          <div key={s.id} className="card stack sm">
            <div className="row between" style={{ flexWrap: 'nowrap' }}>
              <div className="row" style={{ flexWrap: 'nowrap' }}>
                <ServiceIcon name={s.icon} />
                <div>
                  <strong>{pick(s.name_sw, s.name_en)}</strong>
                  <div className="xs muted mono">{s.code}</div>
                </div>
              </div>
              <Button size="sm" variant="secondary" icon={Pencil} onClick={() => { setErrors({}); setEdit({ ...s }); }}>
                {t('common.edit')}
              </Button>
            </div>
            <div style={{ fontSize: '1.3rem', fontWeight: 800, color: 'var(--c-navy)' }}>{s.price !== null ? fmtMoney(s.price) : <span className="muted small">{t('common.priceTba')}</span>}</div>
            <div className="row">
              <Checkbox checked={!!s.accepting} onChange={() => void quickToggle(s, 'accepting')}>
                {t('admin.services.accepting')}
              </Checkbox>
              <Checkbox checked={!!s.is_active} onChange={() => void quickToggle(s, 'is_active')}>
                {t('admin.services.visible')}
              </Checkbox>
            </div>
            <div>
              <div className="row between">
                <strong className="small">{t('services.packages')}</strong>
                <Button size="sm" variant="ghost" icon={Plus} onClick={() => setPkg({ serviceId: s.id, name_sw: '', name_en: '', price: '', is_active: true })}>
                  {t('common.add')}
                </Button>
              </div>
              {s.packages.length === 0 && <p className="xs muted mb-0">{t('admin.services.noPackages')}</p>}
              {s.packages.map((p) => (
                <div key={p.id} className="row between small" style={{ opacity: p.is_active ? 1 : 0.5 }}>
                  <span>{pick(p.name_sw, p.name_en)}</span>
                  <span className="row" style={{ gap: 4 }}>
                    <strong>{fmtMoney(p.price)}</strong>
                    <button className="icon-btn" aria-label={t('common.edit')} onClick={() => setPkg({ serviceId: s.id, id: p.id, name_sw: p.name_sw, name_en: p.name_en ?? '', price: String(p.price), is_active: !!p.is_active })}>
                      <Pencil size={16} />
                    </button>
                    <button
                      className="icon-btn"
                      aria-label={t('common.delete')}
                      onClick={async () => {
                        if (await confirm({ title: t('common.delete'), text: p.name_sw, danger: true })) {
                          await api.del(`/admin/services/${s.id}/packages/${p.id}`);
                          after();
                        }
                      }}
                    >
                      <Trash2 size={16} />
                    </button>
                  </span>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      <Modal open={!!edit} onClose={() => setEdit(null)} title={edit ? pick(edit.name_sw, edit.name_en) : ''} wide footer={<Button loading={busy} onClick={() => void save()}>{t('common.save')}</Button>}>
        {edit && (
          <div className="form-grid">
            <TextField label={`${t('common.price')} (TZS)`} inputMode="numeric" help={t('admin.services.priceHelp')} value={edit.price === null ? '' : String(edit.price)} onChange={(e) => setEdit({ ...edit, price: e.target.value === '' ? null : Number(e.target.value.replace(/\D/g, '')) })} error={errors.price && tv(errors.price)} />
            <TextField label={t('admin.f.sort')} inputMode="numeric" value={String(edit.sort_order)} onChange={(e) => setEdit({ ...edit, sort_order: Number(e.target.value.replace(/\D/g, '') || 0) })} />
            {field('price_note_sw', `${t('admin.services.priceNoteLabel')} (SW)`)}
            {field('price_note_en', `${t('admin.services.priceNoteLabel')} (EN)`)}
            {field('name_sw', `${t('admin.f.name')} (SW)`)}
            {field('name_en', `${t('admin.f.name')} (EN)`)}
            {field('summary_sw', `${t('admin.f.summary')} (SW)`, true)}
            {field('summary_en', `${t('admin.f.summary')} (EN)`, true)}
            {field('details_sw', `${t('admin.f.body')} (SW)`, true)}
            {field('details_en', `${t('admin.f.body')} (EN)`, true)}
            {field('requirements_sw', `${t('services.requirements')} (SW)`, true)}
            {field('requirements_en', `${t('services.requirements')} (EN)`, true)}
          </div>
        )}
      </Modal>

      <Modal open={!!pkg} onClose={() => setPkg(null)} title={t('services.packages')} footer={<Button loading={busy} onClick={() => void savePkg()}>{t('common.save')}</Button>}>
        {pkg && (
          <div className="stack">
            <TextField label={`${t('admin.f.name')} (SW)`} value={pkg.name_sw} onChange={(e) => setPkg({ ...pkg, name_sw: e.target.value })} />
            <TextField label={`${t('admin.f.name')} (EN)`} optional value={pkg.name_en} onChange={(e) => setPkg({ ...pkg, name_en: e.target.value })} />
            <TextField label={`${t('common.price')} (TZS)`} inputMode="numeric" value={pkg.price} onChange={(e) => setPkg({ ...pkg, price: e.target.value.replace(/\D/g, '') })} />
            <Checkbox checked={pkg.is_active} onChange={(v) => setPkg({ ...pkg, is_active: v })}>
              {t('admin.services.visible')}
            </Checkbox>
          </div>
        )}
      </Modal>
    </>
  );
}
