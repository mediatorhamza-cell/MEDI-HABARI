import { useMemo, useRef, useState } from 'react';
import { Link, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { Download, FileDown, FileText, Lock, MessageCircle, Phone, Printer, Send, StickyNote, Trash2, Upload, User as UserIcon, Wallet } from 'lucide-react';
import { useI18n } from '@/i18n';
import { useAuth } from '@/context/AuthContext';
import { useSite } from '@/context/SiteContext';
import { useToast } from '@/context/ToastContext';
import { api, ApiError, fileUrl, query, uploadFile } from '@/lib/api';
import { fmtDateTime, fmtMoney, fmtPhone, waLink } from '@/lib/format';
import { visibleFields, visibleSteps } from '@/lib/forms';
import type { AppDetail, AppStatus, AppSummary, FormSchemaDef, Option, Paged, PaymentStatus } from '@/lib/types';
import {
  Alert,
  Button,
  Card,
  Checkbox,
  EmptyState,
  ErrorState,
  Loading,
  Modal,
  PageHead,
  Pagination,
  PaymentBadge,
  SelectField,
  StatusBadge,
  TextField,
  TextareaField,
  useAsync,
  useConfirm,
  useDocumentTitle,
  useErrorText,
} from '@/components/ui';
import { displayValue } from '@/components/form/Fields';
import { Timeline } from '@/components/Timeline';

export const STATUSES: AppStatus[] = ['received', 'in_progress', 'awaiting_info', 'correction_required', 'completed', 'on_hold', 'closed', 'cancelled'];
export const PAYMENTS: PaymentStatus[] = ['unpaid', 'stationery_paid', 'partial', 'paid', 'waived'];

export function AdminApplicationsPage() {
  const { t, pick, lang } = useI18n();
  const { services } = useSite();
  const navigate = useNavigate();
  const [params, setParams] = useSearchParams();
  const f = {
    q: params.get('q') ?? '',
    status: params.get('status') ?? '',
    service: params.get('service') ?? '',
    payment_status: params.get('payment_status') ?? '',
    from: params.get('from') ?? '',
    to: params.get('to') ?? '',
    page: Number(params.get('page') ?? 1),
  };
  const [q, setQ] = useState(f.q);
  const { data, loading, error, reload } = useAsync(() => api.get<Paged<AppSummary>>(`/admin/applications${query(f)}`), [params.toString()]);
  useDocumentTitle(t('admin.nav.applications'));
  const set = (k: string, v: string) => {
    const n = new URLSearchParams(params);
    if (v) n.set(k, v);
    else n.delete(k);
    if (k !== 'page') n.delete('page');
    setParams(n);
  };

  return (
    <>
      <PageHead
        title={t('admin.nav.applications')}
        subtitle={data ? t('common.results', { count: data.total }) : undefined}
        actions={
          <Link className="btn btn-secondary" to={`/admin/ripoti${query({ status: f.status, service: f.service, from: f.from, to: f.to })}`}>
            <FileDown /> {t('admin.reports.export')}
          </Link>
        }
      />
      <form
        className="toolbar"
        onSubmit={(e) => {
          e.preventDefault();
          set('q', q.trim());
        }}
      >
        <input className="input search-input" value={q} onChange={(e) => setQ(e.target.value)} placeholder={t('admin.apps.searchPlaceholder')} aria-label={t('common.search')} />
        <select className="select" value={f.service} onChange={(e) => set('service', e.target.value)} aria-label={t('common.service')}>
          <option value="">{t('admin.apps.allServices')}</option>
          {services.map((s) => (
            <option key={s.code} value={s.code}>
              {pick(s.name_sw, s.name_en)}
            </option>
          ))}
        </select>
        <select className="select" value={f.status} onChange={(e) => set('status', e.target.value)} aria-label={t('common.status')}>
          <option value="">{t('admin.apps.allStatuses')}</option>
          {STATUSES.map((s) => (
            <option key={s} value={s}>
              {t(`status.${s}`)}
            </option>
          ))}
        </select>
        <select className="select" value={f.payment_status} onChange={(e) => set('payment_status', e.target.value)} aria-label={t('payment.title')}>
          <option value="">{t('admin.apps.allPayments')}</option>
          {PAYMENTS.map((s) => (
            <option key={s} value={s}>
              {t(`payment.${s}`)}
            </option>
          ))}
        </select>
        <input className="input" type="date" value={f.from} onChange={(e) => set('from', e.target.value)} aria-label={t('admin.reports.from')} style={{ flex: '0 1 160px' }} />
        <input className="input" type="date" value={f.to} onChange={(e) => set('to', e.target.value)} aria-label={t('admin.reports.to')} style={{ flex: '0 1 160px' }} />
        <Button type="submit" variant="navy">
          {t('common.search')}
        </Button>
      </form>
      <div className="card flush">
        {loading && !data ? (
          <Loading />
        ) : error ? (
          <ErrorState error={error} onRetry={reload} />
        ) : !data?.items.length ? (
          <EmptyState icon={FileText} title={t('admin.apps.empty')} />
        ) : (
          <>
            <div className="table-wrap">
              <table className="table responsive">
                <thead>
                  <tr>
                    <th>{t('common.reference')}</th>
                    <th>{t('admin.apps.applicant')}</th>
                    <th>{t('common.service')}</th>
                    <th>{t('common.status')}</th>
                    <th>{t('payment.title')}</th>
                    <th>{t('apps.submittedOn')}</th>
                  </tr>
                </thead>
                <tbody>
                  {data.items.map((a) => (
                    <tr key={a.id} className={`clickable ${a.is_new ? 'row-new' : ''}`} onClick={() => navigate(`/admin/maombi/${a.id}`)}>
                      <td data-label={t('common.reference')}>
                        <Link to={`/admin/maombi/${a.id}`} className="mono" onClick={(e) => e.stopPropagation()}>
                          {a.reference}
                        </Link>
                        {a.is_new && <span className="badge-new">{t('common.new')}</span>}
                      </td>
                      <td data-label={t('admin.apps.applicant')}>
                        <div style={{ fontWeight: 600 }}>{a.applicant_name ?? a.user_name}</div>
                        <div className="xs muted">{fmtPhone(a.applicant_phone ?? a.user_phone)}</div>
                      </td>
                      <td data-label={t('common.service')}>{a.service_code}</td>
                      <td data-label={t('common.status')}>
                        <StatusBadge status={a.status} />
                      </td>
                      <td data-label={t('payment.title')}>
                        <PaymentBadge status={a.payment_status} />
                      </td>
                      <td data-label={t('apps.submittedOn')} className="nowrap">
                        {fmtDateTime(a.submitted_at, lang)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <Pagination page={data.page} perPage={data.per_page} total={data.total} onPage={(p) => set('page', String(p))} />
          </>
        )}
      </div>
    </>
  );
}

// ------------------------------------------------------------------ detail

interface AdminAppDetail extends AppDetail {
  sensitive_hidden: string[];
  payments: { id: number; status: PaymentStatus; amount: number | null; method: string | null; transaction_ref: string | null; note: string | null; recorded_by_name: string | null; created_at: string }[];
  changes: { fields: string[]; reason: string; created_at: string }[];
  user: { id: number; first_name: string; second_name: string; last_name: string | null; phone: string; email: string | null; status: string; created_at: string };
  conversations: { id: number; subject: string; status: string }[];
}

export function AdminApplicationDetailPage() {
  const { id } = useParams();
  const { t, pick, tv, lang } = useI18n();
  const { can } = useAuth();
  const { toast } = useToast();
  const errText = useErrorText();
  const { confirm, dialog } = useConfirm();
  const { data, loading, error, reload } = useAsync(async () => {
    const app = await api.get<AdminAppDetail>(`/admin/applications/${id}`);
    const form = await api.get<{ schema: FormSchemaDef; options: { banks: Option[]; heslb_levels: Option[] } }>(`/form-schemas/${app.form_key}`);
    return { app, ...form };
  }, [id]);
  useDocumentTitle(data?.app.reference ?? t('admin.nav.applications'));

  const [statusForm, setStatusForm] = useState({ status: '' as AppStatus | '', public_message: '', internal_note: '', next_action: '', editable_fields: [] as string[] });
  const [payForm, setPayForm] = useState({ payment_status: '' as PaymentStatus | '', amount: '', method: '', transaction_ref: '', note: '' });
  const [resultForm, setResultForm] = useState({ title: '', body: '' });
  const [note, setNote] = useState('');
  const [msg, setMsg] = useState('');
  const [modal, setModal] = useState<'status' | 'payment' | 'result' | 'note' | 'message' | null>(null);
  const [busy, setBusy] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const fileInput = useRef<HTMLInputElement>(null);

  const allFields = useMemo(() => {
    if (!data) return [];
    return data.schema.steps.flatMap((s) => s.fields.filter((f) => f.type !== 'heading').map((f) => ({ key: f.key, label: `${pick(s.title.sw, s.title.en)} › ${pick(f.label.sw, f.label.en)}` })));
  }, [data, pick]);

  if (loading && !data) return <Loading />;
  if (error || !data) return <ErrorState error={error} onRetry={reload} />;
  const { app, schema, options } = data;
  const files = Object.fromEntries(app.files.map((f) => [f.id, f]));
  const yesNo = (v: string) => (v === 'yes' ? t('common.yes') : v === 'no' ? t('common.no') : v);

  const run = async (fn: () => Promise<unknown>, success: string) => {
    setBusy(true);
    setErrors({});
    try {
      await fn();
      toast(success);
      setModal(null);
      await reload();
      return true;
    } catch (e) {
      if (e instanceof ApiError && e.status === 422) setErrors(e.fields);
      toast(errText(e), 'error');
      return false;
    } finally {
      setBusy(false);
    }
  };

  const openStatus = (s?: AppStatus) => {
    setStatusForm({ status: s ?? app.status, public_message: '', internal_note: '', next_action: app.next_action ?? '', editable_fields: [] });
    setErrors({});
    setModal('status');
  };

  const uploadResult = async (file: File | undefined) => {
    if (!file) return;
    const form = new FormData();
    form.append('file', file);
    setBusy(true);
    try {
      await uploadFile(`/admin/applications/${app.id}/result-files`, form);
      toast(t('admin.app.fileUploaded'));
      await reload();
    } catch (e) {
      toast(e instanceof ApiError && e.fields.file ? tv(e.fields.file) : errText(e), 'error');
    } finally {
      setBusy(false);
      if (fileInput.current) fileInput.current.value = '';
    }
  };

  return (
    <>
      {dialog}
      <PageHead
        title={app.reference ?? t('status.draft')}
        subtitle={`${pick(app.service_name_sw, app.service_name_en)} · ${app.applicant_name ?? ''}`}
        crumbs={[{ to: '/admin/maombi', label: t('admin.nav.applications') }, { label: app.reference ?? `#${app.id}` }]}
        actions={
          <>
            <Button variant="secondary" icon={Printer} onClick={() => window.print()} className="no-print">
              {t('common.print')}
            </Button>
            {can('applications.update') && app.status !== 'draft' && (
              <Button icon={Send} onClick={() => openStatus()} className="no-print">
                {t('admin.app.changeStatus')}
              </Button>
            )}
          </>
        }
      />

      {app.status === 'draft' && (
        <div className="mb-4">
          <Alert kind="warning" title={t('admin.drafts.bannerTitle')}>
            {t('admin.drafts.bannerText', { pct: app.progress?.percent ?? 0 })}
            {app.progress?.stopped_at && (
              <>
                {' '}
                {t('admin.drafts.stoppedAt')}: <strong>{pick(app.progress.stopped_at.sw, app.progress.stopped_at.en)}</strong>
              </>
            )}
          </Alert>
        </div>
      )}
      <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(min(100%, 380px), 1fr))', alignItems: 'start' }}>
        <div className="stack">
          <Card>
            <dl className="kv">
              <dt>{t('common.status')}</dt>
              <dd>
                <StatusBadge status={app.status} />
              </dd>
              <dt>{t('payment.title')}</dt>
              <dd>
                <PaymentBadge status={app.payment_status} /> {app.price !== null && <span className="small">({fmtMoney(app.price)}{app.package_name ? ` · ${app.package_name}` : ''})</span>}
              </dd>
              <dt>{t('apps.submittedOn')}</dt>
              <dd>{fmtDateTime(app.submitted_at, lang)}</dd>
              <dt>{t('apps.lastUpdate')}</dt>
              <dd>{fmtDateTime(app.updated_at, lang)}</dd>
              {app.next_action && (
                <>
                  <dt>{t('apps.nextAction')}</dt>
                  <dd>{app.next_action}</dd>
                </>
              )}
            </dl>
            {app.status === 'correction_required' && app.correction_message && (
              <div className="mt-4">
                <Alert kind="warning" title={t('status.correction_required')}>
                  <div className="pre">{app.correction_message}</div>
                  <div className="xs mt-2">{(app.editable_fields ?? []).map((k) => allFields.find((f) => f.key === k)?.label ?? k).join(', ')}</div>
                </Alert>
              </div>
            )}
            <div className="row mt-4 no-print">
              {can('payments.update') && (
                <Button variant="secondary" size="sm" icon={Wallet} onClick={() => { setPayForm({ payment_status: app.payment_status, amount: app.price ? String(app.price) : '', method: '', transaction_ref: '', note: '' }); setModal('payment'); }}>
                  {t('admin.app.recordPayment')}
                </Button>
              )}
              {can('applications.update') && (
                <Button variant="secondary" size="sm" icon={StickyNote} onClick={() => setModal('note')}>
                  {t('admin.app.addNote')}
                </Button>
              )}
              {can('messages.manage') && (
                <Button variant="secondary" size="sm" icon={MessageCircle} onClick={() => setModal('message')}>
                  {t('admin.app.messageApplicant')}
                </Button>
              )}
            </div>
          </Card>

          <Card title={t('admin.app.account')}>
            <div className="row between">
              <div className="row" style={{ flexWrap: 'nowrap' }}>
                <span className="icon-tile">
                  <UserIcon />
                </span>
                <div>
                  <Link to={`/admin/watumiaji/${app.user.id}`} style={{ fontWeight: 600 }}>
                    {app.user.first_name} {app.user.second_name} {app.user.last_name ?? ''}
                  </Link>
                  <div className="small muted">{fmtPhone(app.user.phone)}</div>
                </div>
              </div>
              <div className="row no-print">
                <a className="btn btn-secondary btn-sm" href={`tel:${app.user.phone}`}>
                  <Phone />
                </a>
                <a className="btn btn-success btn-sm" href={waLink(app.user.phone)} target="_blank" rel="noopener noreferrer">
                  WhatsApp
                </a>
              </div>
            </div>
            {app.conversations.length > 0 && (
              <div className="stack sm mt-4">
                {app.conversations.map((c) => (
                  <Link key={c.id} to={`/admin/ujumbe/${c.id}`} className="small">
                    <MessageCircle size={14} /> {c.subject}
                  </Link>
                ))}
              </div>
            )}
          </Card>

          {can('applications.results') && (
            <Card
              title={t('apps.results')}
              actions={
                <span className="row no-print">
                  <Button size="sm" variant="secondary" icon={Upload} loading={busy} onClick={() => fileInput.current?.click()}>
                    {t('admin.app.uploadDoc')}
                  </Button>
                  <Button size="sm" onClick={() => setModal('result')}>
                    {t('admin.app.addResult')}
                  </Button>
                </span>
              }
            >
              <input ref={fileInput} type="file" hidden accept="image/*,application/pdf" onChange={(e) => void uploadResult(e.target.files?.[0])} />
              {app.results.length === 0 && app.result_files.length === 0 && <p className="small muted mb-0">{t('admin.app.noResults')}</p>}
              <div className="stack sm">
                {app.results.map((r) => (
                  <div key={r.id} className="card" style={{ padding: 14, background: 'var(--c-surface-2)' }}>
                    <div className="row between">
                      <strong className="small">{r.title}</strong>
                      <button
                        className="icon-btn no-print"
                        aria-label={t('common.delete')}
                        onClick={async () => (await confirm({ title: t('common.delete'), danger: true })) && run(() => api.del(`/admin/applications/${app.id}/results/${r.id}`), t('common.saved'))}
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                    <div className="pre small break">{r.body}</div>
                    <div className="xs muted">{fmtDateTime(r.created_at, lang)}</div>
                  </div>
                ))}
                {app.result_files.map((f) => (
                  <div key={f.id} className="file-item">
                    <span className="thumb">
                      <Download />
                    </span>
                    <a className="grow break" href={fileUrl(app.id, f.id, true, true)} target="_blank" rel="noopener noreferrer">
                      {f.name}
                    </a>
                    <button
                      className="icon-btn no-print"
                      aria-label={t('common.delete')}
                      onClick={async () => (await confirm({ title: t('common.delete'), danger: true })) && run(() => api.del(`/admin/applications/${app.id}/result-files/${f.id}`), t('common.saved'))}
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                ))}
              </div>
            </Card>
          )}

          <Card title={t('apps.timeline')}>
            <Timeline items={app.timeline} staff />
          </Card>

          {app.payments.length > 0 && (
            <Card title={t('admin.app.paymentHistory')}>
              <div className="stack sm">
                {app.payments.map((p) => (
                  <div key={p.id} className="small">
                    <PaymentBadge status={p.status} /> {p.amount !== null && fmtMoney(p.amount)} {p.method && `· ${p.method}`} {p.transaction_ref && <span className="mono">· {p.transaction_ref}</span>}
                    <div className="xs muted">
                      {fmtDateTime(p.created_at, lang)} · {p.recorded_by_name} {p.note && `· ${p.note}`}
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          )}
          {app.changes.length > 0 && (
            <Card title={t('admin.app.changes')}>
              {app.changes.map((c, i) => (
                <div key={i} className="small">
                  {fmtDateTime(c.created_at, lang)} — {c.fields.map((k) => allFields.find((f) => f.key === k)?.label.split(' › ')[1] ?? k).join(', ') || '—'}
                </div>
              ))}
            </Card>
          )}
        </div>

        <div className="stack">
          {app.sensitive_hidden.length > 0 && <Alert kind="info">{t('admin.app.sensitiveHidden')}</Alert>}
          {visibleSteps(schema, app.data).map((s) => {
            const fields = visibleFields(s, app.data).filter((f) => f.type !== 'heading');
            return (
              <div key={s.key} className="review-section" style={{ background: '#fff' }}>
                <div className="review-section-head">
                  <h4>{pick(s.title.sw, s.title.en)}</h4>
                </div>
                <dl className="kv">
                  {fields.map((f) => (
                    <div key={f.key} style={{ display: 'contents' }}>
                      <dt>
                        {pick(f.label.sw, f.label.en)} {f.sensitive && <Lock size={11} color="var(--c-violet)" />}
                      </dt>
                      <dd className="pre">
                        {f.type === 'file' ? (
                          <span className="stack sm">
                            {((app.data[f.key] as number[] | undefined) ?? []).map((fid) => (
                              <a key={fid} href={fileUrl(app.id, fid, true, true)} target="_blank" rel="noopener noreferrer" className="row" style={{ gap: 6 }}>
                                {files[fid]?.mime.startsWith('image/') ? (
                                  <img src={fileUrl(app.id, fid, true, true)} alt="" style={{ width: 56, height: 56, objectFit: 'cover', borderRadius: 8 }} />
                                ) : (
                                  <FileText size={16} />
                                )}
                                <span className="break">{files[fid]?.name ?? `#${fid}`}</span>
                              </a>
                            ))}
                          </span>
                        ) : app.sensitive_hidden.includes(f.key) ? (
                          <span className="muted">••••••</span>
                        ) : (
                          displayValue(f, app.data[f.key], options, files, pick, yesNo) || <span className="muted">—</span>
                        )}
                      </dd>
                    </div>
                  ))}
                </dl>
              </div>
            );
          })}
        </div>
      </div>

      {/* ---------------- modals ---------------- */}
      <Modal
        open={modal === 'status'}
        onClose={() => setModal(null)}
        title={t('admin.app.changeStatus')}
        wide
        footer={
          <>
            <Button variant="secondary" onClick={() => setModal(null)}>
              {t('common.cancel')}
            </Button>
            <Button loading={busy} onClick={() => void run(() => api.post(`/admin/applications/${app.id}/status`, statusForm), t('admin.app.statusUpdated'))}>
              {t('common.save')}
            </Button>
          </>
        }
      >
        <div className="stack">
          <SelectField label={t('admin.app.newStatus')} value={statusForm.status} onChange={(e) => setStatusForm({ ...statusForm, status: e.target.value as AppStatus })} error={errors.status && tv(errors.status)}>
            {STATUSES.map((s) => (
              <option key={s} value={s}>
                {t(`status.${s}`)}
              </option>
            ))}
          </SelectField>
          <TextareaField
            label={t('admin.app.publicMessage')}
            help={t('admin.app.publicMessageHelp')}
            required={statusForm.status === 'correction_required'}
            value={statusForm.public_message}
            onChange={(e) => setStatusForm({ ...statusForm, public_message: e.target.value })}
            error={errors.public_message && tv(errors.public_message)}
          />
          {statusForm.status === 'correction_required' && (
            <div className="field">
              <span className="field-label">{t('admin.app.editableFields')}</span>
              {errors.editable_fields && <span className="field-error">{tv(errors.editable_fields)}</span>}
              <div className="card" style={{ maxHeight: 260, overflow: 'auto', padding: 12 }}>
                <Checkbox checked={statusForm.editable_fields.includes('*')} onChange={(v) => setStatusForm({ ...statusForm, editable_fields: v ? ['*'] : [] })}>
                  <strong>{t('apps.allFields')}</strong>
                </Checkbox>
                {!statusForm.editable_fields.includes('*') &&
                  allFields.map((f) => (
                    <Checkbox
                      key={f.key}
                      checked={statusForm.editable_fields.includes(f.key)}
                      onChange={(v) => setStatusForm({ ...statusForm, editable_fields: v ? [...statusForm.editable_fields, f.key] : statusForm.editable_fields.filter((x) => x !== f.key) })}
                    >
                      <span className="small">{f.label}</span>
                    </Checkbox>
                  ))}
              </div>
            </div>
          )}
          <TextField label={t('apps.nextAction')} optional value={statusForm.next_action} onChange={(e) => setStatusForm({ ...statusForm, next_action: e.target.value })} />
          <TextareaField label={t('admin.app.internalNote')} help={t('admin.app.internalNoteHelp')} optional value={statusForm.internal_note} onChange={(e) => setStatusForm({ ...statusForm, internal_note: e.target.value })} />
        </div>
      </Modal>

      <Modal
        open={modal === 'payment'}
        onClose={() => setModal(null)}
        title={t('admin.app.recordPayment')}
        footer={
          <Button loading={busy} onClick={() => void run(() => api.post(`/admin/applications/${app.id}/payment`, { ...payForm, amount: payForm.amount || null }), t('common.saved'))}>
            {t('common.save')}
          </Button>
        }
      >
        <div className="stack">
          <SelectField label={t('payment.title')} value={payForm.payment_status} onChange={(e) => setPayForm({ ...payForm, payment_status: e.target.value as PaymentStatus })}>
            {PAYMENTS.map((s) => (
              <option key={s} value={s}>
                {t(`payment.${s}`)}
              </option>
            ))}
          </SelectField>
          <div className="form-grid">
            <TextField label={t('admin.app.amount')} inputMode="numeric" optional value={payForm.amount} onChange={(e) => setPayForm({ ...payForm, amount: e.target.value.replace(/\D/g, '') })} />
            <TextField label={t('admin.app.method')} optional placeholder="M-Pesa / Tigo Pesa / Airtel Money" value={payForm.method} onChange={(e) => setPayForm({ ...payForm, method: e.target.value })} />
          </div>
          <TextField label={t('admin.app.transactionRef')} optional value={payForm.transaction_ref} onChange={(e) => setPayForm({ ...payForm, transaction_ref: e.target.value })} />
          <TextField label={t('admin.app.note')} optional value={payForm.note} onChange={(e) => setPayForm({ ...payForm, note: e.target.value })} />
        </div>
      </Modal>

      <Modal
        open={modal === 'result'}
        onClose={() => setModal(null)}
        title={t('admin.app.addResult')}
        footer={
          <Button loading={busy} onClick={() => void run(() => api.post(`/admin/applications/${app.id}/results`, resultForm), t('common.saved')).then((ok) => ok && setResultForm({ title: '', body: '' }))}>
            {t('common.save')}
          </Button>
        }
      >
        <div className="stack">
          <Alert kind="info">{t('admin.app.resultHelp')}</Alert>
          <TextField label={t('admin.app.resultTitle')} required value={resultForm.title} onChange={(e) => setResultForm({ ...resultForm, title: e.target.value })} error={errors.title && tv(errors.title)} placeholder={t('admin.app.resultTitlePlaceholder')} />
          <TextareaField label={t('admin.app.resultBody')} required rows={6} value={resultForm.body} onChange={(e) => setResultForm({ ...resultForm, body: e.target.value })} error={errors.body && tv(errors.body)} />
        </div>
      </Modal>

      <Modal
        open={modal === 'note'}
        onClose={() => setModal(null)}
        title={t('admin.app.addNote')}
        footer={
          <Button loading={busy} onClick={() => void run(() => api.post(`/admin/applications/${app.id}/notes`, { internal_note: note }), t('common.saved')).then((ok) => ok && setNote(''))}>
            {t('common.save')}
          </Button>
        }
      >
        <TextareaField label={t('admin.app.internalNote')} help={t('admin.app.internalNoteHelp')} value={note} onChange={(e) => setNote(e.target.value)} />
      </Modal>

      <Modal
        open={modal === 'message'}
        onClose={() => setModal(null)}
        title={t('admin.app.messageApplicant')}
        footer={
          <Button
            loading={busy}
            icon={Send}
            onClick={() => void run(() => api.post(`/admin/applications/${app.id}/message`, { body: msg }), t('common.saved')).then((ok) => ok && setMsg(''))}
          >
            {t('common.send')}
          </Button>
        }
      >
        <TextareaField label={t('common.message')} value={msg} onChange={(e) => setMsg(e.target.value)} />
      </Modal>
    </>
  );
}


// ------------------------------------------------------------------ incomplete (draft) applications

/** Applications users started but have not submitted yet — so staff can follow up. */
export function AdminDraftsPage() {
  const { t, pick, lang } = useI18n();
  const [page, setPage] = useState(1);
  const { data, loading, error, reload } = useAsync(() => api.get<Paged<AppSummary>>(`/admin/applications${query({ drafts: '1', sort: 'updated', page })}`), [page]);
  useDocumentTitle(t('admin.nav.drafts'));
  return (
    <>
      <PageHead title={t('admin.nav.drafts')} subtitle={t('admin.drafts.subtitle')} />
      <div className="card flush">
        {loading && !data ? (
          <Loading />
        ) : error ? (
          <ErrorState error={error} onRetry={reload} />
        ) : !data?.items.length ? (
          <EmptyState icon={FileText} title={t('admin.drafts.empty')} />
        ) : (
          <>
            <div className="table-wrap">
              <table className="table responsive">
                <thead>
                  <tr>
                    <th>{t('admin.apps.applicant')}</th>
                    <th>{t('common.service')}</th>
                    <th>{t('admin.drafts.progress')}</th>
                    <th>{t('admin.drafts.lastActivity')}</th>
                    <th>{t('admin.drafts.contact')}</th>
                  </tr>
                </thead>
                <tbody>
                  {data.items.map((a) => {
                    const phone = a.user_phone ?? a.applicant_phone;
                    return (
                      <tr key={a.id}>
                        <td data-label={t('admin.apps.applicant')}>
                          <Link to={`/admin/maombi/${a.id}`} style={{ fontWeight: 600 }}>
                            {a.applicant_name || a.user_name}
                          </Link>
                          <div className="xs muted">{fmtPhone(phone)}</div>
                        </td>
                        <td data-label={t('common.service')}>{pick(a.service_name_sw, a.service_name_en)}</td>
                        <td data-label={t('admin.drafts.progress')} style={{ minWidth: 170 }}>
                          <div className="progress" style={{ height: 8 }}>
                            <div style={{ width: `${a.progress?.percent ?? 0}%` }} />
                          </div>
                          <div className="xs muted mt-2">
                            {a.progress?.percent ?? 0}%
                            {a.progress?.stopped_at && ` · ${t('admin.drafts.stoppedAt')}: ${pick(a.progress.stopped_at.sw, a.progress.stopped_at.en)}`}
                          </div>
                        </td>
                        <td data-label={t('admin.drafts.lastActivity')} className="nowrap">
                          {fmtDateTime(a.updated_at, lang)}
                        </td>
                        <td data-label={t('admin.drafts.contact')}>
                          <div className="row" style={{ gap: 6, flexWrap: 'nowrap' }}>
                            <Link to={`/admin/maombi/${a.id}`} className="btn btn-secondary btn-sm">
                              {t('admin.drafts.preview')}
                            </Link>
                            {phone && (
                              <>
                                <a className="icon-btn" href={`tel:${phone}`} aria-label={t('form.call')} title={t('form.call')}>
                                  <Phone />
                                </a>
                                <a className="icon-btn" href={waLink(phone)} target="_blank" rel="noopener noreferrer" aria-label="WhatsApp" title="WhatsApp" style={{ color: '#16a34a' }}>
                                  <MessageCircle />
                                </a>
                              </>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            <Pagination page={data.page} perPage={data.per_page} total={data.total} onPage={setPage} />
          </>
        )}
      </div>
    </>
  );
}
