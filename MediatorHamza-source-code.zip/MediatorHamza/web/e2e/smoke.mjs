// Browser smoke test (Playwright). Requires both dev servers running:
//   php -S 127.0.0.1:8000 api/tests/dev-router.php   &&   (cd web && npm run dev)
// Run: node web/e2e/smoke.mjs [baseUrl] [screenshotDir]
// Optional env: ADMIN_PHONE / ADMIN_PASSWORD to also exercise the admin portal.
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
let pw;
try { pw = require('playwright'); } catch { pw = require('/opt/node22/lib/node_modules/playwright'); }

const BASE = process.argv[2] ?? 'http://127.0.0.1:5173';
const SHOTS = process.argv[3] ?? null;
const phone = '07' + String(Math.floor(10000000 + Math.random() * 89999999));
let failed = 0;
const check = (name, ok) => { console.log(`${ok ? '✓' : '✗'} ${name}`); if (!ok) failed++; };
const shot = async (page, name) => SHOTS && page.screenshot({ path: `${SHOTS}/${name}.png`, fullPage: false });

const browser = await pw.chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
// HTTPS=1 adds X-Forwarded-Proto so the production .htaccess does not redirect plain-HTTP test servers.
const extra = process.env.HTTPS ? { extraHTTPHeaders: { 'X-Forwarded-Proto': 'https' } } : {};
const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, ...extra });
const page = await ctx.newPage();
const errors = [];
page.on('pageerror', (e) => errors.push(e.message));
if (process.env.DEBUG) page.on('response', async (r) => r.url().includes('/api/') && console.log(r.status(), r.request().method(), r.url(), r.status() >= 400 ? (await r.text().catch(() => '')).slice(0, 300) : ''));

// Public site
await page.goto(BASE + '/');
await page.getByRole('heading', { level: 1 }).first().waitFor();
check('home hero renders in English by default', (await page.locator('.hero3 .btn').first().textContent()).includes('Get Started'));
await page.locator('.service-card').nth(6).waitFor();
check('seven service cards', (await page.locator('.service-card').count()) === 7);
await shot(page, '01-home-mobile');
// Language switch lives in the mobile menu
await page.locator('.menu-toggle').click();
await page.locator('.drawer').getByRole('button', { name: 'SW', exact: true }).click();
await page.locator('.drawer').getByRole('button', { name: 'Close' }).or(page.locator('.drawer').getByRole('button', { name: 'Funga' })).first().click();
check('language switch to Swahili', (await page.locator('.hero3 h1').textContent()).includes('Safari yako'));

// "Omba Huduma" while logged out -> login with preserved destination
await page.locator('.service-card a[href="/app/omba/NAPA"]').click();
await page.waitForURL(/\/login\?next=/);
check('request service redirects to login with next', page.url().includes('next=%2Fapp%2Fomba%2FNAPA'));

// Register
await page.getByRole('link', { name: 'Jisajili' }).last().click();
await page.getByLabel('Jina la kwanza').fill('Neema');
await page.getByLabel('Jina la pili').fill('Mollel');
await page.getByLabel('Namba ya simu').fill(phone);
await page.locator('input[autocomplete="new-password"]').nth(0).fill('Siri12345');
await page.locator('input[autocomplete="new-password"]').nth(1).fill('Siri12345');
await page.locator('.checkbox-line input').check();
await page.getByRole('button', { name: 'Fungua akaunti' }).click();
await page.waitForURL(/\/app\/maombi\/\d+\/jaza/).catch(async (e) => { console.log('URL:', page.url(), await page.locator('.alert, .field-error, .toast').allTextContents()); await shot(page, 'fail-register'); throw e; });
check('after register user lands in the NaPA form', true);

// Fill NaPA form
await page.getByLabel('Majina matatu ya mwombaji').fill('neema joseph mollel');
await page.getByText('Kupata namba ya NaPA (reference)').click();
await page.getByLabel('Namba ya simu ya mwombaji').fill('0754000111');
await page.getByLabel('Majina matatu ya baba').fill('joseph mollel lukumay');
await page.getByLabel('Namba ya simu ya baba').fill('0754000222');
await page.getByLabel('Majina matatu ya mama').fill('anna paulo massawe');
await page.getByLabel('Namba ya simu ya mama').fill('0754000333');
await page.getByLabel('Mkoa unaoishi').selectOption('Arusha');
await page.getByLabel('Wilaya unayoishi').selectOption('Karatu');
await shot(page, '02-form-mobile');
await page.getByRole('button', { name: /Endelea/ }).click();
await page.getByText('Hakiki taarifa zako').waitFor();
check('review step shows uppercased name', await page.getByText('NEEMA JOSEPH MOLLEL').isVisible());
await page.getByRole('button', { name: 'Tuma ombi' }).click();
check('confirmation checkbox required', await page.getByText('Thibitisha kuwa taarifa ni sahihi').isVisible());
await page.locator('.checkbox-line input').check();
await page.getByRole('button', { name: 'Tuma ombi' }).first().click();
await page.getByRole('dialog').getByRole('button', { name: 'Tuma ombi' }).click();
await page.getByText('Ombi limepokelewa!').waitFor();
const ref = await page.locator('.mono').first().textContent();
check('success screen shows reference ' + ref, /^MED-\d{4}-NAPA-\d{6}$/.test(ref.trim()));
await shot(page, '03-success');

// Dashboard & detail
await page.goto(BASE + '/app');
await page.getByText('Karibu, Neema.').waitFor();
check('dashboard welcome', true);
await shot(page, '04-dashboard-mobile');
await page.goto(BASE + '/app/maombi');
await page.getByText(ref.trim()).first().waitFor();
await page.getByRole('link', { name: 'Angalia maelezo' }).first().click();
await page.getByText('Hatua za ombi').waitFor();
check('application detail shows timeline', await page.getByText('Nimepokea').first().isVisible());
await shot(page, '05-detail-mobile');

// Chat with admin
await page.goto(BASE + '/app/ujumbe?new=1');
await page.getByLabel('Mada').fill('Swali la NaPA');
await page.getByLabel('Ujumbe').fill('Habari, ombi langu litachukua muda gani?');
await page.getByRole('dialog').getByRole('button', { name: 'Tuma' }).click();
await page.waitForURL(/\/app\/ujumbe\/\d+/);
await page.getByText('ombi langu litachukua').first().waitFor();
check('chat thread opened', true);

// Admin portal (optional)
if (process.env.ADMIN_PHONE) {
  const admin = await browser.newContext({ viewport: { width: 1366, height: 860 }, ...extra });
  await admin.addInitScript(() => localStorage.setItem('mediator.lang.v2', 'sw'));
  const ap = await admin.newPage();
  ap.on('pageerror', (e) => errors.push(e.message));
  await ap.goto(BASE + '/admin/login');
  await ap.getByLabel('Namba ya simu').fill(process.env.ADMIN_PHONE);
  await ap.locator('input[autocomplete="current-password"]').fill(process.env.ADMIN_PASSWORD);
  await ap.getByRole('button', { name: 'Ingia' }).click();
  await ap.getByText('Muhtasari wa mfumo kwa sasa.').waitFor();
  check('admin dashboard loads', true);
  await shot(ap, '06-admin-dashboard');
  await ap.goto(BASE + '/admin/maombi?q=' + encodeURIComponent(ref.trim()));
  await ap.getByText(ref.trim()).first().click();
  await ap.getByRole('button', { name: 'Badilisha status' }).first().click();
  await ap.getByRole('dialog').getByLabel('Status mpya').selectOption('in_progress');
  await ap.getByRole('dialog').getByLabel('Ujumbe kwa mwombaji').fill('Tumeanza kushughulikia ombi lako.');
  await ap.getByRole('dialog').getByRole('button', { name: 'Hifadhi' }).click();
  await ap.getByText('Status imesasishwa').waitFor();
  check('admin changed status', true);
  await shot(ap, '07-admin-application');
  await ap.goto(BASE + '/admin/ujumbe');
  await ap.getByText('Swali la NaPA').first().click();
  await ap.getByLabel('Andika ujumbe...').fill('Karibu! Ndani ya siku 3.');
  await ap.getByRole('button', { name: 'Tuma' }).click();
  await ap.getByText('Ndani ya siku 3.').waitFor();
  check('admin replied in chat', true);
  await admin.close();

  await page.goto(BASE + '/app/arifa');
  await page.getByText('Inafanyiwa Kazi').first().waitFor();
  check('user notified of status change', true);
}

check('no uncaught page errors', errors.length === 0);
if (errors.length) console.log(errors);
await browser.close();
console.log(failed ? `${failed} check(s) failed` : 'All browser checks passed');
process.exit(failed ? 1 : 0);
