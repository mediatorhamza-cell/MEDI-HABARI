<?php
declare(strict_types=1);

/**
 * Mediator API front controller. All /api/* requests are rewritten here by .htaccess.
 */

use Mediator\Controllers\SetupController;
use Mediator\Core\Audit;
use Mediator\Core\Auth;
use Mediator\Core\Env;
use Mediator\Core\HttpException;
use Mediator\Core\Migrator;
use Mediator\Core\Request;
use Mediator\Core\Response;
use Mediator\Core\Router;
use Mediator\Core\Settings;

require __DIR__ . '/src/bootstrap.php';

Response::securityHeaders();

try {
    $request = Request::capture();
    Audit::setRequest($request);

    // First run: no configuration yet -> only the web setup endpoints are available.
    if ((Env::get('APP_KEY', '') ?? '') === '') {
        match ([$request->method, $request->path]) {
            ['GET', '/health'] => Response::ok(['status' => 'not_configured']),
            ['GET', '/setup/status'] => SetupController::status(),
            ['POST', '/setup'] => SetupController::configure($request),
            default => throw new HttpException(503, 'not_configured', 'The application is not configured yet.'),
        };
    }

    // Interrupted first-run setup can be resumed with the same DB credentials.
    if ($request->method === 'POST' && $request->path === '/setup') {
        SetupController::resume($request);
    }

    // After each deployment: apply new migrations / default content once.
    Migrator::ensure();

    Auth::startSession($request);
    Auth::verifyCsrf($request);

    // "Coming soon" mode: until the admin opens the site, only staff can use accounts.
    if (!Settings::get('site_live', false) && !Auth::isStaff()) {
        $blocked = ['/auth/register', '/auth/login', '/auth/forgot-password', '/auth/reset-password', '/assistant', '/contact'];
        if (in_array($request->path, $blocked, true) || str_starts_with($request->path, '/me') || str_starts_with($request->path, '/applications')) {
            throw new HttpException(503, 'coming_soon', 'Mediator Hamza inakuja hivi karibuni.');
        }
    }

    $router = new Router();
    (require __DIR__ . '/src/routes.php')($router);
    $router->dispatch($request);
} catch (HttpException $e) {
    Response::error($e->status, $e->errorCode, $e->getMessage(), $e->errors);
} catch (\Throwable $e) {
    error_log(sprintf('[%s] %s in %s:%d', get_class($e), $e->getMessage(), $e->getFile(), $e->getLine()));
    $message = Env::bool('APP_DEBUG') ? $e->getMessage() : 'Server error. Please try again later.';
    Response::error(500, 'server_error', $message);
}
