-- Track which submitted applications staff have opened (drives the "New" badges).
ALTER TABLE applications ADD COLUMN admin_seen_at DATETIME NULL AFTER submitted_at;

-- Existing applications count as already seen so the badge starts from zero.
UPDATE applications SET admin_seen_at = COALESCE(submitted_at, updated_at) WHERE status <> 'draft';

-- Owner-requested first-person wording on the "received" timeline step.
UPDATE application_status_history SET public_message = 'Nimepokea ombi lako. Nitakujulisha hatua zinazofuata.'
 WHERE public_message = 'Tumepokea ombi lako. Tutakujulisha hatua zinazofuata.';
