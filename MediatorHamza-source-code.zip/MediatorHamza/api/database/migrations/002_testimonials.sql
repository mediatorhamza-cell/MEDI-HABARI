-- Customer testimonials shown on the public site (managed by admin).
CREATE TABLE IF NOT EXISTS testimonials (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  role_sw VARCHAR(150) NULL,
  role_en VARCHAR(150) NULL,
  location VARCHAR(120) NULL,
  body_sw TEXT NOT NULL,
  body_en TEXT NULL,
  rating TINYINT UNSIGNED NOT NULL DEFAULT 5,
  year SMALLINT UNSIGNED NOT NULL,
  photo_id INT UNSIGNED NULL,
  is_published TINYINT(1) NOT NULL DEFAULT 1,
  sort_order INT NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL,
  KEY idx_testimonials_year (year)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
