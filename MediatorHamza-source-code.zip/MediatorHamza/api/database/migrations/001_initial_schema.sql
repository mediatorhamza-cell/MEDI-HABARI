-- Mediator initial schema (MySQL 5.7+/8 / MariaDB 10.3+), utf8mb4

CREATE TABLE IF NOT EXISTS users (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  first_name VARCHAR(80) NOT NULL,
  second_name VARCHAR(80) NOT NULL,
  last_name VARCHAR(80) NULL,
  phone VARCHAR(20) NOT NULL,
  email VARCHAR(190) NULL,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('user','support','readonly','admin','super_admin') NOT NULL DEFAULT 'user',
  status ENUM('active','suspended','disabled') NOT NULL DEFAULT 'active',
  suspended_until DATETIME NULL,
  suspension_reason VARCHAR(255) NULL,
  language ENUM('sw','en') NOT NULL DEFAULT 'sw',
  phone_verified_at DATETIME NULL,
  totp_secret TEXT NULL,
  totp_enabled TINYINT(1) NOT NULL DEFAULT 0,
  session_version INT UNSIGNED NOT NULL DEFAULT 1,
  last_login_at DATETIME NULL,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL,
  UNIQUE KEY uq_users_phone (phone),
  KEY idx_users_role (role),
  KEY idx_users_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS login_events (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NULL,
  event VARCHAR(40) NOT NULL,
  ip_address VARCHAR(45) NULL,
  user_agent VARCHAR(255) NULL,
  created_at DATETIME NOT NULL,
  KEY idx_login_user (user_id, created_at),
  CONSTRAINT fk_login_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS rate_limits (
  bucket CHAR(64) PRIMARY KEY,
  window_start INT UNSIGNED NOT NULL,
  hits INT UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS otp_codes (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  purpose ENUM('password_reset','phone_verify','admin_reset') NOT NULL,
  code_hash VARCHAR(255) NOT NULL,
  attempts TINYINT UNSIGNED NOT NULL DEFAULT 0,
  expires_at DATETIME NOT NULL,
  used_at DATETIME NULL,
  created_by INT UNSIGNED NULL,
  created_at DATETIME NOT NULL,
  KEY idx_otp_user (user_id, purpose),
  CONSTRAINT fk_otp_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS settings (
  setting_key VARCHAR(80) PRIMARY KEY,
  setting_value MEDIUMTEXT NULL,
  updated_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Public media (logos, article images, guidebook PDFs). Private application files live in application_files.
CREATE TABLE IF NOT EXISTS media (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  stored_name VARCHAR(255) NOT NULL,
  original_name VARCHAR(190) NOT NULL,
  mime VARCHAR(80) NOT NULL,
  size INT UNSIGNED NOT NULL,
  uploaded_by INT UNSIGNED NULL,
  created_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS services (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(20) NOT NULL,
  slug VARCHAR(80) NOT NULL,
  form_key VARCHAR(40) NOT NULL,
  icon VARCHAR(40) NOT NULL DEFAULT 'file-text',
  name_sw VARCHAR(150) NOT NULL,
  name_en VARCHAR(150) NULL,
  summary_sw VARCHAR(400) NULL,
  summary_en VARCHAR(400) NULL,
  details_sw MEDIUMTEXT NULL,
  details_en MEDIUMTEXT NULL,
  requirements_sw TEXT NULL,
  requirements_en TEXT NULL,
  price INT UNSIGNED NULL,
  price_note_sw VARCHAR(200) NULL,
  price_note_en VARCHAR(200) NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  accepting TINYINT(1) NOT NULL DEFAULT 1,
  sort_order INT NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL,
  UNIQUE KEY uq_services_code (code),
  UNIQUE KEY uq_services_slug (slug)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS service_packages (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  service_id INT UNSIGNED NOT NULL,
  name_sw VARCHAR(150) NOT NULL,
  name_en VARCHAR(150) NULL,
  price INT UNSIGNED NOT NULL DEFAULT 0,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  sort_order INT NOT NULL DEFAULT 0,
  CONSTRAINT fk_pkg_service FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS reference_sequences (
  service_code VARCHAR(20) NOT NULL,
  seq_year SMALLINT UNSIGNED NOT NULL,
  last_value INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (service_code, seq_year)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS applications (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  reference VARCHAR(40) NULL,
  user_id INT UNSIGNED NOT NULL,
  service_id INT UNSIGNED NOT NULL,
  package_id INT UNSIGNED NULL,
  status ENUM('draft','received','in_progress','awaiting_info','correction_required','completed','on_hold','closed','cancelled') NOT NULL DEFAULT 'draft',
  payment_status ENUM('unpaid','stationery_paid','partial','paid','waived') NOT NULL DEFAULT 'unpaid',
  price_snapshot INT UNSIGNED NULL,
  package_name_snapshot VARCHAR(150) NULL,
  form_version SMALLINT UNSIGNED NOT NULL DEFAULT 1,
  data JSON NULL,
  sensitive_data MEDIUMTEXT NULL,
  applicant_name VARCHAR(190) NULL,
  applicant_phone VARCHAR(20) NULL,
  editable_fields JSON NULL,
  correction_message TEXT NULL,
  next_action VARCHAR(400) NULL,
  submitted_at DATETIME NULL,
  completed_at DATETIME NULL,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL,
  UNIQUE KEY uq_app_reference (reference),
  KEY idx_app_user (user_id, created_at),
  KEY idx_app_status (status),
  KEY idx_app_service (service_id, status),
  KEY idx_app_submitted (submitted_at),
  CONSTRAINT fk_app_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE RESTRICT,
  CONSTRAINT fk_app_service FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS application_status_history (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  application_id INT UNSIGNED NOT NULL,
  from_status VARCHAR(30) NULL,
  to_status VARCHAR(30) NOT NULL,
  public_message TEXT NULL,
  internal_note TEXT NULL,
  next_action VARCHAR(400) NULL,
  changed_by INT UNSIGNED NULL,
  created_at DATETIME NOT NULL,
  KEY idx_hist_app (application_id, created_at),
  CONSTRAINT fk_hist_app FOREIGN KEY (application_id) REFERENCES applications(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS application_files (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  application_id INT UNSIGNED NOT NULL,
  field_key VARCHAR(60) NOT NULL,
  kind ENUM('applicant','result') NOT NULL DEFAULT 'applicant',
  stored_name VARCHAR(255) NOT NULL,
  original_name VARCHAR(190) NOT NULL,
  mime VARCHAR(80) NOT NULL,
  size INT UNSIGNED NOT NULL,
  uploaded_by INT UNSIGNED NOT NULL,
  created_at DATETIME NOT NULL,
  KEY idx_files_app (application_id, kind),
  CONSTRAINT fk_files_app FOREIGN KEY (application_id) REFERENCES applications(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS application_changes (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  application_id INT UNSIGNED NOT NULL,
  changed_by INT UNSIGNED NOT NULL,
  changed_fields JSON NOT NULL,
  reason VARCHAR(60) NOT NULL,
  created_at DATETIME NOT NULL,
  KEY idx_changes_app (application_id),
  CONSTRAINT fk_changes_app FOREIGN KEY (application_id) REFERENCES applications(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Results/feedback (may contain portal usernames & passwords -> body encrypted)
CREATE TABLE IF NOT EXISTS application_results (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  application_id INT UNSIGNED NOT NULL,
  title VARCHAR(200) NOT NULL,
  body_encrypted MEDIUMTEXT NOT NULL,
  created_by INT UNSIGNED NOT NULL,
  created_at DATETIME NOT NULL,
  KEY idx_results_app (application_id),
  CONSTRAINT fk_results_app FOREIGN KEY (application_id) REFERENCES applications(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS payment_records (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  application_id INT UNSIGNED NOT NULL,
  status VARCHAR(30) NOT NULL,
  amount INT UNSIGNED NULL,
  method VARCHAR(60) NULL,
  transaction_ref VARCHAR(100) NULL,
  note VARCHAR(400) NULL,
  recorded_by INT UNSIGNED NOT NULL,
  created_at DATETIME NOT NULL,
  KEY idx_pay_app (application_id),
  CONSTRAINT fk_pay_app FOREIGN KEY (application_id) REFERENCES applications(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS notification_batches (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(200) NOT NULL,
  body TEXT NOT NULL,
  audience JSON NOT NULL,
  recipients INT UNSIGNED NOT NULL DEFAULT 0,
  sent_by INT UNSIGNED NULL,
  created_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS notifications (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  type VARCHAR(40) NOT NULL,
  title_sw VARCHAR(200) NOT NULL,
  title_en VARCHAR(200) NULL,
  body_sw TEXT NOT NULL,
  body_en TEXT NULL,
  link VARCHAR(255) NULL,
  batch_id INT UNSIGNED NULL,
  read_at DATETIME NULL,
  created_at DATETIME NOT NULL,
  KEY idx_notif_user (user_id, read_at, created_at),
  CONSTRAINT fk_notif_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS conversations (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  application_id INT UNSIGNED NULL,
  subject VARCHAR(200) NOT NULL,
  status ENUM('open','closed') NOT NULL DEFAULT 'open',
  awaiting_reply TINYINT(1) NOT NULL DEFAULT 1,
  last_message_at DATETIME NOT NULL,
  created_at DATETIME NOT NULL,
  KEY idx_conv_user (user_id, last_message_at),
  KEY idx_conv_awaiting (awaiting_reply, last_message_at),
  CONSTRAINT fk_conv_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_conv_app FOREIGN KEY (application_id) REFERENCES applications(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS messages (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  conversation_id INT UNSIGNED NOT NULL,
  sender_id INT UNSIGNED NOT NULL,
  from_staff TINYINT(1) NOT NULL DEFAULT 0,
  body TEXT NOT NULL,
  read_at DATETIME NULL,
  created_at DATETIME NOT NULL,
  KEY idx_msg_conv (conversation_id, created_at),
  CONSTRAINT fk_msg_conv FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS categories (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  scope ENUM('article','guide','institution_type','faq') NOT NULL,
  slug VARCHAR(80) NOT NULL,
  name_sw VARCHAR(120) NOT NULL,
  name_en VARCHAR(120) NULL,
  sort_order INT NOT NULL DEFAULT 0,
  UNIQUE KEY uq_cat (scope, slug)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS articles (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  category_id INT UNSIGNED NULL,
  slug VARCHAR(190) NOT NULL,
  title_sw VARCHAR(200) NOT NULL,
  title_en VARCHAR(200) NULL,
  summary_sw VARCHAR(400) NULL,
  summary_en VARCHAR(400) NULL,
  body_sw MEDIUMTEXT NULL,
  body_en MEDIUMTEXT NULL,
  image_id INT UNSIGNED NULL,
  attachment_id INT UNSIGNED NULL,
  is_published TINYINT(1) NOT NULL DEFAULT 0,
  published_at DATETIME NULL,
  sort_order INT NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL,
  UNIQUE KEY uq_articles_slug (slug),
  KEY idx_articles_pub (is_published, published_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS institutions (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(200) NOT NULL,
  short_name VARCHAR(40) NULL,
  category_id INT UNSIGNED NULL,
  ownership ENUM('public','private','other') NULL,
  region VARCHAR(80) NULL,
  location VARCHAR(200) NULL,
  logo_id INT UNSIGNED NULL,
  website_url VARCHAR(300) NULL,
  apply_url VARCHAR(300) NULL,
  login_url VARCHAR(300) NULL,
  description_sw TEXT NULL,
  description_en TEXT NULL,
  links_verified_at DATETIME NULL,
  is_featured TINYINT(1) NOT NULL DEFAULT 0,
  is_published TINYINT(1) NOT NULL DEFAULT 0,
  sort_order INT NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL,
  KEY idx_inst_pub (is_published, name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS guidebooks (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  category_id INT UNSIGNED NULL,
  title_sw VARCHAR(200) NOT NULL,
  title_en VARCHAR(200) NULL,
  academic_year VARCHAR(20) NULL,
  description_sw TEXT NULL,
  description_en TEXT NULL,
  file_id INT UNSIGNED NULL,
  external_url VARCHAR(300) NULL,
  is_outdated TINYINT(1) NOT NULL DEFAULT 0,
  is_published TINYINT(1) NOT NULL DEFAULT 0,
  sort_order INT NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS deadlines (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  service_id INT UNSIGNED NULL,
  title_sw VARCHAR(200) NOT NULL,
  title_en VARCHAR(200) NULL,
  description_sw TEXT NULL,
  description_en TEXT NULL,
  opens_at DATE NULL,
  closes_at DATE NOT NULL,
  remind_days_before SMALLINT UNSIGNED NOT NULL DEFAULT 3,
  last_reminder_at DATETIME NULL,
  is_published TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL,
  KEY idx_deadline_close (is_published, closes_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS announcements (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  title_sw VARCHAR(200) NOT NULL,
  title_en VARCHAR(200) NULL,
  body_sw MEDIUMTEXT NULL,
  body_en MEDIUMTEXT NULL,
  is_pinned TINYINT(1) NOT NULL DEFAULT 0,
  is_published TINYINT(1) NOT NULL DEFAULT 0,
  published_at DATETIME NULL,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS faqs (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  category_id INT UNSIGNED NULL,
  question_sw VARCHAR(300) NOT NULL,
  question_en VARCHAR(300) NULL,
  answer_sw TEXT NOT NULL,
  answer_en TEXT NULL,
  keywords VARCHAR(300) NULL,
  is_published TINYINT(1) NOT NULL DEFAULT 1,
  sort_order INT NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS whatsapp_groups (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  description_sw TEXT NULL,
  description_en TEXT NULL,
  invite_url VARCHAR(300) NOT NULL,
  is_published TINYINT(1) NOT NULL DEFAULT 1,
  sort_order INT NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS contact_messages (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  phone VARCHAR(20) NULL,
  email VARCHAR(190) NULL,
  message TEXT NOT NULL,
  is_handled TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS audit_logs (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NULL,
  action VARCHAR(80) NOT NULL,
  entity_type VARCHAR(40) NULL,
  entity_id INT UNSIGNED NULL,
  details JSON NULL,
  ip_address VARCHAR(45) NULL,
  created_at DATETIME NOT NULL,
  KEY idx_audit_created (created_at),
  KEY idx_audit_entity (entity_type, entity_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Privacy-respecting analytics: one row per (day, salted visitor hash). No raw IPs stored.
CREATE TABLE IF NOT EXISTS visitor_days (
  visit_day DATE NOT NULL,
  visitor_hash CHAR(64) NOT NULL,
  page_views INT UNSIGNED NOT NULL DEFAULT 1,
  PRIMARY KEY (visit_day, visitor_hash)
) ENGINE=InnoDB;
