<?php
declare(strict_types=1);

use Mediator\Controllers\Admin\ApplicationAdminController as AdminApps;
use Mediator\Controllers\Admin\ContentAdminController as AdminContent;
use Mediator\Controllers\Admin\DashboardController as AdminDashboard;
use Mediator\Controllers\Admin\MessageAdminController as AdminMessages;
use Mediator\Controllers\Admin\NotificationAdminController as AdminNotifications;
use Mediator\Controllers\Admin\ReportController as AdminReports;
use Mediator\Controllers\Admin\ServiceAdminController as AdminServices;
use Mediator\Controllers\Admin\SettingsController as AdminSettings;
use Mediator\Controllers\Admin\StaffController as AdminStaff;
use Mediator\Controllers\Admin\UserAdminController as AdminUsers;
use Mediator\Controllers\ApplicationController as Apps;
use Mediator\Controllers\AssistantController as Assistant;
use Mediator\Controllers\AuthController as AuthC;
use Mediator\Controllers\MessageController as Messages;
use Mediator\Controllers\NotificationController as Notifications;
use Mediator\Controllers\ProfileController as Profile;
use Mediator\Controllers\PublicController as Pub;
use Mediator\Core\Auth;
use Mediator\Core\Router;

return static function (Router $r): void {
    $user = static fn () => Auth::requireUser();
    $staff = static fn () => Auth::requireStaff();

    // ---------------------------------------------------------------- public
    $r->get('/health', static fn () => \Mediator\Core\Response::ok(['status' => 'ok', 'time' => date('c')]));
    $r->get('/bootstrap', [Pub::class, 'bootstrap']);
    $r->get('/home', [Pub::class, 'home']);
    $r->get('/services/{slug}', [Pub::class, 'service']);
    $r->get('/form-schemas/{key}', [Pub::class, 'form']);
    $r->get('/regions', [Pub::class, 'regions']);
    $r->get('/categories', [Pub::class, 'categories']);
    $r->get('/articles', [Pub::class, 'articles']);
    $r->get('/articles/{slug}', [Pub::class, 'article']);
    $r->get('/institutions', [Pub::class, 'institutions']);
    $r->get('/institution-names', [Pub::class, 'institutionNames']);
    $r->get('/guidebooks', [Pub::class, 'guidebooks']);
    $r->get('/deadlines', [Pub::class, 'deadlines']);
    $r->get('/announcements', [Pub::class, 'announcements']);
    $r->get('/testimonials', [Pub::class, 'testimonials']);
    $r->get('/faqs', [Pub::class, 'faqs']);
    $r->get('/search', [Pub::class, 'search']);
    $r->get('/media/{id}', [Pub::class, 'media']);
    $r->post('/contact', [Pub::class, 'contact']);
    $r->post('/track', [Pub::class, 'track']);
    $r->post('/assistant', [Assistant::class, 'ask']);

    // ---------------------------------------------------------------- auth
    $r->get('/auth/session', [AuthC::class, 'session']);
    $r->post('/auth/register', [AuthC::class, 'register']);
    $r->post('/auth/login', [AuthC::class, 'login']);
    $r->post('/auth/logout', [AuthC::class, 'logout']);
    $r->post('/auth/forgot-password', [AuthC::class, 'forgotPassword']);
    $r->post('/auth/reset-password', [AuthC::class, 'resetPassword']);
    $r->post('/admin/auth/login', [AuthC::class, 'adminLogin']);
    $r->post('/admin/auth/2fa', [AuthC::class, 'verifyTwoFactor']);
    $r->post('/install', [AuthC::class, 'install']);

    // ---------------------------------------------------------------- user area
    $r->group('/me', [$user], static function (Router $r): void {
        $r->get('/dashboard', [Profile::class, 'dashboard']);
        $r->put('/profile', [Profile::class, 'update']);
        $r->put('/language', [Profile::class, 'language']);
        $r->post('/password', [Profile::class, 'changePassword']);
        $r->get('/notifications', [Notifications::class, 'index']);
        $r->get('/notifications/counts', [Notifications::class, 'counts']);
        $r->post('/notifications/read-all', [Notifications::class, 'markAllRead']);
        $r->post('/notifications/{id}/read', [Notifications::class, 'markRead']);
        $r->delete('/notifications/{id}', [Notifications::class, 'delete']);
        $r->delete('/notifications', [Notifications::class, 'clear']);
        $r->get('/groups', [Pub::class, 'whatsappGroups']);
        $r->get('/conversations', [Messages::class, 'index']);
        $r->post('/conversations', [Messages::class, 'create']);
        $r->get('/conversations/{id}', [Messages::class, 'show']);
        $r->post('/conversations/{id}/messages', [Messages::class, 'reply']);
    });
    $r->group('/applications', [$user], static function (Router $r): void {
        $r->get('', [Apps::class, 'index']);
        $r->get('/history', [Apps::class, 'fieldHistory']);
        $r->post('', [Apps::class, 'create']);
        $r->get('/{id}', [Apps::class, 'show']);
        $r->put('/{id}', [Apps::class, 'update']);
        $r->post('/{id}/submit', [Apps::class, 'submit']);
        $r->post('/{id}/cancel', [Apps::class, 'cancel']);
        $r->post('/{id}/files', [Apps::class, 'uploadFile']);
        $r->delete('/{id}/files/{fileId}', [Apps::class, 'deleteFile']);
        $r->get('/{id}/files/{fileId}', [Apps::class, 'downloadFile']);
    });

    // ---------------------------------------------------------------- admin portal
    $r->group('/admin', [$staff], static function (Router $r): void {
        $r->get('/dashboard', [AdminDashboard::class, 'stats']);

        $r->get('/applications', [AdminApps::class, 'index']);
        $r->get('/applications/{id}', [AdminApps::class, 'show']);
        $r->post('/applications/{id}/status', [AdminApps::class, 'updateStatus']);
        $r->post('/applications/{id}/notes', [AdminApps::class, 'addNote']);
        $r->post('/applications/{id}/payment', [AdminApps::class, 'updatePayment']);
        $r->post('/applications/{id}/results', [AdminApps::class, 'addResult']);
        $r->delete('/applications/{id}/results/{resultId}', [AdminApps::class, 'deleteResult']);
        $r->post('/applications/{id}/result-files', [AdminApps::class, 'uploadResultFile']);
        $r->delete('/applications/{id}/result-files/{fileId}', [AdminApps::class, 'deleteResultFile']);
        $r->get('/applications/{id}/files/{fileId}', [AdminApps::class, 'downloadFile']);
        $r->post('/applications/{id}/message', [AdminApps::class, 'message']);

        $r->get('/users', [AdminUsers::class, 'index']);
        $r->get('/users/{id}', [AdminUsers::class, 'show']);
        $r->put('/users/{id}', [AdminUsers::class, 'update']);
        $r->post('/users/{id}/status', [AdminUsers::class, 'suspend']);
        $r->post('/users/{id}/reset-code', [AdminUsers::class, 'issueResetCode']);
        $r->post('/users/{id}/notify', [AdminUsers::class, 'notify']);

        $r->get('/staff', [AdminStaff::class, 'index']);
        $r->post('/staff', [AdminStaff::class, 'create']);
        $r->put('/staff/{id}', [AdminStaff::class, 'update']);
        $r->post('/security/2fa/setup', [AdminStaff::class, 'twoFactorSetup']);
        $r->post('/security/2fa/enable', [AdminStaff::class, 'twoFactorEnable']);
        $r->post('/security/2fa/disable', [AdminStaff::class, 'twoFactorDisable']);

        $r->get('/services', [AdminServices::class, 'index']);
        $r->put('/services/{id}', [AdminServices::class, 'update']);
        $r->post('/services/{id}/packages', [AdminServices::class, 'savePackage']);
        $r->delete('/services/{id}/packages/{packageId}', [AdminServices::class, 'deletePackage']);

        $r->post('/media', [AdminContent::class, 'uploadMedia']);
        $r->post('/content/institutions/{id}/verify-links', [AdminContent::class, 'verifyLinks']);
        $r->get('/content/{type}', [AdminContent::class, 'index']);
        $r->post('/content/{type}', [AdminContent::class, 'create']);
        $r->get('/content/{type}/{id}', [AdminContent::class, 'show']);
        $r->put('/content/{type}/{id}', [AdminContent::class, 'update']);
        $r->delete('/content/{type}/{id}', [AdminContent::class, 'delete']);

        $r->get('/notifications', [AdminNotifications::class, 'history']);
        $r->post('/notifications', [AdminNotifications::class, 'send']);
        $r->post('/notifications/preview', [AdminNotifications::class, 'preview']);
        $r->post('/deadlines/{id}/remind', [AdminNotifications::class, 'deadlineReminder']);

        $r->get('/conversations', [AdminMessages::class, 'index']);
        $r->get('/conversations/{id}', [AdminMessages::class, 'show']);
        $r->post('/conversations/{id}/messages', [AdminMessages::class, 'reply']);
        $r->post('/conversations/{id}/status', [AdminMessages::class, 'setStatus']);

        $r->get('/reports/columns', [AdminReports::class, 'columns']);
        $r->get('/reports/applications', [AdminReports::class, 'applications']);
        $r->get('/reports/phones', [AdminReports::class, 'phones']);
        $r->get('/reports/summary', [AdminReports::class, 'summary']);

        $r->get('/settings', [AdminSettings::class, 'show']);
        $r->put('/settings', [AdminSettings::class, 'update']);
        $r->get('/audit', [AdminSettings::class, 'audit']);
        $r->get('/contact-messages', [AdminSettings::class, 'contactMessages']);
        $r->post('/contact-messages/{id}', [AdminSettings::class, 'contactHandled']);
    });
};
