<?php
declare(strict_types=1);

namespace Mediator\Controllers;

use Mediator\Core\Auth;
use Mediator\Core\DB;
use Mediator\Core\FormSchema;
use Mediator\Core\HttpException;
use Mediator\Core\RateLimiter;
use Mediator\Core\Request;
use Mediator\Core\Response;
use Mediator\Core\Settings;
use Mediator\Core\Applications;
use Mediator\Core\Uploads;
use Mediator\Core\Validator;

/** Public (anonymous) read endpoints for the website. */
final class PublicController
{
    public static function bootstrap(Request $r): void
    {
        Response::ok([
            'settings' => Settings::publicSettings(),
            'services' => self::services(),
        ]);
    }

    /** @return list<array<string,mixed>> */
    public static function services(): array
    {
        $rows = DB::all('SELECT * FROM services WHERE is_active = 1 ORDER BY sort_order, id');
        $packages = [];
        foreach (DB::all('SELECT * FROM service_packages WHERE is_active = 1 ORDER BY sort_order, id') as $p) {
            $packages[(int) $p['service_id']][] = ['id' => (int) $p['id'], 'name_sw' => $p['name_sw'], 'name_en' => $p['name_en'], 'price' => (int) $p['price']];
        }
        return array_map(static fn ($s) => [
            'id' => (int) $s['id'],
            'code' => $s['code'],
            'slug' => $s['slug'],
            'form_key' => $s['form_key'],
            'icon' => $s['icon'],
            'name_sw' => $s['name_sw'],
            'name_en' => $s['name_en'],
            'summary_sw' => $s['summary_sw'],
            'summary_en' => $s['summary_en'],
            'price' => $s['price'] !== null ? (int) $s['price'] : null,
            'price_note_sw' => $s['price_note_sw'],
            'price_note_en' => $s['price_note_en'],
            'accepting' => (bool) $s['accepting'],
            'packages' => $packages[(int) $s['id']] ?? [],
        ], $rows);
    }

    public static function service(Request $r): void
    {
        $s = DB::one('SELECT * FROM services WHERE slug = ? AND is_active = 1', [$r->param('slug')]);
        if (!$s) {
            throw HttpException::notFound();
        }
        $summary = array_values(array_filter(self::services(), static fn ($x) => $x['id'] === (int) $s['id']))[0];
        Response::ok(array_merge($summary, [
            'details_sw' => $s['details_sw'],
            'details_en' => $s['details_en'],
            'requirements_sw' => $s['requirements_sw'],
            'requirements_en' => $s['requirements_en'],
            'deadlines' => array_values(array_filter(self::upcomingDeadlines(20), static fn ($d) => $d['service_id'] === (int) $s['id'])),
        ]));
    }

    /** Service form schema (public so visitors can preview requirements). */
    public static function form(Request $r): void
    {
        $schema = FormSchema::load($r->param('key'));
        $ctx = Applications::formContext();
        Response::ok(['schema' => $schema->schema, 'options' => $ctx]);
    }

    public static function regions(Request $r): void
    {
        header('Cache-Control: public, max-age=86400');
        $out = [];
        foreach (FormSchema::regions() as $name => $districts) {
            $out[] = ['name' => $name, 'districts' => $districts];
        }
        Response::ok($out);
    }

    public static function home(Request $r): void
    {
        Response::ok([
            'deadlines' => self::upcomingDeadlines(4),
            'articles' => self::articleList(null, 3, 0)['items'],
            'institutions' => array_map([self::class, 'institution'], DB::all(
                'SELECT * FROM institutions WHERE is_published = 1 AND is_featured = 1 ORDER BY sort_order, name LIMIT 8'
            )),
            'guidebooks' => array_map([self::class, 'guidebook'], DB::all(
                'SELECT g.*, c.name_sw AS category_sw, c.name_en AS category_en FROM guidebooks g LEFT JOIN categories c ON c.id = g.category_id
                 WHERE g.is_published = 1 AND g.is_outdated = 0 ORDER BY g.created_at DESC LIMIT 4'
            )),
            'faqs' => array_slice(self::faqList(), 0, 6),
            'announcements' => self::latestAnnouncements(3),
        ]);
    }

    public static function categories(Request $r): void
    {
        $scope = $r->query('scope', 'article');
        Response::ok(DB::all('SELECT id, scope, slug, name_sw, name_en FROM categories WHERE scope = ? ORDER BY sort_order, id', [$scope]));
    }

    // ---------------------------------------------------------------- articles

    /** @return array{items: list<array<string,mixed>>, total: int} */
    private static function articleList(?int $categoryId, int $limit, int $offset, string $q = ''): array
    {
        $where = 'a.is_published = 1 AND (a.published_at IS NULL OR a.published_at <= NOW())';
        $params = [];
        if ($categoryId) {
            $where .= ' AND a.category_id = ?';
            $params[] = $categoryId;
        }
        if ($q !== '') {
            $where .= ' AND (a.title_sw LIKE ? OR a.title_en LIKE ? OR a.summary_sw LIKE ?)';
            array_push($params, DB::like($q), DB::like($q), DB::like($q));
        }
        $total = (int) DB::value("SELECT COUNT(*) FROM articles a WHERE {$where}", $params);
        $rows = DB::all(
            "SELECT a.*, c.name_sw AS category_sw, c.name_en AS category_en, c.slug AS category_slug FROM articles a
             LEFT JOIN categories c ON c.id = a.category_id WHERE {$where}
             ORDER BY a.sort_order DESC, COALESCE(a.published_at, a.created_at) DESC LIMIT ? OFFSET ?",
            array_merge($params, [$limit, $offset])
        );
        return ['items' => array_map(static fn ($a) => [
            'id' => (int) $a['id'], 'slug' => $a['slug'], 'title_sw' => $a['title_sw'], 'title_en' => $a['title_en'],
            'summary_sw' => $a['summary_sw'], 'summary_en' => $a['summary_en'], 'image_id' => $a['image_id'] ? (int) $a['image_id'] : null,
            'attachment_id' => $a['attachment_id'] ? (int) $a['attachment_id'] : null,
            'category_sw' => $a['category_sw'], 'category_en' => $a['category_en'], 'category_slug' => $a['category_slug'],
            'published_at' => $a['published_at'] ?? $a['created_at'],
        ], $rows), 'total' => $total];
    }

    public static function articles(Request $r): void
    {
        $page = $r->queryInt('page', 1);
        $per = 12;
        $cat = $r->query('category');
        $catId = $cat ? (int) DB::value("SELECT id FROM categories WHERE scope = 'article' AND slug = ?", [$cat]) : null;
        $res = self::articleList($catId ?: null, $per, ($page - 1) * $per, (string) $r->query('q', ''));
        Response::ok($res + ['page' => $page, 'per_page' => $per]);
    }

    public static function article(Request $r): void
    {
        $a = DB::one(
            'SELECT a.*, c.name_sw AS category_sw, c.name_en AS category_en FROM articles a LEFT JOIN categories c ON c.id = a.category_id
             WHERE a.slug = ? AND a.is_published = 1',
            [$r->param('slug')]
        );
        if (!$a) {
            throw HttpException::notFound();
        }
        $a['id'] = (int) $a['id'];
        Response::ok($a);
    }

    // ---------------------------------------------------------------- institutions

    /** @return array<string,mixed> */
    public static function institution(array $i): array
    {
        return [
            'id' => (int) $i['id'], 'name' => $i['name'], 'short_name' => $i['short_name'],
            'category_id' => $i['category_id'] ? (int) $i['category_id'] : null,
            'type_sw' => $i['type_sw'] ?? null, 'type_en' => $i['type_en'] ?? null,
            'ownership' => $i['ownership'], 'region' => $i['region'], 'location' => $i['location'],
            'logo_id' => $i['logo_id'] ? (int) $i['logo_id'] : null, 'website_url' => $i['website_url'],
            'apply_url' => $i['apply_url'], 'login_url' => $i['login_url'],
            'description_sw' => $i['description_sw'], 'description_en' => $i['description_en'],
            'links_verified_at' => $i['links_verified_at'], 'is_featured' => (bool) $i['is_featured'],
        ];
    }

    public static function institutions(Request $r): void
    {
        $where = 'i.is_published = 1';
        $params = [];
        if ($q = $r->query('q')) {
            $where .= ' AND (i.name LIKE ? OR i.short_name LIKE ? OR i.location LIKE ?)';
            array_push($params, DB::like($q), DB::like($q), DB::like($q));
        }
        if ($type = $r->query('type')) {
            $where .= ' AND c.slug = ?';
            $params[] = $type;
        }
        if ($region = $r->query('region')) {
            $where .= ' AND i.region = ?';
            $params[] = $region;
        }
        if (($own = $r->query('ownership')) && in_array($own, ['public', 'private', 'other'], true)) {
            $where .= ' AND i.ownership = ?';
            $params[] = $own;
        }
        $page = $r->queryInt('page', 1);
        $per = 24;
        $total = (int) DB::value("SELECT COUNT(*) FROM institutions i LEFT JOIN categories c ON c.id = i.category_id WHERE {$where}", $params);
        $rows = DB::all(
            "SELECT i.*, c.name_sw AS type_sw, c.name_en AS type_en FROM institutions i LEFT JOIN categories c ON c.id = i.category_id
             WHERE {$where} ORDER BY i.is_featured DESC, i.sort_order, i.name LIMIT ? OFFSET ?",
            array_merge($params, [$per, ($page - 1) * $per])
        );
        Response::ok([
            'items' => array_map([self::class, 'institution'], $rows),
            'total' => $total, 'page' => $page, 'per_page' => $per,
            'regions' => array_column(DB::all('SELECT DISTINCT region FROM institutions WHERE is_published = 1 AND region IS NOT NULL ORDER BY region'), 'region'),
        ]);
    }

    /** Names only, for autocomplete in the college application form. */
    public static function institutionNames(Request $r): void
    {
        Response::ok(array_column(DB::all('SELECT name FROM institutions WHERE is_published = 1 ORDER BY name'), 'name'));
    }

    // ---------------------------------------------------------------- guidebooks

    /** @return array<string,mixed> */
    public static function guidebook(array $g): array
    {
        return [
            'id' => (int) $g['id'], 'title_sw' => $g['title_sw'], 'title_en' => $g['title_en'],
            'category_sw' => $g['category_sw'] ?? null, 'category_en' => $g['category_en'] ?? null,
            'category_id' => $g['category_id'] ? (int) $g['category_id'] : null,
            'academic_year' => $g['academic_year'], 'description_sw' => $g['description_sw'], 'description_en' => $g['description_en'],
            'file_id' => $g['file_id'] ? (int) $g['file_id'] : null, 'external_url' => $g['external_url'],
            'is_outdated' => (bool) $g['is_outdated'], 'created_at' => $g['created_at'],
        ];
    }

    public static function guidebooks(Request $r): void
    {
        $where = 'g.is_published = 1';
        $params = [];
        if ($cat = $r->query('category')) {
            $where .= ' AND c.slug = ?';
            $params[] = $cat;
        }
        if ($year = $r->query('year')) {
            $where .= ' AND g.academic_year = ?';
            $params[] = $year;
        }
        if ($q = $r->query('q')) {
            $where .= ' AND (g.title_sw LIKE ? OR g.title_en LIKE ? OR g.description_sw LIKE ?)';
            array_push($params, DB::like($q), DB::like($q), DB::like($q));
        }
        if ($r->query('include_outdated') !== '1') {
            $where .= ' AND g.is_outdated = 0';
        }
        $rows = DB::all(
            "SELECT g.*, c.name_sw AS category_sw, c.name_en AS category_en FROM guidebooks g LEFT JOIN categories c ON c.id = g.category_id
             WHERE {$where} ORDER BY g.is_outdated, g.sort_order, g.created_at DESC LIMIT 200",
            $params
        );
        Response::ok([
            'items' => array_map([self::class, 'guidebook'], $rows),
            'years' => array_column(DB::all('SELECT DISTINCT academic_year FROM guidebooks WHERE is_published = 1 AND academic_year IS NOT NULL ORDER BY academic_year DESC'), 'academic_year'),
        ]);
    }

    // ---------------------------------------------------------------- deadlines / announcements / faq

    /** @return list<array<string,mixed>> */
    public static function upcomingDeadlines(int $limit, bool $includePast = false): array
    {
        $rows = DB::all(
            'SELECT d.*, s.name_sw AS service_sw, s.name_en AS service_en, s.code AS service_code FROM deadlines d
             LEFT JOIN services s ON s.id = d.service_id
             WHERE d.is_published = 1' . ($includePast ? '' : ' AND d.closes_at >= CURDATE()') . '
             ORDER BY ' . ($includePast ? 'd.closes_at DESC' : 'd.closes_at ASC') . ' LIMIT ?',
            [$limit]
        );
        return array_map(static fn ($d) => [
            'id' => (int) $d['id'], 'service_id' => $d['service_id'] ? (int) $d['service_id'] : null,
            'service_sw' => $d['service_sw'], 'service_en' => $d['service_en'], 'service_code' => $d['service_code'],
            'title_sw' => $d['title_sw'], 'title_en' => $d['title_en'], 'description_sw' => $d['description_sw'],
            'description_en' => $d['description_en'], 'opens_at' => $d['opens_at'], 'closes_at' => $d['closes_at'],
            'days_left' => (int) floor((strtotime($d['closes_at'] . ' 23:59:59') - time()) / 86400),
        ], $rows);
    }

    public static function deadlines(Request $r): void
    {
        Response::ok([
            'upcoming' => self::upcomingDeadlines(100),
            'past' => $r->query('past') === '1' ? self::upcomingDeadlines(30, true) : [],
        ]);
    }

    /** @return list<array<string,mixed>> */
    public static function latestAnnouncements(int $limit): array
    {
        return array_map(static fn ($a) => [
            'id' => (int) $a['id'], 'title_sw' => $a['title_sw'], 'title_en' => $a['title_en'],
            'body_sw' => $a['body_sw'], 'body_en' => $a['body_en'], 'is_pinned' => (bool) $a['is_pinned'],
            'published_at' => $a['published_at'] ?? $a['created_at'],
        ], DB::all(
            'SELECT * FROM announcements WHERE is_published = 1 AND (published_at IS NULL OR published_at <= NOW())
             ORDER BY is_pinned DESC, COALESCE(published_at, created_at) DESC LIMIT ?',
            [$limit]
        ));
    }

    public static function announcements(Request $r): void
    {
        Response::ok(self::latestAnnouncements(50));
    }

    /** @return list<array<string,mixed>> */
    public static function faqList(): array
    {
        return array_map(static fn ($f) => [
            'id' => (int) $f['id'], 'question_sw' => $f['question_sw'], 'question_en' => $f['question_en'],
            'answer_sw' => $f['answer_sw'], 'answer_en' => $f['answer_en'],
            'category_sw' => $f['category_sw'], 'category_en' => $f['category_en'],
        ], DB::all(
            'SELECT f.*, c.name_sw AS category_sw, c.name_en AS category_en FROM faqs f LEFT JOIN categories c ON c.id = f.category_id
             WHERE f.is_published = 1 ORDER BY f.sort_order, f.id'
        ));
    }

    public static function testimonials(Request $r): void
    {
        Response::ok(array_map(static fn ($t) => [
            'id' => (int) $t['id'], 'name' => $t['name'], 'role_sw' => $t['role_sw'], 'role_en' => $t['role_en'],
            'location' => $t['location'], 'body_sw' => $t['body_sw'], 'body_en' => $t['body_en'],
            'rating' => max(1, min(5, (int) $t['rating'])), 'year' => (int) $t['year'],
            'photo_id' => $t['photo_id'] !== null ? (int) $t['photo_id'] : null,
        ], DB::all('SELECT * FROM testimonials WHERE is_published = 1 ORDER BY year DESC, sort_order ASC, id DESC LIMIT 200')));
    }

    public static function faqs(Request $r): void
    {
        Response::ok(self::faqList());
    }

    public static function whatsappGroups(Request $r): void
    {
        Auth::requireUser();
        Response::ok(DB::all('SELECT id, name, description_sw, description_en, invite_url FROM whatsapp_groups WHERE is_published = 1 ORDER BY sort_order, id'));
    }

    // ---------------------------------------------------------------- search

    public static function search(Request $r): void
    {
        $q = mb_substr((string) $r->query('q', ''), 0, 100);
        if (mb_strlen($q) < 2) {
            Response::ok(['query' => $q, 'results' => []]);
        }
        RateLimiter::hit('search:' . $r->ip(), 120, 600);
        $like = DB::like($q);
        $results = [];
        foreach (DB::all('SELECT slug, name_sw, name_en, summary_sw, summary_en FROM services WHERE is_active = 1 AND (name_sw LIKE ? OR name_en LIKE ? OR summary_sw LIKE ? OR details_sw LIKE ?) LIMIT 10', [$like, $like, $like, $like]) as $s) {
            $results[] = ['type' => 'service', 'title_sw' => $s['name_sw'], 'title_en' => $s['name_en'], 'excerpt_sw' => $s['summary_sw'], 'excerpt_en' => $s['summary_en'], 'url' => '/huduma/' . $s['slug']];
        }
        foreach (DB::all('SELECT slug, title_sw, title_en, summary_sw, summary_en FROM articles WHERE is_published = 1 AND (title_sw LIKE ? OR title_en LIKE ? OR summary_sw LIKE ? OR body_sw LIKE ?) LIMIT 15', [$like, $like, $like, $like]) as $a) {
            $results[] = ['type' => 'article', 'title_sw' => $a['title_sw'], 'title_en' => $a['title_en'], 'excerpt_sw' => $a['summary_sw'], 'excerpt_en' => $a['summary_en'], 'url' => '/elimu/' . $a['slug']];
        }
        foreach (DB::all('SELECT id, name, location FROM institutions WHERE is_published = 1 AND (name LIKE ? OR short_name LIKE ? OR location LIKE ?) LIMIT 15', [$like, $like, $like]) as $i) {
            $results[] = ['type' => 'institution', 'title_sw' => $i['name'], 'title_en' => $i['name'], 'excerpt_sw' => $i['location'], 'excerpt_en' => $i['location'], 'url' => '/vyuo?q=' . rawurlencode($i['name'])];
        }
        foreach (DB::all('SELECT id, title_sw, title_en, academic_year FROM guidebooks WHERE is_published = 1 AND (title_sw LIKE ? OR title_en LIKE ? OR description_sw LIKE ?) LIMIT 10', [$like, $like, $like]) as $g) {
            $results[] = ['type' => 'guidebook', 'title_sw' => $g['title_sw'], 'title_en' => $g['title_en'], 'excerpt_sw' => $g['academic_year'], 'excerpt_en' => $g['academic_year'], 'url' => '/miongozo?q=' . rawurlencode($g['title_sw'])];
        }
        foreach (DB::all('SELECT id, title_sw, title_en FROM announcements WHERE is_published = 1 AND (title_sw LIKE ? OR title_en LIKE ? OR body_sw LIKE ?) LIMIT 10', [$like, $like, $like]) as $a) {
            $results[] = ['type' => 'announcement', 'title_sw' => $a['title_sw'], 'title_en' => $a['title_en'], 'excerpt_sw' => null, 'excerpt_en' => null, 'url' => '/matangazo#a' . $a['id']];
        }
        foreach (DB::all('SELECT id, question_sw, question_en FROM faqs WHERE is_published = 1 AND (question_sw LIKE ? OR question_en LIKE ? OR answer_sw LIKE ? OR keywords LIKE ?) LIMIT 10', [$like, $like, $like, $like]) as $f) {
            $results[] = ['type' => 'faq', 'title_sw' => $f['question_sw'], 'title_en' => $f['question_en'], 'excerpt_sw' => null, 'excerpt_en' => null, 'url' => '/faq#q' . $f['id']];
        }
        Response::ok(['query' => $q, 'results' => $results]);
    }

    // ---------------------------------------------------------------- contact & analytics

    public static function contact(Request $r): void
    {
        RateLimiter::hit('contact:' . $r->ip(), 5, 3600);
        if ($r->str('website') !== '') { // honeypot
            Response::ok();
        }
        $data = Validator::validate($r->body(), [
            'name' => 'required|string|max:120',
            'phone' => 'phone',
            'email' => 'email|max:190',
            'message' => 'required|string|min:5|max:3000',
        ]);
        if (empty($data['phone']) && empty($data['email'])) {
            throw HttpException::validation(['phone' => 'phone_or_email']);
        }
        DB::insert('contact_messages', $data + ['created_at' => DB::now()]);
        Response::created();
    }

    /** Privacy-respecting page view counter: salted daily hash, no IP stored. */
    public static function track(Request $r): void
    {
        if (RateLimiter::tooMany('track:' . $r->ip(), 300, 3600)) {
            Response::ok();
        }
        $day = date('Y-m-d');
        $salt = (string) Settings::get('analytics_salt', '');
        $hash = hash('sha256', $salt . '|' . $day . '|' . $r->ip() . '|' . $r->userAgent());
        DB::run(
            'INSERT INTO visitor_days (visit_day, visitor_hash, page_views) VALUES (?, ?, 1)
             ON DUPLICATE KEY UPDATE page_views = page_views + 1',
            [$day, $hash]
        );
        Response::ok();
    }

    /** Serve public media (logos, article images, guidebook PDFs). */
    public static function media(Request $r): void
    {
        $m = DB::one('SELECT * FROM media WHERE id = ?', [$r->intParam('id')]);
        if (!$m) {
            throw HttpException::notFound();
        }
        $path = Uploads::path($m['stored_name']);
        if (!is_file($path)) {
            throw HttpException::notFound();
        }
        $isImage = str_starts_with($m['mime'], 'image/');
        header('Content-Type: ' . $m['mime']);
        header('Content-Length: ' . filesize($path));
        header('Cache-Control: public, max-age=604800');
        header('X-Content-Type-Options: nosniff');
        $disposition = ($isImage || $r->query('download') !== '1') ? 'inline' : 'attachment';
        header(sprintf('Content-Disposition: %s; filename="%s"', $disposition, preg_replace('/[^A-Za-z0-9._-]/', '_', $m['original_name'])));
        readfile($path);
        exit;
    }
}
