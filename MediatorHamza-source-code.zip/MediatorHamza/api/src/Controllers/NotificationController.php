<?php
declare(strict_types=1);

namespace Mediator\Controllers;

use Mediator\Core\Auth;
use Mediator\Core\DB;
use Mediator\Core\Request;
use Mediator\Core\Response;

final class NotificationController
{
    /** @return list<array<string,mixed>> */
    public static function latest(int $userId, int $limit, int $offset = 0): array
    {
        return array_map(static fn ($n) => [
            'id' => (int) $n['id'],
            'type' => $n['type'],
            'title_sw' => $n['title_sw'],
            'title_en' => $n['title_en'],
            'body_sw' => $n['body_sw'],
            'body_en' => $n['body_en'],
            'link' => $n['link'],
            'read' => $n['read_at'] !== null,
            'created_at' => $n['created_at'],
        ], DB::all(
            'SELECT * FROM notifications WHERE user_id = ? ORDER BY id DESC LIMIT ? OFFSET ?',
            [$userId, $limit, $offset]
        ));
    }

    public static function index(Request $r): void
    {
        $user = Auth::requireUser();
        $page = $r->queryInt('page', 1);
        $per = 20;
        $uid = (int) $user['id'];
        Response::ok([
            'items' => self::latest($uid, $per, ($page - 1) * $per),
            'total' => (int) DB::value('SELECT COUNT(*) FROM notifications WHERE user_id = ?', [$uid]),
            'unread' => (int) DB::value('SELECT COUNT(*) FROM notifications WHERE user_id = ? AND read_at IS NULL', [$uid]),
            'page' => $page,
            'per_page' => $per,
        ]);
    }

    /** Lightweight poll used by the app shell for badges & browser notifications. */
    public static function counts(Request $r): void
    {
        $user = Auth::requireUser();
        $uid = (int) $user['id'];
        $since = $r->queryInt('since', 0, 0);
        $out = [
            'unread' => (int) DB::value('SELECT COUNT(*) FROM notifications WHERE user_id = ? AND read_at IS NULL', [$uid]),
            'unread_messages' => (int) DB::value(
                'SELECT COUNT(*) FROM messages m JOIN conversations c ON c.id = m.conversation_id
                 WHERE c.user_id = ? AND m.from_staff = 1 AND m.read_at IS NULL',
                [$uid]
            ),
            'latest_id' => (int) DB::value('SELECT COALESCE(MAX(id),0) FROM notifications WHERE user_id = ?', [$uid]),
            'new' => [],
        ];
        if ($since > 0) {
            $out['new'] = array_map(static fn ($n) => [
                'id' => (int) $n['id'], 'title_sw' => $n['title_sw'], 'title_en' => $n['title_en'],
                'body_sw' => $n['body_sw'], 'body_en' => $n['body_en'], 'link' => $n['link'],
            ], DB::all('SELECT * FROM notifications WHERE user_id = ? AND id > ? ORDER BY id LIMIT 5', [$uid, $since]));
        }
        Response::ok($out);
    }

    public static function markRead(Request $r): void
    {
        $user = Auth::requireUser();
        DB::run('UPDATE notifications SET read_at = ? WHERE id = ? AND user_id = ? AND read_at IS NULL', [DB::now(), $r->intParam('id'), $user['id']]);
        Response::ok();
    }

    public static function delete(Request $r): void
    {
        $user = Auth::requireUser();
        DB::run('DELETE FROM notifications WHERE id = ? AND user_id = ?', [$r->intParam('id'), $user['id']]);
        Response::ok();
    }

    /** Remove every notification of the current user. */
    public static function clear(Request $r): void
    {
        $user = Auth::requireUser();
        DB::run('DELETE FROM notifications WHERE user_id = ?', [$user['id']]);
        Response::ok();
    }

    public static function markAllRead(Request $r): void
    {
        $user = Auth::requireUser();
        DB::run('UPDATE notifications SET read_at = ? WHERE user_id = ? AND read_at IS NULL', [DB::now(), $user['id']]);
        Response::ok();
    }
}
