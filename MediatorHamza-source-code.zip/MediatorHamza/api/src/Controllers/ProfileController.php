<?php
declare(strict_types=1);

namespace Mediator\Controllers;

use Mediator\Core\Applications;
use Mediator\Core\Auth;
use Mediator\Core\DB;
use Mediator\Core\HttpException;
use Mediator\Core\RateLimiter;
use Mediator\Core\Request;
use Mediator\Core\Response;
use Mediator\Core\Validator;

final class ProfileController
{
    public static function update(Request $r): void
    {
        $user = Auth::requireUser();
        $data = Validator::validate($r->body(), [
            'first_name' => 'required|string|max:80',
            'second_name' => 'required|string|max:80',
            'last_name' => 'string|max:80',
            'email' => 'email|max:190',
            'language' => 'in:sw,en',
        ]);
        foreach (['first_name', 'second_name', 'last_name'] as $k) {
            if (!empty($data[$k]) && !preg_match("/^[\\p{L}' .-]{2,80}$/u", $data[$k])) {
                throw HttpException::validation([$k => 'invalid_name']);
            }
        }
        DB::update('users', [
            'first_name' => $data['first_name'],
            'second_name' => $data['second_name'],
            'last_name' => $data['last_name'] ?: null,
            'email' => $data['email'] ?: null,
            'language' => $data['language'] ?? $user['language'],
            'updated_at' => DB::now(),
        ], ['id' => $user['id']]);
        $fresh = DB::one('SELECT * FROM users WHERE id = ?', [$user['id']]);
        Response::ok(Auth::publicUser($fresh));
    }

    public static function language(Request $r): void
    {
        $user = Auth::requireUser();
        $lang = $r->str('language');
        if (!in_array($lang, ['sw', 'en'], true)) {
            throw HttpException::validation(['language' => 'invalid']);
        }
        DB::update('users', ['language' => $lang], ['id' => $user['id']]);
        Response::ok();
    }

    public static function changePassword(Request $r): void
    {
        $user = Auth::requireUser();
        RateLimiter::hit('pwchange:' . $user['id'], 10, 3600);
        $data = Validator::validate($r->body(), [
            'current_password' => 'required|string',
            'password' => 'required|string|min:8|max:200',
            'password_confirmation' => 'required|string',
        ]);
        if (!password_verify($data['current_password'], $user['password_hash'])) {
            throw HttpException::validation(['current_password' => 'password_incorrect']);
        }
        if ($data['password'] !== $data['password_confirmation']) {
            throw HttpException::validation(['password_confirmation' => 'password_mismatch']);
        }
        $minLen = Auth::isStaff($user) ? 12 : 8;
        if (mb_strlen($data['password']) < $minLen || !AuthController::strongEnough($data['password'])) {
            throw HttpException::validation(['password' => 'password_weak']);
        }
        // Bump session_version so other devices are logged out, then re-login this session.
        DB::run('UPDATE users SET password_hash = ?, session_version = session_version + 1, updated_at = ? WHERE id = ?', [
            password_hash($data['password'], PASSWORD_DEFAULT), DB::now(), $user['id'],
        ]);
        AuthController::logEvent((int) $user['id'], 'password_changed', $r);
        Auth::login(DB::one('SELECT * FROM users WHERE id = ?', [$user['id']]));
        Response::ok(['csrf' => Auth::csrfToken()]);
    }

    public static function activity(Request $r): void
    {
        $user = Auth::requireUser();
        $events = DB::all(
            'SELECT event, ip_address, user_agent, created_at FROM login_events WHERE user_id = ? ORDER BY id DESC LIMIT 30',
            [$user['id']]
        );
        Response::ok($events);
    }

    /** Dashboard aggregate for the logged-in user. */
    public static function dashboard(Request $r): void
    {
        $user = Auth::requireUser();
        $uid = (int) $user['id'];
        $apps = DB::all(
            'SELECT a.*, s.code AS service_code, s.slug AS service_slug, s.icon AS service_icon,
                    s.name_sw AS service_name_sw, s.name_en AS service_name_en
             FROM applications a JOIN services s ON s.id = a.service_id
             WHERE a.user_id = ? ORDER BY a.updated_at DESC LIMIT 50',
            [$uid]
        );
        $counts = [];
        foreach ($apps as $a) {
            $counts[$a['status']] = ($counts[$a['status']] ?? 0) + 1;
        }
        $pendingDocs = array_values(array_filter($apps, static fn ($a) => in_array($a['status'], ['correction_required', 'awaiting_info'], true)));
        Response::ok([
            'applications' => array_map([Applications::class, 'summary'], array_slice($apps, 0, 6)),
            'status_counts' => $counts,
            'total_applications' => count($apps),
            'needs_action' => array_map([Applications::class, 'summary'], $pendingDocs),
            'unpaid' => array_map([Applications::class, 'summary'], array_values(array_filter(
                $apps,
                static fn ($a) => $a['status'] !== 'draft' && $a['status'] !== 'cancelled' && $a['payment_status'] === 'unpaid' && $a['price_snapshot'] > 0
            ))),
            'notifications' => NotificationController::latest($uid, 5),
            'unread_notifications' => (int) DB::value('SELECT COUNT(*) FROM notifications WHERE user_id = ? AND read_at IS NULL', [$uid]),
            'unread_messages' => (int) DB::value(
                'SELECT COUNT(*) FROM messages m JOIN conversations c ON c.id = m.conversation_id
                 WHERE c.user_id = ? AND m.from_staff = 1 AND m.read_at IS NULL',
                [$uid]
            ),
            'deadlines' => PublicController::upcomingDeadlines(5),
            'announcements' => PublicController::latestAnnouncements(3),
        ]);
    }
}
