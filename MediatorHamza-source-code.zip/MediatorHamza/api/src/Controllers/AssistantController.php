<?php
declare(strict_types=1);

namespace Mediator\Controllers;

use Mediator\Core\DB;
use Mediator\Core\RateLimiter;
use Mediator\Core\Request;
use Mediator\Core\Response;

/**
 * Rule-based help assistant (optional feature). It ONLY answers from content the
 * admin has published (FAQs, services/prices, deadlines) and always hands off to
 * a human for anything it cannot match. It never claims to have verified an
 * application or a payment.
 */
final class AssistantController
{
    private const STOPWORDS = ['ya', 'na', 'wa', 'kwa', 'ni', 'je', 'la', 'za', 'cha', 'vya', 'the', 'a', 'an', 'is', 'to', 'of',
        'how', 'what', 'do', 'i', 'my', 'nini', 'gani', 'vipi', 'nina', 'naomba', 'nataka', 'kuhusu', 'in', 'for', 'can'];

    public static function ask(Request $r): void
    {
        RateLimiter::hit('assistant:' . $r->ip(), 40, 600);
        $question = mb_substr(trim($r->str('question')), 0, 400);
        $lang = $r->str('language') === 'en' ? 'en' : 'sw';
        $words = self::tokens($question);
        if ($words === []) {
            Response::ok(self::fallback($lang));
        }

        $answers = [];
        // 1. FAQ matches
        foreach (DB::all('SELECT * FROM faqs WHERE is_published = 1') as $f) {
            $hay = self::tokens(implode(' ', [$f['question_sw'], $f['question_en'], $f['keywords'], $f['answer_sw']]));
            $score = count(array_intersect($words, $hay));
            if ($score > 0) {
                $answers[] = ['score' => $score / max(3, count($words)), 'text' => $lang === 'en' && $f['answer_en'] ? $f['answer_en'] : $f['answer_sw'],
                    'title' => $lang === 'en' && $f['question_en'] ? $f['question_en'] : $f['question_sw'], 'link' => '/faq#q' . $f['id']];
            }
        }
        // 2. Prices / services
        $priceWords = ['bei', 'gharama', 'price', 'cost', 'shilingi', 'kiasi', 'malipo', 'lipa'];
        $asksPrice = array_intersect($words, $priceWords) !== [];
        foreach (DB::all('SELECT * FROM services WHERE is_active = 1') as $s) {
            $hay = self::tokens($s['name_sw'] . ' ' . $s['name_en'] . ' ' . $s['code'] . ' ' . $s['summary_sw']);
            $score = count(array_intersect($words, $hay));
            if ($score > 0) {
                $name = $lang === 'en' && $s['name_en'] ? $s['name_en'] : $s['name_sw'];
                $price = $s['price'] !== null ? number_format((int) $s['price']) . ' TZS' : ($lang === 'en' ? 'not set' : 'haijawekwa');
                $text = $lang === 'en'
                    ? "{$name}: service fee {$price}. " . ($s['accepting'] ? 'Applications are open — log in and choose "Request Service".' : 'Applications are currently closed.')
                    : "{$name}: gharama ya huduma {$price}. " . ($s['accepting'] ? 'Maombi yako wazi — ingia kwenye akaunti yako kisha bonyeza "Omba Huduma".' : 'Maombi yamefungwa kwa sasa.');
                $answers[] = ['score' => $score / max(3, count($words)) + ($asksPrice ? 0.5 : 0.1), 'text' => $text, 'title' => $name, 'link' => '/huduma/' . $s['slug']];
            }
        }
        // 3. Deadlines
        $deadlineWords = ['deadline', 'mwisho', 'tarehe', 'lini', 'when', 'closing', 'dirisha'];
        if (array_intersect($words, $deadlineWords) !== []) {
            $items = PublicController::upcomingDeadlines(5);
            if ($items) {
                $lines = array_map(static fn ($d) => '• ' . ($lang === 'en' && $d['title_en'] ? $d['title_en'] : $d['title_sw']) . ': ' . date('d/m/Y', strtotime($d['closes_at'])), $items);
                $answers[] = ['score' => 0.9, 'title' => $lang === 'en' ? 'Published deadlines' : 'Deadlines zilizochapishwa',
                    'text' => implode("\n", $lines), 'link' => '/deadlines'];
            }
        }
        usort($answers, static fn ($a, $b) => $b['score'] <=> $a['score']);
        $answers = array_slice(array_filter($answers, static fn ($a) => $a['score'] >= 0.2), 0, 3);
        if ($answers === []) {
            Response::ok(self::fallback($lang));
        }
        Response::ok([
            'answers' => array_values(array_map(static fn ($a) => ['title' => $a['title'], 'text' => $a['text'], 'link' => $a['link']], $answers)),
            'disclaimer' => $lang === 'en'
                ? 'These answers come from information published by Mediator. For your specific application or payment, please chat with the admin.'
                : 'Majibu haya yanatokana na taarifa zilizochapishwa na Mediator. Kwa ombi au malipo yako mahususi, tafadhali wasiliana na admin.',
            'handoff' => true,
        ]);
    }

    /** @return array<string,mixed> */
    private static function fallback(string $lang): array
    {
        return [
            'answers' => [],
            'disclaimer' => $lang === 'en'
                ? "I'm not sure about that. Please send your question to the admin through the chat and you will get help."
                : 'Sina uhakika na jibu la swali hili. Tafadhali tuma swali lako kwa admin kupitia Chat na utasaidiwa.',
            'handoff' => true,
        ];
    }

    /** @return list<string> */
    private static function tokens(string $text): array
    {
        $text = mb_strtolower($text);
        $parts = preg_split('/[^\p{L}\p{N}]+/u', $text, -1, PREG_SPLIT_NO_EMPTY) ?: [];
        $out = [];
        foreach ($parts as $p) {
            if (mb_strlen($p) < 3 && !in_array($p, ['tcu', 'nida'], true) || in_array($p, self::STOPWORDS, true)) {
                continue;
            }
            $out[] = $p;
        }
        return array_values(array_unique($out));
    }
}
