<?php
declare(strict_types=1);

namespace Mediator\Controllers\Admin;

use Mediator\Controllers\PublicController;
use Mediator\Core\Auth;
use Mediator\Core\DB;
use Mediator\Core\Request;
use Mediator\Core\Response;

final class DashboardController
{
    public static function stats(Request $r): void
    {
        Auth::requireStaff('dashboard.view');
        $byStatus = [];
        foreach (DB::all("SELECT status, COUNT(*) AS n FROM applications WHERE status <> 'draft' GROUP BY status") as $row) {
            $byStatus[$row['status']] = (int) $row['n'];
        }
        $byService = DB::all(
            "SELECT s.code, s.name_sw, s.name_en, COUNT(a.id) AS total,
                    SUM(a.status IN ('received','in_progress','awaiting_info','correction_required','on_hold')) AS active
             FROM services s LEFT JOIN applications a ON a.service_id = s.id AND a.status <> 'draft'
             GROUP BY s.id ORDER BY total DESC"
        );
        $visitors = DB::all(
            'SELECT visit_day, COUNT(*) AS visitors, SUM(page_views) AS views FROM visitor_days
             WHERE visit_day >= DATE_SUB(CURDATE(), INTERVAL 29 DAY) GROUP BY visit_day ORDER BY visit_day'
        );
        $daily = DB::all(
            "SELECT DATE(submitted_at) AS day, COUNT(*) AS n FROM applications
             WHERE submitted_at >= DATE_SUB(CURDATE(), INTERVAL 29 DAY) GROUP BY DATE(submitted_at) ORDER BY day"
        );
        Response::ok([
            'users_total' => (int) DB::value("SELECT COUNT(*) FROM users WHERE role = 'user'"),
            'users_new_7d' => (int) DB::value("SELECT COUNT(*) FROM users WHERE role = 'user' AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)"),
            'applications_total' => array_sum($byStatus),
            'applications_received' => $byStatus['received'] ?? 0,
            'applications_in_progress' => ($byStatus['in_progress'] ?? 0),
            'applications_completed' => $byStatus['completed'] ?? 0,
            'applications_awaiting_docs' => ($byStatus['awaiting_info'] ?? 0) + ($byStatus['correction_required'] ?? 0),
            'by_status' => $byStatus,
            'by_service' => array_map(static fn ($s) => [
                'code' => $s['code'], 'name_sw' => $s['name_sw'], 'name_en' => $s['name_en'],
                'total' => (int) $s['total'], 'active' => (int) $s['active'],
            ], $byService),
            'unpaid' => (int) DB::value("SELECT COUNT(*) FROM applications WHERE status NOT IN ('draft','cancelled') AND payment_status = 'unpaid' AND price_snapshot > 0"),
            'new_applications' => (int) DB::value("SELECT COUNT(*) FROM applications WHERE status <> 'draft' AND admin_seen_at IS NULL"),
            'drafts' => (int) DB::value("SELECT COUNT(*) FROM applications WHERE status = 'draft'"),
            'unanswered_messages' => (int) DB::value("SELECT COUNT(*) FROM conversations WHERE awaiting_reply = 1 AND status = 'open'"),
            'contact_unhandled' => (int) DB::value('SELECT COUNT(*) FROM contact_messages WHERE is_handled = 0'),
            'visitors_today' => (int) DB::value('SELECT COUNT(*) FROM visitor_days WHERE visit_day = CURDATE()'),
            'visitors_30d' => (int) DB::value('SELECT COUNT(*) FROM visitor_days WHERE visit_day >= DATE_SUB(CURDATE(), INTERVAL 29 DAY)'),
            'visitors_series' => array_map(static fn ($v) => ['day' => $v['visit_day'], 'visitors' => (int) $v['visitors'], 'views' => (int) $v['views']], $visitors),
            'applications_series' => array_map(static fn ($d) => ['day' => $d['day'], 'count' => (int) $d['n']], $daily),
            'deadlines' => PublicController::upcomingDeadlines(5),
            'recent' => array_map(static fn ($a) => [
                'id' => (int) $a['id'], 'reference' => $a['reference'], 'applicant_name' => $a['applicant_name'],
                'service_code' => $a['code'], 'status' => $a['status'], 'submitted_at' => $a['submitted_at'],
            ], DB::all(
                "SELECT a.id, a.reference, a.applicant_name, a.status, a.submitted_at, s.code FROM applications a
                 JOIN services s ON s.id = a.service_id WHERE a.status <> 'draft' ORDER BY a.submitted_at DESC LIMIT 8"
            )),
        ]);
    }
}
