<?php
declare(strict_types=1);

namespace Mediator\Controllers\Admin;

use Mediator\Controllers\MessageController;
use Mediator\Core\Applications;
use Mediator\Core\Audit;
use Mediator\Core\Auth;
use Mediator\Core\Crypto;
use Mediator\Core\DB;
use Mediator\Core\FormSchema;
use Mediator\Core\HttpException;
use Mediator\Core\Notifier;
use Mediator\Core\Request;
use Mediator\Core\Response;
use Mediator\Core\Uploads;
use Mediator\Core\Validator;

final class ApplicationAdminController
{
    /**
     * Shared filter builder (used by list + exports).
     * @return array{0:string,1:list<mixed>}
     */
    public static function filters(Request $r): array
    {
        $where = ["a.status <> 'draft'"];
        $params = [];
        if ($r->query('include_drafts') === '1') {
            $where = ['1=1'];
        }
        if ($r->query('drafts') === '1') {
            // Unfinished applications the user has started but not yet submitted.
            $where = ["a.status = 'draft'"];
        }
        if ($q = $r->query('q')) {
            $where[] = '(a.reference LIKE ? OR a.applicant_name LIKE ? OR a.applicant_phone LIKE ? OR u.phone LIKE ? OR CONCAT(u.first_name, " ", u.second_name) LIKE ?)';
            $like = DB::like($q);
            $digits = preg_replace('/\D/', '', $q);
            $phoneLike = $digits !== '' && strlen($digits) >= 4 ? DB::like(ltrim($digits, '0')) : $like;
            array_push($params, $like, $like, $phoneLike, $phoneLike, $like);
        }
        if (($s = $r->query('status')) && in_array($s, Applications::STATUSES, true)) {
            $where[] = 'a.status = ?';
            $params[] = $s;
        }
        if (($p = $r->query('payment_status')) && in_array($p, Applications::PAYMENT_STATUSES, true)) {
            $where[] = 'a.payment_status = ?';
            $params[] = $p;
        }
        if ($svc = $r->query('service')) {
            $where[] = 's.code = ?';
            $params[] = strtoupper($svc);
        }
        if (($from = $r->query('from')) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $from)) {
            $where[] = 'a.submitted_at >= ?';
            $params[] = $from . ' 00:00:00';
        }
        if (($to = $r->query('to')) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $to)) {
            $where[] = 'a.submitted_at <= ?';
            $params[] = $to . ' 23:59:59';
        }
        if ($uid = $r->query('user_id')) {
            $where[] = 'a.user_id = ?';
            $params[] = (int) $uid;
        }
        return [implode(' AND ', $where), $params];
    }

    public static function index(Request $r): void
    {
        Auth::requireStaff('applications.view');
        [$where, $params] = self::filters($r);
        $page = $r->queryInt('page', 1);
        $per = $r->queryInt('per_page', 25, 5, 100);
        $base = "FROM applications a JOIN services s ON s.id = a.service_id JOIN users u ON u.id = a.user_id WHERE {$where}";
        $total = (int) DB::value("SELECT COUNT(*) {$base}", $params);
        $sort = match ($r->query('sort')) {
            'oldest' => 'a.submitted_at ASC',
            'updated' => 'a.updated_at DESC',
            default => 'COALESCE(a.submitted_at, a.created_at) DESC',
        };
        $rows = DB::all(
            "SELECT a.*, s.code AS service_code, s.slug AS service_slug, s.icon AS service_icon, s.name_sw AS service_name_sw,
                    s.name_en AS service_name_en, s.form_key, u.first_name, u.second_name, u.phone AS user_phone
             {$base} ORDER BY {$sort} LIMIT ? OFFSET ?",
            array_merge($params, [$per, ($page - 1) * $per])
        );
        Response::ok([
            'items' => array_map(static function ($a) {
                $item = Applications::summary($a) + [
                    'user_name' => trim($a['first_name'] . ' ' . $a['second_name']),
                    'user_phone' => $a['user_phone'],
                    'is_new' => $a['status'] !== 'draft' && $a['admin_seen_at'] === null,
                ];
                if ($a['status'] === 'draft') {
                    try {
                        $item['progress'] = FormSchema::load($a['form_key'])->progress(Applications::formData($a, true));
                    } catch (\Throwable) {
                        $item['progress'] = null;
                    }
                }
                return $item;
            }, $rows),
            'total' => $total, 'page' => $page, 'per_page' => $per,
        ]);
    }

    public static function show(Request $r): void
    {
        $staff = Auth::requireStaff('applications.view');
        $app = Applications::find($r->intParam('id'));
        $canSensitive = Auth::can($staff, 'applications.sensitive');
        $user = DB::one('SELECT id, first_name, second_name, last_name, phone, email, status, created_at FROM users WHERE id = ?', [$app['user_id']]);
        if ($canSensitive) {
            Audit::log('application.viewed_sensitive', 'application', (int) $app['id']);
        }
        $schema = FormSchema::load($app['form_key']);
        if ($app['status'] !== 'draft' && ($app['admin_seen_at'] ?? null) === null) {
            DB::run('UPDATE applications SET admin_seen_at = ? WHERE id = ?', [DB::now(), $app['id']]);
        }
        Response::ok(array_merge(Applications::summary($app), [
            'progress' => $app['status'] === 'draft' ? $schema->progress(Applications::formData($app, true)) : null,
            'form_key' => $app['form_key'],
            'data' => Applications::formData($app, $canSensitive),
            'sensitive_hidden' => !$canSensitive ? $schema->sensitiveKeys() : [],
            'files' => Applications::files((int) $app['id']),
            'result_files' => Applications::files((int) $app['id'], 'result'),
            'timeline' => Applications::timeline((int) $app['id'], true),
            'results' => Auth::can($staff, 'applications.results') ? Applications::results((int) $app['id']) : [],
            'payments' => DB::all(
                'SELECT p.*, u.first_name AS recorded_by_name FROM payment_records p LEFT JOIN users u ON u.id = p.recorded_by
                 WHERE p.application_id = ? ORDER BY p.id DESC',
                [$app['id']]
            ),
            'changes' => array_map(static fn ($c) => [
                'fields' => json_decode((string) $c['changed_fields'], true), 'reason' => $c['reason'], 'created_at' => $c['created_at'],
            ], DB::all('SELECT * FROM application_changes WHERE application_id = ? ORDER BY id DESC', [$app['id']])),
            'editable_fields' => json_decode((string) ($app['editable_fields'] ?? 'null'), true),
            'correction_message' => $app['correction_message'],
            'next_action' => $app['next_action'],
            'user' => $user,
            'conversations' => array_map(static fn ($c) => ['id' => (int) $c['id'], 'subject' => $c['subject'], 'status' => $c['status']],
                DB::all('SELECT id, subject, status FROM conversations WHERE application_id = ? ORDER BY id DESC', [$app['id']])),
        ]));
    }

    public static function updateStatus(Request $r): void
    {
        $staff = Auth::requireStaff('applications.update');
        $app = Applications::find($r->intParam('id'));
        $data = Validator::validate($r->body(), [
            'status' => 'required|in:' . implode(',', array_diff(Applications::STATUSES, ['draft'])),
            'public_message' => 'string|max:3000',
            'internal_note' => 'string|max:3000',
            'next_action' => 'string|max:400',
        ]);
        if ($app['status'] === 'draft') {
            throw new HttpException(409, 'draft', 'Rasimu haiwezi kubadilishwa status.');
        }
        $editable = null;
        if ($data['status'] === 'correction_required') {
            $fields = $r->input('editable_fields', []);
            $schema = FormSchema::load($app['form_key']);
            $editable = [];
            foreach (is_array($fields) ? $fields : [] as $f) {
                if ($f === '*' || $schema->hasField((string) $f)) {
                    $editable[] = (string) $f;
                }
            }
            if ($editable === []) {
                throw HttpException::validation(['editable_fields' => 'required']);
            }
            if (empty($data['public_message'])) {
                throw HttpException::validation(['public_message' => 'required']);
            }
        }
        $now = DB::now();
        DB::transaction(static function () use ($app, $data, $editable, $staff, $now): void {
            DB::update('applications', [
                'status' => $data['status'],
                'editable_fields' => $editable !== null ? json_encode($editable) : null,
                'correction_message' => $data['status'] === 'correction_required' ? $data['public_message'] : null,
                'next_action' => $data['next_action'] ?: null,
                'completed_at' => $data['status'] === 'completed' ? $now : $app['completed_at'],
                'updated_at' => $now,
            ], ['id' => $app['id']]);
            Applications::recordStatus((int) $app['id'], $app['status'], $data['status'], $data['public_message'] ?: null,
                $data['internal_note'] ?: null, $data['next_action'] ?: null, (int) $staff['id']);
        });
        $ref = $app['reference'];
        $labelSw = Applications::label($data['status'], 'sw');
        $labelEn = Applications::label($data['status'], 'en');
        Notifier::notify(
            (int) $app['user_id'], 'status_changed',
            "Ombi {$ref}: {$labelSw}",
            $data['public_message'] ?: "Hali ya ombi lako imebadilika kuwa: {$labelSw}.",
            '/app/maombi/' . $app['id'],
            "Application {$ref}: {$labelEn}",
            $data['public_message'] ?: "Your application status changed to: {$labelEn}.",
        );
        Notifier::smsUser((int) $app['user_id'], "Mediator Hamza: Ombi {$ref} sasa ni '{$labelSw}'. Ingia mediatorhamza.com kuona maelezo.");
        Audit::log('application.status', 'application', (int) $app['id'], ['from' => $app['status'], 'to' => $data['status']]);
        Response::ok();
    }

    /** Internal note without changing the status. */
    public static function addNote(Request $r): void
    {
        $staff = Auth::requireStaff('applications.update');
        $app = Applications::find($r->intParam('id'));
        $note = mb_substr($r->str('internal_note'), 0, 3000);
        if ($note === '') {
            throw HttpException::validation(['internal_note' => 'required']);
        }
        Applications::recordStatus((int) $app['id'], $app['status'], $app['status'], null, $note, null, (int) $staff['id']);
        Response::created();
    }

    public static function updatePayment(Request $r): void
    {
        $staff = Auth::requireStaff('payments.update');
        $app = Applications::find($r->intParam('id'));
        $data = Validator::validate($r->body(), [
            'payment_status' => 'required|in:' . implode(',', Applications::PAYMENT_STATUSES),
            'amount' => 'int',
            'method' => 'string|max:60',
            'transaction_ref' => 'string|max:100',
            'note' => 'string|max:400',
        ]);
        DB::update('applications', ['payment_status' => $data['payment_status'], 'updated_at' => DB::now()], ['id' => $app['id']]);
        DB::insert('payment_records', [
            'application_id' => $app['id'], 'status' => $data['payment_status'], 'amount' => $data['amount'],
            'method' => $data['method'], 'transaction_ref' => $data['transaction_ref'], 'note' => $data['note'],
            'recorded_by' => $staff['id'], 'created_at' => DB::now(),
        ]);
        $l = Applications::PAYMENT_LABELS[$data['payment_status']];
        Notifier::notify((int) $app['user_id'], 'payment', "Malipo: {$l[0]}", "Hali ya malipo ya ombi {$app['reference']} imesasishwa: {$l[0]}.",
            '/app/maombi/' . $app['id'], "Payment: {$l[1]}", "Payment status for {$app['reference']} updated: {$l[1]}.");
        Audit::log('application.payment', 'application', (int) $app['id'], ['status' => $data['payment_status'], 'amount' => $data['amount']]);
        Response::ok();
    }

    /** Result/feedback for the applicant (e.g. portal username/password, next steps). Stored encrypted. */
    public static function addResult(Request $r): void
    {
        $staff = Auth::requireStaff('applications.results');
        $app = Applications::find($r->intParam('id'));
        $data = Validator::validate($r->body(), [
            'title' => 'required|string|max:200',
            'body' => 'required|string|max:10000',
            'notify' => 'bool',
        ]);
        $id = DB::insert('application_results', [
            'application_id' => $app['id'], 'title' => $data['title'], 'body_encrypted' => Crypto::encrypt($data['body']),
            'created_by' => $staff['id'], 'created_at' => DB::now(),
        ]);
        if ($data['notify'] !== false) {
            Notifier::notify((int) $app['user_id'], 'result', "Mrejesho wa ombi {$app['reference']}",
                'Umepokea mrejesho mpya kuhusu ombi lako. Ingia kuona maelezo.', '/app/maombi/' . $app['id'],
                "Feedback on {$app['reference']}", 'You have new feedback on your application. Log in to view it.');
        }
        Audit::log('application.result_added', 'application', (int) $app['id'], ['result_id' => $id]);
        Response::created(['id' => $id]);
    }

    public static function deleteResult(Request $r): void
    {
        Auth::requireStaff('applications.results');
        $app = Applications::find($r->intParam('id'));
        DB::run('DELETE FROM application_results WHERE id = ? AND application_id = ?', [$r->intParam('resultId'), $app['id']]);
        Audit::log('application.result_deleted', 'application', (int) $app['id']);
        Response::ok();
    }

    public static function uploadResultFile(Request $r): void
    {
        $staff = Auth::requireStaff('applications.results');
        $app = Applications::find($r->intParam('id'));
        $stored = Uploads::store($_FILES['file'] ?? [], 'applications/' . $app['id'], Uploads::IMAGE_TYPES + Uploads::DOC_TYPES, Uploads::maxBytes() * 2);
        $id = DB::insert('application_files', array_merge($stored, [
            'application_id' => $app['id'], 'field_key' => 'result', 'kind' => 'result',
            'uploaded_by' => $staff['id'], 'created_at' => DB::now(),
        ]));
        Notifier::notify((int) $app['user_id'], 'result', "Nyaraka mpya: {$app['reference']}", 'Umetumiwa nyaraka mpya za kupakua.',
            '/app/maombi/' . $app['id'], "New document: {$app['reference']}", 'A new document is available to download.');
        Audit::log('application.result_file', 'application', (int) $app['id'], ['file_id' => $id]);
        Response::created(['id' => $id]);
    }

    public static function deleteResultFile(Request $r): void
    {
        Auth::requireStaff('applications.results');
        $app = Applications::find($r->intParam('id'));
        $file = DB::one("SELECT * FROM application_files WHERE id = ? AND application_id = ? AND kind = 'result'", [$r->intParam('fileId'), $app['id']]);
        if (!$file) {
            throw HttpException::notFound();
        }
        DB::run('DELETE FROM application_files WHERE id = ?', [$file['id']]);
        Uploads::delete($file['stored_name']);
        Response::ok();
    }

    public static function downloadFile(Request $r): void
    {
        $staff = Auth::requireStaff('applications.view');
        $app = Applications::find($r->intParam('id'));
        $file = DB::one('SELECT * FROM application_files WHERE id = ? AND application_id = ?', [$r->intParam('fileId'), $app['id']]);
        if (!$file) {
            throw HttpException::notFound();
        }
        Audit::log('application.file_downloaded', 'application', (int) $app['id'], ['file_id' => (int) $file['id']]);
        Response::file(Uploads::path($file['stored_name']), $file['mime'], ($app['reference'] ?? 'draft') . '-' . $file['original_name'], $r->query('inline') === '1');
    }

    /** Start a conversation with the applicant from the admin side. */
    public static function message(Request $r): void
    {
        $staff = Auth::requireStaff('messages.manage');
        $app = Applications::find($r->intParam('id'));
        $body = mb_substr($r->str('body'), 0, 4000);
        if ($body === '') {
            throw HttpException::validation(['body' => 'required']);
        }
        $now = DB::now();
        $cid = DB::insert('conversations', [
            'user_id' => $app['user_id'], 'application_id' => $app['id'],
            'subject' => mb_substr($r->str('subject') ?: ('Ombi ' . $app['reference']), 0, 200),
            'status' => 'open', 'awaiting_reply' => 0, 'last_message_at' => $now, 'created_at' => $now,
        ]);
        MessageController::staffReply($cid, (int) $staff['id'], $body);
        Response::created(['id' => $cid]);
    }
}
