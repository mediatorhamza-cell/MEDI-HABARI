<?php
declare(strict_types=1);

namespace Mediator\Controllers\Admin;

use Mediator\Core\Audit;
use Mediator\Core\Auth;
use Mediator\Core\DB;
use Mediator\Core\HttpException;
use Mediator\Core\Request;
use Mediator\Core\Response;
use Mediator\Core\Validator;

/** Services, prices and packages. Price changes never alter submitted applications (price is snapshotted). */
final class ServiceAdminController
{
    public static function index(Request $r): void
    {
        Auth::requireStaff('services.manage');
        $services = DB::all('SELECT * FROM services ORDER BY sort_order, id');
        $packages = DB::all('SELECT * FROM service_packages ORDER BY sort_order, id');
        foreach ($services as &$s) {
            $s['packages'] = array_values(array_filter($packages, static fn ($p) => (int) $p['service_id'] === (int) $s['id']));
        }
        Response::ok($services);
    }

    public static function update(Request $r): void
    {
        Auth::requireStaff('services.manage');
        $id = $r->intParam('id');
        $existing = DB::one('SELECT * FROM services WHERE id = ?', [$id]);
        if (!$existing) {
            throw HttpException::notFound();
        }
        $rules = [
            'name_sw' => 'required|string|max:150', 'name_en' => 'string|max:150',
            'summary_sw' => 'string|max:400', 'summary_en' => 'string|max:400',
            'details_sw' => 'string|max:50000', 'details_en' => 'string|max:50000',
            'requirements_sw' => 'string|max:10000', 'requirements_en' => 'string|max:10000',
            'price' => 'int', 'price_note_sw' => 'string|max:200', 'price_note_en' => 'string|max:200',
            'icon' => 'string|max:40', 'is_active' => 'bool', 'accepting' => 'bool', 'sort_order' => 'int',
        ];
        $body = $r->body();
        $data = Validator::validate($body, array_intersect_key($rules, $body));
        if (isset($data['price']) && $data['price'] < 0) {
            throw HttpException::validation(['price' => 'number']);
        }
        foreach ($data as $k => $v) {
            if (is_bool($v)) {
                $data[$k] = $v ? 1 : 0;
            }
        }
        DB::update('services', $data + ['updated_at' => DB::now()], ['id' => $id]);
        if (array_key_exists('price', $data) && $data['price'] !== ($existing['price'] !== null ? (int) $existing['price'] : null)) {
            Audit::log('service.price_changed', 'service', $id, ['from' => $existing['price'], 'to' => $data['price']]);
        }
        Audit::log('service.updated', 'service', $id);
        Response::ok();
    }

    public static function savePackage(Request $r): void
    {
        Auth::requireStaff('services.manage');
        $serviceId = $r->intParam('id');
        if (DB::value('SELECT id FROM services WHERE id = ?', [$serviceId]) === null) {
            throw HttpException::notFound();
        }
        $data = Validator::validate($r->body(), [
            'id' => 'int', 'name_sw' => 'required|string|max:150', 'name_en' => 'string|max:150',
            'price' => 'required|int', 'is_active' => 'bool', 'sort_order' => 'int',
        ]);
        $row = [
            'service_id' => $serviceId, 'name_sw' => $data['name_sw'], 'name_en' => $data['name_en'],
            'price' => max(0, $data['price']), 'is_active' => $data['is_active'] ? 1 : 0, 'sort_order' => $data['sort_order'] ?? 0,
        ];
        if ($data['id']) {
            DB::update('service_packages', $row, ['id' => $data['id'], 'service_id' => $serviceId]);
            $id = $data['id'];
        } else {
            $id = DB::insert('service_packages', $row);
        }
        Audit::log('service.package_saved', 'service', $serviceId, ['package_id' => $id, 'price' => $row['price']]);
        Response::ok(['id' => $id]);
    }

    public static function deletePackage(Request $r): void
    {
        Auth::requireStaff('services.manage');
        DB::run('DELETE FROM service_packages WHERE id = ? AND service_id = ?', [$r->intParam('packageId'), $r->intParam('id')]);
        Audit::log('service.package_deleted', 'service', $r->intParam('id'), ['package_id' => $r->intParam('packageId')]);
        Response::ok();
    }
}
