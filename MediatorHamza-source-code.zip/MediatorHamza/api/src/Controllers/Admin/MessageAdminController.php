<?php
declare(strict_types=1);

namespace Mediator\Controllers\Admin;

use Mediator\Controllers\MessageController;
use Mediator\Core\Auth;
use Mediator\Core\DB;
use Mediator\Core\HttpException;
use Mediator\Core\RateLimiter;
use Mediator\Core\Request;
use Mediator\Core\Response;

final class MessageAdminController
{
    public static function index(Request $r): void
    {
        Auth::requireStaff('messages.manage');
        $where = '1=1';
        $params = [];
        $filter = $r->query('filter', 'all');
        if ($filter === 'unanswered') {
            $where = "c.awaiting_reply = 1 AND c.status = 'open'";
        } elseif ($filter === 'closed') {
            $where = "c.status = 'closed'";
        } elseif ($filter === 'open') {
            $where = "c.status = 'open'";
        }
        if ($q = $r->query('q')) {
            $where .= ' AND (c.subject LIKE ? OR u.phone LIKE ? OR CONCAT(u.first_name, " ", u.second_name) LIKE ? OR a.reference LIKE ?)';
            array_push($params, DB::like($q), DB::like(ltrim(preg_replace('/\D/', '', $q) ?: $q, '0')), DB::like($q), DB::like($q));
        }
        $rows = DB::all(
            "SELECT c.*, a.reference, u.first_name, u.second_name, u.phone,
                    (SELECT body FROM messages WHERE conversation_id = c.id ORDER BY id DESC LIMIT 1) AS last_message,
                    (SELECT COUNT(*) FROM messages WHERE conversation_id = c.id AND from_staff = 0 AND read_at IS NULL) AS unread
             FROM conversations c JOIN users u ON u.id = c.user_id LEFT JOIN applications a ON a.id = c.application_id
             WHERE {$where} ORDER BY c.awaiting_reply DESC, c.last_message_at DESC LIMIT 200",
            $params
        );
        Response::ok([
            'items' => array_map([MessageController::class, 'conversationSummary'], $rows),
            'unanswered' => (int) DB::value("SELECT COUNT(*) FROM conversations WHERE awaiting_reply = 1 AND status = 'open'"),
        ]);
    }

    public static function show(Request $r): void
    {
        Auth::requireStaff('messages.manage');
        $c = DB::one(
            'SELECT c.*, a.reference, u.first_name, u.second_name, u.phone FROM conversations c JOIN users u ON u.id = c.user_id
             LEFT JOIN applications a ON a.id = c.application_id WHERE c.id = ?',
            [$r->intParam('id')]
        );
        if (!$c) {
            throw HttpException::notFound();
        }
        DB::run('UPDATE messages SET read_at = ? WHERE conversation_id = ? AND from_staff = 0 AND read_at IS NULL', [DB::now(), $c['id']]);
        Response::ok(['conversation' => MessageController::conversationSummary($c), 'messages' => MessageController::messages((int) $c['id'])]);
    }

    public static function reply(Request $r): void
    {
        $staff = Auth::requireStaff('messages.manage');
        RateLimiter::hit('staff-msg:' . $staff['id'], 300, 3600);
        $body = mb_substr($r->str('body'), 0, 4000);
        if ($body === '') {
            throw HttpException::validation(['body' => 'required']);
        }
        MessageController::staffReply($r->intParam('id'), (int) $staff['id'], $body);
        Response::created();
    }

    public static function setStatus(Request $r): void
    {
        Auth::requireStaff('messages.manage');
        $status = $r->str('status') === 'closed' ? 'closed' : 'open';
        DB::update('conversations', ['status' => $status, 'awaiting_reply' => $status === 'closed' ? 0 : 1], ['id' => $r->intParam('id')]);
        Response::ok();
    }
}
