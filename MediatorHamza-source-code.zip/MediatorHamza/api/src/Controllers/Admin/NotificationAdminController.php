<?php
declare(strict_types=1);

namespace Mediator\Controllers\Admin;

use Mediator\Core\Applications;
use Mediator\Core\Audit;
use Mediator\Core\Auth;
use Mediator\Core\DB;
use Mediator\Core\HttpException;
use Mediator\Core\Notifier;
use Mediator\Core\Request;
use Mediator\Core\Response;
use Mediator\Core\Validator;

final class NotificationAdminController
{
    /**
     * Resolve an audience definition to user ids.
     * audience: {type: all|users|service, user_ids?: int[], service?: CODE, status?: status}
     * @return list<int>
     */
    public static function resolveAudience(array $audience): array
    {
        $type = $audience['type'] ?? 'all';
        if ($type === 'users') {
            $ids = array_values(array_filter(array_map('intval', (array) ($audience['user_ids'] ?? []))));
            if ($ids === []) {
                return [];
            }
            $in = implode(',', array_fill(0, count($ids), '?'));
            return array_map('intval', array_column(DB::all("SELECT id FROM users WHERE id IN ({$in}) AND role = 'user'", $ids), 'id'));
        }
        if ($type === 'service') {
            $sql = "SELECT DISTINCT a.user_id FROM applications a JOIN services s ON s.id = a.service_id JOIN users u ON u.id = a.user_id
                    WHERE u.role = 'user' AND u.status = 'active' AND a.status <> 'draft'";
            $params = [];
            if (!empty($audience['service'])) {
                $sql .= ' AND s.code = ?';
                $params[] = strtoupper((string) $audience['service']);
            }
            if (!empty($audience['status']) && in_array($audience['status'], Applications::STATUSES, true)) {
                $sql .= ' AND a.status = ?';
                $params[] = $audience['status'];
            }
            if (!empty($audience['payment_status']) && in_array($audience['payment_status'], Applications::PAYMENT_STATUSES, true)) {
                $sql .= ' AND a.payment_status = ?';
                $params[] = $audience['payment_status'];
            }
            return array_map('intval', array_column(DB::all($sql, $params), 'user_id'));
        }
        return array_map('intval', array_column(DB::all("SELECT id FROM users WHERE role = 'user' AND status = 'active'"), 'id'));
    }

    public static function send(Request $r): void
    {
        $staff = Auth::requireStaff('notifications.send');
        $data = Validator::validate($r->body(), [
            'title' => 'required|string|max:200',
            'body' => 'required|string|max:3000',
            'title_en' => 'string|max:200',
            'body_en' => 'string|max:3000',
            'link' => 'string|max:255',
        ]);
        $audience = $r->input('audience', ['type' => 'all']);
        if (!is_array($audience)) {
            throw HttpException::validation(['audience' => 'invalid']);
        }
        if (($audience['type'] ?? 'all') === 'all' && !Auth::can($staff, 'content.manage')) {
            throw HttpException::forbidden(); // broadcasts to everyone restricted to admins
        }
        if (!empty($data['link']) && !str_starts_with($data['link'], '/')) {
            throw HttpException::validation(['link' => 'invalid']);
        }
        $ids = self::resolveAudience($audience);
        if ($ids === []) {
            throw HttpException::validation(['audience' => 'empty_audience']);
        }
        $batchId = DB::insert('notification_batches', [
            'title' => $data['title'], 'body' => $data['body'], 'audience' => json_encode($audience),
            'recipients' => count($ids), 'sent_by' => $staff['id'], 'created_at' => DB::now(),
        ]);
        DB::transaction(static function () use ($ids, $data, $batchId): void {
            foreach ($ids as $uid) {
                Notifier::notify($uid, 'broadcast', $data['title'], $data['body'], $data['link'] ?: null,
                    $data['title_en'] ?: null, $data['body_en'] ?: null, $batchId);
            }
        });
        Audit::log('notification.sent', 'notification_batch', $batchId, ['recipients' => count($ids), 'audience' => $audience]);
        Response::created(['batch_id' => $batchId, 'recipients' => count($ids)]);
    }

    public static function preview(Request $r): void
    {
        Auth::requireStaff('notifications.send');
        $audience = $r->input('audience', ['type' => 'all']);
        Response::ok(['recipients' => count(self::resolveAudience(is_array($audience) ? $audience : []))]);
    }

    public static function history(Request $r): void
    {
        Auth::requireStaff('notifications.send');
        $page = $r->queryInt('page', 1);
        $rows = DB::all(
            'SELECT b.*, u.first_name AS sent_by_name,
                    (SELECT COUNT(*) FROM notifications n WHERE n.batch_id = b.id AND n.read_at IS NOT NULL) AS read_count
             FROM notification_batches b LEFT JOIN users u ON u.id = b.sent_by ORDER BY b.id DESC LIMIT 25 OFFSET ?',
            [($page - 1) * 25]
        );
        foreach ($rows as &$row) {
            $row['audience'] = json_decode((string) $row['audience'], true);
        }
        Response::ok(['items' => $rows, 'total' => (int) DB::value('SELECT COUNT(*) FROM notification_batches'), 'page' => $page, 'per_page' => 25]);
    }

    /** Send a deadline reminder now (also used by the cron job). */
    public static function deadlineReminder(Request $r): void
    {
        $staff = Auth::requireStaff('notifications.send');
        $d = DB::one('SELECT * FROM deadlines WHERE id = ?', [$r->intParam('id')]);
        if (!$d) {
            throw HttpException::notFound();
        }
        $count = self::sendDeadlineReminder($d, (int) $staff['id']);
        Audit::log('deadline.reminder', 'deadline', (int) $d['id'], ['recipients' => $count]);
        Response::ok(['recipients' => $count]);
    }

    public static function sendDeadlineReminder(array $d, ?int $staffId): int
    {
        $ids = self::resolveAudience(['type' => 'all']);
        $date = date('d/m/Y', strtotime($d['closes_at']));
        $titleSw = 'Kumbusho: ' . $d['title_sw'];
        $bodySw = "Mwisho wa kutuma maombi ni {$date}. Usisubiri dakika za mwisho.";
        $batchId = DB::insert('notification_batches', [
            'title' => $titleSw, 'body' => $bodySw, 'audience' => json_encode(['type' => 'all', 'deadline_id' => (int) $d['id']]),
            'recipients' => count($ids), 'sent_by' => $staffId, 'created_at' => DB::now(),
        ]);
        DB::transaction(static function () use ($ids, $d, $titleSw, $bodySw, $date, $batchId): void {
            foreach ($ids as $uid) {
                Notifier::notify($uid, 'deadline', $titleSw, $bodySw, '/deadlines',
                    'Reminder: ' . ($d['title_en'] ?: $d['title_sw']), "The application deadline is {$date}. Don't wait for the last minute.", $batchId);
            }
        });
        DB::update('deadlines', ['last_reminder_at' => DB::now()], ['id' => $d['id']]);
        return count($ids);
    }
}
