<?php
declare(strict_types=1);

namespace Mediator\Controllers\Admin;

use Mediator\Core\Audit;
use Mediator\Core\Auth;
use Mediator\Core\ContentTypes;
use Mediator\Core\DB;
use Mediator\Core\HttpException;
use Mediator\Core\Request;
use Mediator\Core\Response;
use Mediator\Core\Uploads;
use Mediator\Core\Validator;

/** Generic CRUD for admin-managed content (articles, institutions, guidebooks, deadlines, ...). */
final class ContentAdminController
{
    public static function index(Request $r): void
    {
        Auth::requireStaff('content.manage');
        $type = ContentTypes::get($r->param('type'));
        $where = '1=1';
        $params = [];
        if ($q = $r->query('q')) {
            $where = '(' . implode(' OR ', array_map(static fn ($c) => "`{$c}` LIKE ?", $type['search'])) . ')';
            $params = array_fill(0, count($type['search']), DB::like($q));
        }
        if ($type['table'] === 'categories' && ($scope = $r->query('scope'))) {
            $where .= ' AND scope = ?';
            $params[] = $scope;
        }
        $page = $r->queryInt('page', 1);
        $per = $r->queryInt('per_page', 50, 5, 200);
        $total = (int) DB::value("SELECT COUNT(*) FROM `{$type['table']}` WHERE {$where}", $params);
        $rows = DB::all(
            "SELECT * FROM `{$type['table']}` WHERE {$where} ORDER BY {$type['order']} LIMIT ? OFFSET ?",
            array_merge($params, [$per, ($page - 1) * $per])
        );
        Response::ok(['items' => $rows, 'total' => $total, 'page' => $page, 'per_page' => $per]);
    }

    public static function show(Request $r): void
    {
        Auth::requireStaff('content.manage');
        $type = ContentTypes::get($r->param('type'));
        $row = DB::one("SELECT * FROM `{$type['table']}` WHERE id = ?", [$r->intParam('id')]);
        if (!$row) {
            throw HttpException::notFound();
        }
        Response::ok($row);
    }

    public static function create(Request $r): void
    {
        Auth::requireStaff('content.manage');
        $typeKey = $r->param('type');
        $type = ContentTypes::get($typeKey);
        $data = self::clean($type, $r, null);
        if (empty($type['no_timestamps'])) {
            $data['created_at'] = $data['updated_at'] = DB::now();
        }
        $id = DB::insert($type['table'], $data);
        Audit::log("content.{$typeKey}.created", $typeKey, $id);
        Response::created(DB::one("SELECT * FROM `{$type['table']}` WHERE id = ?", [$id]));
    }

    public static function update(Request $r): void
    {
        Auth::requireStaff('content.manage');
        $typeKey = $r->param('type');
        $type = ContentTypes::get($typeKey);
        $id = $r->intParam('id');
        $existing = DB::one("SELECT * FROM `{$type['table']}` WHERE id = ?", [$id]);
        if (!$existing) {
            throw HttpException::notFound();
        }
        $data = self::clean($type, $r, $existing);
        if (empty($type['no_timestamps'])) {
            $data['updated_at'] = DB::now();
        }
        DB::update($type['table'], $data, ['id' => $id]);
        Audit::log("content.{$typeKey}.updated", $typeKey, $id);
        Response::ok(DB::one("SELECT * FROM `{$type['table']}` WHERE id = ?", [$id]));
    }

    public static function delete(Request $r): void
    {
        Auth::requireStaff('content.manage');
        $typeKey = $r->param('type');
        $type = ContentTypes::get($typeKey);
        $id = $r->intParam('id');
        DB::run("DELETE FROM `{$type['table']}` WHERE id = ?", [$id]);
        Audit::log("content.{$typeKey}.deleted", $typeKey, $id);
        Response::ok();
    }

    /** @return array<string,mixed> */
    private static function clean(array $type, Request $r, ?array $existing): array
    {
        $body = $r->body();
        // On update, only validate provided keys plus required ones already present.
        $rules = $type['rules'];
        if ($existing !== null) {
            $rules = array_intersect_key($rules, $body);
        }
        $data = Validator::validate($body, $rules);
        // Omitted optional fields fall back to the column defaults.
        $data = array_filter($data, static fn ($v, $k) => $v !== null || array_key_exists($k, $body), ARRAY_FILTER_USE_BOTH);
        foreach ($data as $k => $v) {
            if (str_ends_with($k, '_id') && ($v === 0 || $v === null)) {
                $data[$k] = null;
            }
            if (is_bool($v)) {
                $data[$k] = $v ? 1 : 0;
            }
        }
        if (isset($type['slug_from'])) {
            $base = $data['slug'] ?? null;
            if (!$base && $existing === null) {
                $base = $data[$type['slug_from']] ?? 'item';
            }
            if ($base) {
                $data['slug'] = ContentTypes::uniqueSlug($type['table'], ContentTypes::slugify((string) $base), $existing ? (int) $existing['id'] : null);
            }
        }
        if ($type['table'] === 'articles' && !empty($data['is_published']) && empty($data['published_at']) && empty($existing['published_at'])) {
            $data['published_at'] = DB::now();
        }
        if ($type['table'] === 'announcements' && !empty($data['is_published']) && empty($data['published_at']) && empty($existing['published_at'])) {
            $data['published_at'] = DB::now();
        }
        if ($type['table'] === 'institutions') {
            // Changing any link invalidates the previous verification.
            foreach (['website_url', 'apply_url', 'login_url'] as $k) {
                if (array_key_exists($k, $data) && ($existing[$k] ?? null) !== $data[$k]) {
                    $data['links_verified_at'] = null;
                }
            }
            $merged = array_merge($existing ?? [], $data);
            $verified = !array_key_exists('links_verified_at', $data) && !empty($existing['links_verified_at']);
            $hasLinks = !empty($merged['website_url']) || !empty($merged['apply_url']) || !empty($merged['login_url']);
            if (!empty($merged['is_published']) && $hasLinks && !$verified) {
                throw HttpException::validation(['is_published' => 'links_not_verified']);
            }
        }
        if ($type['table'] === 'deadlines' && !empty($data['opens_at']) && !empty($data['closes_at']) && $data['opens_at'] > $data['closes_at']) {
            throw HttpException::validation(['closes_at' => 'date_order']);
        }
        return $data;
    }

    /** Check institution links over HTTP before they are published. */
    public static function verifyLinks(Request $r): void
    {
        Auth::requireStaff('content.manage');
        $inst = DB::one('SELECT * FROM institutions WHERE id = ?', [$r->intParam('id')]);
        if (!$inst) {
            throw HttpException::notFound();
        }
        $results = [];
        $allOk = true;
        foreach (['website_url', 'apply_url', 'login_url'] as $k) {
            if (empty($inst[$k])) {
                continue;
            }
            $status = self::probe($inst[$k]);
            $ok = $status >= 200 && $status < 400;
            $results[$k] = ['url' => $inst[$k], 'status' => $status, 'ok' => $ok];
            $allOk = $allOk && $ok;
        }
        $manual = $r->bool('manual');
        if ($allOk || $manual) {
            DB::update('institutions', ['links_verified_at' => DB::now()], ['id' => $inst['id']]);
            Audit::log('content.institutions.links_verified', 'institutions', (int) $inst['id'], ['manual' => $manual && !$allOk]);
        }
        Response::ok(['results' => $results, 'verified' => $allOk || $manual]);
    }

    public static function probe(string $url): int
    {
        if (!preg_match('#^https?://#i', $url)) {
            return 0;
        }
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_NOBODY => false,
            CURLOPT_RANGE => '0-1024',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 5,
            CURLOPT_TIMEOUT => 12,
            CURLOPT_CONNECTTIMEOUT => 6,
            CURLOPT_PROTOCOLS => CURLPROTO_HTTP | CURLPROTO_HTTPS,
            CURLOPT_REDIR_PROTOCOLS => CURLPROTO_HTTP | CURLPROTO_HTTPS,
            CURLOPT_USERAGENT => 'MediatorLinkChecker/1.0',
        ]);
        curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        return $code;
    }

    /** Upload public media (images/PDF) for content. */
    public static function uploadMedia(Request $r): void
    {
        $staff = Auth::requireStaff('content.manage');
        $stored = Uploads::store($_FILES['file'] ?? [], 'media', Uploads::IMAGE_TYPES + Uploads::DOC_TYPES + ['image/x-icon' => 'ico', 'image/vnd.microsoft.icon' => 'ico'], 20 * 1024 * 1024);
        $id = DB::insert('media', $stored + ['uploaded_by' => $staff['id'], 'created_at' => DB::now()]);
        Response::created(['id' => $id, 'name' => $stored['original_name'], 'mime' => $stored['mime'], 'size' => $stored['size']]);
    }
}
