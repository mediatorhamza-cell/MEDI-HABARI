<?php
declare(strict_types=1);

namespace Mediator\Controllers\Admin;

use Mediator\Core\Audit;
use Mediator\Core\Auth;
use Mediator\Core\DB;
use Mediator\Core\Env;
use Mediator\Core\HttpException;
use Mediator\Core\Request;
use Mediator\Core\Response;
use Mediator\Core\Settings;
use Mediator\Core\Sms;

final class SettingsController
{
    public static function show(Request $r): void
    {
        Auth::requireStaff('settings.manage');
        Response::ok([
            'settings' => Settings::publicSettings(),
            'system' => [
                'sms_driver' => Sms::driver(),
                'sms_live' => Sms::isLive(),
                'php_version' => PHP_VERSION,
                'db_version' => DB::value('SELECT VERSION()'),
                'environment' => Env::get('APP_ENV', 'production'),
                'upload_max_mb' => Env::int('UPLOAD_MAX_MB', 5),
                'last_backup' => self::lastBackup(),
            ],
        ]);
    }

    public static function update(Request $r): void
    {
        Auth::requireStaff('settings.manage');
        $body = $r->input('settings', []);
        if (!is_array($body)) {
            throw HttpException::validation(['settings' => 'invalid']);
        }
        $changed = [];
        foreach ($body as $key => $value) {
            if (!in_array($key, Settings::PUBLIC_KEYS, true)) {
                continue;
            }
            if (in_array($key, ['banks', 'heslb_levels'], true)) {
                $value = self::cleanOptions($value);
            } elseif (in_array($key, ['logo_file_id', 'favicon_file_id'], true)) {
                $value = $value ? (int) $value : null;
            } elseif ($key === 'site_live') {
                $value = $value === true || $value === 1 || $value === '1' || $value === 'true';
                if ($value !== (bool) Settings::get('site_live', false)) {
                    Audit::log($value ? 'site.opened' : 'site.coming_soon');
                }
            } elseif ($key === 'default_language') {
                $value = $value === 'en' ? 'en' : 'sw';
            } elseif ($value !== null) {
                $value = mb_substr(trim((string) $value), 0, 20000);
                if (str_starts_with($key, 'social_') && $value !== '' && !preg_match('#^https://#i', $value)) {
                    throw HttpException::validation([$key => 'url']);
                }
            }
            Settings::set($key, $value);
            $changed[] = $key;
        }
        Audit::log('settings.updated', null, null, ['keys' => $changed]);
        Response::ok(Settings::publicSettings());
    }

    /** @return list<array{value:string,label:array{sw:string,en:string}}> */
    private static function cleanOptions(mixed $value): array
    {
        $out = [];
        foreach (is_array($value) ? $value : [] as $item) {
            if (is_string($item)) {
                $item = ['value' => $item, 'label' => ['sw' => $item, 'en' => $item]];
            }
            $v = trim((string) ($item['value'] ?? ''));
            if ($v === '') {
                continue;
            }
            $out[] = [
                'value' => mb_substr($v, 0, 100),
                'label' => [
                    'sw' => mb_substr(trim((string) ($item['label']['sw'] ?? $v)), 0, 150),
                    'en' => mb_substr(trim((string) ($item['label']['en'] ?? $item['label']['sw'] ?? $v)), 0, 150),
                ],
            ];
        }
        return $out;
    }

    private static function lastBackup(): ?string
    {
        $files = glob(Env::storagePath('backups') . '/*.sql.gz') ?: [];
        if ($files === []) {
            return null;
        }
        rsort($files);
        return date('Y-m-d H:i', (int) filemtime($files[0]));
    }

    public static function audit(Request $r): void
    {
        Auth::requireStaff('audit.view');
        $where = '1=1';
        $params = [];
        if ($action = $r->query('action')) {
            $where .= ' AND l.action LIKE ?';
            $params[] = DB::like($action);
        }
        $page = $r->queryInt('page', 1);
        $rows = DB::all(
            "SELECT l.*, u.first_name, u.second_name, u.role FROM audit_logs l LEFT JOIN users u ON u.id = l.user_id
             WHERE {$where} ORDER BY l.id DESC LIMIT 50 OFFSET ?",
            array_merge($params, [($page - 1) * 50])
        );
        foreach ($rows as &$row) {
            $row['details'] = json_decode((string) $row['details'], true);
        }
        Response::ok(['items' => $rows, 'total' => (int) DB::value("SELECT COUNT(*) FROM audit_logs l WHERE {$where}", $params), 'page' => $page, 'per_page' => 50]);
    }

    public static function contactMessages(Request $r): void
    {
        Auth::requireStaff('contact.view');
        Response::ok(DB::all('SELECT * FROM contact_messages ORDER BY is_handled ASC, id DESC LIMIT 200'));
    }

    public static function contactHandled(Request $r): void
    {
        Auth::requireStaff('contact.view');
        DB::update('contact_messages', ['is_handled' => $r->bool('handled') ? 1 : 0], ['id' => $r->intParam('id')]);
        Response::ok();
    }
}
