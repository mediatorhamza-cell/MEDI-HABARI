<?php
declare(strict_types=1);

namespace Mediator\Controllers\Admin;

use Mediator\Core\Applications;
use Mediator\Core\Audit;
use Mediator\Core\Auth;
use Mediator\Core\DB;
use Mediator\Core\Export;
use Mediator\Core\FormSchema;
use Mediator\Core\HttpException;
use Mediator\Core\Phone;
use Mediator\Core\Request;
use Mediator\Core\Response;

/** XLSX / PDF / CSV exports. Sensitive (encrypted) fields are never exported. */
final class ReportController
{
    /** Selectable base columns => [label, extractor] */
    private static function baseColumns(): array
    {
        return [
            'reference' => ['Namba ya Ombi', static fn ($a) => $a['reference']],
            'service' => ['Huduma', static fn ($a) => $a['service_name_sw']],
            'applicant_name' => ['Jina la Mwombaji', static fn ($a) => $a['applicant_name']],
            'applicant_phone' => ['Simu ya Mwombaji', static fn ($a) => $a['applicant_phone'] ? Phone::local($a['applicant_phone']) : ''],
            'account_name' => ['Jina la Akaunti', static fn ($a) => trim($a['first_name'] . ' ' . $a['second_name'])],
            'account_phone' => ['Simu ya Akaunti', static fn ($a) => Phone::local($a['user_phone'])],
            'status' => ['Status', static fn ($a) => Applications::label($a['status'])],
            'payment_status' => ['Malipo', static fn ($a) => Applications::PAYMENT_LABELS[$a['payment_status']][0] ?? $a['payment_status']],
            'price' => ['Bei (TZS)', static fn ($a) => $a['price_snapshot'] !== null ? (int) $a['price_snapshot'] : ''],
            'package' => ['Kifurushi', static fn ($a) => $a['package_name_snapshot']],
            'submitted_at' => ['Tarehe ya Kutuma', static fn ($a) => $a['submitted_at'] ? date('d/m/Y H:i', strtotime($a['submitted_at'])) : ''],
            'updated_at' => ['Ilisasishwa', static fn ($a) => date('d/m/Y H:i', strtotime($a['updated_at']))],
        ];
    }

    public static function columns(Request $r): void
    {
        Auth::requireStaff('reports.export');
        $out = [];
        foreach (self::baseColumns() as $k => [$label]) {
            $out[] = ['key' => $k, 'label' => $label];
        }
        $formFields = [];
        if ($svc = $r->query('service')) {
            $s = DB::one('SELECT form_key FROM services WHERE code = ?', [strtoupper($svc)]);
            if ($s) {
                $schema = FormSchema::load($s['form_key']);
                foreach ($schema->fields() as $k => $f) {
                    if (empty($f['sensitive']) && !in_array($f['type'], ['file', 'repeater'], true)) {
                        $formFields[] = ['key' => 'f:' . $k, 'label' => $schema->label($k)];
                    }
                }
            }
        }
        Response::ok(['base' => $out, 'form' => $formFields]);
    }

    public static function applications(Request $r): void
    {
        Auth::requireStaff('reports.export');
        $format = $r->query('format', 'xlsx');
        if (!in_array($format, ['xlsx', 'pdf', 'csv'], true)) {
            throw HttpException::bad('invalid_format');
        }
        [$where, $params] = ApplicationAdminController::filters($r);
        $rows = DB::all(
            "SELECT a.*, s.code AS service_code, s.form_key, s.name_sw AS service_name_sw, u.first_name, u.second_name, u.phone AS user_phone
             FROM applications a JOIN services s ON s.id = a.service_id JOIN users u ON u.id = a.user_id
             WHERE {$where} ORDER BY a.submitted_at DESC LIMIT 20000",
            $params
        );
        $base = self::baseColumns();
        $requested = array_filter(explode(',', (string) $r->query('columns', 'reference,service,applicant_name,applicant_phone,status,payment_status,price,submitted_at')));
        $headers = [];
        $extractors = [];
        $schemas = [];
        foreach ($requested as $col) {
            if (isset($base[$col])) {
                $headers[] = $base[$col][0];
                $extractors[] = $base[$col][1];
            } elseif (str_starts_with($col, 'f:')) {
                $key = substr($col, 2);
                $headers[] = $key;
                $extractors[] = static function ($a) use ($key, &$schemas) {
                    $schemas[$a['form_key']] ??= FormSchema::load($a['form_key']);
                    $field = $schemas[$a['form_key']]->fields()[$key] ?? null;
                    if ($field === null || !empty($field['sensitive'])) {
                        return '';
                    }
                    $data = json_decode((string) $a['data'], true) ?: [];
                    $v = $data[$key] ?? '';
                    return is_array($v) ? implode('; ', array_map('strval', array_filter($v, 'is_scalar'))) : $v;
                };
            }
        }
        // Use friendly labels for form columns when a single service is selected.
        if ($svc = $r->query('service')) {
            $s = DB::one('SELECT form_key FROM services WHERE code = ?', [strtoupper($svc)]);
            if ($s) {
                $schema = FormSchema::load($s['form_key']);
                foreach ($headers as $i => $h) {
                    if ($schema->hasField($h)) {
                        $headers[$i] = $schema->label($h);
                    }
                }
            }
        }
        if ($headers === []) {
            throw HttpException::validation(['columns' => 'required']);
        }
        $data = array_map(static fn ($a) => array_map(static fn ($fn) => $fn($a), $extractors), $rows);
        Audit::log('report.export', null, null, ['format' => $format, 'rows' => count($data), 'filters' => $_GET]);
        self::output($format, 'Ripoti ya Maombi - Mediator Hamza', $headers, $data, 'maombi');
    }

    /** Phone list export (for bulk SMS campaigns run outside the system). */
    public static function phones(Request $r): void
    {
        Auth::requireStaff('reports.export');
        $format = $r->query('format', 'xlsx');
        if (!in_array($format, ['xlsx', 'pdf', 'csv'], true)) {
            throw HttpException::bad('invalid_format');
        }
        $audience = ['type' => $r->query('service') || $r->query('status') ? 'service' : 'all', 'service' => $r->query('service'), 'status' => $r->query('status')];
        $ids = NotificationAdminController::resolveAudience($audience);
        $rows = [];
        if ($ids) {
            $in = implode(',', array_fill(0, count($ids), '?'));
            foreach (DB::all("SELECT first_name, second_name, phone, created_at FROM users WHERE id IN ({$in}) ORDER BY first_name", $ids) as $u) {
                $rows[] = [trim($u['first_name'] . ' ' . $u['second_name']), Phone::local($u['phone']), $u['phone'], date('d/m/Y', strtotime($u['created_at']))];
            }
        }
        Audit::log('report.phones_export', null, null, ['format' => $format, 'rows' => count($rows), 'audience' => $audience]);
        self::output($format, 'Orodha ya Namba za Simu - Mediator Hamza', ['Jina', 'Simu', 'Simu (Kimataifa)', 'Alisajiliwa'], $rows, 'namba-za-simu');
    }

    /** Per-service / period summary. */
    public static function summary(Request $r): void
    {
        Auth::requireStaff('reports.export');
        [$where, $params] = ApplicationAdminController::filters($r);
        $rows = DB::all(
            "SELECT s.code, s.name_sw, a.status, COUNT(*) AS n, SUM(COALESCE(a.price_snapshot,0)) AS value,
                    SUM(CASE WHEN a.payment_status IN ('paid','stationery_paid') THEN COALESCE(a.price_snapshot,0) ELSE 0 END) AS paid_value
             FROM applications a JOIN services s ON s.id = a.service_id JOIN users u ON u.id = a.user_id
             WHERE {$where} GROUP BY s.code, s.name_sw, a.status ORDER BY s.code",
            $params
        );
        Response::ok($rows);
    }

    /** @param list<string> $headers @param list<list<mixed>> $rows */
    private static function output(string $format, string $title, array $headers, array $rows, string $base): never
    {
        $name = $base . '-' . date('Ymd-His');
        match ($format) {
            'csv' => Response::download(Export::csv($headers, $rows), 'text/csv; charset=utf-8', $name . '.csv'),
            'pdf' => Response::download(Export::pdf($title, $headers, $rows), 'application/pdf', $name . '.pdf'),
            default => Response::download(Export::xlsx($headers, $rows, 'Mediator'), 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', $name . '.xlsx'),
        };
    }
}
