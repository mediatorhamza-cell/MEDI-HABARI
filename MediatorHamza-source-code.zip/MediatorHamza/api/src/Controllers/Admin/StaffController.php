<?php
declare(strict_types=1);

namespace Mediator\Controllers\Admin;

use Mediator\Controllers\AuthController;
use Mediator\Core\Audit;
use Mediator\Core\Auth;
use Mediator\Core\Crypto;
use Mediator\Core\DB;
use Mediator\Core\HttpException;
use Mediator\Core\Request;
use Mediator\Core\Response;
use Mediator\Core\Totp;
use Mediator\Core\Validator;

/** Staff account management (Super Admin only) and staff 2FA self-service. */
final class StaffController
{
    public static function index(Request $r): void
    {
        Auth::requireStaff('staff.manage');
        Response::ok(DB::all(
            "SELECT id, first_name, second_name, phone, email, role, status, totp_enabled, last_login_at, created_at
             FROM users WHERE role <> 'user' ORDER BY FIELD(role, 'super_admin','admin','support','readonly'), first_name"
        ));
    }

    public static function create(Request $r): void
    {
        Auth::requireStaff('staff.manage');
        $data = Validator::validate($r->body(), [
            'first_name' => 'required|string|max:80',
            'second_name' => 'required|string|max:80',
            'phone' => 'required|phone',
            'email' => 'email|max:190',
            'role' => 'required|in:admin,support,readonly,super_admin',
            'password' => 'required|string|min:12|max:200',
        ]);
        if (!AuthController::strongEnough($data['password'])) {
            throw HttpException::validation(['password' => 'password_weak']);
        }
        if (DB::value('SELECT id FROM users WHERE phone = ?', [$data['phone']]) !== null) {
            throw HttpException::validation(['phone' => 'phone_taken']);
        }
        $now = DB::now();
        $id = DB::insert('users', [
            'first_name' => $data['first_name'], 'second_name' => $data['second_name'], 'phone' => $data['phone'],
            'email' => $data['email'], 'role' => $data['role'], 'password_hash' => password_hash($data['password'], PASSWORD_DEFAULT),
            'created_at' => $now, 'updated_at' => $now,
        ]);
        Audit::log('staff.created', 'user', $id, ['role' => $data['role']]);
        Response::created(['id' => $id]);
    }

    public static function update(Request $r): void
    {
        $me = Auth::requireStaff('staff.manage');
        $id = $r->intParam('id');
        $target = DB::one("SELECT * FROM users WHERE id = ? AND role <> 'user'", [$id]);
        if (!$target) {
            throw HttpException::notFound();
        }
        $data = Validator::validate($r->body(), [
            'role' => 'required|in:admin,support,readonly,super_admin',
            'status' => 'required|in:active,disabled',
        ]);
        if ($id === (int) $me['id'] && ($data['role'] !== 'super_admin' || $data['status'] !== 'active')) {
            throw HttpException::bad('self_lockout', 'You cannot demote or disable your own account.');
        }
        DB::run('UPDATE users SET role = ?, status = ?, session_version = session_version + 1, updated_at = ? WHERE id = ?',
            [$data['role'], $data['status'], DB::now(), $id]);
        Audit::log('staff.updated', 'user', $id, ['role' => $data['role'], 'status' => $data['status']]);
        Response::ok();
    }

    // ---------------------------------------------------------------- 2FA (any staff, for themselves)

    public static function twoFactorSetup(Request $r): void
    {
        $me = Auth::requireStaff();
        $secret = Totp::generateSecret();
        $_SESSION['totp_setup'] = $secret;
        Response::ok(['secret' => $secret, 'otpauth_uri' => Totp::uri($secret, $me['phone'])]);
    }

    public static function twoFactorEnable(Request $r): void
    {
        $me = Auth::requireStaff();
        $secret = $_SESSION['totp_setup'] ?? null;
        if (!is_string($secret) || !Totp::verify($secret, $r->str('code'))) {
            throw HttpException::validation(['code' => 'code_invalid']);
        }
        DB::update('users', ['totp_secret' => Crypto::encrypt($secret), 'totp_enabled' => 1], ['id' => $me['id']]);
        unset($_SESSION['totp_setup']);
        Audit::log('staff.2fa_enabled', 'user', (int) $me['id']);
        Response::ok();
    }

    public static function twoFactorDisable(Request $r): void
    {
        $me = Auth::requireStaff();
        if (!password_verify((string) $r->input('password', ''), $me['password_hash'])) {
            throw HttpException::validation(['password' => 'password_incorrect']);
        }
        DB::update('users', ['totp_secret' => null, 'totp_enabled' => 0], ['id' => $me['id']]);
        Audit::log('staff.2fa_disabled', 'user', (int) $me['id']);
        Response::ok();
    }
}
