<?php
declare(strict_types=1);

namespace Mediator\Controllers\Admin;

use Mediator\Controllers\AuthController;
use Mediator\Core\Applications;
use Mediator\Core\Audit;
use Mediator\Core\Auth;
use Mediator\Core\DB;
use Mediator\Core\HttpException;
use Mediator\Core\Notifier;
use Mediator\Core\Request;
use Mediator\Core\Response;
use Mediator\Core\Validator;

final class UserAdminController
{
    /** @return array<string,mixed> */
    private static function row(array $u): array
    {
        return [
            'id' => (int) $u['id'], 'first_name' => $u['first_name'], 'second_name' => $u['second_name'],
            'last_name' => $u['last_name'], 'phone' => $u['phone'], 'email' => $u['email'], 'role' => $u['role'],
            'status' => $u['status'], 'suspended_until' => $u['suspended_until'], 'suspension_reason' => $u['suspension_reason'],
            'language' => $u['language'], 'last_login_at' => $u['last_login_at'], 'created_at' => $u['created_at'],
            'applications_count' => isset($u['applications_count']) ? (int) $u['applications_count'] : null,
            'totp_enabled' => (bool) $u['totp_enabled'],
        ];
    }

    public static function index(Request $r): void
    {
        Auth::requireStaff('users.view');
        $where = ["u.role = 'user'"];
        $params = [];
        if ($q = $r->query('q')) {
            $digits = preg_replace('/\D/', '', $q);
            $where[] = '(CONCAT_WS(" ", u.first_name, u.second_name, u.last_name) LIKE ? OR u.phone LIKE ? OR u.email LIKE ?)';
            array_push($params, DB::like($q), $digits !== '' ? DB::like(ltrim($digits, '0')) : DB::like($q), DB::like($q));
        }
        if (($s = $r->query('status')) && in_array($s, ['active', 'suspended', 'disabled'], true)) {
            $where[] = 'u.status = ?';
            $params[] = $s;
        }
        $w = implode(' AND ', $where);
        $page = $r->queryInt('page', 1);
        $per = 25;
        $total = (int) DB::value("SELECT COUNT(*) FROM users u WHERE {$w}", $params);
        $rows = DB::all(
            "SELECT u.*, (SELECT COUNT(*) FROM applications a WHERE a.user_id = u.id AND a.status <> 'draft') AS applications_count
             FROM users u WHERE {$w} ORDER BY u.created_at DESC LIMIT ? OFFSET ?",
            array_merge($params, [$per, ($page - 1) * $per])
        );
        Response::ok(['items' => array_map([self::class, 'row'], $rows), 'total' => $total, 'page' => $page, 'per_page' => $per]);
    }

    public static function show(Request $r): void
    {
        Auth::requireStaff('users.view');
        $u = DB::one('SELECT * FROM users WHERE id = ?', [$r->intParam('id')]);
        if (!$u) {
            throw HttpException::notFound();
        }
        $apps = DB::all(
            'SELECT a.*, s.code AS service_code, s.slug AS service_slug, s.icon AS service_icon, s.name_sw AS service_name_sw, s.name_en AS service_name_en
             FROM applications a JOIN services s ON s.id = a.service_id WHERE a.user_id = ? ORDER BY a.created_at DESC',
            [$u['id']]
        );
        Response::ok([
            'user' => self::row($u),
            'applications' => array_map([Applications::class, 'summary'], $apps),
            'logins' => DB::all('SELECT event, ip_address, user_agent, created_at FROM login_events WHERE user_id = ? ORDER BY id DESC LIMIT 20', [$u['id']]),
            'conversations' => DB::all('SELECT id, subject, status, last_message_at FROM conversations WHERE user_id = ? ORDER BY last_message_at DESC', [$u['id']]),
        ]);
    }

    /** Correct inaccurate account details. */
    public static function update(Request $r): void
    {
        $staff = Auth::requireStaff('users.manage');
        $u = self::target($r, $staff);
        $data = Validator::validate($r->body(), [
            'first_name' => 'required|string|max:80',
            'second_name' => 'required|string|max:80',
            'last_name' => 'string|max:80',
            'email' => 'email|max:190',
            'phone' => 'required|phone',
        ]);
        if ($data['phone'] !== $u['phone'] && DB::value('SELECT id FROM users WHERE phone = ? AND id <> ?', [$data['phone'], $u['id']]) !== null) {
            throw HttpException::validation(['phone' => 'phone_taken']);
        }
        DB::update('users', [
            'first_name' => $data['first_name'], 'second_name' => $data['second_name'], 'last_name' => $data['last_name'] ?: null,
            'email' => $data['email'] ?: null, 'phone' => $data['phone'], 'updated_at' => DB::now(),
        ], ['id' => $u['id']]);
        Audit::log('user.updated', 'user', (int) $u['id'], ['phone_changed' => $data['phone'] !== $u['phone']]);
        Response::ok();
    }

    public static function suspend(Request $r): void
    {
        $staff = Auth::requireStaff('users.manage');
        $u = self::target($r, $staff);
        $data = Validator::validate($r->body(), [
            'action' => 'required|in:suspend,activate,disable',
            'until' => 'date',
            'reason' => 'string|max:255',
        ]);
        $update = match ($data['action']) {
            'suspend' => ['status' => 'suspended', 'suspended_until' => $data['until'] ? $data['until'] . ' 23:59:59' : null, 'suspension_reason' => $data['reason']],
            'disable' => ['status' => 'disabled', 'suspended_until' => null, 'suspension_reason' => $data['reason']],
            default => ['status' => 'active', 'suspended_until' => null, 'suspension_reason' => null],
        };
        DB::run('UPDATE users SET session_version = session_version + 1 WHERE id = ?', [$u['id']]);
        DB::update('users', $update + ['updated_at' => DB::now()], ['id' => $u['id']]);
        Audit::log('user.' . $data['action'], 'user', (int) $u['id'], ['until' => $data['until'], 'reason' => $data['reason']]);
        Response::ok();
    }

    /**
     * Admin-assisted recovery: generates a one-time code that staff read out to the
     * verified account owner. Staff never see or set the user's password.
     */
    public static function issueResetCode(Request $r): void
    {
        $staff = Auth::requireStaff('users.manage');
        $u = self::target($r, $staff);
        $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
        $code = '';
        for ($i = 0; $i < 8; $i++) {
            $code .= $alphabet[random_int(0, strlen($alphabet) - 1)];
        }
        DB::run("UPDATE otp_codes SET used_at = ? WHERE user_id = ? AND used_at IS NULL", [DB::now(), $u['id']]);
        DB::insert('otp_codes', [
            'user_id' => $u['id'], 'purpose' => 'admin_reset', 'code_hash' => password_hash($code, PASSWORD_DEFAULT),
            'expires_at' => date('Y-m-d H:i:s', time() + 3600), 'created_by' => $staff['id'], 'created_at' => DB::now(),
        ]);
        Audit::log('user.reset_code_issued', 'user', (int) $u['id']);
        Response::ok(['code' => $code, 'expires_in_minutes' => 60]);
    }

    public static function notify(Request $r): void
    {
        $staff = Auth::requireStaff('notifications.send');
        $u = DB::one("SELECT * FROM users WHERE id = ?", [$r->intParam('id')]);
        if (!$u) {
            throw HttpException::notFound();
        }
        $data = Validator::validate($r->body(), ['title' => 'required|string|max:200', 'body' => 'required|string|max:3000']);
        Notifier::notify((int) $u['id'], 'admin_message', $data['title'], $data['body']);
        Audit::log('notification.single', 'user', (int) $u['id']);
        Response::created();
    }

    /** @return array<string,mixed> */
    private static function target(Request $r, array $staff): array
    {
        $u = DB::one('SELECT * FROM users WHERE id = ?', [$r->intParam('id')]);
        if (!$u) {
            throw HttpException::notFound();
        }
        // Only super admins may modify staff accounts (handled in StaffController).
        if ($u['role'] !== 'user') {
            throw HttpException::forbidden();
        }
        return $u;
    }
}
