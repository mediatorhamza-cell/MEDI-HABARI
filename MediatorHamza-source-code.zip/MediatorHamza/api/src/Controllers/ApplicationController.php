<?php
declare(strict_types=1);

namespace Mediator\Controllers;

use Mediator\Core\Applications;
use Mediator\Core\Audit;
use Mediator\Core\Auth;
use Mediator\Core\DB;
use Mediator\Core\FormSchema;
use Mediator\Core\HttpException;
use Mediator\Core\Notifier;
use Mediator\Core\RateLimiter;
use Mediator\Core\Reference;
use Mediator\Core\Request;
use Mediator\Core\Response;
use Mediator\Core\Uploads;

/** Applicant-facing application endpoints. Every query is scoped to the logged-in user. */
final class ApplicationController
{
    /**
     * Values this user typed in earlier applications, per field key (newest first),
     * offered as suggestions when filling a form again. Sensitive fields are never included
     * because they are stored separately (encrypted) and not in `data`.
     */
    public static function fieldHistory(Request $r): void
    {
        $user = Auth::requireUser();
        $rows = DB::all('SELECT data FROM applications WHERE user_id = ? AND data IS NOT NULL ORDER BY updated_at DESC LIMIT 40', [$user['id']]);
        $out = [];
        foreach ($rows as $row) {
            $data = json_decode((string) $row['data'], true);
            if (!is_array($data)) {
                continue;
            }
            foreach ($data as $key => $value) {
                if (!is_string($value) || $value === '' || mb_strlen($value) > 200) {
                    continue;
                }
                $out[$key] ??= [];
                if (count($out[$key]) < 6 && !in_array($value, $out[$key], true)) {
                    $out[$key][] = $value;
                }
            }
        }
        Response::ok((object) $out);
    }

    public static function index(Request $r): void
    {
        $user = Auth::requireUser();
        $rows = DB::all(
            'SELECT a.*, s.code AS service_code, s.slug AS service_slug, s.icon AS service_icon,
                    s.name_sw AS service_name_sw, s.name_en AS service_name_en
             FROM applications a JOIN services s ON s.id = a.service_id
             WHERE a.user_id = ? ORDER BY a.updated_at DESC',
            [$user['id']]
        );
        Response::ok(array_map([Applications::class, 'summary'], $rows));
    }

    /** Start (or resume) a draft for a service. Re-uses an existing empty draft to avoid duplicates. */
    public static function create(Request $r): void
    {
        $user = Auth::requireUser();
        RateLimiter::hit('app-create:' . $user['id'], 30, 3600);
        $service = DB::one('SELECT * FROM services WHERE code = ? AND is_active = 1', [strtoupper($r->str('service_code'))]);
        if (!$service) {
            throw HttpException::notFound();
        }
        if ((int) $service['accepting'] !== 1) {
            throw new HttpException(409, 'service_closed', 'Huduma hii haipokei maombi kwa sasa.');
        }
        $existing = DB::one(
            "SELECT id FROM applications WHERE user_id = ? AND service_id = ? AND status = 'draft' ORDER BY id DESC LIMIT 1",
            [$user['id'], $service['id']]
        );
        if ($existing && !$r->bool('force_new')) {
            Response::ok(['id' => (int) $existing['id'], 'resumed' => true]);
        }
        $now = DB::now();
        $id = DB::insert('applications', [
            'user_id' => $user['id'],
            'service_id' => $service['id'],
            'status' => 'draft',
            'data' => '{}',
            'created_at' => $now,
            'updated_at' => $now,
        ]);
        Response::created(['id' => $id, 'resumed' => false]);
    }

    public static function show(Request $r): void
    {
        $user = Auth::requireUser();
        $app = Applications::findOwned($r->intParam('id'), (int) $user['id']);
        Response::ok(self::detail($app));
    }

    /** @return array<string,mixed> */
    private static function detail(array $app): array
    {
        $packages = DB::all('SELECT id, name_sw, name_en, price FROM service_packages WHERE service_id = ? AND is_active = 1 ORDER BY sort_order, id', [$app['service_id']]);
        $service = DB::one('SELECT price, accepting FROM services WHERE id = ?', [$app['service_id']]);
        return array_merge(Applications::summary($app), [
            'form_key' => $app['form_key'],
            'data' => Applications::formData($app),
            'files' => Applications::files((int) $app['id']),
            'result_files' => Applications::files((int) $app['id'], 'result'),
            'timeline' => Applications::timeline((int) $app['id'], false),
            'results' => Applications::results((int) $app['id']),
            'editable_fields' => json_decode((string) ($app['editable_fields'] ?? 'null'), true),
            'correction_message' => $app['correction_message'],
            'next_action' => $app['next_action'],
            'package_id' => $app['package_id'] !== null ? (int) $app['package_id'] : null,
            'packages' => array_map(static fn ($p) => ['id' => (int) $p['id'], 'name_sw' => $p['name_sw'], 'name_en' => $p['name_en'], 'price' => (int) $p['price']], $packages),
            'current_price' => $service && $service['price'] !== null ? (int) $service['price'] : null,
        ]);
    }

    /** Autosave (draft) or correction save. */
    public static function update(Request $r): void
    {
        $user = Auth::requireUser();
        $app = Applications::findOwned($r->intParam('id'), (int) $user['id']);
        RateLimiter::hit('autosave:' . $user['id'], 240, 3600);
        $schema = FormSchema::load($app['form_key']);
        $input = $r->input('data', []);
        if (!is_array($input)) {
            throw HttpException::bad('invalid_data');
        }
        $current = Applications::formData($app);

        if ($app['status'] === 'draft') {
            $merged = array_merge($current, $input);
        } elseif ($app['status'] === 'correction_required') {
            $merged = self::applyCorrections($app, $current, $input);
        } else {
            throw new HttpException(409, 'not_editable', 'Ombi hili haliwezi kubadilishwa kwa sasa.');
        }
        [$clean] = $schema->validate($merged, false, Applications::ownedFiles((int) $app['id']), Applications::formContext());
        $extra = [];
        if ($app['status'] === 'draft' && $r->input('package_id') !== null) {
            $extra['package_id'] = self::validPackage((int) $app['service_id'], $r->input('package_id'));
        }
        Applications::storeData((int) $app['id'], $schema, $clean, $extra);
        Response::ok(['saved_at' => DB::now()]);
    }

    /**
     * Only fields the admin unlocked may change while a correction is requested.
     * @return array<string,mixed>
     */
    private static function applyCorrections(array $app, array $current, array $input): array
    {
        $editable = json_decode((string) ($app['editable_fields'] ?? '[]'), true) ?: [];
        if (in_array('*', $editable, true)) {
            return array_merge($current, $input);
        }
        foreach ($input as $k => $v) {
            if (in_array($k, $editable, true)) {
                $current[$k] = $v;
            }
        }
        return $current;
    }

    private static function validPackage(int $serviceId, mixed $packageId): ?int
    {
        if ($packageId === '' || $packageId === null) {
            return null;
        }
        $id = DB::value('SELECT id FROM service_packages WHERE id = ? AND service_id = ? AND is_active = 1', [(int) $packageId, $serviceId]);
        if ($id === null) {
            throw HttpException::validation(['package_id' => 'invalid_option']);
        }
        return (int) $id;
    }

    /** Final submission (or re-submission after correction). Idempotent. */
    public static function submit(Request $r): void
    {
        $user = Auth::requireUser();
        $appId = $r->intParam('id');
        RateLimiter::hit('submit:' . $user['id'], 30, 3600);

        $result = DB::transaction(static function () use ($appId, $user, $r) {
            // Lock the row to prevent double submission from double clicks/retries.
            $locked = DB::one('SELECT id, user_id, status FROM applications WHERE id = ? FOR UPDATE', [$appId]);
            if (!$locked || (int) $locked['user_id'] !== (int) $user['id']) {
                throw HttpException::notFound();
            }
            $app = Applications::find($appId);
            if (!in_array($app['status'], ['draft', 'correction_required'], true)) {
                return ['reference' => $app['reference'], 'submitted_at' => $app['submitted_at'], 'already' => true];
            }
            $schema = FormSchema::load($app['form_key']);
            $data = Applications::formData($app);
            $input = $r->input('data');
            if (is_array($input)) {
                $data = $app['status'] === 'draft' ? array_merge($data, $input) : self::applyCorrections($app, $data, $input);
            }
            [$clean, $errors] = $schema->validate($data, true, Applications::ownedFiles($appId), Applications::formContext());
            if ($errors !== []) {
                throw HttpException::validation($errors);
            }
            if (!$r->bool('confirm')) {
                throw HttpException::validation(['confirm' => 'confirm_required']);
            }

            $now = DB::now();
            if ($app['status'] === 'draft') {
                $service = DB::one('SELECT * FROM services WHERE id = ?', [$app['service_id']]);
                if ((int) $service['accepting'] !== 1 || (int) $service['is_active'] !== 1) {
                    throw new HttpException(409, 'service_closed', 'Huduma hii haipokei maombi kwa sasa.');
                }
                $packageId = $r->input('package_id') !== null
                    ? self::validPackage((int) $app['service_id'], $r->input('package_id'))
                    : ($app['package_id'] !== null ? (int) $app['package_id'] : null);
                $price = $service['price'] !== null ? (int) $service['price'] : null;
                $packageName = null;
                if ($packageId !== null) {
                    $pkg = DB::one('SELECT * FROM service_packages WHERE id = ?', [$packageId]);
                    $price = (int) $pkg['price'];
                    $packageName = $pkg['name_sw'];
                }
                $reference = Reference::next($service['code']);
                Applications::storeData($appId, $schema, $clean, [
                    'reference' => $reference,
                    'status' => 'received',
                    'package_id' => $packageId,
                    'price_snapshot' => $price, // price frozen at submission time
                    'package_name_snapshot' => $packageName,
                    'form_version' => (int) ($schema->schema['version'] ?? 1),
                    'submitted_at' => $now,
                ]);
                Applications::recordStatus($appId, 'draft', 'received', 'Nimepokea ombi lako. Nitakujulisha hatua zinazofuata.');
                Notifier::notify(
                    (int) $user['id'], 'application_received',
                    "Ombi {$reference} limepokelewa",
                    "Nimepokea ombi lako la {$service['name_sw']}. Namba ya ombi: {$reference}.",
                    "/app/maombi/{$appId}",
                    "Application {$reference} received",
                    "I have received your {$service['name_en']} application. Reference: {$reference}.",
                );
                return ['reference' => $reference, 'submitted_at' => $now, 'already' => false];
            }

            // Re-submission after correction: record what changed.
            $before = Applications::formData($app);
            $changed = [];
            foreach ($clean as $k => $v) {
                if (($before[$k] ?? null) !== $v) {
                    $changed[] = $k;
                }
            }
            Applications::storeData($appId, $schema, $clean, [
                'status' => 'received',
                'editable_fields' => null,
                'correction_message' => null,
            ]);
            DB::insert('application_changes', [
                'application_id' => $appId, 'changed_by' => $user['id'],
                'changed_fields' => json_encode($changed), 'reason' => 'correction', 'created_at' => $now,
            ]);
            Applications::recordStatus($appId, 'correction_required', 'received', 'Taarifa zimerekebishwa na kutumwa upya.', null, null, (int) $user['id']);
            Audit::log('application.corrected', 'application', $appId, ['fields' => $changed]);
            return ['reference' => $app['reference'], 'submitted_at' => $app['submitted_at'], 'resubmitted_at' => $now, 'already' => false];
        });
        Response::ok($result);
    }

    public static function cancel(Request $r): void
    {
        $user = Auth::requireUser();
        $app = Applications::findOwned($r->intParam('id'), (int) $user['id']);
        if ($app['status'] === 'draft') {
            foreach (DB::all('SELECT stored_name FROM application_files WHERE application_id = ?', [$app['id']]) as $f) {
                Uploads::delete($f['stored_name']);
            }
            DB::run('DELETE FROM applications WHERE id = ?', [$app['id']]);
            Response::ok(['deleted' => true]);
        }
        if ($app['status'] !== 'received') {
            throw new HttpException(409, 'not_cancellable', 'Ombi hili haliwezi kughairiwa. Wasiliana na Mediator.');
        }
        DB::update('applications', ['status' => 'cancelled', 'updated_at' => DB::now()], ['id' => $app['id']]);
        Applications::recordStatus((int) $app['id'], 'received', 'cancelled', 'Ombi limeghairiwa na mwombaji.', null, null, (int) $user['id']);
        Response::ok(['cancelled' => true]);
    }

    // ------------------------------------------------------------ files

    public static function uploadFile(Request $r): void
    {
        $user = Auth::requireUser();
        $app = Applications::findOwned($r->intParam('id'), (int) $user['id']);
        RateLimiter::hit('upload:' . $user['id'], 120, 3600);
        $fieldKey = (string) ($_POST['field_key'] ?? '');
        $schema = FormSchema::load($app['form_key']);
        $field = $schema->fields()[$fieldKey] ?? null;
        if ($field === null || $field['type'] !== 'file') {
            throw HttpException::validation(['field_key' => 'invalid']);
        }
        if ($app['status'] === 'correction_required') {
            $editable = json_decode((string) ($app['editable_fields'] ?? '[]'), true) ?: [];
            if (!in_array('*', $editable, true) && !in_array($fieldKey, $editable, true)) {
                throw new HttpException(409, 'not_editable', 'Sehemu hii haiwezi kubadilishwa.');
            }
        } elseif ($app['status'] !== 'draft') {
            throw new HttpException(409, 'not_editable', 'Ombi hili haliwezi kubadilishwa kwa sasa.');
        }
        $existing = (int) DB::value('SELECT COUNT(*) FROM application_files WHERE application_id = ? AND field_key = ?', [$app['id'], $fieldKey]);
        if ($existing >= (int) ($field['maxFiles'] ?? 1) + 2) {
            throw HttpException::validation(['file' => 'max_files']);
        }
        $allowed = match ($field['accept'] ?? 'image_or_document') {
            'image' => Uploads::IMAGE_TYPES,
            'document' => Uploads::DOC_TYPES,
            default => Uploads::IMAGE_TYPES + Uploads::DOC_TYPES,
        };
        $stored = Uploads::store($_FILES['file'] ?? [], 'applications/' . $app['id'], $allowed, Uploads::maxBytes());
        $id = DB::insert('application_files', array_merge($stored, [
            'application_id' => $app['id'],
            'field_key' => $fieldKey,
            'kind' => 'applicant',
            'uploaded_by' => $user['id'],
            'created_at' => DB::now(),
        ]));
        Response::created(['id' => $id, 'name' => $stored['original_name'], 'mime' => $stored['mime'], 'size' => $stored['size'], 'field_key' => $fieldKey]);
    }

    public static function deleteFile(Request $r): void
    {
        $user = Auth::requireUser();
        $app = Applications::findOwned($r->intParam('id'), (int) $user['id']);
        if (!in_array($app['status'], ['draft', 'correction_required'], true)) {
            throw new HttpException(409, 'not_editable', 'Ombi hili haliwezi kubadilishwa kwa sasa.');
        }
        $file = DB::one("SELECT * FROM application_files WHERE id = ? AND application_id = ? AND kind = 'applicant'", [$r->intParam('fileId'), $app['id']]);
        if (!$file) {
            throw HttpException::notFound();
        }
        if ($app['status'] === 'correction_required') {
            $editable = json_decode((string) ($app['editable_fields'] ?? '[]'), true) ?: [];
            if (!in_array('*', $editable, true) && !in_array($file['field_key'], $editable, true)) {
                throw new HttpException(409, 'not_editable', 'Sehemu hii haiwezi kubadilishwa.');
            }
        }
        DB::run('DELETE FROM application_files WHERE id = ?', [$file['id']]);
        Uploads::delete($file['stored_name']);
        // Remove the reference from saved data as well.
        $schema = FormSchema::load($app['form_key']);
        $data = Applications::formData($app);
        if (isset($data[$file['field_key']]) && is_array($data[$file['field_key']])) {
            $data[$file['field_key']] = array_values(array_diff($data[$file['field_key']], [(int) $file['id']]));
            Applications::storeData((int) $app['id'], $schema, $data);
        }
        Response::ok();
    }

    /** Download a file attached to the user's own application (applicant uploads or result documents). */
    public static function downloadFile(Request $r): void
    {
        $user = Auth::requireUser();
        $app = Applications::findOwned($r->intParam('id'), (int) $user['id']);
        $file = DB::one('SELECT * FROM application_files WHERE id = ? AND application_id = ?', [$r->intParam('fileId'), $app['id']]);
        if (!$file) {
            throw HttpException::notFound();
        }
        Response::file(Uploads::path($file['stored_name']), $file['mime'], $file['original_name'], $r->query('inline') === '1');
    }
}
