<?php
declare(strict_types=1);

namespace Mediator\Controllers;

use Mediator\Core\Audit;
use Mediator\Core\Auth;
use Mediator\Core\DB;
use Mediator\Core\Env;
use Mediator\Core\HttpException;
use Mediator\Core\Phone;
use Mediator\Core\RateLimiter;
use Mediator\Core\Request;
use Mediator\Core\Response;
use Mediator\Core\Sms;
use Mediator\Core\Totp;
use Mediator\Core\Crypto;
use Mediator\Core\Validator;

final class AuthController
{
    private const GENERIC_LOGIN_ERROR = 'Namba ya simu au nenosiri si sahihi.';

    public static function session(Request $r): void
    {
        $user = Auth::user();
        Response::ok([
            'user' => $user ? Auth::publicUser($user) : null,
            'csrf' => Auth::csrfToken(),
            'pending_2fa' => isset($_SESSION['pending_2fa']),
            'idle' => $user ? Auth::idleInfo() : null,
        ]);
    }

    public static function register(Request $r): void
    {
        RateLimiter::hit('register:' . $r->ip(), 10, 3600);
        $data = Validator::validate($r->body(), [
            'first_name' => 'required|string|max:80',
            'second_name' => 'required|string|max:80',
            'phone' => 'required|phone',
            'password' => 'required|string|min:8|max:200',
            'password_confirmation' => 'required|string',
            'accept_terms' => 'required|bool',
            'language' => 'in:sw,en',
        ]);
        $errors = [];
        foreach (['first_name', 'second_name'] as $k) {
            if (!preg_match("/^[\\p{L}' .-]{2,80}$/u", $data[$k])) {
                $errors[$k] = 'invalid_name';
            }
        }
        if ($data['password'] !== $data['password_confirmation']) {
            $errors['password_confirmation'] = 'password_mismatch';
        }
        if (!self::strongEnough($data['password'])) {
            $errors['password'] = 'password_weak';
        }
        if ($data['accept_terms'] !== true) {
            $errors['accept_terms'] = 'accept_terms';
        }
        if (DB::value('SELECT id FROM users WHERE phone = ?', [$data['phone']]) !== null) {
            $errors['phone'] = 'phone_taken';
        }
        if ($errors !== []) {
            throw HttpException::validation($errors);
        }
        $now = DB::now();
        $id = DB::insert('users', [
            'first_name' => self::titleCase($data['first_name']),
            'second_name' => self::titleCase($data['second_name']),
            'phone' => $data['phone'],
            'password_hash' => password_hash($data['password'], PASSWORD_DEFAULT),
            'role' => 'user',
            'language' => $data['language'] ?? 'en',
            'created_at' => $now,
            'updated_at' => $now,
        ]);
        $user = DB::one('SELECT * FROM users WHERE id = ?', [$id]);
        Auth::login($user);
        self::logEvent($id, 'register', $r);
        Response::created(['user' => Auth::publicUser($user), 'csrf' => Auth::csrfToken()]);
    }

    public static function login(Request $r): void
    {
        self::doLogin($r, false);
    }

    public static function adminLogin(Request $r): void
    {
        self::doLogin($r, true);
    }

    private static function doLogin(Request $r, bool $staffPortal): void
    {
        $phone = Phone::normalize($r->str('phone'));
        $password = (string) $r->input('password', '');
        RateLimiter::hit('login-ip:' . $r->ip(), 30, 900);
        if ($phone === null || $password === '') {
            throw new HttpException(401, 'invalid_credentials', self::GENERIC_LOGIN_ERROR);
        }
        RateLimiter::hit('login-phone:' . $phone, 8, 900);
        $user = DB::one('SELECT * FROM users WHERE phone = ?', [$phone]);
        // Always run password_verify to keep timing similar for unknown numbers.
        $hash = $user['password_hash'] ?? '$2y$10$dmpC/BZmyNG9.MZFLHNNf.RzO/o5y1duByVa4R0TQqgbUEhJvXxpu';
        $valid = password_verify($password, $hash);
        if (!$user || !$valid) {
            self::logEvent($user['id'] ?? null, 'login_failed', $r);
            throw new HttpException(401, 'invalid_credentials', self::GENERIC_LOGIN_ERROR);
        }
        $isStaff = Auth::isStaff($user);
        if ($staffPortal !== $isStaff) {
            // Staff must use the admin portal; users cannot log in via the admin portal.
            self::logEvent((int) $user['id'], 'login_wrong_portal', $r);
            throw new HttpException(401, 'invalid_credentials', self::GENERIC_LOGIN_ERROR);
        }
        if (!Auth::isActive($user)) {
            throw new HttpException(403, 'account_suspended', 'Akaunti yako imesitishwa. Wasiliana na Mediator.');
        }
        if ($user['status'] === 'suspended') {
            DB::update('users', ['status' => 'active', 'suspended_until' => null], ['id' => $user['id']]);
        }
        if (password_needs_rehash($hash, PASSWORD_DEFAULT)) {
            DB::update('users', ['password_hash' => password_hash($password, PASSWORD_DEFAULT)], ['id' => $user['id']]);
        }
        RateLimiter::clear('login-phone:' . $phone);

        if ($isStaff && (int) $user['totp_enabled'] === 1) {
            session_regenerate_id(true);
            $_SESSION = ['pending_2fa' => (int) $user['id'], 'pending_2fa_at' => time(), 'csrf' => bin2hex(random_bytes(32))];
            Response::ok(['requires_2fa' => true, 'csrf' => Auth::csrfToken()]);
        }
        self::completeLogin($user, $r);
    }

    public static function verifyTwoFactor(Request $r): void
    {
        $uid = $_SESSION['pending_2fa'] ?? null;
        if (!is_int($uid) || time() - (int) ($_SESSION['pending_2fa_at'] ?? 0) > 300) {
            unset($_SESSION['pending_2fa']);
            throw new HttpException(401, 'two_factor_expired', 'Muda umeisha. Ingia upya.');
        }
        RateLimiter::hit('2fa:' . $uid, 6, 900);
        $user = DB::one('SELECT * FROM users WHERE id = ?', [$uid]);
        $secret = Crypto::decrypt($user['totp_secret'] ?? null);
        if (!$user || $secret === null || !Totp::verify($secret, $r->str('code'))) {
            self::logEvent($uid, '2fa_failed', $r);
            throw HttpException::validation(['code' => 'code_invalid']);
        }
        self::completeLogin($user, $r);
    }

    /** @param array<string,mixed> $user */
    private static function completeLogin(array $user, Request $r): never
    {
        Auth::login($user);
        DB::update('users', ['last_login_at' => DB::now()], ['id' => $user['id']]);
        self::logEvent((int) $user['id'], 'login', $r);
        if (Auth::isStaff($user)) {
            Audit::log('staff.login', 'user', (int) $user['id']);
        }
        $fresh = DB::one('SELECT * FROM users WHERE id = ?', [$user['id']]);
        Response::ok(['user' => Auth::publicUser($fresh), 'csrf' => Auth::csrfToken()]);
    }

    public static function logout(Request $r): void
    {
        $uid = Auth::id();
        if ($uid) {
            self::logEvent($uid, 'logout', $r);
        }
        Auth::logout();
        Response::ok();
    }

    /** Step 1: request an OTP. Always returns the same response (no account enumeration). */
    public static function forgotPassword(Request $r): void
    {
        RateLimiter::hit('forgot-ip:' . $r->ip(), 10, 3600);
        $phone = Phone::normalize($r->str('phone'));
        if ($phone !== null && !RateLimiter::tooMany('forgot-phone:' . $phone, 3, 3600)) {
            $user = DB::one("SELECT id, status FROM users WHERE phone = ? AND role = 'user'", [$phone]);
            if ($user && $user['status'] !== 'disabled') {
                $code = (string) random_int(100000, 999999);
                DB::run("UPDATE otp_codes SET used_at = ? WHERE user_id = ? AND purpose = 'password_reset' AND used_at IS NULL", [DB::now(), $user['id']]);
                DB::insert('otp_codes', [
                    'user_id' => $user['id'],
                    'purpose' => 'password_reset',
                    'code_hash' => password_hash($code, PASSWORD_DEFAULT),
                    'expires_at' => date('Y-m-d H:i:s', time() + 600),
                    'created_at' => DB::now(),
                ]);
                Sms::send($phone, "Mediator Hamza: Namba yako ya kurejesha nenosiri ni {$code}. Inaisha baada ya dakika 10. Usimpe mtu yeyote.");
            }
        }
        Response::ok([
            'message' => 'Kama namba hii imesajiliwa, utapokea SMS yenye namba ya uthibitisho.',
            'sms_enabled' => Sms::isLive(),
        ]);
    }

    /** Step 2: verify OTP (user-requested SMS code or admin-issued recovery code) and set a new password. */
    public static function resetPassword(Request $r): void
    {
        RateLimiter::hit('reset-ip:' . $r->ip(), 20, 3600);
        $data = Validator::validate($r->body(), [
            'phone' => 'required|phone',
            'code' => 'required|string|max:20',
            'password' => 'required|string|min:8|max:200',
            'password_confirmation' => 'required|string',
        ]);
        if ($data['password'] !== $data['password_confirmation']) {
            throw HttpException::validation(['password_confirmation' => 'password_mismatch']);
        }
        if (!self::strongEnough($data['password'])) {
            throw HttpException::validation(['password' => 'password_weak']);
        }
        $invalid = HttpException::validation(['code' => 'code_invalid']);
        $user = DB::one("SELECT * FROM users WHERE phone = ? AND role = 'user'", [$data['phone']]);
        if (!$user) {
            throw $invalid;
        }
        $otp = DB::one(
            "SELECT * FROM otp_codes WHERE user_id = ? AND purpose IN ('password_reset','admin_reset')
             AND used_at IS NULL AND expires_at > ? ORDER BY id DESC LIMIT 1",
            [$user['id'], DB::now()]
        );
        if (!$otp || $otp['attempts'] >= 5) {
            throw $invalid;
        }
        if (!password_verify(strtoupper(preg_replace('/\s+/', '', $data['code']) ?? ''), $otp['code_hash'])) {
            DB::run('UPDATE otp_codes SET attempts = attempts + 1 WHERE id = ?', [$otp['id']]);
            throw $invalid;
        }
        DB::transaction(static function () use ($user, $otp, $data): void {
            DB::update('otp_codes', ['used_at' => DB::now()], ['id' => $otp['id']]);
            DB::run(
                'UPDATE users SET password_hash = ?, session_version = session_version + 1, phone_verified_at = COALESCE(phone_verified_at, ?), updated_at = ? WHERE id = ?',
                [password_hash($data['password'], PASSWORD_DEFAULT), DB::now(), DB::now(), $user['id']]
            );
        });
        self::logEvent((int) $user['id'], 'password_reset', $r);
        Response::ok(['message' => 'Nenosiri limebadilishwa. Sasa unaweza kuingia.']);
    }

    public static function strongEnough(string $password): bool
    {
        return mb_strlen($password) >= 8 && preg_match('/\d/', $password) === 1 && preg_match('/\p{L}/u', $password) === 1;
    }

    private static function titleCase(string $s): string
    {
        return mb_convert_case(mb_strtolower($s), MB_CASE_TITLE);
    }

    public static function logEvent(?int $userId, string $event, Request $r): void
    {
        DB::insert('login_events', [
            'user_id' => $userId,
            'event' => $event,
            'ip_address' => $r->ip(),
            'user_agent' => $r->userAgent(),
            'created_at' => DB::now(),
        ]);
    }

    /**
     * One-time installer: creates the first Super Admin. Only works when
     * INSTALL_TOKEN is set (>= 24 chars) AND no super admin exists yet.
     */
    public static function install(Request $r): void
    {
        $token = Env::get('INSTALL_TOKEN', '') ?? '';
        RateLimiter::hit('install:' . $r->ip(), 5, 3600);
        if (strlen($token) < 24 || !hash_equals($token, $r->str('install_token'))) {
            throw HttpException::forbidden();
        }
        if (DB::value("SELECT COUNT(*) FROM users WHERE role = 'super_admin'") > 0) {
            throw new HttpException(409, 'already_installed', 'Installation already completed.');
        }
        $data = Validator::validate($r->body(), [
            'first_name' => 'required|string|max:80',
            'second_name' => 'required|string|max:80',
            'phone' => 'required|phone',
            'password' => 'required|string|min:12|max:200',
        ]);
        if (!self::strongEnough($data['password'])) {
            throw HttpException::validation(['password' => 'password_weak']);
        }
        if (DB::value('SELECT id FROM users WHERE phone = ?', [$data['phone']]) !== null) {
            throw HttpException::validation(['phone' => 'phone_taken']);
        }
        $now = DB::now();
        $id = DB::insert('users', [
            'first_name' => $data['first_name'], 'second_name' => $data['second_name'], 'phone' => $data['phone'],
            'password_hash' => password_hash($data['password'], PASSWORD_DEFAULT), 'role' => 'super_admin',
            'created_at' => $now, 'updated_at' => $now,
        ]);
        Audit::log('install.super_admin_created', 'user', $id);
        Response::created(['message' => 'Super Admin created. Remove INSTALL_TOKEN from .env now.']);
    }
}
