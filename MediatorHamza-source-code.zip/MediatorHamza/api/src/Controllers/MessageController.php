<?php
declare(strict_types=1);

namespace Mediator\Controllers;

use Mediator\Core\Auth;
use Mediator\Core\DB;
use Mediator\Core\HttpException;
use Mediator\Core\Notifier;
use Mediator\Core\RateLimiter;
use Mediator\Core\Request;
use Mediator\Core\Response;

/** Chat with admin: user side + shared helpers used by the admin controller. */
final class MessageController
{
    /** @return array<string,mixed> */
    public static function conversationSummary(array $c): array
    {
        return [
            'id' => (int) $c['id'],
            'subject' => $c['subject'],
            'status' => $c['status'],
            'application_id' => $c['application_id'] !== null ? (int) $c['application_id'] : null,
            'application_reference' => $c['reference'] ?? null,
            'awaiting_reply' => (bool) $c['awaiting_reply'],
            'last_message_at' => $c['last_message_at'],
            'last_message' => $c['last_message'] ?? null,
            'unread' => (int) ($c['unread'] ?? 0),
            'user_name' => isset($c['first_name']) ? trim($c['first_name'] . ' ' . $c['second_name']) : null,
            'user_phone' => $c['phone'] ?? null,
            'user_id' => (int) $c['user_id'],
            'created_at' => $c['created_at'],
        ];
    }

    /** @return list<array<string,mixed>> */
    public static function messages(int $conversationId): array
    {
        return array_map(static fn ($m) => [
            'id' => (int) $m['id'],
            'body' => $m['body'],
            'from_staff' => (bool) $m['from_staff'],
            'sender_name' => $m['from_staff'] ? ($m['first_name'] ?? 'Mediator') : trim(($m['first_name'] ?? '') . ' ' . ($m['second_name'] ?? '')),
            'read' => $m['read_at'] !== null,
            'created_at' => $m['created_at'],
        ], DB::all(
            'SELECT m.*, u.first_name, u.second_name FROM messages m LEFT JOIN users u ON u.id = m.sender_id
             WHERE m.conversation_id = ? ORDER BY m.id',
            [$conversationId]
        ));
    }

    public static function index(Request $r): void
    {
        $user = Auth::requireUser();
        $rows = DB::all(
            "SELECT c.*, a.reference,
                    (SELECT body FROM messages WHERE conversation_id = c.id ORDER BY id DESC LIMIT 1) AS last_message,
                    (SELECT COUNT(*) FROM messages WHERE conversation_id = c.id AND from_staff = 1 AND read_at IS NULL) AS unread
             FROM conversations c LEFT JOIN applications a ON a.id = c.application_id
             WHERE c.user_id = ? ORDER BY c.last_message_at DESC",
            [$user['id']]
        );
        Response::ok(array_map([self::class, 'conversationSummary'], $rows));
    }

    public static function create(Request $r): void
    {
        $user = Auth::requireUser();
        RateLimiter::hit('conv-create:' . $user['id'], 10, 3600);
        $subject = mb_substr($r->str('subject'), 0, 200);
        $body = mb_substr($r->str('body'), 0, 4000);
        $errors = [];
        if ($subject === '') {
            $errors['subject'] = 'required';
        }
        if ($body === '') {
            $errors['body'] = 'required';
        }
        if ($errors) {
            throw HttpException::validation($errors);
        }
        $appId = null;
        if ($r->input('application_id')) {
            $appId = DB::value('SELECT id FROM applications WHERE id = ? AND user_id = ?', [(int) $r->input('application_id'), $user['id']]);
            if ($appId === null) {
                throw HttpException::validation(['application_id' => 'invalid']);
            }
        }
        $now = DB::now();
        $id = DB::transaction(static function () use ($user, $subject, $body, $appId, $now) {
            $id = DB::insert('conversations', [
                'user_id' => $user['id'], 'application_id' => $appId, 'subject' => $subject,
                'status' => 'open', 'awaiting_reply' => 1, 'last_message_at' => $now, 'created_at' => $now,
            ]);
            DB::insert('messages', ['conversation_id' => $id, 'sender_id' => $user['id'], 'from_staff' => 0, 'body' => $body, 'created_at' => $now]);
            return $id;
        });
        Response::created(['id' => $id]);
    }

    public static function show(Request $r): void
    {
        $user = Auth::requireUser();
        $c = DB::one(
            'SELECT c.*, a.reference FROM conversations c LEFT JOIN applications a ON a.id = c.application_id WHERE c.id = ? AND c.user_id = ?',
            [$r->intParam('id'), $user['id']]
        );
        if (!$c) {
            throw HttpException::notFound();
        }
        DB::run('UPDATE messages SET read_at = ? WHERE conversation_id = ? AND from_staff = 1 AND read_at IS NULL', [DB::now(), $c['id']]);
        Response::ok(['conversation' => self::conversationSummary($c), 'messages' => self::messages((int) $c['id'])]);
    }

    public static function reply(Request $r): void
    {
        $user = Auth::requireUser();
        RateLimiter::hit('msg:' . $user['id'], 60, 3600);
        $c = DB::one('SELECT * FROM conversations WHERE id = ? AND user_id = ?', [$r->intParam('id'), $user['id']]);
        if (!$c) {
            throw HttpException::notFound();
        }
        $body = mb_substr($r->str('body'), 0, 4000);
        if ($body === '') {
            throw HttpException::validation(['body' => 'required']);
        }
        $now = DB::now();
        DB::insert('messages', ['conversation_id' => $c['id'], 'sender_id' => $user['id'], 'from_staff' => 0, 'body' => $body, 'created_at' => $now]);
        DB::update('conversations', ['status' => 'open', 'awaiting_reply' => 1, 'last_message_at' => $now], ['id' => $c['id']]);
        Response::created();
    }

    /** Used by the admin controller. */
    public static function staffReply(int $conversationId, int $staffId, string $body): void
    {
        $c = DB::one('SELECT * FROM conversations WHERE id = ?', [$conversationId]);
        if (!$c) {
            throw HttpException::notFound();
        }
        $now = DB::now();
        DB::insert('messages', ['conversation_id' => $c['id'], 'sender_id' => $staffId, 'from_staff' => 1, 'body' => $body, 'created_at' => $now]);
        DB::update('conversations', ['awaiting_reply' => 0, 'last_message_at' => $now], ['id' => $c['id']]);
        DB::run('UPDATE messages SET read_at = ? WHERE conversation_id = ? AND from_staff = 0 AND read_at IS NULL', [$now, $c['id']]);
        Notifier::notify(
            (int) $c['user_id'], 'message',
            'Ujumbe mpya kutoka Mediator', 'Umepokea jibu kuhusu: ' . $c['subject'], '/app/ujumbe/' . $c['id'],
            'New message from Mediator', 'You have a reply about: ' . $c['subject'],
        );
    }
}
