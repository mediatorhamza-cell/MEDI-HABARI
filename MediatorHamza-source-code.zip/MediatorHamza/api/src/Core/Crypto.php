<?php
declare(strict_types=1);

namespace Mediator\Core;

use RuntimeException;

/**
 * Authenticated symmetric encryption for sensitive fields.
 * v2: AES-256-GCM via OpenSSL (always available on shared hosting).
 * v1: libsodium secretbox (read support kept when the extension exists).
 */
final class Crypto
{
    private const KEY_BYTES = 32;

    private static function key(): string
    {
        $raw = Env::get('APP_KEY', '') ?? '';
        if (str_starts_with($raw, 'base64:')) {
            $raw = substr($raw, 7);
        }
        $key = base64_decode($raw, true);
        if ($key === false || strlen($key) !== self::KEY_BYTES) {
            throw new RuntimeException('APP_KEY is missing or invalid. Run: php bin/generate-key.php');
        }
        return $key;
    }

    public static function encrypt(string $plain): string
    {
        $iv = random_bytes(12);
        $tag = '';
        $cipher = openssl_encrypt($plain, 'aes-256-gcm', self::key(), OPENSSL_RAW_DATA, $iv, $tag, '', 16);
        if ($cipher === false) {
            throw new RuntimeException('Encryption failed');
        }
        return 'v2:' . base64_encode($iv . $tag . $cipher);
    }

    public static function decrypt(?string $cipher): ?string
    {
        if ($cipher === null || $cipher === '') {
            return null;
        }
        if (str_starts_with($cipher, 'v2:')) {
            $bin = base64_decode(substr($cipher, 3), true);
            if ($bin === false || strlen($bin) < 28) {
                return null;
            }
            $plain = openssl_decrypt(substr($bin, 28), 'aes-256-gcm', self::key(), OPENSSL_RAW_DATA, substr($bin, 0, 12), substr($bin, 12, 16));
            return $plain === false ? null : $plain;
        }
        if (str_starts_with($cipher, 'v1:') && function_exists('sodium_crypto_secretbox_open')) {
            $bin = base64_decode(substr($cipher, 3), true);
            if ($bin === false || strlen($bin) < 24) {
                return null;
            }
            $plain = sodium_crypto_secretbox_open(substr($bin, 24), substr($bin, 0, 24), self::key());
            return $plain === false ? null : $plain;
        }
        return null;
    }

    /** @param array<string,mixed> $data */
    public static function encryptJson(array $data): ?string
    {
        return $data === [] ? null : self::encrypt(json_encode($data, JSON_UNESCAPED_UNICODE));
    }

    /** @return array<string,mixed> */
    public static function decryptJson(?string $cipher): array
    {
        $plain = self::decrypt($cipher);
        $data = $plain === null ? null : json_decode($plain, true);
        return is_array($data) ? $data : [];
    }

    public static function generateKey(): string
    {
        return 'base64:' . base64_encode(random_bytes(self::KEY_BYTES));
    }
}
