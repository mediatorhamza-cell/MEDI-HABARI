<?php
declare(strict_types=1);

namespace Mediator\Core;

/** Key/value site settings stored as JSON (brand, contacts, homepage copy, banks...). */
final class Settings
{
    /** Keys that may be returned to anonymous visitors. */
    public const PUBLIC_KEYS = [
        'brand_name', 'tagline', 'tagline_en', 'description_sw', 'description_en', 'logo_file_id', 'favicon_file_id',
        'contact_phone', 'contact_whatsapp', 'contact_sms', 'contact_email', 'working_hours_sw', 'working_hours_en',
        'address', 'social_facebook', 'social_instagram', 'social_tiktok', 'social_linkedin', 'social_youtube',
        'social_x', 'hero_title_sw', 'hero_title_en', 'hero_text_sw', 'hero_text_en', 'welcome_note_sw',
        'welcome_note_en', 'about_sw', 'about_en', 'privacy_sw', 'privacy_en', 'terms_sw', 'terms_en',
        'default_language', 'payment_instructions_sw', 'payment_instructions_en', 'banks', 'heslb_levels',
        'dashboard_welcome_sw', 'dashboard_welcome_en', 'site_live', 'coming_soon_sw', 'coming_soon_en',
    ];

    /** @var array<string,mixed>|null */
    private static ?array $cache = null;

    /** @return array<string,mixed> */
    public static function all(): array
    {
        if (self::$cache === null) {
            self::$cache = [];
            foreach (DB::all('SELECT setting_key, setting_value FROM settings') as $row) {
                self::$cache[$row['setting_key']] = json_decode((string) $row['setting_value'], true);
            }
        }
        return self::$cache;
    }

    public static function get(string $key, mixed $default = null): mixed
    {
        return self::all()[$key] ?? $default;
    }

    public static function set(string $key, mixed $value): void
    {
        DB::run(
            'INSERT INTO settings (setting_key, setting_value, updated_at) VALUES (?, ?, ?)
             ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = VALUES(updated_at)',
            [$key, json_encode($value, JSON_UNESCAPED_UNICODE), DB::now()]
        );
        self::$cache = null;
    }

    /** @return array<string,mixed> */
    public static function publicSettings(): array
    {
        $all = self::all();
        $out = [];
        foreach (self::PUBLIC_KEYS as $k) {
            $out[$k] = $all[$k] ?? null;
        }
        return $out;
    }
}
