<?php
declare(strict_types=1);

namespace Mediator\Core;

/** Collision-safe application reference numbers, e.g. MED-2026-HESLB-000001. */
final class Reference
{
    public static function next(string $serviceCode): string
    {
        $year = (int) date('Y');
        return DB::transaction(static function () use ($serviceCode, $year): string {
            DB::run(
                'INSERT INTO reference_sequences (service_code, seq_year, last_value) VALUES (?, ?, 0)
                 ON DUPLICATE KEY UPDATE last_value = last_value',
                [$serviceCode, $year]
            );
            // Row lock serialises concurrent submissions for the same service/year.
            $current = (int) DB::value(
                'SELECT last_value FROM reference_sequences WHERE service_code = ? AND seq_year = ? FOR UPDATE',
                [$serviceCode, $year]
            );
            $next = $current + 1;
            DB::run(
                'UPDATE reference_sequences SET last_value = ? WHERE service_code = ? AND seq_year = ?',
                [$next, $serviceCode, $year]
            );
            return sprintf('MED-%d-%s-%06d', $year, $serviceCode, $next);
        });
    }
}
