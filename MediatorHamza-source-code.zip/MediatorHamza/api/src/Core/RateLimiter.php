<?php
declare(strict_types=1);

namespace Mediator\Core;

/** Fixed-window rate limiter stored in MySQL (works on shared hosting without Redis). */
final class RateLimiter
{
    public static function hit(string $key, int $max, int $windowSeconds): void
    {
        if (self::tooMany($key, $max, $windowSeconds)) {
            throw new HttpException(429, 'too_many_requests', 'Too many attempts. Please wait and try again.');
        }
    }

    public static function tooMany(string $key, int $max, int $windowSeconds): bool
    {
        $hash = hash('sha256', $key);
        $now = time();
        $windowStart = $now - ($now % $windowSeconds);
        DB::run(
            'INSERT INTO rate_limits (bucket, window_start, hits) VALUES (?, ?, 1)
             ON DUPLICATE KEY UPDATE hits = IF(window_start = VALUES(window_start), hits + 1, 1),
                                     window_start = VALUES(window_start)',
            [$hash, $windowStart]
        );
        $hits = (int) DB::value('SELECT hits FROM rate_limits WHERE bucket = ?', [$hash]);
        if (random_int(1, 200) === 1) {
            DB::run('DELETE FROM rate_limits WHERE window_start < ?', [$now - 86400]);
        }
        return $hits > $max;
    }

    public static function clear(string $key): void
    {
        DB::run('DELETE FROM rate_limits WHERE bucket = ?', [hash('sha256', $key)]);
    }
}
