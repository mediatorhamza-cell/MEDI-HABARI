<?php
declare(strict_types=1);

namespace Mediator\Core;

/** Applies SQL migrations; used by the CLI and automatically after each deployment. */
final class Migrator
{
    /** @return list<string> applied migration names */
    public static function run(): array
    {
        DB::pdo()->exec('CREATE TABLE IF NOT EXISTS schema_migrations (name VARCHAR(190) PRIMARY KEY, applied_at DATETIME NOT NULL) ENGINE=InnoDB');
        $applied = array_column(DB::all('SELECT name FROM schema_migrations'), 'name');
        $done = [];
        foreach (self::files() as $file) {
            $name = basename($file);
            if (in_array($name, $applied, true)) {
                continue;
            }
            $sql = (string) file_get_contents($file);
            foreach (preg_split('/;\s*\n/', $sql) ?: [] as $statement) {
                $lines = array_filter(explode("\n", $statement), static fn ($l) => !str_starts_with(trim($l), '--'));
                $statement = trim(implode("\n", $lines));
                if ($statement !== '') {
                    DB::pdo()->exec($statement);
                }
            }
            DB::insert('schema_migrations', ['name' => $name, 'applied_at' => DB::now()]);
            $done[] = $name;
        }
        return $done;
    }

    /** @return list<string> */
    private static function files(): array
    {
        $files = glob(MEDIATOR_API_ROOT . '/database/migrations/*.sql') ?: [];
        sort($files);
        return $files;
    }

    /**
     * Cheap per-request check: runs pending migrations + idempotent seed once per
     * deployed code version (marker file in storage), guarded by a MySQL lock.
     */
    public static function ensure(): void
    {
        // Re-run when migrations, the seeder (e.g. a new service) or this file change.
        $seeder = __DIR__ . '/Seeder.php';
        $sig = substr(hash('sha256', implode('|', array_map(static fn ($f) => basename($f) . filesize($f), self::files())) . filemtime(__FILE__) . filesize($seeder) . filesize(__FILE__)), 0, 16);
        $marker = Env::storagePath('logs/.schema-' . $sig);
        if (is_file($marker)) {
            return;
        }
        if ((int) DB::value("SELECT GET_LOCK('mediator_migrate', 20)") !== 1) {
            return;
        }
        try {
            self::run();
            Seeder::run(false);
            @file_put_contents($marker, date('c'));
        } finally {
            DB::value("SELECT RELEASE_LOCK('mediator_migrate')");
        }
    }
}
