<?php
declare(strict_types=1);

namespace Mediator\Core;

/**
 * Minimal rule-based validator for non-form endpoints.
 * Rules: required, string, max:N, min:N, email, phone, url, int, in:a,b, date, bool
 * Error values are translation keys understood by the frontend (validation.*).
 */
final class Validator
{
    /**
     * @param array<string,mixed> $data
     * @param array<string,string> $rules
     * @return array<string,mixed> cleaned values
     */
    public static function validate(array $data, array $rules): array
    {
        $errors = [];
        $clean = [];
        foreach ($rules as $field => $ruleString) {
            $rulesList = explode('|', $ruleString);
            $value = $data[$field] ?? null;
            if (is_string($value)) {
                $value = trim($value);
            }
            $empty = $value === null || $value === '' || $value === [];
            if ($empty) {
                if (in_array('required', $rulesList, true)) {
                    $errors[$field] = 'required';
                } else {
                    $clean[$field] = in_array('bool', $rulesList, true) ? false : null;
                }
                continue;
            }
            foreach ($rulesList as $rule) {
                [$name, $arg] = array_pad(explode(':', $rule, 2), 2, null);
                $error = null;
                switch ($name) {
                    case 'string':
                        if (!is_string($value)) { $error = 'invalid'; }
                        break;
                    case 'max':
                        if (is_string($value) && mb_strlen($value) > (int) $arg) { $error = 'too_long'; }
                        break;
                    case 'min':
                        if (is_string($value) && mb_strlen($value) < (int) $arg) { $error = 'too_short'; }
                        break;
                    case 'email':
                        if (!filter_var($value, FILTER_VALIDATE_EMAIL)) { $error = 'email'; }
                        break;
                    case 'url':
                        if (!filter_var($value, FILTER_VALIDATE_URL) || !preg_match('#^https?://#i', (string) $value)) { $error = 'url'; }
                        break;
                    case 'phone':
                        $n = is_string($value) ? Phone::normalize($value) : null;
                        if ($n === null) { $error = 'phone'; } else { $value = $n; }
                        break;
                    case 'int':
                        if (filter_var($value, FILTER_VALIDATE_INT) === false) { $error = 'number'; } else { $value = (int) $value; }
                        break;
                    case 'in':
                        if (!in_array((string) $value, explode(',', (string) $arg), true)) { $error = 'invalid'; }
                        break;
                    case 'date':
                        $d = \DateTime::createFromFormat('Y-m-d', (string) $value);
                        if (!$d || $d->format('Y-m-d') !== $value) { $error = 'date'; }
                        break;
                    case 'datetime':
                        $ts = strtotime((string) $value);
                        if ($ts === false) { $error = 'date'; } else { $value = date('Y-m-d H:i:s', $ts); }
                        break;
                    case 'bool':
                        $value = $value === true || $value === 1 || $value === '1' || $value === 'true';
                        break;
                }
                if ($error !== null) {
                    $errors[$field] = $error;
                    break;
                }
            }
            if (!isset($errors[$field])) {
                $clean[$field] = $value;
            }
        }
        if ($errors !== []) {
            throw HttpException::validation($errors);
        }
        return $clean;
    }
}
