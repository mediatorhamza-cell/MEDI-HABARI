<?php
declare(strict_types=1);

namespace Mediator\Core;

/**
 * Cookie-based PHP session authentication.
 * The role is ALWAYS read from the database on each request; nothing the
 * browser sends can change it.
 */
final class Auth
{
    public const STAFF_ROLES = ['super_admin', 'admin', 'support', 'readonly'];

    /** Role => permissions. '*' grants everything. */
    private const PERMISSIONS = [
        'super_admin' => ['*'],
        'admin' => [
            'dashboard.view', 'applications.view', 'applications.update', 'applications.sensitive',
            'applications.results', 'payments.update', 'users.view', 'users.manage', 'messages.manage',
            'notifications.send', 'content.manage', 'services.manage', 'reports.export', 'settings.manage',
            'audit.view', 'contact.view',
        ],
        'support' => [
            'dashboard.view', 'applications.view', 'applications.update', 'applications.sensitive',
            'applications.results', 'payments.update', 'users.view', 'messages.manage', 'notifications.send',
            'contact.view',
        ],
        'readonly' => ['dashboard.view', 'applications.view', 'users.view', 'reports.export'],
        'user' => [],
    ];

    /** @var array<string,mixed>|null|false */
    private static array|null|false $user = false;

    public static function startSession(Request $request): void
    {
        if (session_status() === PHP_SESSION_ACTIVE) {
            return;
        }
        // Anonymous GETs (bootstrap, content) must not create sessions: parallel first
        // requests would otherwise race and overwrite each other's session cookie.
        $hasCookie = isset($_COOKIE[Env::get('SESSION_NAME', 'mediator_sid')]);
        if (!$hasCookie && $request->method === 'GET' && $request->path !== '/auth/session') {
            return;
        }
        $path = Env::storagePath('sessions');
        if (is_dir($path) && is_writable($path)) {
            session_save_path($path);
        }
        session_name(Env::get('SESSION_NAME', 'mediator_sid'));
        ini_set('session.use_strict_mode', '1');
        ini_set('session.use_only_cookies', '1');
        ini_set('session.gc_maxlifetime', (string) (self::idleTimeout(true) + 300));
        session_set_cookie_params([
            'lifetime' => 0,
            'path' => '/',
            'secure' => $request->isSecure() || Env::bool('SESSION_SECURE', Env::isProduction()),
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
        session_start();

        $now = time();
        $last = $_SESSION['last_activity'] ?? $now;
        $isStaff = in_array($_SESSION['role'] ?? '', self::STAFF_ROLES, true);
        if (isset($_SESSION['uid']) && $now - $last > self::idleTimeout($isStaff)) {
            self::destroySession();
            session_start();
        }
        // Background polls (badges, chat refresh) must not keep an idle session alive.
        if ($request->header('X-Background') !== '1' || !isset($_SESSION['last_activity'])) {
            $_SESSION['last_activity'] = $now;
        }
    }

    /** @return array{timeout:int,remaining:int} idle-timeout facts for the signed-in session */
    public static function idleInfo(): array
    {
        $isStaff = in_array($_SESSION['role'] ?? '', self::STAFF_ROLES, true);
        $timeout = self::idleTimeout($isStaff);
        $last = (int) ($_SESSION['last_activity'] ?? time());
        return ['timeout' => $timeout, 'remaining' => max(0, $timeout - (time() - $last))];
    }

    private static function idleTimeout(bool $staff): int
    {
        return $staff
            ? Env::int('ADMIN_SESSION_IDLE_MINUTES', 60) * 60
            : Env::int('SESSION_IDLE_MINUTES', 240) * 60;
    }

    /** @return array<string,mixed>|null */
    public static function user(): ?array
    {
        if (self::$user !== false) {
            return self::$user;
        }
        $uid = $_SESSION['uid'] ?? null;
        if (!is_int($uid)) {
            return self::$user = null;
        }
        $row = DB::one('SELECT * FROM users WHERE id = ?', [$uid]);
        if ($row === null || !self::isActive($row) || ($row['session_version'] ?? 0) !== ($_SESSION['sv'] ?? -1)) {
            self::destroySession();
            return self::$user = null;
        }
        return self::$user = $row;
    }

    /** @param array<string,mixed> $user */
    public static function isActive(array $user): bool
    {
        if ($user['status'] === 'disabled') {
            return false;
        }
        if ($user['status'] === 'suspended') {
            return $user['suspended_until'] !== null && strtotime((string) $user['suspended_until']) <= time();
        }
        return true;
    }

    /** @param array<string,mixed> $user */
    public static function login(array $user): void
    {
        session_regenerate_id(true); // prevent session fixation
        $_SESSION = [
            'uid' => (int) $user['id'],
            'role' => $user['role'],
            'sv' => (int) $user['session_version'],
            'last_activity' => time(),
            'csrf' => bin2hex(random_bytes(32)),
        ];
        self::$user = false;
    }

    public static function logout(): void
    {
        self::destroySession();
        self::$user = null;
    }

    private static function destroySession(): void
    {
        $_SESSION = [];
        if (session_status() === PHP_SESSION_ACTIVE) {
            $p = session_get_cookie_params();
            setcookie(session_name(), '', [
                'expires' => time() - 3600, 'path' => $p['path'], 'secure' => $p['secure'],
                'httponly' => true, 'samesite' => 'Lax',
            ]);
            session_destroy();
        }
    }

    public static function id(): int
    {
        $u = self::user();
        return $u ? (int) $u['id'] : 0;
    }

    /** @return array<string,mixed> */
    public static function requireUser(): array
    {
        $u = self::user();
        if ($u === null) {
            throw HttpException::unauthenticated();
        }
        return $u;
    }

    /** @return array<string,mixed> */
    public static function requireStaff(?string $permission = null): array
    {
        $u = self::requireUser();
        if (!in_array($u['role'], self::STAFF_ROLES, true)) {
            throw HttpException::forbidden();
        }
        if ($permission !== null && !self::can($u, $permission)) {
            throw HttpException::forbidden();
        }
        return $u;
    }

    /** @param array<string,mixed> $user */
    public static function can(array $user, string $permission): bool
    {
        $perms = self::PERMISSIONS[$user['role']] ?? [];
        return in_array('*', $perms, true) || in_array($permission, $perms, true);
    }

    /** @param array<string,mixed> $user @return list<string> */
    public static function permissions(array $user): array
    {
        $perms = self::PERMISSIONS[$user['role']] ?? [];
        if (in_array('*', $perms, true)) {
            $all = [];
            foreach (self::PERMISSIONS as $list) {
                foreach ($list as $p) {
                    if ($p !== '*') {
                        $all[$p] = true;
                    }
                }
            }
            $all['staff.manage'] = true;
            return array_keys($all);
        }
        return $perms;
    }

    public static function isStaff(?array $user = null): bool
    {
        $user ??= self::user();
        return $user !== null && in_array($user['role'], self::STAFF_ROLES, true);
    }

    // ---------------------------------------------------------------- CSRF

    public static function csrfToken(): string
    {
        if (empty($_SESSION['csrf'])) {
            $_SESSION['csrf'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf'];
    }

    public static function verifyCsrf(Request $request): void
    {
        if (in_array($request->method, ['GET', 'HEAD', 'OPTIONS'], true)) {
            return;
        }
        $sent = $request->header('X-CSRF-Token') ?? '';
        $expected = $_SESSION['csrf'] ?? '';
        if ($expected === '' || !hash_equals($expected, $sent)) {
            throw new HttpException(403, 'csrf_mismatch', 'Session expired. Please refresh the page and try again.');
        }
    }

    /** @param array<string,mixed> $user @return array<string,mixed> */
    public static function publicUser(array $user): array
    {
        return [
            'id' => (int) $user['id'],
            'first_name' => $user['first_name'],
            'second_name' => $user['second_name'],
            'last_name' => $user['last_name'],
            'phone' => $user['phone'],
            'email' => $user['email'],
            'role' => $user['role'],
            'language' => $user['language'],
            'is_staff' => self::isStaff($user),
            'permissions' => self::permissions($user),
            'totp_enabled' => (bool) $user['totp_enabled'],
            'phone_verified' => $user['phone_verified_at'] !== null,
            'created_at' => $user['created_at'],
        ];
    }
}
