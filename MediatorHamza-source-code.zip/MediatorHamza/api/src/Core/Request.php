<?php
declare(strict_types=1);

namespace Mediator\Core;

final class Request
{
    /** @var array<string,mixed>|null */
    private ?array $jsonBody = null;

    /** @param array<string,string> $params route params */
    public function __construct(
        public readonly string $method,
        public readonly string $path,
        public array $params = [],
    ) {
    }

    public static function capture(): self
    {
        $method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
        // Some shared hosts (LiteSpeed/ModSecurity) reject PUT/DELETE, so the client tunnels them through POST.
        $override = strtoupper((string) ($_SERVER['HTTP_X_HTTP_METHOD_OVERRIDE'] ?? ''));
        if ($method === 'POST' && in_array($override, ['PUT', 'PATCH', 'DELETE'], true)) {
            $method = $override;
        }
        $uri = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
        $base = rtrim(Env::get('API_BASE_PATH', '/api') ?? '/api', '/');
        if ($base !== '' && str_starts_with($uri, $base)) {
            $uri = substr($uri, strlen($base));
        }
        $uri = '/' . trim($uri, '/');
        return new self($method, $uri);
    }

    public function param(string $key): string
    {
        return $this->params[$key] ?? '';
    }

    public function intParam(string $key): int
    {
        $v = $this->params[$key] ?? '';
        if (!ctype_digit($v)) {
            throw HttpException::notFound();
        }
        return (int) $v;
    }

    public function query(string $key, ?string $default = null): ?string
    {
        $v = $_GET[$key] ?? $default;
        return is_string($v) ? trim($v) : $default;
    }

    public function queryInt(string $key, int $default, int $min = 1, int $max = PHP_INT_MAX): int
    {
        $v = $_GET[$key] ?? null;
        if (!is_string($v) || !preg_match('/^\d+$/', $v)) {
            return $default;
        }
        return max($min, min($max, (int) $v));
    }

    /** @return array<string,mixed> */
    public function body(): array
    {
        if ($this->jsonBody !== null) {
            return $this->jsonBody;
        }
        $type = $_SERVER['CONTENT_TYPE'] ?? '';
        if (str_contains($type, 'application/json')) {
            $raw = file_get_contents('php://input') ?: '';
            if (strlen($raw) > 2_000_000) {
                throw new HttpException(413, 'payload_too_large', 'Request too large');
            }
            $decoded = $raw === '' ? [] : json_decode($raw, true);
            if (!is_array($decoded)) {
                throw HttpException::bad('invalid_json', 'Invalid JSON body');
            }
            $this->jsonBody = $decoded;
        } else {
            $this->jsonBody = $_POST;
        }
        return $this->jsonBody;
    }

    public function input(string $key, mixed $default = null): mixed
    {
        $body = $this->body();
        return $body[$key] ?? $default;
    }

    public function str(string $key, string $default = ''): string
    {
        $v = $this->input($key, $default);
        if (is_int($v) || is_float($v)) {
            $v = (string) $v;
        }
        return is_string($v) ? trim($v) : $default;
    }

    public function bool(string $key): bool
    {
        $v = $this->input($key, false);
        return $v === true || $v === 1 || $v === '1' || $v === 'true' || $v === 'on';
    }

    public function header(string $name): ?string
    {
        $key = 'HTTP_' . strtoupper(str_replace('-', '_', $name));
        return $_SERVER[$key] ?? null;
    }

    public function ip(): string
    {
        // Behind Hostinger's proxy REMOTE_ADDR is the client address; only trust
        // forwarded headers when explicitly configured.
        if (Env::bool('TRUST_PROXY_HEADERS')) {
            $fwd = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? '';
            if ($fwd !== '') {
                $first = trim(explode(',', $fwd)[0]);
                if (filter_var($first, FILTER_VALIDATE_IP)) {
                    return $first;
                }
            }
        }
        return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    }

    public function userAgent(): string
    {
        return mb_substr((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255);
    }

    public function isSecure(): bool
    {
        if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
            return true;
        }
        return Env::bool('TRUST_PROXY_HEADERS') && ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https';
    }
}
