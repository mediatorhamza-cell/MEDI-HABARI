<?php
declare(strict_types=1);

namespace Mediator\Core;

use Mediator\Controllers\Admin\ContentAdminController;

/**
 * Default settings, the six services, categories and starter content.
 * Idempotent: existing rows/keys are never overwritten.
 * Prices are intentionally left empty: set them in Admin > Huduma & Bei.
 */
final class Seeder
{
    /** @param callable(string):void $log */
    public static function run(bool $verifyLinks = false, ?callable $log = null): void
    {
        $log ??= static fn (string $m) => null;
        $now = DB::now();
        $opt = static fn (string $v, string $sw, string $en) => ['value' => $v, 'label' => ['sw' => $sw, 'en' => $en]];

        // ------------------------------------------------------------------ settings
        $defaults = [
            'brand_name' => 'Mediator Hamza',
            'tagline' => 'Safari yako ya elimu inaanza hapa.',
            'tagline_en' => 'Your education journey starts here.',
            'description_sw' => 'Pata elimu ya maombi, miongozo, taarifa za vyuo na msaada wa kufuatilia huduma zako sehemu moja.',
            'description_en' => 'Get application guidance, official guidebooks, institution information and help tracking your services in one place.',
            'hero_title_sw' => 'Safari yako ya elimu inaanza hapa.',
            'hero_title_en' => 'Your education journey starts here.',
            'hero_text_sw' => 'Fahamu taratibu za maombi, pata miongozo sahihi na fuatilia huduma zako sehemu moja.',
            'hero_text_en' => 'Understand application procedures, get the right guidance and track your services in one place.',
            'welcome_note_sw' => 'Karibu Mediator Hamza — tunakusaidia kuomba mikopo ya elimu, vyuo, vyeti vya kuzaliwa na vifo, NaPA na uhakiki wa vyeti bila usumbufu.',
            'welcome_note_en' => 'Welcome to Mediator Hamza — we help you apply for education loans, colleges, birth and death certificates, NaPA and certificate verification without hassle.',
            'dashboard_welcome_sw' => 'Chagua huduma unayohitaji, jaza taarifa, kisha fuatilia maendeleo ya ombi lako hapa.',
            'dashboard_welcome_en' => 'Choose the service you need, fill in the details, then track your application here.',
            'contact_phone' => '+255767033297',
            'contact_whatsapp' => '+255767033297',
            'contact_sms' => '+255767033297',
            'contact_email' => null,
            'working_hours_sw' => 'Jumatatu – Jumamosi: 2:00 asubuhi – 12:00 jioni',
            'working_hours_en' => 'Monday – Saturday: 8:00 AM – 6:00 PM',
            'address' => 'Tanzania',
            'default_language' => 'sw',
            'payment_instructions_sw' => 'Malipo hufanyika baada ya kuthibitishwa kwa ombi lako. Utapokea maelekezo ya namba ya malipo kupitia ujumbe (notification) kwenye akaunti yako. Usilipe kwa namba nyingine yoyote.',
            'payment_instructions_en' => 'Payment is made after your application is confirmed. You will receive payment number instructions as a notification in your account. Do not pay to any other number.',
            'about_sw' => "Mediator Hamza ni jukwaa la huduma kwa wanafunzi na wananchi linalorahisisha maombi ya mikopo ya elimu ya juu (HESLB), udahili wa vyuo, vyeti vya kuzaliwa na vifo, huduma za NaPA na uhakiki wa vyeti.\n\nTunatoa elimu ya maombi, miongozo rasmi na msaada wa karibu ili kila mwombaji akamilishe maombi yake kwa usahihi na kwa wakati.\n\nMediator si taasisi ya serikali. Tunakusaidia kuwasilisha maombi kwenye mifumo rasmi ya HESLB, TCU/NACTVET, RITA na NaPA kwa niaba yako na kwa ridhaa yako.",
            'about_en' => "Mediator Hamza is a student and citizen services platform that simplifies applications for higher education loans (HESLB), college admission, birth and death certificates, NaPA services and certificate verification.\n\nWe provide application education, official guidebooks and close support so that every applicant completes their application correctly and on time.\n\nMediator is not a government agency. We help you submit applications on the official HESLB, TCU/NACTVET, RITA and NaPA systems on your behalf and with your consent.",
            'privacy_sw' => "Sera hii ya faragha ni rasimu ya awali na inapaswa kupitiwa na mmiliki/mshauri wa sheria kabla ya kuchapishwa rasmi.\n\n1. Taarifa tunazokusanya: majina, namba ya simu, taarifa za maombi na nyaraka unazopakia kwa ajili ya huduma uliyoomba tu.\n2. Matumizi: tunatumia taarifa zako kushughulikia maombi yako, kuwasiliana nawe na kutimiza masharti ya kisheria.\n3. Taarifa nyeti (mf. majibu ya uhakiki wa NIDA, taarifa za akaunti za mifumo mingine) huhifadhiwa kwa usimbaji (encryption) na huonekana kwa wahudumu walioidhinishwa pekee.\n4. Hatuuzi wala kushiriki taarifa zako na watu wengine isipokuwa taasisi rasmi zinazohusika na huduma uliyoomba.\n5. Una haki ya kuomba kuona, kurekebisha au kufuta taarifa zako kwa kuwasiliana nasi.\n6. Tunatumia vidakuzi (cookies) vya lazima tu kwa ajili ya kuingia kwenye akaunti. Takwimu za wageni hazihifadhi anwani yako ya IP.",
            'privacy_en' => "This privacy policy is an initial draft and should be reviewed by the owner/legal adviser before formal publication.\n\n1. Data we collect: names, phone number, application details and documents you upload, only for the service you requested.\n2. Use: we use your data to process your applications, contact you and meet legal obligations.\n3. Sensitive data (e.g. NIDA verification answers, credentials for other portals) is stored encrypted and only visible to authorised staff.\n4. We do not sell or share your data except with the official institutions involved in the service you requested.\n5. You may request access to, correction or deletion of your data by contacting us.\n6. We only use essential cookies for logging in. Visitor statistics do not store your IP address.",
            'terms_sw' => "Masharti haya ni rasimu ya awali na yanapaswa kupitiwa na mmiliki kabla ya kuchapishwa rasmi.\n\n1. Kwa kutumia Mediator unakubali kutoa taarifa sahihi na za kweli.\n2. Mediator hukusaidia kuwasilisha maombi; maamuzi ya mwisho hufanywa na taasisi husika (HESLB, vyuo, TCU, NACTVET, RITA, NaPA).\n3. Ada ya huduma ni ile iliyoonyeshwa wakati wa kutuma ombi na haibadiliki kwa ombi hilo.\n4. Usishiriki nenosiri lako na mtu yeyote. Mediator haitakuomba nenosiri lako kwa simu.\n5. Mediator inaweza kusitisha akaunti inayotumika kwa udanganyifu.",
            'terms_en' => "These terms are an initial draft and should be reviewed by the owner before formal publication.\n\n1. By using Mediator you agree to provide accurate and truthful information.\n2. Mediator helps you submit applications; final decisions are made by the relevant institutions (HESLB, colleges, TCU, NACTVET, RITA, NaPA).\n3. The service fee is the one shown when you submit an application and does not change for that application.\n4. Do not share your password with anyone. Mediator will never ask for your password by phone.\n5. Mediator may suspend accounts used fraudulently.",
            'banks' => array_map(static fn ($b) => $opt($b, $b, $b), [
                'CRDB Bank', 'NMB Bank', 'NBC Bank', 'Absa Bank Tanzania', 'Stanbic Bank', 'Exim Bank', 'Equity Bank',
                'KCB Bank', 'DTB Bank', 'Azania Bank', 'TCB Bank (Tanzania Commercial Bank)', 'Akiba Commercial Bank',
                'Amana Bank', 'Bank of Africa', 'Mwalimu Commercial Bank', 'I&M Bank', 'Access Bank', 'Ecobank',
                'Standard Chartered', 'People\'s Bank of Zanzibar (PBZ)', 'Letshego Bank', 'Mkombozi Commercial Bank',
                'Maendeleo Bank', 'DCB Commercial Bank', 'UBA Bank', 'Uchumi Commercial Bank', 'Mucoba Bank', 'China Dasheng Bank',
            ]),
            'heslb_levels' => [$opt('degree', 'Shahada (Degree)', 'Degree'), $opt('diploma', 'Stashahada (Diploma)', 'Diploma')],
            'analytics_salt' => bin2hex(random_bytes(16)),
            'site_live' => false,
            'coming_soon_sw' => 'Mfumo wa Mediator Hamza unaandaliwa ili kukusaidia na maombi ya mikopo, vyuo, vyeti vya kuzaliwa na vifo, NaPA na uhakiki wa vyeti.',
            'coming_soon_en' => 'Mediator Hamza is getting ready to help you with loan, college, birth and death certificate, NaPA and certificate verification applications.',
        ];
        $existing = Settings::all();
        foreach ($defaults as $k => $v) {
            if (!array_key_exists($k, $existing)) {
                Settings::set($k, $v);
            }
        }
        $log("Settings ok\n");

        // ------------------------------------------------------------------ services
        $services = [
            ['HESLB', 'mikopo-ya-elimu-heslb', 'heslb', 'graduation-cap', 'Maombi ya Mikopo ya Elimu (HESLB)', 'Higher Education Loans (HESLB)',
                'Tunakusaidia kujaza na kutuma maombi ya mkopo wa elimu ya juu kwenye mfumo wa HESLB kwa usahihi.',
                'We help you complete and submit your higher education loan application on the HESLB system correctly.',
                "• Namba za mitihani (Kidato cha Nne, Sita au AVN)\n• Namba ya NIDA na majibu ya uhakiki\n• RITA verification code ya cheti cha kuzaliwa\n• Namba za NaPA\n• Taarifa za wazazi/mlezi na mdhamini\n• Picha ya passport (yako na ya mdhamini)\n• Taarifa za akaunti ya benki",
                "• Exam index numbers (Form Four, Six or AVN)\n• NIDA number and verification answers\n• RITA birth certificate verification code\n• NaPA reference numbers\n• Parent/guardian and guarantor details\n• Passport photos (yours and guarantor's)\n• Bank account details"],
            ['VYUO', 'maombi-ya-vyuo', 'college', 'school', 'Maombi ya Vyuo na Udahili', 'College & University Admission',
                'Omba udahili wa vyuo vikuu na vyuo vya kati kupitia sisi — tunachagua kozi pamoja nawe na kutuma maombi.',
                'Apply for university and college admission through us — we choose programmes with you and submit the applications.',
                "• Namba za mitihani (Kidato cha Nne na Sita/AVN)\n• Historia ya shule ya msingi na sekondari\n• Taarifa za mtu wa karibu\n• Orodha ya vyuo na kozi unazopenda",
                "• Exam index numbers (Form Four and Six/AVN)\n• Primary and secondary school history\n• Next of kin details\n• List of preferred institutions and programmes"],
            ['BIRTH', 'cheti-cha-kuzaliwa', 'birth_certificate', 'baby', 'Vyeti vya Kuzaliwa', 'Birth Certificates',
                'Zama hizi si lazima uzunguke kwenda RITA. Tunakuombea cheti online, kikitoka unakifuata RITA.',
                'No need to queue at RITA. We apply online for you; once ready you collect it from RITA.',
                "• Taarifa za mtoto, baba na mama\n• Viambatisho viwili (2) kati ya: kadi ya kliniki, leaving certificate, pasi ya kusafiria, kitambulisho cha kura/NIDA cha wazazi, cheti cha ubatizo, barua ya mwenyekiti\n• Mkoa na wilaya ya kuchukulia cheti\n• Namba za simu zilizosajiliwa na Mtendaji (NaPA)",
                "• Child, father and mother details\n• Two (2) of: clinic card, leaving certificate, passport, parents' voter/NIDA ID, baptism certificate, local chairperson's letter\n• Collection region and district\n• Phone numbers registered with the Executive Officer (NaPA)"],
            ['DEATH', 'cheti-cha-kifo', 'death_certificate', 'file-heart', 'Vyeti vya Kifo', 'Death Certificates',
                'Tunakusaidia kuomba cheti cha kifo kwa haraka ukiwa na taarifa za marehemu na mtoa taarifa.',
                'We help you apply for a death certificate quickly with the deceased\'s and informant\'s details.',
                "• Taarifa za marehemu (majina, tarehe za kuzaliwa na kifo, makazi)\n• Sehemu na sababu ya kifo\n• Taarifa za mtoa taarifa pamoja na namba ya kitambulisho cha mpiga kura\n• Mkoa na wilaya ya kuchukulia cheti",
                "• Deceased's details (names, dates of birth and death, residence)\n• Place and cause of death\n• Informant's details including voter ID number\n• Collection region and district"],
            ['NAPA', 'huduma-za-napa', 'napa', 'map-pin', 'Huduma za NaPA', 'NaPA Services',
                'Pata au rekebisha namba yako ya Anwani za Makazi (NaPA) inayohitajika kwenye maombi mbalimbali.',
                'Get or correct your National Addressing (NaPA) reference number required in many applications.',
                "• Namba za simu zilizosajiliwa na Mtendaji (mwombaji, baba, mama au mlezi)",
                "• Phone numbers registered with the Executive Officer (applicant, father, mother or guardian)"],
            ['VERIFY', 'uhakiki-wa-vyeti', 'certificate_verification', 'badge-check', 'Uhakiki wa Vyeti', 'Certificate Verification',
                'Tunakusaidia kuhakiki vyeti vya elimu na vyeti vingine kabla ya kuomba chuo, mkopo au ajira.',
                'We help you verify education and other certificates before applying for college, loans or jobs.',
                "• Nakala ya cheti\n• Namba ya cheti/index na mwaka", "• Copy of the certificate\n• Certificate/index number and year"],
            ['APPEAL', 'rufaa-ya-mkopo-heslb', 'heslb_appeal', 'scale', 'Rufaa ya Mkopo (HESLB Appeal)', 'HESLB Loan Appeal',
                'Hukuridhika na mkopo uliopangiwa? Tunakusaidia kukata rufaa ya HESLB kwa usahihi na kwa wakati.',
                'Not satisfied with your loan allocation? We help you file your HESLB appeal correctly and on time.',
                "• Aina ya rufaa (kuongezewa ada, kupangiwa mkopo au vipengele vingine)\n• Username na password ya akaunti yako ya HESLB\n• Picha ya passport\n• Barua na nyaraka za kuthibitisha\n• Birth verification code (RITA)\n• Death verification code, DRN au namba ya TASAF (kama zipo)",
                "• Appeal type (fee increase, loan allocation or other items)\n• Your HESLB account username and password\n• Passport photo\n• Letter and supporting documents\n• Birth verification code (RITA)\n• Death verification code, DRN or TASAF number (if any)"],
        ];
        foreach ($services as $i => $s) {
            if (DB::value('SELECT id FROM services WHERE code = ?', [$s[0]]) !== null) {
                continue;
            }
            DB::insert('services', [
                'code' => $s[0], 'slug' => $s[1], 'form_key' => $s[2], 'icon' => $s[3], 'name_sw' => $s[4], 'name_en' => $s[5],
                'summary_sw' => $s[6], 'summary_en' => $s[7], 'requirements_sw' => $s[8], 'requirements_en' => $s[9],
                'details_sw' => $s[6], 'details_en' => $s[7],
                'price' => null, 'price_note_sw' => 'Bei itatangazwa', 'price_note_en' => 'Price to be announced',
                'is_active' => 1, 'accepting' => 1, 'sort_order' => $i + 1, 'created_at' => $now, 'updated_at' => $now,
            ]);
        }
        $log("Services ok\n");

        // ------------------------------------------------------------------ categories
        $cats = [
            ['article', 'mikopo', 'Elimu ya mikopo ya elimu', 'Education loans'],
            ['article', 'vyuo', 'Elimu ya kuomba vyuo', 'College applications'],
            ['article', 'vyeti', 'Vyeti vya kuzaliwa na vifo', 'Birth & death certificates'],
            ['article', 'napa', 'Elimu ya NaPA', 'NaPA'],
            ['article', 'nyingine', 'Elimu nyingine', 'Other guidance'],
            ['guide', 'tcu', 'TCU Guidebooks', 'TCU Guidebooks'],
            ['guide', 'heslb', 'HESLB Guidebooks', 'HESLB Guidebooks'],
            ['guide', 'joining', 'Joining Instructions', 'Joining Instructions'],
            ['guide', 'nactvet', 'NACTVET Guidebooks', 'NACTVET Guidebooks'],
            ['guide', 'miongozo-ya-vyuo', 'Miongozo ya vyuo', 'Institution guides'],
            ['institution_type', 'chuo-kikuu', 'Chuo Kikuu', 'University'],
            ['institution_type', 'chuo-kikuu-kishiriki', 'Chuo Kikuu Kishiriki', 'University College'],
            ['institution_type', 'chuo-cha-kati', 'Chuo cha Kati', 'Middle-level College'],
            ['institution_type', 'chuo-cha-afya', 'Chuo cha Afya', 'Health Training Institution'],
            ['institution_type', 'chuo-cha-ualimu', 'Chuo cha Ualimu', 'Teachers College'],
            ['faq', 'jumla', 'Maswali ya jumla', 'General'],
        ];
        foreach ($cats as $i => $c) {
            DB::run('INSERT IGNORE INTO categories (scope, slug, name_sw, name_en, sort_order) VALUES (?, ?, ?, ?, ?)', [$c[0], $c[1], $c[2], $c[3], $i]);
        }
        $catId = static fn (string $scope, string $slug) => (int) DB::value('SELECT id FROM categories WHERE scope = ? AND slug = ?', [$scope, $slug]);
        $log("Categories ok\n");

        // ------------------------------------------------------------------ FAQs
        if ((int) DB::value('SELECT COUNT(*) FROM faqs') === 0) {
            $faqs = [
                ['Ninawezaje kufungua akaunti?', 'How do I create an account?',
                    'Bonyeza "Jisajili", weka jina la kwanza, jina la pili, namba ya simu na nenosiri. Namba moja ya simu inaweza kusajili akaunti moja tu.',
                    'Click "Register", enter your first name, second name, phone number and a password. One phone number can only register one account.', 'akaunti jisajili register usajili'],
                ['Ninaombaje huduma?', 'How do I request a service?',
                    'Ingia kwenye akaunti yako, chagua huduma kisha bonyeza "Omba Huduma". Jaza fomu hatua kwa hatua, pakia nyaraka, hakiki taarifa zako kisha tuma. Utapata namba ya ombi (mf. MED-2026-HESLB-000001).',
                    'Log in, choose a service and click "Request Service". Fill the form step by step, upload documents, review and submit. You will receive a reference number (e.g. MED-2026-HESLB-000001).', 'omba huduma fomu maombi apply'],
                ['Nitafuatiliaje ombi langu?', 'How do I track my application?',
                    'Nenda "Maombi Yangu" kwenye dashboard. Kila ombi linaonyesha status (Nimepokea, Inafanyiwa Kazi, Rekebisha Taarifa, Imekamilika) pamoja na maelezo ya hatua inayofuata.',
                    'Go to "My Applications" on your dashboard. Each application shows its status (Received, In Progress, Correction Required, Completed) and the next step.', 'fuatilia track status ombi'],
                ['Nifanye nini nikiambiwa "Rekebisha Taarifa"?', 'What should I do when asked to "Correct Information"?',
                    'Fungua ombi lako, soma maelekezo ya admin, rekebisha sehemu zilizoonyeshwa tu kisha bonyeza "Tuma Upya". Huhitaji kuanza ombi upya.',
                    'Open your application, read the admin\'s instructions, correct only the highlighted fields and click "Resubmit". You do not need to start over.', 'rekebisha correction'],
                ['Nalipiaje huduma?', 'How do I pay for a service?',
                    'Bei ya kila huduma inaonekana kabla ya kutuma ombi. Maelekezo ya malipo yatatumwa kwenye akaunti yako. Admin atathibitisha malipo yako na status ya malipo itaonekana kwenye ombi lako.',
                    'The price of each service is shown before you submit. Payment instructions will be sent to your account. The admin confirms your payment and the payment status appears on your application.', 'malipo bei gharama lipa payment price'],
                ['Je, taarifa zangu ziko salama?', 'Is my information safe?',
                    'Ndiyo. Taarifa nyeti kama majibu ya uhakiki wa NIDA na taarifa za akaunti zinahifadhiwa kwa usimbaji (encryption) na zinaonekana kwa wahudumu walioidhinishwa pekee.',
                    'Yes. Sensitive information such as NIDA verification answers and account credentials is encrypted and only visible to authorised staff.', 'usalama salama nida faragha privacy'],
                ['Nimesahau nenosiri, nifanye nini?', 'I forgot my password, what do I do?',
                    'Bonyeza "Umesahau nenosiri?" kwenye ukurasa wa kuingia, weka namba yako ya simu na utapokea namba ya uthibitisho kwa SMS. Kama hupokei SMS, wasiliana na Mediator kwa msaada.',
                    'Click "Forgot password?" on the login page, enter your phone number and you will receive a verification code by SMS. If you do not receive it, contact Mediator for help.', 'nenosiri password sahau forgot'],
                ['Cheti cha kuzaliwa kinahitaji viambatisho gani?', 'Which documents are needed for a birth certificate?',
                    'Viwili (2) kati ya: kadi ya kliniki, leaving certificate, pasi ya kusafiria, kitambulisho cha kura au NIDA vya wazazi, cheti cha ubatizo, au barua ya utambulisho ya mwenyekiti.',
                    'Two (2) of: clinic card, leaving certificate, passport, parents\' voter or NIDA ID, baptism certificate, or an introduction letter from the local chairperson.', 'cheti kuzaliwa rita viambatisho birth certificate'],
            ];
            foreach ($faqs as $i => $f) {
                DB::insert('faqs', ['category_id' => $catId('faq', 'jumla'), 'question_sw' => $f[0], 'question_en' => $f[1], 'answer_sw' => $f[2], 'answer_en' => $f[3],
                    'keywords' => $f[4], 'is_published' => 1, 'sort_order' => $i, 'created_at' => $now, 'updated_at' => $now]);
            }
            $log("FAQs ok\n");
        }

        // ------------------------------------------------------------------ starter articles (generic guidance)
        if ((int) DB::value('SELECT COUNT(*) FROM articles') === 0) {
            $articles = [
                ['mikopo', 'Jinsi ya kujiandaa kuomba mkopo wa HESLB', 'How to prepare for a HESLB loan application',
                    'Orodha ya taarifa na nyaraka unazopaswa kuandaa kabla dirisha la maombi ya mkopo halijafunguliwa.',
                    "Maombi ya mkopo wa elimu ya juu hufanyika kupitia mfumo rasmi wa Bodi ya Mikopo (HESLB). Kabla ya kuanza, andaa:\n\n1. Namba za mitihani: Kidato cha Nne (na ya pili kama ulirudia), Kidato cha Sita au AVN kwa wenye Stashahada.\n2. Namba ya NIDA na majibu ya maswali ya uhakiki.\n3. RITA verification code ya cheti chako cha kuzaliwa.\n4. Namba za NaPA (Anwani za Makazi) zako na za wazazi.\n5. Taarifa za wazazi/mlezi, hali zao (hai/hawapo) na ulemavu kama upo (DRN).\n6. Taarifa za mdhamini pamoja na NIDA yake na picha.\n7. Akaunti ya benki iliyo kwa jina lako.\n\nKumbuka: Soma mwongozo rasmi wa HESLB wa mwaka husika kwenye ukurasa wa Miongozo. Mediator inaweza kukusaidia kujaza na kutuma maombi yako — bonyeza \"Omba Huduma\"."],
                ['vyuo', 'Hatua za kuomba udahili wa chuo', 'Steps to apply for college admission',
                    'Fahamu hatua muhimu za kuomba vyuo vikuu na vyuo vya kati na jinsi ya kuchagua kozi.',
                    "1. Soma Guidebook ya TCU (vyuo vikuu) au NACTVET (vyuo vya kati) ya mwaka husika ili kujua sifa za kila kozi.\n2. Linganisha ufaulu wako na sifa za kujiunga.\n3. Chagua vyuo na kozi kwa kipaumbele.\n4. Andaa namba za mitihani, historia ya elimu na taarifa za mtu wa karibu.\n5. Tuma maombi kabla ya tarehe ya mwisho na fuatilia matokeo ya udahili.\n\nKwenye ukurasa wa Vyuo vya Tanzania utapata links rasmi za vyuo mbalimbali."],
                ['vyeti', 'Kuomba cheti cha kuzaliwa online', 'Applying for a birth certificate online',
                    'Si lazima uzunguke kwenda RITA. Fahamu taarifa zinazohitajika kuomba cheti cha kuzaliwa.',
                    "Taarifa zinazohitajika:\n\n• Taarifa za mtoto: majina matatu, tarehe ya kuzaliwa, mahali alipozaliwa (mkoa, wilaya, kata, mtaa), elimu, makazi ya sasa.\n• Taarifa za baba na mama: majina, kazi, namba za simu, tarehe za kuzaliwa, kama wapo hai, elimu na makazi.\n• Viambatisho viwili (2): kadi ya kliniki, leaving certificate, pasi ya kusafiria, kitambulisho cha kura/NIDA cha wazazi, cheti cha ubatizo au barua ya mwenyekiti.\n\nOmbi likikamilika, cheti huchukuliwa kwenye ofisi ya RITA uliyochagua."],
                ['napa', 'NaPA ni nini na kwa nini unaihitaji?', 'What is NaPA and why do you need it?',
                    'Anwani za Makazi (NaPA) zinahitajika kwenye maombi mengi ikiwemo mkopo wa HESLB.',
                    "NaPA (National Physical Addressing) ni mfumo wa Anwani za Makazi unaompa kila mkazi anwani rasmi. Namba ya NaPA (reference) huombwa kwenye maombi mbalimbali kama mkopo wa elimu ya juu.\n\nIli kupata namba yako, unahitaji namba za simu zilizotumika kusajili makazi kwa Mtendaji wa kata/kijiji/mtaa (yako, ya baba, mama au mlezi). Mediator inaweza kukusaidia kuipata."],
            ];
            foreach ($articles as $i => $a) {
                DB::insert('articles', [
                    'category_id' => $catId('article', $a[0]), 'slug' => ContentTypes::uniqueSlug('articles', ContentTypes::slugify($a[1])),
                    'title_sw' => $a[1], 'title_en' => $a[2], 'summary_sw' => $a[3], 'body_sw' => $a[4],
                    'is_published' => 1, 'published_at' => $now, 'sort_order' => 0, 'created_at' => $now, 'updated_at' => $now,
                ]);
            }
            $log("Articles ok\n");
        }

        // ------------------------------------------------------------------ institutions (official websites)
        if ((int) DB::value('SELECT COUNT(*) FROM institutions') === 0) {
            $verify = $verifyLinks;
            $uni = $catId('institution_type', 'chuo-kikuu');
            $inst = [
                ['University of Dar es Salaam', 'UDSM', 'public', 'Dar es Salaam', 'https://www.udsm.ac.tz', 1],
                ['University of Dodoma', 'UDOM', 'public', 'Dodoma', 'https://www.udom.ac.tz', 1],
                ['Sokoine University of Agriculture', 'SUA', 'public', 'Morogoro', 'https://www.sua.ac.tz', 1],
                ['Muhimbili University of Health and Allied Sciences', 'MUHAS', 'public', 'Dar es Salaam', 'https://www.muhas.ac.tz', 1],
                ['Ardhi University', 'ARU', 'public', 'Dar es Salaam', 'https://www.aru.ac.tz', 0],
                ['Mzumbe University', 'MU', 'public', 'Morogoro', 'https://www.mzumbe.ac.tz', 0],
                ['Open University of Tanzania', 'OUT', 'public', 'Dar es Salaam', 'https://www.out.ac.tz', 0],
                ['Mbeya University of Science and Technology', 'MUST', 'public', 'Mbeya', 'https://www.must.ac.tz', 0],
                ['Nelson Mandela African Institution of Science and Technology', 'NM-AIST', 'public', 'Arusha', 'https://www.nm-aist.ac.tz', 0],
                ['State University of Zanzibar', 'SUZA', 'public', 'Mjini Magharibi', 'https://www.suza.ac.tz', 0],
                ['Moshi Co-operative University', 'MoCU', 'public', 'Kilimanjaro', 'https://www.mocu.ac.tz', 0],
                ['Dar es Salaam Institute of Technology', 'DIT', 'public', 'Dar es Salaam', 'https://www.dit.ac.tz', 0],
                ['Institute of Finance Management', 'IFM', 'public', 'Dar es Salaam', 'https://www.ifm.ac.tz', 0],
                ['College of Business Education', 'CBE', 'public', 'Dar es Salaam', 'https://www.cbe.ac.tz', 0],
                ['Institute of Accountancy Arusha', 'IAA', 'public', 'Arusha', 'https://www.iaa.ac.tz', 0],
                ['St. Augustine University of Tanzania', 'SAUT', 'private', 'Mwanza', 'https://www.saut.ac.tz', 0],
            ];
            foreach ($inst as $i => $x) {
                $verifiedAt = null;
                if ($verify) {
                    $code = ContentAdminController::probe($x[4]);
                    $verifiedAt = ($code >= 200 && $code < 400) ? $now : null;
                    $log("  {$x[1]} {$x[4]} -> HTTP {$code}\n");
                }
                DB::insert('institutions', [
                    'name' => $x[0], 'short_name' => $x[1], 'category_id' => $uni, 'ownership' => $x[2], 'region' => $x[3], 'location' => $x[3],
                    'website_url' => $x[4], 'is_featured' => $x[5], 'links_verified_at' => $verifiedAt,
                    'is_published' => $verifiedAt !== null ? 1 : 0, 'sort_order' => $i, 'created_at' => $now, 'updated_at' => $now,
                ]);
            }
            $log($verify ? "Institutions ok (only verified links published)\n" : "Institutions added UNPUBLISHED - verify links in Admin > Vyuo, or rerun seed with --verify-links on a fresh table\n");
        }

        $log("Seed complete.\n");
    }
}
