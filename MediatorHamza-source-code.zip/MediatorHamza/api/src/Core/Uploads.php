<?php
declare(strict_types=1);

namespace Mediator\Core;

/** Validated file storage outside the web root (or in an .htaccess-protected folder). */
final class Uploads
{
    public const IMAGE_TYPES = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
    public const DOC_TYPES = ['application/pdf' => 'pdf'];

    /**
     * @param array<string,mixed> $file entry from $_FILES
     * @param array<string,string> $allowed mime => extension
     * @return array{stored_name:string, original_name:string, mime:string, size:int}
     */
    public static function store(array $file, string $folder, array $allowed, int $maxBytes): array
    {
        if (!isset($file['error']) || is_array($file['error'])) {
            throw HttpException::bad('upload_invalid', 'Invalid upload');
        }
        if ($file['error'] === UPLOAD_ERR_INI_SIZE || $file['error'] === UPLOAD_ERR_FORM_SIZE) {
            throw HttpException::validation(['file' => 'file_too_large']);
        }
        if ($file['error'] !== UPLOAD_ERR_OK || !is_uploaded_file($file['tmp_name'])) {
            throw HttpException::bad('upload_failed', 'Upload failed');
        }
        $size = (int) $file['size'];
        if ($size <= 0 || $size > $maxBytes) {
            throw HttpException::validation(['file' => 'file_too_large']);
        }
        $finfo = new \finfo(FILEINFO_MIME_TYPE);
        $mime = (string) $finfo->file($file['tmp_name']);
        if (!isset($allowed[$mime])) {
            throw HttpException::validation(['file' => 'file_type_not_allowed']);
        }
        if (isset(self::IMAGE_TYPES[$mime]) && @getimagesize($file['tmp_name']) === false) {
            throw HttpException::validation(['file' => 'file_type_not_allowed']);
        }
        $dir = Env::storagePath('uploads/' . $folder . '/' . date('Y/m'));
        if (!is_dir($dir) && !mkdir($dir, 0750, true) && !is_dir($dir)) {
            throw new \RuntimeException('Cannot create upload directory');
        }
        $stored = bin2hex(random_bytes(16)) . '.' . $allowed[$mime];
        $relative = $folder . '/' . date('Y/m') . '/' . $stored;
        $target = Env::storagePath('uploads/' . $relative);
        if (!move_uploaded_file($file['tmp_name'], $target)) {
            throw new \RuntimeException('Could not save upload');
        }
        @chmod($target, 0640);
        $original = mb_substr(basename((string) ($file['name'] ?? 'file')), 0, 180);
        return ['stored_name' => $relative, 'original_name' => $original, 'mime' => $mime, 'size' => $size];
    }

    public static function path(string $storedName): string
    {
        if (str_contains($storedName, '..')) {
            throw HttpException::notFound();
        }
        return Env::storagePath('uploads/' . $storedName);
    }

    public static function delete(string $storedName): void
    {
        $p = self::path($storedName);
        if (is_file($p)) {
            @unlink($p);
        }
    }

    public static function maxBytes(): int
    {
        return Env::int('UPLOAD_MAX_MB', 5) * 1024 * 1024;
    }
}
