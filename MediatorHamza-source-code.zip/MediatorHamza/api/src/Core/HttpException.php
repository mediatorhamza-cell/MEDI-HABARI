<?php
declare(strict_types=1);

namespace Mediator\Core;

use RuntimeException;

final class HttpException extends RuntimeException
{
    /** @param array<string,string> $errors field => message key */
    public function __construct(
        public readonly int $status,
        public readonly string $errorCode,
        string $message = '',
        public readonly array $errors = [],
    ) {
        parent::__construct($message !== '' ? $message : $errorCode);
    }

    public static function notFound(): self
    {
        return new self(404, 'not_found', 'Not found');
    }

    public static function forbidden(): self
    {
        return new self(403, 'forbidden', 'You do not have permission to perform this action.');
    }

    public static function unauthenticated(): self
    {
        return new self(401, 'unauthenticated', 'Please log in.');
    }

    /** @param array<string,string> $errors */
    public static function validation(array $errors): self
    {
        return new self(422, 'validation_failed', 'Some fields are invalid.', $errors);
    }

    public static function bad(string $code, string $message = ''): self
    {
        return new self(400, $code, $message);
    }
}
