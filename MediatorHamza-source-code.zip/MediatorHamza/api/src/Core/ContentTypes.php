<?php
declare(strict_types=1);

namespace Mediator\Core;

/**
 * Registry of admin-managed content types. Drives the generic admin CRUD
 * endpoints (whitelisted columns + validation) and the public listings.
 */
final class ContentTypes
{
    /** @return array<string,array<string,mixed>> */
    public static function all(): array
    {
        return [
            'articles' => [
                'table' => 'articles',
                'rules' => [
                    'category_id' => 'int', 'slug' => 'string|max:190', 'title_sw' => 'required|string|max:200',
                    'title_en' => 'string|max:200', 'summary_sw' => 'string|max:400', 'summary_en' => 'string|max:400',
                    'body_sw' => 'string|max:100000', 'body_en' => 'string|max:100000', 'image_id' => 'int',
                    'attachment_id' => 'int', 'is_published' => 'bool', 'published_at' => 'datetime', 'sort_order' => 'int',
                ],
                'order' => 'COALESCE(published_at, created_at) DESC, id DESC',
                'search' => ['title_sw', 'title_en', 'summary_sw', 'body_sw'],
                'slug_from' => 'title_sw',
            ],
            'institutions' => [
                'table' => 'institutions',
                'rules' => [
                    'name' => 'required|string|max:200', 'short_name' => 'string|max:40', 'category_id' => 'int',
                    'ownership' => 'in:public,private,other', 'region' => 'string|max:80', 'location' => 'string|max:200',
                    'logo_id' => 'int', 'website_url' => 'url|max:300', 'apply_url' => 'url|max:300', 'login_url' => 'url|max:300',
                    'description_sw' => 'string|max:5000', 'description_en' => 'string|max:5000',
                    'is_featured' => 'bool', 'is_published' => 'bool', 'sort_order' => 'int',
                ],
                'order' => 'sort_order ASC, name ASC',
                'search' => ['name', 'short_name', 'location', 'region'],
            ],
            'guidebooks' => [
                'table' => 'guidebooks',
                'rules' => [
                    'category_id' => 'int', 'title_sw' => 'required|string|max:200', 'title_en' => 'string|max:200',
                    'academic_year' => 'string|max:20', 'description_sw' => 'string|max:3000', 'description_en' => 'string|max:3000',
                    'file_id' => 'int', 'external_url' => 'url|max:300', 'is_outdated' => 'bool', 'is_published' => 'bool', 'sort_order' => 'int',
                ],
                'order' => 'is_outdated ASC, sort_order ASC, created_at DESC',
                'search' => ['title_sw', 'title_en', 'description_sw', 'academic_year'],
            ],
            'deadlines' => [
                'table' => 'deadlines',
                'rules' => [
                    'service_id' => 'int', 'title_sw' => 'required|string|max:200', 'title_en' => 'string|max:200',
                    'description_sw' => 'string|max:3000', 'description_en' => 'string|max:3000', 'opens_at' => 'date',
                    'closes_at' => 'required|date', 'remind_days_before' => 'int', 'is_published' => 'bool',
                ],
                'order' => 'closes_at ASC',
                'search' => ['title_sw', 'title_en'],
            ],
            'announcements' => [
                'table' => 'announcements',
                'rules' => [
                    'title_sw' => 'required|string|max:200', 'title_en' => 'string|max:200', 'body_sw' => 'string|max:50000',
                    'body_en' => 'string|max:50000', 'is_pinned' => 'bool', 'is_published' => 'bool', 'published_at' => 'datetime',
                ],
                'order' => 'is_pinned DESC, COALESCE(published_at, created_at) DESC',
                'search' => ['title_sw', 'title_en', 'body_sw'],
            ],
            'faqs' => [
                'table' => 'faqs',
                'rules' => [
                    'category_id' => 'int', 'question_sw' => 'required|string|max:300', 'question_en' => 'string|max:300',
                    'answer_sw' => 'required|string|max:5000', 'answer_en' => 'string|max:5000', 'keywords' => 'string|max:300',
                    'is_published' => 'bool', 'sort_order' => 'int',
                ],
                'order' => 'sort_order ASC, id ASC',
                'search' => ['question_sw', 'question_en', 'answer_sw', 'keywords'],
            ],
            'whatsapp_groups' => [
                'table' => 'whatsapp_groups',
                'rules' => [
                    'name' => 'required|string|max:150', 'description_sw' => 'string|max:2000', 'description_en' => 'string|max:2000',
                    'invite_url' => 'required|url|max:300', 'is_published' => 'bool', 'sort_order' => 'int',
                ],
                'order' => 'sort_order ASC, id ASC',
                'search' => ['name'],
            ],
            'testimonials' => [
                'table' => 'testimonials',
                'rules' => [
                    'name' => 'required|string|max:150', 'role_sw' => 'string|max:150', 'role_en' => 'string|max:150',
                    'location' => 'string|max:120', 'body_sw' => 'required|string|max:2000', 'body_en' => 'string|max:2000',
                    'rating' => 'int', 'year' => 'required|int', 'photo_id' => 'int', 'is_published' => 'bool', 'sort_order' => 'int',
                ],
                'order' => 'year DESC, sort_order ASC, id DESC',
                'search' => ['name', 'body_sw', 'location'],
            ],
            'categories' => [
                'table' => 'categories',
                'rules' => [
                    'scope' => 'required|in:article,guide,institution_type,faq', 'slug' => 'string|max:80',
                    'name_sw' => 'required|string|max:120', 'name_en' => 'string|max:120', 'sort_order' => 'int',
                ],
                'order' => 'scope, sort_order, id',
                'search' => ['name_sw', 'name_en'],
                'slug_from' => 'name_sw',
                'no_timestamps' => true,
            ],
        ];
    }

    /** @return array<string,mixed> */
    public static function get(string $type): array
    {
        $all = self::all();
        if (!isset($all[$type])) {
            throw HttpException::notFound();
        }
        return $all[$type];
    }

    public static function slugify(string $text): string
    {
        $s = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $text) ?: $text;
        $s = strtolower(trim(preg_replace('/[^A-Za-z0-9]+/', '-', $s) ?? '', '-'));
        return $s !== '' ? mb_substr($s, 0, 150) : 'item';
    }

    public static function uniqueSlug(string $table, string $base, ?int $ignoreId = null): string
    {
        $slug = $base;
        $i = 2;
        while (DB::value("SELECT id FROM `{$table}` WHERE slug = ?" . ($ignoreId ? ' AND id <> ' . (int) $ignoreId : ''), [$slug]) !== null) {
            $slug = $base . '-' . $i++;
        }
        return $slug;
    }
}
