<?php
declare(strict_types=1);

namespace Mediator\Core;

final class Router
{
    /** @var list<array{method:string, regex:string, names:list<string>, handler:callable, guards:list<callable>}> */
    private array $routes = [];

    /** @var list<callable> */
    private array $groupGuards = [];
    private string $groupPrefix = '';

    /** @param list<callable> $guards */
    public function group(string $prefix, array $guards, callable $define): void
    {
        $prevPrefix = $this->groupPrefix;
        $prevGuards = $this->groupGuards;
        $this->groupPrefix .= $prefix;
        $this->groupGuards = array_merge($this->groupGuards, $guards);
        $define($this);
        $this->groupPrefix = $prevPrefix;
        $this->groupGuards = $prevGuards;
    }

    /** @param list<callable> $guards */
    public function add(string $method, string $pattern, callable $handler, array $guards = []): void
    {
        $pattern = $this->groupPrefix . $pattern;
        $names = [];
        $regex = preg_replace_callback('/\{(\w+)\}/', static function ($m) use (&$names) {
            $names[] = $m[1];
            return '([^/]+)';
        }, rtrim($pattern, '/') ?: '/');
        $this->routes[] = [
            'method' => $method,
            'regex' => '#^' . $regex . '$#',
            'names' => $names,
            'handler' => $handler,
            'guards' => array_merge($this->groupGuards, $guards),
        ];
    }

    public function get(string $p, callable $h, array $g = []): void { $this->add('GET', $p, $h, $g); }
    public function post(string $p, callable $h, array $g = []): void { $this->add('POST', $p, $h, $g); }
    public function put(string $p, callable $h, array $g = []): void { $this->add('PUT', $p, $h, $g); }
    public function patch(string $p, callable $h, array $g = []): void { $this->add('PATCH', $p, $h, $g); }
    public function delete(string $p, callable $h, array $g = []): void { $this->add('DELETE', $p, $h, $g); }

    public function dispatch(Request $request): void
    {
        $path = rtrim($request->path, '/') ?: '/';
        $methodMismatch = false;
        foreach ($this->routes as $route) {
            if (!preg_match($route['regex'], $path, $m)) {
                continue;
            }
            if ($route['method'] !== $request->method) {
                $methodMismatch = true;
                continue;
            }
            array_shift($m);
            $request->params = array_combine($route['names'], array_map('rawurldecode', $m)) ?: [];
            foreach ($route['guards'] as $guard) {
                $guard($request);
            }
            ($route['handler'])($request);
            Response::ok();
        }
        if ($methodMismatch) {
            throw new HttpException(405, 'method_not_allowed', 'Method not allowed');
        }
        throw HttpException::notFound();
    }
}
