<?php
declare(strict_types=1);

namespace Mediator\Core;

/** Tanzanian mobile number normalisation. Stored format: +255XXXXXXXXX */
final class Phone
{
    public static function normalize(string $input): ?string
    {
        $digits = preg_replace('/\D+/', '', $input) ?? '';
        if (str_starts_with($digits, '255') && strlen($digits) === 12) {
            $local = substr($digits, 3);
        } elseif (str_starts_with($digits, '0') && strlen($digits) === 10) {
            $local = substr($digits, 1);
        } elseif (strlen($digits) === 9) {
            $local = $digits;
        } else {
            return null;
        }
        // Tanzanian mobile numbers start with 6 or 7.
        if (!preg_match('/^[67]\d{8}$/', $local)) {
            return null;
        }
        return '+255' . $local;
    }

    public static function local(string $normalized): string
    {
        return str_starts_with($normalized, '+255') ? '0' . substr($normalized, 4) : $normalized;
    }
}
