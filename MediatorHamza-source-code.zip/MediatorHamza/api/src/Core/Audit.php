<?php
declare(strict_types=1);

namespace Mediator\Core;

final class Audit
{
    private static ?Request $request = null;

    public static function setRequest(Request $r): void
    {
        self::$request = $r;
    }

    /** @param array<string,mixed> $details Never pass passwords, OTPs or NIDA answers here. */
    public static function log(string $action, ?string $entityType = null, ?int $entityId = null, array $details = []): void
    {
        DB::insert('audit_logs', [
            'user_id' => Auth::id() ?: null,
            'action' => $action,
            'entity_type' => $entityType,
            'entity_id' => $entityId,
            'details' => $details === [] ? null : json_encode($details, JSON_UNESCAPED_UNICODE),
            'ip_address' => self::$request?->ip(),
            'created_at' => DB::now(),
        ]);
    }
}
