<?php
declare(strict_types=1);

namespace Mediator\Core;

/**
 * Dependency-free exporters: CSV, XLSX (Office Open XML via ZipArchive) and a
 * simple tabular PDF (built-in Helvetica, landscape A4).
 */
final class Export
{
    /** @param list<string> $headers @param list<list<scalar|null>> $rows */
    public static function csv(array $headers, array $rows): string
    {
        $fh = fopen('php://temp', 'r+');
        fwrite($fh, "\xEF\xBB\xBF"); // UTF-8 BOM so Excel opens Swahili text correctly
        fputcsv($fh, $headers, ',', '"', '\\');
        foreach ($rows as $row) {
            fputcsv($fh, array_map([self::class, 'safeCell'], $row), ',', '"', '\\');
        }
        rewind($fh);
        $out = stream_get_contents($fh) ?: '';
        fclose($fh);
        return $out;
    }

    /** Prevent CSV/Excel formula injection. */
    private static function safeCell(mixed $v): string
    {
        $s = (string) ($v ?? '');
        if ($s !== '' && in_array($s[0], ['=', '+', '-', '@', "\t", "\r"], true) && !preg_match('/^[+-]?\d/', $s)) {
            return "'" . $s;
        }
        return $s;
    }

    /** @param list<string> $headers @param list<list<scalar|null>> $rows */
    public static function xlsx(array $headers, array $rows, string $sheetName = 'Data'): string
    {
        $esc = static fn ($s) => htmlspecialchars((string) $s, ENT_XML1 | ENT_QUOTES, 'UTF-8');
        $colName = static function (int $i): string {
            $s = '';
            for ($i++; $i > 0; $i = intdiv($i - 1, 26)) {
                $s = chr(65 + (($i - 1) % 26)) . $s;
            }
            return $s;
        };
        $sheet = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            . '<sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>'
            . '<cols>';
        foreach ($headers as $i => $h) {
            $sheet .= sprintf('<col min="%d" max="%d" width="%d" customWidth="1"/>', $i + 1, $i + 1, max(12, min(45, mb_strlen($h) + 6)));
        }
        $sheet .= '</cols><sheetData>';
        $all = array_merge([$headers], $rows);
        foreach ($all as $r => $row) {
            $sheet .= '<row r="' . ($r + 1) . '">';
            foreach (array_values($row) as $c => $val) {
                $ref = $colName($c) . ($r + 1);
                $style = $r === 0 ? ' s="1"' : '';
                if (is_int($val) || is_float($val)) {
                    $sheet .= "<c r=\"{$ref}\"{$style}><v>{$val}</v></c>";
                } else {
                    $sheet .= "<c r=\"{$ref}\" t=\"inlineStr\"{$style}><is><t xml:space=\"preserve\">" . $esc($val ?? '') . '</t></is></c>';
                }
            }
            $sheet .= '</row>';
        }
        $sheet .= '</sheetData></worksheet>';

        $tmp = tempnam(sys_get_temp_dir(), 'xlsx');
        $zip = new \ZipArchive();
        $zip->open($tmp, \ZipArchive::OVERWRITE);
        $zip->addFromString('[Content_Types].xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
            . '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
            . '<Default Extension="xml" ContentType="application/xml"/>'
            . '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
            . '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
            . '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
            . '</Types>');
        $zip->addFromString('_rels/.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
            . '</Relationships>');
        $zip->addFromString('xl/workbook.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
            . '<sheets><sheet name="' . $esc(mb_substr($sheetName, 0, 31)) . '" sheetId="1" r:id="rId1"/></sheets></workbook>');
        $zip->addFromString('xl/_rels/workbook.xml.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>'
            . '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
            . '</Relationships>');
        $zip->addFromString('xl/styles.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            . '<fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font></fonts>'
            . '<fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill>'
            . '<fill><patternFill patternType="solid"><fgColor rgb="FF102B5C"/><bgColor indexed="64"/></patternFill></fill></fills>'
            . '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
            . '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
            . '<cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
            . '<xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"/></cellXfs>'
            . '</styleSheet>');
        $zip->addFromString('xl/worksheets/sheet1.xml', $sheet);
        $zip->close();
        $data = (string) file_get_contents($tmp);
        @unlink($tmp);
        return $data;
    }

    /** @param list<string> $headers @param list<list<scalar|null>> $rows */
    public static function pdf(string $title, array $headers, array $rows): string
    {
        $pageW = 842.0; // A4 landscape in points
        $pageH = 595.0;
        $margin = 30.0;
        $fontSize = 8.0;
        $lineH = 12.0;
        $usable = $pageW - 2 * $margin;
        $ncols = max(1, count($headers));

        // Column widths proportional to content length (capped).
        $weights = [];
        foreach ($headers as $i => $h) {
            $max = mb_strlen($h);
            foreach (array_slice($rows, 0, 200) as $r) {
                $max = max($max, mb_strlen((string) ($r[$i] ?? '')));
            }
            $weights[] = min(40, max(6, $max));
        }
        $total = array_sum($weights) ?: 1;
        $widths = array_map(static fn ($w) => $usable * $w / $total, $weights);

        $enc = static function (string $s): string {
            $s = iconv('UTF-8', 'Windows-1252//TRANSLIT//IGNORE', $s) ?: '';
            return str_replace(['\\', '(', ')', "\r", "\n"], ['\\\\', '\\(', '\\)', ' ', ' '], $s);
        };
        $fit = static function (string $s, float $width) use ($fontSize): string {
            $maxChars = (int) floor($width / ($fontSize * 0.5)) - 1;
            return mb_strlen($s) > $maxChars ? mb_substr($s, 0, max(1, $maxChars - 1)) . '.' : $s;
        };

        $pages = [];
        $content = '';
        $y = 0.0;
        $pageNo = 0;
        $newPage = static function () use (&$content, &$pages, &$y, &$pageNo, $pageH, $margin, $title, $enc, $headers, $widths, $fit, $fontSize, $lineH, $pageW): void {
            if ($content !== '') {
                $pages[] = $content;
            }
            $pageNo++;
            $content = '';
            $y = $pageH - $margin;
            $content .= sprintf("BT /F2 13 Tf %.2f %.2f Td (%s) Tj ET\n", $margin, $y - 4, $enc($title));
            $content .= sprintf("BT /F1 8 Tf %.2f %.2f Td (%s) Tj ET\n", $pageW - $margin - 160, $y - 4, $enc(date('d/m/Y H:i') . '  |  Ukurasa ' . $pageNo));
            $y -= 26;
            $content .= sprintf("0.063 0.169 0.361 rg %.2f %.2f %.2f %.2f re f\n", $margin, $y - 4, array_sum($widths), $lineH + 2);
            $x = $margin;
            $content .= "1 1 1 rg\n";
            foreach ($headers as $i => $h) {
                $content .= sprintf("BT /F2 %.1f Tf %.2f %.2f Td (%s) Tj ET\n", $fontSize, $x + 2, $y, $enc($fit($h, $widths[$i])));
                $x += $widths[$i];
            }
            $content .= "0 0 0 rg\n";
            $y -= $lineH + 2;
        };
        $newPage();
        foreach ($rows as $n => $row) {
            if ($y < $margin + $lineH) {
                $newPage();
            }
            if ($n % 2 === 1) {
                $content .= sprintf("0.96 0.97 0.98 rg %.2f %.2f %.2f %.2f re f 0 0 0 rg\n", $margin, $y - 3, array_sum($widths), $lineH);
            }
            $x = $margin;
            foreach ($widths as $i => $w) {
                $content .= sprintf("BT /F1 %.1f Tf %.2f %.2f Td (%s) Tj ET\n", $fontSize, $x + 2, $y, $enc($fit((string) ($row[$i] ?? ''), $w)));
                $x += $w;
            }
            $y -= $lineH;
        }
        $pages[] = $content;

        // Assemble PDF objects.
        $objects = [];
        $objects[1] = '<< /Type /Catalog /Pages 2 0 R >>';
        $objects[3] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>';
        $objects[4] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>';
        $kids = [];
        $next = 5;
        foreach ($pages as $stream) {
            $pageId = $next++;
            $contentId = $next++;
            $kids[] = "{$pageId} 0 R";
            $objects[$pageId] = sprintf('<< /Type /Page /Parent 2 0 R /MediaBox [0 0 %.0f %.0f] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents %d 0 R >>', $pageW, $pageH, $contentId);
            $objects[$contentId] = '<< /Length ' . strlen($stream) . " >>\nstream\n" . $stream . "\nendstream";
        }
        $objects[2] = '<< /Type /Pages /Kids [' . implode(' ', $kids) . '] /Count ' . count($kids) . ' >>';
        ksort($objects);
        $pdf = "%PDF-1.4\n";
        $offsets = [];
        foreach ($objects as $id => $obj) {
            $offsets[$id] = strlen($pdf);
            $pdf .= "{$id} 0 obj\n{$obj}\nendobj\n";
        }
        $xref = strlen($pdf);
        $count = max(array_keys($objects)) + 1;
        $pdf .= "xref\n0 {$count}\n0000000000 65535 f \n";
        for ($i = 1; $i < $count; $i++) {
            $pdf .= sprintf("%010d 00000 n \n", $offsets[$i] ?? 0);
        }
        $pdf .= "trailer\n<< /Size {$count} /Root 1 0 R >>\nstartxref\n{$xref}\n%%EOF";
        return $pdf;
    }
}
