<?php
declare(strict_types=1);

namespace Mediator\Core;

/**
 * Loads a service-specific form definition (api/forms/<key>.json) and validates
 * submitted data against it on the server. The same JSON drives the React form
 * renderer so client and server rules never drift apart.
 *
 * Each service has its OWN schema with its own steps, fields, validation and
 * document requirements; only the rendering/validation engine is shared.
 */
final class FormSchema
{
    /** @var array<string,mixed> */
    public readonly array $schema;

    /** @var array<string,array<string,mixed>> top-level fields by key */
    private array $fields = [];

    /** @var array<string,string> field key => step key */
    private array $fieldStep = [];

    /** @var array<string,list<string>>|null */
    private static ?array $regions = null;

    public function __construct(array $schema)
    {
        $this->schema = $schema;
        foreach ($schema['steps'] as $step) {
            foreach ($step['fields'] as $field) {
                if (($field['type'] ?? '') === 'heading') {
                    continue;
                }
                $this->fields[$field['key']] = $field;
                $this->fieldStep[$field['key']] = $step['key'];
            }
        }
    }

    public static function load(string $formKey): self
    {
        if (!preg_match('/^[a-z0-9_]+$/', $formKey)) {
            throw HttpException::notFound();
        }
        $file = MEDIATOR_API_ROOT . '/forms/' . $formKey . '.json';
        if (!is_file($file)) {
            throw new \RuntimeException("Form schema {$formKey} not found");
        }
        $schema = json_decode((string) file_get_contents($file), true, 64, JSON_THROW_ON_ERROR);
        return new self($schema);
    }

    /** @return array<string,list<string>> */
    public static function regions(): array
    {
        if (self::$regions === null) {
            $data = json_decode((string) file_get_contents(MEDIATOR_API_ROOT . '/data/tz_regions.json'), true);
            self::$regions = [];
            foreach ($data['regions'] as $r) {
                self::$regions[$r['name']] = $r['districts'];
            }
        }
        return self::$regions;
    }

    /** @return array<string,array<string,mixed>> */
    public function fields(): array
    {
        return $this->fields;
    }

    /** @return list<string> */
    public function sensitiveKeys(): array
    {
        return array_keys(array_filter($this->fields, static fn ($f) => !empty($f['sensitive'])));
    }

    /** @return list<string> */
    public function fileKeys(): array
    {
        $keys = [];
        foreach ($this->fields as $k => $f) {
            if ($f['type'] === 'file') {
                $keys[] = $k;
            }
        }
        return $keys;
    }

    public function hasField(string $key): bool
    {
        return isset($this->fields[$key]);
    }

    /** @param array<string,mixed> $data */
    public static function conditionMet(?array $cond, array $data): bool
    {
        if ($cond === null) {
            return true;
        }
        if (isset($cond['all'])) {
            foreach ($cond['all'] as $c) {
                if (!self::conditionMet($c, $data)) {
                    return false;
                }
            }
            return true;
        }
        if (isset($cond['any'])) {
            foreach ($cond['any'] as $c) {
                if (self::conditionMet($c, $data)) {
                    return true;
                }
            }
            return false;
        }
        $value = $data[$cond['field']] ?? null;
        if (array_key_exists('equals', $cond)) {
            return (string) $value === (string) $cond['equals'];
        }
        if (array_key_exists('notEquals', $cond)) {
            return (string) $value !== (string) $cond['notEquals'];
        }
        if (isset($cond['in'])) {
            return in_array((string) $value, array_map('strval', $cond['in']), true);
        }
        if (isset($cond['includes'])) {
            return is_array($value) && in_array((string) $cond['includes'], array_map('strval', $value), true);
        }
        if (isset($cond['filled'])) {
            $filled = $value !== null && $value !== '' && $value !== [];
            return $cond['filled'] ? $filled : !$filled;
        }
        return true;
    }

    /** @param array<string,mixed> $data */
    public function isVisible(string $key, array $data): bool
    {
        $field = $this->fields[$key];
        foreach ($this->schema['steps'] as $step) {
            if ($step['key'] === $this->fieldStep[$key]) {
                if (!self::conditionMet($step['showIf'] ?? null, $data)) {
                    return false;
                }
                break;
            }
        }
        return self::conditionMet($field['showIf'] ?? null, $data);
    }

    /**
     * Validate and clean submitted data.
     *
     * @param array<string,mixed> $input raw values keyed by field key
     * @param bool $strict false for draft autosave (no required checks, invalid values kept as text)
     * @param array<string,list<int>> $ownedFiles field key => file ids that belong to this application
     * @param array<string,mixed> $context e.g. ['heslb_levels' => [...], 'banks' => [...]]
     * @return array{0: array<string,mixed>, 1: array<string,string>} [clean data, errors]
     */
    public function validate(array $input, bool $strict, array $ownedFiles = [], array $context = []): array
    {
        $clean = [];
        $errors = [];

        // First pass: normalise scalar values so conditions can be evaluated on clean data.
        foreach ($this->fields as $key => $field) {
            if (array_key_exists($key, $input)) {
                $clean[$key] = $this->sanitize($field, $input[$key]);
            }
        }

        foreach ($this->fields as $key => $field) {
            if (!$this->isVisible($key, $clean)) {
                unset($clean[$key]);
                continue;
            }
            $value = $clean[$key] ?? null;
            $required = !empty($field['required'])
                || (isset($field['requiredIf']) && self::conditionMet($field['requiredIf'], $clean));
            $empty = $value === null || $value === '' || $value === [];

            if ($empty) {
                unset($clean[$key]);
                if ($strict && $required) {
                    $errors[$key] = 'required';
                }
                continue;
            }

            $error = $this->check($field, $value, $clean, $ownedFiles, $context, $strict);
            if ($error !== null) {
                if ($strict) {
                    $errors[$key] = $error;
                } elseif ($field['type'] === 'file') {
                    unset($clean[$key]);
                }
            }
        }
        return [$clean, $errors];
    }

    private function sanitize(array $field, mixed $value): mixed
    {
        switch ($field['type']) {
            case 'checkboxes':
                if (!is_array($value)) {
                    return [];
                }
                return array_values(array_unique(array_map(
                    static fn ($v) => mb_substr(trim((string) $v), 0, 100),
                    array_filter($value, 'is_scalar')
                )));
            case 'file':
                if (!is_array($value)) {
                    $value = $value === null || $value === '' ? [] : [$value];
                }
                return array_values(array_unique(array_map('intval', array_filter($value, 'is_numeric'))));
            case 'repeater':
                if (!is_array($value)) {
                    return [];
                }
                $rows = [];
                foreach (array_slice(array_values($value), 0, 30) as $row) {
                    if (!is_array($row)) {
                        continue;
                    }
                    $cleanRow = [];
                    foreach ($field['fields'] as $sub) {
                        $v = $row[$sub['key']] ?? '';
                        $cleanRow[$sub['key']] = $this->sanitize($sub, $v);
                    }
                    $rows[] = $cleanRow;
                }
                return $rows;
            default:
                if (is_array($value) || is_object($value)) {
                    return '';
                }
                if (is_bool($value)) {
                    $value = $value ? 'yes' : 'no';
                }
                $v = trim(preg_replace('/\s+/u', ' ', (string) $value) ?? '');
                if ($field['type'] === 'textarea') {
                    $v = trim(str_replace("\r\n", "\n", (string) $value));
                }
                $v = mb_substr($v, 0, (int) ($field['maxLength'] ?? ($field['type'] === 'textarea' ? 3000 : 200)));
                if (!empty($field['uppercase'])) {
                    $v = mb_strtoupper($v);
                }
                if ($field['type'] === 'tel' && $v !== '') {
                    $n = Phone::normalize($v);
                    $v = $n ?? $v;
                }
                return $v;
        }
    }

    /**
     * @param array<string,mixed> $all
     * @param array<string,list<int>> $ownedFiles
     * @param array<string,mixed> $context
     */
    private function check(array $field, mixed $value, array $all, array $ownedFiles, array $context, bool $strict): ?string
    {
        $type = $field['type'];
        if (is_string($value)) {
            if (isset($field['minLength']) && mb_strlen($value) < $field['minLength']) {
                return 'too_short';
            }
            if (isset($field['minWords']) && count(preg_split('/\s+/u', $value) ?: []) < $field['minWords']) {
                return 'min_words';
            }
            if (isset($field['mask']) && mb_strlen($value) !== mb_strlen($field['mask'])) {
                return 'pattern';
            }
            if (isset($field['pattern']) && !preg_match('~^(?:' . $field['pattern'] . ')$~u', $value)) {
                return 'pattern';
            }
        }

        switch ($type) {
            case 'email':
                return filter_var($value, FILTER_VALIDATE_EMAIL) ? null : 'email';
            case 'tel':
                return Phone::normalize((string) $value) !== null ? null : 'phone';
            case 'date':
                $d = \DateTime::createFromFormat('!Y-m-d', (string) $value);
                if (!$d || $d->format('Y-m-d') !== $value) {
                    return 'date';
                }
                if (($field['max'] ?? null) === 'today' && $value > date('Y-m-d')) {
                    return 'date_future';
                }
                if (isset($field['after']) && !empty($all[$field['after']]) && $value < $all[$field['after']]) {
                    return 'date_order';
                }
                if (isset($field['before']) && !empty($all[$field['before']]) && is_string($all[$field['before']]) && $value >= $all[$field['before']]) {
                    return 'date_before';
                }
                if (isset($field['min']) && $field['min'] !== 'today' && $value < $field['min']) {
                    return 'date';
                }
                return null;
            case 'year':
                if (!preg_match('/^\d{4}$/', (string) $value)) {
                    return 'year';
                }
                $y = (int) $value;
                $max = (int) date('Y') + (int) ($field['maxOffset'] ?? 0);
                return ($y < (int) ($field['min'] ?? 1940) || $y > $max) ? 'year' : null;
            case 'number':
                if (!preg_match('/^\d+$/', (string) $value)) {
                    return 'number';
                }
                return null;
            case 'select':
            case 'radio':
                return in_array($value, $this->optionValues($field, $context), true) ? null : 'invalid_option';
            case 'yesno':
                return in_array($value, ['yes', 'no'], true) ? null : 'invalid_option';
            case 'region':
                return isset(self::regions()[$value]) ? null : 'invalid_option';
            case 'district':
                $region = $all[$field['regionField']] ?? null;
                $districts = is_string($region) ? (self::regions()[$region] ?? []) : [];
                return in_array($value, $districts, true) ? null : 'invalid_option';
            case 'checkboxes':
                $allowed = $this->optionValues($field, $context);
                foreach ($value as $v) {
                    if (!in_array($v, $allowed, true)) {
                        return 'invalid_option';
                    }
                }
                if (isset($field['minSelected']) && count($value) < $field['minSelected']) {
                    return 'min_selected';
                }
                if (isset($field['maxSelected']) && count($value) > $field['maxSelected']) {
                    return 'max_selected';
                }
                return null;
            case 'file':
                $owned = $ownedFiles[$field['key']] ?? [];
                foreach ($value as $id) {
                    if (!in_array($id, $owned, true)) {
                        return 'file_invalid';
                    }
                }
                if (count($value) < (int) ($field['minFiles'] ?? 1)) {
                    return 'min_files';
                }
                if (count($value) > (int) ($field['maxFiles'] ?? 1)) {
                    return 'max_files';
                }
                return null;
            case 'repeater':
                if (count($value) < (int) ($field['minItems'] ?? 1)) {
                    return 'min_items';
                }
                if (count($value) > (int) ($field['maxItems'] ?? 10)) {
                    return 'max_items';
                }
                foreach ($value as $row) {
                    foreach ($field['fields'] as $sub) {
                        $v = $row[$sub['key']] ?? '';
                        if (($v === '' || $v === []) && !empty($sub['required'])) {
                            return 'items_incomplete';
                        }
                        if ($v !== '' && $v !== [] && $this->check($sub, $v, $row, $ownedFiles, $context, $strict) !== null) {
                            return 'items_invalid';
                        }
                    }
                }
                return null;
        }
        return null;
    }

    /** @param array<string,mixed> $context @return list<string> */
    private function optionValues(array $field, array $context): array
    {
        if (isset($field['optionsSource'])) {
            $src = $context[$field['optionsSource']] ?? [];
            return array_map(static fn ($o) => is_array($o) ? (string) $o['value'] : (string) $o, $src);
        }
        return array_map(static fn ($o) => (string) $o['value'], $field['options'] ?? []);
    }

    /**
     * How far a draft has got: share of required (visible) fields filled and the first
     * step that still has something missing.
     * @param array<string,mixed> $data
     * @return array{percent:int,stopped_at:?array{sw:string,en:string}}
     */
    public function progress(array $data): array
    {
        $required = 0;
        $done = 0;
        $stop = null;
        foreach ($this->schema['steps'] as $step) {
            if (!self::conditionMet($step['showIf'] ?? null, $data)) {
                continue;
            }
            foreach ($step['fields'] as $f) {
                if (($f['type'] ?? '') === 'heading' || !self::conditionMet($f['showIf'] ?? null, $data)) {
                    continue;
                }
                if (empty($f['required']) && !(isset($f['requiredIf']) && self::conditionMet($f['requiredIf'], $data))) {
                    continue;
                }
                $required++;
                $v = $data[$f['key']] ?? null;
                if ($v !== null && $v !== '' && $v !== []) {
                    $done++;
                } else {
                    $stop ??= ['sw' => $step['title']['sw'] ?? $step['key'], 'en' => $step['title']['en'] ?? $step['key']];
                }
            }
        }
        return ['percent' => $required > 0 ? (int) round(100 * $done / $required) : 0, 'stopped_at' => $stop];
    }

    /**
     * Human readable label for a field (used in exports/admin view).
     */
    public function label(string $key, string $lang = 'sw'): string
    {
        $f = $this->fields[$key] ?? null;
        return $f ? ($f['label'][$lang] ?? $f['label']['sw'] ?? $key) : $key;
    }
}
