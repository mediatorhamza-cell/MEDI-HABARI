<?php
declare(strict_types=1);

namespace Mediator\Core;

final class Notifier
{
    /**
     * In-app notification. Titles/bodies are stored bilingual when available.
     * Never include NIDA answers, passwords or result credentials in notifications.
     */
    public static function notify(
        int $userId,
        string $type,
        string $titleSw,
        string $bodySw,
        ?string $link = null,
        ?string $titleEn = null,
        ?string $bodyEn = null,
        ?int $batchId = null,
    ): void {
        DB::insert('notifications', [
            'user_id' => $userId,
            'type' => $type,
            'title_sw' => mb_substr($titleSw, 0, 200),
            'title_en' => $titleEn !== null ? mb_substr($titleEn, 0, 200) : null,
            'body_sw' => $bodySw,
            'body_en' => $bodyEn,
            'link' => $link,
            'batch_id' => $batchId,
            'created_at' => DB::now(),
        ]);
    }

    public static function smsUser(int $userId, string $message): void
    {
        if (!Sms::isLive() || !Env::bool('SMS_NOTIFY_STATUS', false)) {
            return;
        }
        $phone = DB::value('SELECT phone FROM users WHERE id = ?', [$userId]);
        if (is_string($phone)) {
            Sms::send($phone, $message);
        }
    }
}
