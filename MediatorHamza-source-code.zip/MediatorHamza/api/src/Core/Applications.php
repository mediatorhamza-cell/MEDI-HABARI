<?php
declare(strict_types=1);

namespace Mediator\Core;

/** Shared application helpers used by both user and admin controllers. */
final class Applications
{
    public const STATUSES = [
        'draft', 'received', 'in_progress', 'awaiting_info', 'correction_required',
        'completed', 'on_hold', 'closed', 'cancelled',
    ];
    public const PAYMENT_STATUSES = ['unpaid', 'stationery_paid', 'partial', 'paid', 'waived'];

    public const STATUS_LABELS = [
        'draft' => ['Rasimu', 'Draft'],
        'received' => ['Nimepokea', 'Received'],
        'in_progress' => ['Inafanyiwa Kazi', 'In Progress'],
        'awaiting_info' => ['Inasubiri Taarifa', 'Awaiting Information'],
        'correction_required' => ['Rekebisha Taarifa', 'Correction Required'],
        'completed' => ['Imekamilika', 'Completed'],
        'on_hold' => ['Imeahirishwa', 'On Hold'],
        'closed' => ['Imefungwa', 'Closed'],
        'cancelled' => ['Imeghairiwa', 'Cancelled'],
    ];

    public const PAYMENT_LABELS = [
        'unpaid' => ['Hujalipia', 'Not paid'],
        'stationery_paid' => ['Umelipa stationery', 'Stationery paid'],
        'partial' => ['Umelipa sehemu', 'Partially paid'],
        'paid' => ['Umelipa', 'Paid'],
        'waived' => ['Hakuna malipo', 'Waived'],
    ];

    /** @return array<string,mixed> */
    public static function formContext(): array
    {
        $banks = Settings::get('banks', []);
        $levels = Settings::get('heslb_levels', []);
        return [
            'banks' => is_array($banks) ? $banks : [],
            'heslb_levels' => is_array($levels) ? $levels : [],
        ];
    }

    /** @return array<string,mixed> */
    public static function find(int $id): array
    {
        $app = DB::one(
            'SELECT a.*, s.code AS service_code, s.form_key, s.name_sw AS service_name_sw, s.name_en AS service_name_en,
                    s.slug AS service_slug, s.icon AS service_icon
             FROM applications a JOIN services s ON s.id = a.service_id WHERE a.id = ?',
            [$id]
        );
        if ($app === null) {
            throw HttpException::notFound();
        }
        return $app;
    }

    /** Load an application owned by the current user (ownership enforced in SQL). */
    public static function findOwned(int $id, int $userId): array
    {
        $app = self::find($id);
        if ((int) $app['user_id'] !== $userId) {
            throw HttpException::notFound();
        }
        return $app;
    }

    /**
     * Full form data: public JSON + decrypted sensitive values.
     * @return array<string,mixed>
     */
    public static function formData(array $app, bool $includeSensitive = true): array
    {
        $data = json_decode((string) ($app['data'] ?? '{}'), true) ?: [];
        if ($includeSensitive) {
            $data = array_merge($data, Crypto::decryptJson($app['sensitive_data'] ?? null));
        }
        return $data;
    }

    /**
     * Split clean data into public & sensitive and persist.
     * @param array<string,mixed> $clean
     */
    public static function storeData(int $appId, FormSchema $schema, array $clean, array $extra = []): void
    {
        $sensitiveKeys = $schema->sensitiveKeys();
        $public = array_diff_key($clean, array_flip($sensitiveKeys));
        $sensitive = array_intersect_key($clean, array_flip($sensitiveKeys));
        $summary = $schema->schema['summary'] ?? [];
        // A summary key may list alternatives (forms whose branches use different fields); the first filled one wins.
        $first = static function (string|array|null $keys) use ($clean): ?string {
            foreach ((array) $keys as $k) {
                if (isset($clean[$k]) && is_scalar($clean[$k]) && (string) $clean[$k] !== '') {
                    return (string) $clean[$k];
                }
            }
            return null;
        };
        $name = $first($summary['name'] ?? null);
        DB::update('applications', array_merge([
            'data' => json_encode($public, JSON_UNESCAPED_UNICODE),
            'sensitive_data' => Crypto::encryptJson($sensitive),
            'applicant_name' => $name !== null ? mb_substr($name, 0, 190) : null,
            'applicant_phone' => $first($summary['phone'] ?? null),
            'updated_at' => DB::now(),
        ], $extra), ['id' => $appId]);
    }

    /** @return array<string,list<int>> field key => file ids */
    public static function ownedFiles(int $appId): array
    {
        $out = [];
        foreach (DB::all("SELECT id, field_key FROM application_files WHERE application_id = ? AND kind = 'applicant'", [$appId]) as $f) {
            $out[$f['field_key']][] = (int) $f['id'];
        }
        return $out;
    }

    /** @return list<array<string,mixed>> */
    public static function files(int $appId, string $kind = 'applicant'): array
    {
        return array_map(static fn ($f) => [
            'id' => (int) $f['id'],
            'field_key' => $f['field_key'],
            'name' => $f['original_name'],
            'mime' => $f['mime'],
            'size' => (int) $f['size'],
            'created_at' => $f['created_at'],
        ], DB::all('SELECT * FROM application_files WHERE application_id = ? AND kind = ? ORDER BY id', [$appId, $kind]));
    }

    /** @return list<array<string,mixed>> */
    public static function timeline(int $appId, bool $staff): array
    {
        $rows = DB::all(
            'SELECT h.*, u.first_name, u.second_name FROM application_status_history h
             LEFT JOIN users u ON u.id = h.changed_by WHERE h.application_id = ? ORDER BY h.id',
            [$appId]
        );
        return array_map(static function ($h) use ($staff) {
            $item = [
                'id' => (int) $h['id'],
                'from_status' => $h['from_status'],
                'to_status' => $h['to_status'],
                'public_message' => $h['public_message'],
                'next_action' => $h['next_action'],
                'created_at' => $h['created_at'],
            ];
            if ($staff) {
                $item['internal_note'] = $h['internal_note'];
                $item['changed_by'] = $h['first_name'] ? trim($h['first_name'] . ' ' . $h['second_name']) : null;
            }
            return $item;
        }, $rows);
    }

    /** @return list<array<string,mixed>> */
    public static function results(int $appId): array
    {
        return array_map(static fn ($r) => [
            'id' => (int) $r['id'],
            'title' => $r['title'],
            'body' => Crypto::decrypt($r['body_encrypted']) ?? '',
            'created_at' => $r['created_at'],
        ], DB::all('SELECT * FROM application_results WHERE application_id = ? ORDER BY id DESC', [$appId]));
    }

    public static function recordStatus(
        int $appId,
        ?string $from,
        string $to,
        ?string $publicMessage,
        ?string $internalNote = null,
        ?string $nextAction = null,
        ?int $by = null,
    ): void {
        DB::insert('application_status_history', [
            'application_id' => $appId,
            'from_status' => $from,
            'to_status' => $to,
            'public_message' => $publicMessage,
            'internal_note' => $internalNote,
            'next_action' => $nextAction,
            'changed_by' => $by,
            'created_at' => DB::now(),
        ]);
    }

    /** Summary used in lists/cards. @return array<string,mixed> */
    public static function summary(array $a): array
    {
        return [
            'id' => (int) $a['id'],
            'reference' => $a['reference'],
            'service_code' => $a['service_code'],
            'service_slug' => $a['service_slug'] ?? null,
            'service_name_sw' => $a['service_name_sw'],
            'service_name_en' => $a['service_name_en'],
            'service_icon' => $a['service_icon'] ?? null,
            'status' => $a['status'],
            'payment_status' => $a['payment_status'],
            'price' => $a['price_snapshot'] !== null ? (int) $a['price_snapshot'] : null,
            'package_name' => $a['package_name_snapshot'],
            'applicant_name' => $a['applicant_name'],
            'applicant_phone' => $a['applicant_phone'],
            'editable' => in_array($a['status'], ['draft', 'correction_required'], true),
            'submitted_at' => $a['submitted_at'],
            'updated_at' => $a['updated_at'],
            'created_at' => $a['created_at'],
        ];
    }

    public static function label(string $status, string $lang = 'sw'): string
    {
        $l = self::STATUS_LABELS[$status] ?? [$status, $status];
        return $lang === 'en' ? $l[1] : $l[0];
    }
}
