<?php
declare(strict_types=1);

namespace Mediator\Core;

final class Env
{
    /** @var array<string,string> */
    private static array $values = [];

    public static function load(string $file): void
    {
        $lines = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [];
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '' || $line[0] === '#' || !str_contains($line, '=')) {
                continue;
            }
            [$key, $value] = explode('=', $line, 2);
            $key = trim($key);
            $value = trim($value);
            if (strlen($value) >= 2 && ($value[0] === '"' || $value[0] === "'") && $value[-1] === $value[0]) {
                $value = substr($value, 1, -1);
            }
            self::$values[$key] = $value;
        }
    }

    public static function set(string $key, string $value): void
    {
        self::$values[$key] = $value;
    }

    public static function get(string $key, ?string $default = null): ?string
    {
        if (array_key_exists($key, self::$values)) {
            return self::$values[$key];
        }
        $env = getenv($key);
        return $env === false ? $default : $env;
    }

    public static function bool(string $key, bool $default = false): bool
    {
        $v = self::get($key);
        if ($v === null || $v === '') {
            return $default;
        }
        return in_array(strtolower($v), ['1', 'true', 'yes', 'on'], true);
    }

    public static function int(string $key, int $default): int
    {
        $v = self::get($key);
        return ($v === null || $v === '') ? $default : (int) $v;
    }

    /** Folder next to public_html that holds .env and storage on Hostinger. */
    public static function privateDir(): string
    {
        return dirname(MEDIATOR_API_ROOT, 2) . '/mediator_private';
    }

    public static function isProduction(): bool
    {
        return self::get('APP_ENV', 'production') === 'production';
    }

    public static function storagePath(string $sub = ''): string
    {
        static $resolved = null;
        if ($resolved === null) {
            $base = self::get('STORAGE_PATH');
            if (!$base) {
                // Prefer the private folder next to public_html (Hostinger layout), else api/storage.
                $private = self::privateDir() . '/storage';
                if (!is_dir($private) && is_writable(dirname(self::privateDir()))) {
                    @mkdir($private, 0750, true);
                }
                $base = is_dir($private) ? $private : MEDIATOR_API_ROOT . '/storage';
            }
            $resolved = rtrim($base, '/');
            foreach (['uploads', 'logs', 'sessions', 'backups'] as $d) {
                if (!is_dir($resolved . '/' . $d)) {
                    @mkdir($resolved . '/' . $d, 0750, true);
                }
            }
        }
        $base = $resolved;
        return $sub === '' ? $base : $base . '/' . ltrim($sub, '/');
    }
}
