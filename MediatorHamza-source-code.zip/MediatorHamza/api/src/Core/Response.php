<?php
declare(strict_types=1);

namespace Mediator\Core;

final class Response
{
    public static function securityHeaders(): void
    {
        header('X-Content-Type-Options: nosniff');
        header('X-Frame-Options: DENY');
        header('Referrer-Policy: strict-origin-when-cross-origin');
        header('Cache-Control: no-store, max-age=0');
    }

    public static function json(mixed $data, int $status = 200): never
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
        exit;
    }

    public static function ok(mixed $data = null): never
    {
        self::json(['ok' => true, 'data' => $data]);
    }

    public static function created(mixed $data = null): never
    {
        self::json(['ok' => true, 'data' => $data], 201);
    }

    /** @param array<string,string> $errors */
    public static function error(int $status, string $code, string $message, array $errors = []): never
    {
        $payload = ['ok' => false, 'error' => ['code' => $code, 'message' => $message]];
        if ($errors !== []) {
            $payload['error']['fields'] = $errors;
        }
        self::json($payload, $status);
    }

    public static function file(string $path, string $mime, string $downloadName, bool $inline = false): never
    {
        if (!is_file($path)) {
            throw HttpException::notFound();
        }
        $safeName = preg_replace('/[^A-Za-z0-9._ -]/', '_', $downloadName) ?: 'file';
        header('Content-Type: ' . $mime);
        header('Content-Length: ' . filesize($path));
        header(sprintf(
            'Content-Disposition: %s; filename="%s"; filename*=UTF-8\'\'%s',
            $inline ? 'inline' : 'attachment',
            $safeName,
            rawurlencode($downloadName)
        ));
        header('Cache-Control: private, max-age=0, no-store');
        header("Content-Security-Policy: default-src 'none'; img-src 'self'; style-src 'unsafe-inline'; sandbox");
        readfile($path);
        exit;
    }

    public static function download(string $content, string $mime, string $filename): never
    {
        header('Content-Type: ' . $mime);
        header('Content-Length: ' . strlen($content));
        header('Content-Disposition: attachment; filename="' . preg_replace('/[^A-Za-z0-9._-]/', '_', $filename) . '"');
        echo $content;
        exit;
    }
}
