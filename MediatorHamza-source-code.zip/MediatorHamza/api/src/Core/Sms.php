<?php
declare(strict_types=1);

namespace Mediator\Core;

/**
 * Pluggable SMS gateway. Drivers:
 *  - log            (default; writes to storage/logs/sms.log - development only)
 *  - beem           (Beem Africa: SMS_API_KEY, SMS_SECRET_KEY, SMS_SENDER_ID)
 *  - africastalking (SMS_USERNAME, SMS_API_KEY, SMS_SENDER_ID)
 * No credentials are bundled; the owner must supply them in .env.
 */
final class Sms
{
    public static function driver(): string
    {
        return Env::get('SMS_DRIVER', 'log') ?? 'log';
    }

    public static function isLive(): bool
    {
        return self::driver() !== 'log';
    }

    public static function send(string $phone, string $message): bool
    {
        $to = ltrim($phone, '+');
        try {
            return match (self::driver()) {
                'beem' => self::beem($to, $message),
                'africastalking' => self::africasTalking('+' . $to, $message),
                default => self::log($to, $message),
            };
        } catch (\Throwable $e) {
            error_log('SMS send failed: ' . $e->getMessage());
            return false;
        }
    }

    private static function log(string $to, string $message): bool
    {
        $line = sprintf("[%s] to=%s %s\n", date('c'), $to, $message);
        return file_put_contents(Env::storagePath('logs/sms.log'), $line, FILE_APPEND | LOCK_EX) !== false;
    }

    private static function beem(string $to, string $message): bool
    {
        $payload = json_encode([
            'source_addr' => Env::get('SMS_SENDER_ID', 'INFO'),
            'encoding' => 0,
            'message' => $message,
            'recipients' => [['recipient_id' => 1, 'dest_addr' => $to]],
        ]);
        $ch = curl_init('https://apisms.beem.africa/v1/send');
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $payload,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 15,
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'Authorization: Basic ' . base64_encode(Env::get('SMS_API_KEY', '') . ':' . Env::get('SMS_SECRET_KEY', '')),
            ],
        ]);
        curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        return $code >= 200 && $code < 300;
    }

    private static function africasTalking(string $to, string $message): bool
    {
        $fields = ['username' => Env::get('SMS_USERNAME', ''), 'to' => $to, 'message' => $message];
        if (Env::get('SMS_SENDER_ID')) {
            $fields['from'] = Env::get('SMS_SENDER_ID');
        }
        $ch = curl_init('https://api.africastalking.com/version1/messaging');
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => http_build_query($fields),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 15,
            CURLOPT_HTTPHEADER => ['Accept: application/json', 'apiKey: ' . Env::get('SMS_API_KEY', '')],
        ]);
        curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        return $code >= 200 && $code < 300;
    }
}
