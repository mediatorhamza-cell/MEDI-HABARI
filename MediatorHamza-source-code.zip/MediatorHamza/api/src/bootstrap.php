<?php
declare(strict_types=1);

use Mediator\Core\Env;

define('MEDIATOR_API_ROOT', dirname(__DIR__));

spl_autoload_register(static function (string $class): void {
    $prefix = 'Mediator\\';
    if (strncmp($class, $prefix, strlen($prefix)) !== 0) {
        return;
    }
    $relative = str_replace('\\', '/', substr($class, strlen($prefix)));
    $file = __DIR__ . '/' . $relative . '.php';
    if (is_file($file)) {
        require $file;
    }
});

// Load configuration. The .env file should live OUTSIDE public_html in production.
// Search order: MEDIATOR_ENV_FILE env var, ../../mediator_private/.env, api/.env
$candidates = array_filter([
    getenv('MEDIATOR_ENV_FILE') ?: null,
    dirname(MEDIATOR_API_ROOT, 2) . '/mediator_private/.env',
    dirname(MEDIATOR_API_ROOT) . '/mediator_private/.env',
    MEDIATOR_API_ROOT . '/.env',
]);
foreach ($candidates as $file) {
    if (is_file($file)) {
        Env::load($file);
        break;
    }
}

date_default_timezone_set(Env::get('APP_TIMEZONE', 'Africa/Dar_es_Salaam'));
mb_internal_encoding('UTF-8');

if (Env::bool('APP_DEBUG', false)) {
    ini_set('display_errors', '0');
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', '0');
    error_reporting(E_ALL & ~E_DEPRECATED);
}
ini_set('log_errors', '1');
$logDir = Env::storagePath('logs');
if (is_dir($logDir) && is_writable($logDir)) {
    ini_set('error_log', $logDir . '/php-error.log');
}
