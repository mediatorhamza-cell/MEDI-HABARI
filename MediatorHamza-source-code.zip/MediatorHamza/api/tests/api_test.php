<?php
declare(strict_types=1);
/**
 * End-to-end API test against a running server.
 *   php -S 127.0.0.1:8000 api/tests/dev-router.php   (in another terminal)
 *   php api/tests/api_test.php [http://127.0.0.1:8000/api]
 * Requires a migrated + seeded database and creates its own test accounts.
 */

$BASE = $argv[1] ?? 'http://127.0.0.1:8000/api';
$failures = 0;
$passes = 0;

// Reset rate-limit counters so repeated local runs are not throttled.
require dirname(__DIR__) . '/src/bootstrap.php';
\Mediator\Core\DB::run('DELETE FROM rate_limits');
\Mediator\Core\Migrator::ensure();

echo "== Coming soon mode\n";
\Mediator\Core\Settings::set('site_live', false);
$cs = new Client($BASE);
$r = $cs->req('POST', '/auth/register', ['first_name' => 'A', 'second_name' => 'B', 'phone' => '0712000000', 'password' => 'Siri12345', 'password_confirmation' => 'Siri12345', 'accept_terms' => true]);
check('registration blocked while coming soon', $r['status'] === 503 && $r['body']['error']['code'] === 'coming_soon', $r['body']);
$r = $cs->req('GET', '/bootstrap');
check('bootstrap exposes site_live=false', ($r['body']['data']['settings']['site_live'] ?? null) === false, $r['body']['data']['settings']['site_live'] ?? null);
\Mediator\Core\Settings::set('site_live', true);

final class Client
{
    public string $csrf = '';
    private string $jar;

    public function __construct(private string $base)
    {
        $this->jar = tempnam(sys_get_temp_dir(), 'jar');
        $this->refresh();
    }

    public function refresh(): void
    {
        $r = $this->req('GET', '/auth/session');
        $this->csrf = $r['body']['data']['csrf'] ?? '';
    }

    /** @return array{status:int, body:mixed, raw:string, headers:string} */
    public function req(string $method, string $path, mixed $json = null, ?array $multipart = null, bool $csrf = true): array
    {
        $ch = curl_init($this->base . $path);
        $headers = [];
        if ($csrf && $this->csrf) {
            $headers[] = 'X-CSRF-Token: ' . $this->csrf;
        }
        $opts = [
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_COOKIEJAR => $this->jar,
            CURLOPT_COOKIEFILE => $this->jar,
            CURLOPT_HEADER => true,
        ];
        if ($json !== null) {
            $headers[] = 'Content-Type: application/json';
            $opts[CURLOPT_POSTFIELDS] = json_encode($json);
        } elseif ($multipart !== null) {
            $opts[CURLOPT_POSTFIELDS] = $multipart;
        }
        $opts[CURLOPT_HTTPHEADER] = $headers;
        curl_setopt_array($ch, $opts);
        $resp = (string) curl_exec($ch);
        $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $hsize = (int) curl_getinfo($ch, CURLINFO_HEADER_SIZE);
        curl_close($ch);
        $raw = substr($resp, $hsize);
        return ['status' => $status, 'body' => json_decode($raw, true), 'raw' => $raw, 'headers' => substr($resp, 0, $hsize)];
    }
}

function check(string $name, bool $cond, mixed $debug = null): void
{
    global $failures, $passes;
    if ($cond) {
        $passes++;
        echo "  \u{2713} {$name}\n";
    } else {
        $failures++;
        echo "  \u{2717} {$name}\n";
        if ($debug !== null) {
            echo '      ' . substr(is_string($debug) ? $debug : json_encode($debug, JSON_UNESCAPED_UNICODE), 0, 800) . "\n";
        }
    }
}

function phone(): string
{
    return '07' . random_int(1, 9) . str_pad((string) random_int(0, 9999999), 7, '0', STR_PAD_LEFT);
}

function tmpImage(): string
{
    $f = tempnam(sys_get_temp_dir(), 'img') . '.png';
    $im = imagecreatetruecolor(60, 80);
    imagefill($im, 0, 0, imagecolorallocate($im, 200, 220, 255));
    imagepng($im, $f);
    return $f;
}

function tmpPdf(): string
{
    $f = tempnam(sys_get_temp_dir(), 'doc') . '.pdf';
    file_put_contents($f, "%PDF-1.4\n1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj 2 0 obj<</Type/Pages/Kids[]/Count 0>>endobj\ntrailer<</Root 1 0 R>>\n%%EOF");
    return $f;
}

echo "== Hosting safety\n";
// Apache denies real folders (api/forms, api/src, ...) before PHP runs, so no route may start with a folder name.
$routes = (string) file_get_contents(dirname(__DIR__) . '/src/routes.php');
preg_match_all("#->(?:get|post|put|delete)\\('(/[a-z0-9-]+)#", $routes, $m);
$dirs = array_map('basename', glob(dirname(__DIR__) . '/*', GLOB_ONLYDIR) ?: []);
$clash = array_intersect(array_map(static fn ($p) => ltrim($p, '/'), $m[1]), $dirs);
check('no API route collides with an api/ folder name', $clash === [], array_values($clash));

echo "== Public\n";
$anon = new Client($BASE);
$r = $anon->req('GET', '/bootstrap');
check('bootstrap returns 7 services', count($r['body']['data']['services'] ?? []) === 7, $r['body']);
$r = $anon->req('GET', '/form-schemas/heslb');
check('heslb form schema served', ($r['body']['data']['schema']['service'] ?? '') === 'HESLB');
$r = $anon->req('GET', '/form-schemas/../../etc');
check('form key traversal rejected', $r['status'] === 404, $r['status']);
$r = $anon->req('GET', '/search?q=mkopo');
check('search finds results', count($r['body']['data']['results'] ?? []) > 0, $r['body']);
$r = $anon->req('POST', '/assistant', ['question' => 'bei ya cheti cha kuzaliwa ni ngapi?']);
check('assistant answers with handoff', ($r['body']['data']['handoff'] ?? false) === true && count($r['body']['data']['answers']) > 0, $r['body']);
$r = $anon->req('POST', '/contact', ['name' => 'Test', 'phone' => '0712345678', 'message' => 'Habari, nahitaji msaada.']);
check('contact form accepted', $r['status'] === 201, $r['body']);
$r = $anon->req('POST', '/track', ['path' => '/'], null, true);
check('track page view', $r['status'] === 200, $r['body']);
$r = $anon->req('POST', '/contact', ['name' => 'x', 'message' => 'hello there'], null, false);
check('CSRF required on POST', ($r['body']['error']['code'] ?? '') === 'csrf_mismatch', $r['body']);
$r = $anon->req('GET', '/applications');
check('applications require login', $r['status'] === 401);
$r = $anon->req('GET', '/admin/dashboard');
check('admin requires login', $r['status'] === 401);

echo "== Registration & login\n";
$userPhone = phone();
$alice = new Client($BASE);
$r = $alice->req('POST', '/auth/register', ['first_name' => 'Asha', 'second_name' => 'Juma', 'phone' => $userPhone, 'password' => 'short', 'password_confirmation' => 'short', 'accept_terms' => true]);
check('weak password rejected', $r['status'] === 422 && isset($r['body']['error']['fields']['password']), $r['body']);
$r = $alice->req('POST', '/auth/register', ['first_name' => 'Asha', 'second_name' => 'Juma', 'phone' => $userPhone, 'password' => 'Siri12345', 'password_confirmation' => 'Siri12345', 'accept_terms' => false]);
check('terms must be accepted', $r['status'] === 422 && isset($r['body']['error']['fields']['accept_terms']), $r['body']);
$r = $alice->req('POST', '/auth/register', ['first_name' => 'Asha', 'second_name' => 'Juma', 'phone' => $userPhone, 'password' => 'Siri12345', 'password_confirmation' => 'Siri12345', 'accept_terms' => true]);
check('register ok', $r['status'] === 201, $r['body']);
$alice->csrf = $r['body']['data']['csrf'] ?? $alice->csrf;
check('phone normalised to +255', ($r['body']['data']['user']['phone'] ?? '') === '+255' . substr($userPhone, 1), $r['body']);
$dup = new Client($BASE);
$r = $dup->req('POST', '/auth/register', ['first_name' => 'Asha', 'second_name' => 'Juma', 'phone' => '+255' . substr($userPhone, 1), 'password' => 'Siri12345', 'password_confirmation' => 'Siri12345', 'accept_terms' => true]);
check('duplicate phone rejected', ($r['body']['error']['fields']['phone'] ?? '') === 'phone_taken', $r['body']);
$r = $dup->req('POST', '/auth/login', ['phone' => $userPhone, 'password' => 'wrongpass1']);
check('wrong password generic 401', $r['status'] === 401 && $r['body']['error']['code'] === 'invalid_credentials', $r['body']);
$r = $dup->req('POST', '/auth/login', ['phone' => '0799999998', 'password' => 'wrongpass1']);
check('unknown phone same generic 401', $r['status'] === 401 && $r['body']['error']['code'] === 'invalid_credentials', $r['body']);
$r = $dup->req('POST', '/admin/auth/login', ['phone' => $userPhone, 'password' => 'Siri12345']);
check('regular user cannot log into admin portal', $r['status'] === 401, $r['body']);

echo "== HESLB application flow\n";
$r = $alice->req('POST', '/applications', ['service_code' => 'HESLB']);
check('draft created', $r['status'] === 201, $r['body']);
$appId = $r['body']['data']['id'] ?? 0;
$r = $alice->req('POST', '/applications', ['service_code' => 'HESLB']);
check('existing draft resumed (no duplicates)', ($r['body']['data']['id'] ?? 0) === $appId && $r['body']['data']['resumed'] === true, $r['body']);
$r = $alice->req('PUT', "/applications/{$appId}", ['data' => ['full_name' => 'asha juma ali', 'f4_index' => 's0101/0012/2020']]);
check('autosave ok', $r['status'] === 200, $r['body']);
$r = $alice->req('GET', "/applications/{$appId}");
check('autosave persisted + uppercased', ($r['body']['data']['data']['full_name'] ?? '') === 'ASHA JUMA ALI' && $r['body']['data']['data']['f4_index'] === 'S0101/0012/2020', $r['body']);
$r = $alice->req('POST', "/applications/{$appId}/submit", ['confirm' => true]);
check('incomplete submit rejected with field errors', $r['status'] === 422 && isset($r['body']['error']['fields']['phone']), $r['body']);

$img = tmpImage();
$r = $alice->req('POST', "/applications/{$appId}/files", null, ['field_key' => 'photo', 'file' => new CURLFile($img, 'image/png', 'picha.png')]);
check('photo upload ok', $r['status'] === 201, $r['body']);
$photoId = $r['body']['data']['id'] ?? 0;
$r = $alice->req('POST', "/applications/{$appId}/files", null, ['field_key' => 'g_photo', 'file' => new CURLFile($img, 'image/png', 'mdhamini.png')]);
$gPhotoId = $r['body']['data']['id'] ?? 0;
$bad = tempnam(sys_get_temp_dir(), 'x') . '.png';
file_put_contents($bad, '<?php echo "hack"; ?>');
$r = $alice->req('POST', "/applications/{$appId}/files", null, ['field_key' => 'photo', 'file' => new CURLFile($bad, 'image/png', 'evil.png')]);
check('disguised PHP upload rejected', $r['status'] === 422, $r['body']);
$r = $alice->req('POST', "/applications/{$appId}/files", null, ['field_key' => 'not_a_field', 'file' => new CURLFile($img, 'image/png', 'x.png')]);
check('upload to unknown field rejected', $r['status'] === 422, $r['body']);

$full = [
    'full_name' => 'ASHA JUMA ALI', 'f4_index' => 'S0101/0012/2020', 'entry_qualification' => 'avn', 'avn' => '21NA0001ME',
    'avn_college' => 'Chuo cha Ufundi Arusha', 'avn_course' => 'Diploma in Civil Engineering', 'avn_year_start' => '2021', 'avn_year_end' => '2024',
    'avn_reg_no' => 'ATC/2021/001', 'phone' => '0755123456', 'email' => 'asha@example.com', 'has_nida' => 'yes',
    'nida_number' => '20000101-12345-00001-12', 'level' => 'degree', 'photo' => [$photoId],
    'nida_mother_names' => 'MWANAIDI SALIM JUMA', 'nida_ward' => 'Kariakoo', 'nida_street' => 'Msimbazi', 'nida_primary_district' => 'Ilala',
    'nida_primary_school' => 'Mchikichini', 'nida_primary_year' => '2013',
    'dob' => '2000-01-01', 'rita_code' => '202608043191-BV', 'napa_ref' => '8707Q50302', 'birth_region' => 'Dar es Salaam', 'birth_district' => 'Ilala',
    'res_region' => 'Dar es Salaam', 'res_district' => 'Ilala',
    'nida_phone' => '0755123456', 'avn_gpa' => '3.8', 'nida_res_ward' => 'Kariakoo', 'nida_res_street' => 'Msimbazi', 'g_nida_res_ward' => 'Chang\'ombe', 'g_nida_res_street' => 'Mtaa A', 'father_known' => 'yes', 'mother_known' => 'yes', 'father_death_code' => 'DV20230001',
    'mother_napa' => '8707Q50303', 'mother_disabled' => 'no', 'father_disabled' => 'no', 'g_who' => 'father',
    'father_alive' => 'no', 'mother_alive' => 'yes', 'has_guardian' => 'no', 'tasaf' => 'yes', 'tasaf_number' => 'TASAF-12345',
    'mother_names' => 'MWANAIDI SALIM JUMA', 'mother_occupation' => 'Mfanyabiashara', 'mother_phone' => '0655111222', 'mother_education' => 'primary',
    'mother_region' => 'Dar es Salaam', 'mother_district' => 'Ilala',
    'father_names' => 'JUMA ALI HASSAN', 'father_education' => 'o_level', 'father_region' => 'Pwani', 'father_district' => 'Kibaha',
    'has_disability' => 'no', 'secondary_sponsored' => 'no', 'applicant_type' => 'first_year',
    'g_name' => 'HAMISI JUMA ALI', 'g_gender' => 'male', 'g_region' => 'Dar es Salaam', 'g_district' => 'Temeke',
    'g_nida_number' => '19800101-12345-00001-12', 'g_nida_mother_names' => 'ZAINABU ALI MUSA', 'g_nida_ward' => 'Chang\'ombe',
    'g_nida_street' => 'Mtaa A', 'g_nida_primary_district' => 'Temeke', 'g_nida_primary_school' => 'Temeke', 'g_nida_primary_year' => '1994',
    'g_napa' => '1234A56789', 'g_photo' => [$gPhotoId],
    'bank_account_name' => 'ASHA JUMA ALI', 'bank_account_number' => '0152123456700', 'bank_name' => 'CRDB Bank',
    'guardian_names' => 'SHOULD BE DROPPED BECAUSE HIDDEN',
];
$r = $alice->req('POST', "/applications/{$appId}/submit", ['data' => array_merge($full, ['birth_district' => 'Arusha Jiji'])]);
check('district must belong to region', ($r['body']['error']['fields']['birth_district'] ?? '') === 'invalid_option', $r['body']);
$r = $alice->req('POST', "/applications/{$appId}/submit", ['data' => array_merge($full, ['nida_number' => '20000101-12345'])]);
check('masked NIDA must be complete', ($r['body']['error']['fields']['nida_number'] ?? '') === 'pattern', $r['body']);
$r = $alice->req('POST', "/applications/{$appId}/submit", ['data' => array_merge($full, ['father_death_code' => ''])]);
check('death code required when parent deceased', ($r['body']['error']['fields']['father_death_code'] ?? '') === 'required', $r['body']);
$r = $alice->req('POST', "/applications/{$appId}/submit", ['data' => array_merge($full, ['father_known' => 'no', 'father_alive' => '', 'father_death_code' => ''])]);
check('unknown father skips father details', !isset($r['body']['error']['fields']['father_names']) && !isset($r['body']['error']['fields']['father_alive']), $r['body']);
$r = $alice->req('POST', "/applications/{$appId}/submit", ['data' => $full]);
check('confirmation required before submit', ($r['body']['error']['fields']['confirm'] ?? '') === 'confirm_required', $r['body']);
$r = $alice->req('POST', "/applications/{$appId}/submit", ['data' => $full, 'confirm' => true]);
check('submit ok with reference', $r['status'] === 200 && preg_match('/^MED-\d{4}-HESLB-\d{6}$/', $r['body']['data']['reference'] ?? ''), $r['body']);
$ref = $r['body']['data']['reference'] ?? '';
$r = $alice->req('POST', "/applications/{$appId}/submit", ['data' => $full, 'confirm' => true]);
check('double submit is idempotent', ($r['body']['data']['reference'] ?? '') === $ref && $r['body']['data']['already'] === true, $r['body']);
$r = $alice->req('GET', "/applications/{$appId}");
check('status received + timeline', ($r['body']['data']['status'] ?? '') === 'received' && count($r['body']['data']['timeline']) === 1, $r['body']);
check('hidden guardian field dropped', !isset($r['body']['data']['data']['guardian_names']), $r['body']['data']['data'] ?? null);
check('owner sees own sensitive data', ($r['body']['data']['data']['nida_mother_names'] ?? '') === 'MWANAIDI SALIM JUMA');
check('internal notes never exposed to user', !array_key_exists('internal_note', $r['body']['data']['timeline'][0] ?? []), $r['body']['data']['timeline'] ?? null);
$r = $alice->req('PUT', "/applications/{$appId}", ['data' => ['full_name' => 'CHANGED']]);
check('cannot edit after submit', $r['status'] === 409, $r['body']);

echo "== Isolation between users\n";
$bob = new Client($BASE);
$r = $bob->req('POST', '/auth/register', ['first_name' => 'Bakari', 'second_name' => 'Musa', 'phone' => phone(), 'password' => 'Siri12345', 'password_confirmation' => 'Siri12345', 'accept_terms' => true]);
$bob->csrf = $r['body']['data']['csrf'] ?? $bob->csrf;
$r = $bob->req('GET', "/applications/{$appId}");
check("other user cannot read Alice's application", $r['status'] === 404, $r['status']);
$r = $bob->req('GET', "/applications/{$appId}/files/{$photoId}");
check("other user cannot download Alice's file", $r['status'] === 404, $r['status']);
$r = $bob->req('GET', '/admin/applications');
check('regular user forbidden from admin API', $r['status'] === 403, $r['status']);

echo "== Admin\n";
$adminPhone = phone();
$out = shell_exec(sprintf('MEDIATOR_ADMIN_PASSWORD=%s php %s --phone=%s --first=Hamza --second=Msaji --role=super_admin 2>&1',
    escapeshellarg('AdminSiri12345'), escapeshellarg(dirname(__DIR__) . '/bin/create-admin.php'), escapeshellarg($adminPhone)));
check('CLI admin created', str_contains((string) $out, 'Created super_admin'), $out);
$admin = new Client($BASE);
$r = $admin->req('POST', '/auth/login', ['phone' => $adminPhone, 'password' => 'AdminSiri12345']);
check('staff cannot use user login', $r['status'] === 401, $r['body']);
$r = $admin->req('POST', '/admin/auth/login', ['phone' => $adminPhone, 'password' => 'AdminSiri12345']);
check('admin login ok', $r['status'] === 200 && ($r['body']['data']['user']['role'] ?? '') === 'super_admin', $r['body']);
$admin->csrf = $r['body']['data']['csrf'] ?? $admin->csrf;
$r = $admin->req('GET', '/admin/dashboard');
check('dashboard stats', $r['status'] === 200 && $r['body']['data']['applications_total'] >= 1, $r['body']);
$r = $admin->req('GET', '/admin/applications?q=' . urlencode($ref));
check('search by reference', ($r['body']['data']['items'][0]['reference'] ?? '') === $ref, $r['body']);
$r = $admin->req('GET', '/admin/applications?q=' . substr($userPhone, 1));
check('search by phone', ($r['body']['data']['total'] ?? 0) >= 1, $r['body']);
$r = $admin->req('GET', "/admin/applications/{$appId}");
check('admin sees sensitive data', ($r['body']['data']['data']['g_nida_ward'] ?? '') === "Chang'ombe", $r['body']);
$r = $admin->req('POST', "/admin/applications/{$appId}/status", ['status' => 'correction_required', 'public_message' => 'Tafadhali rekebisha namba ya simu ya mama.', 'internal_note' => 'Namba haipatikani', 'editable_fields' => ['mother_phone']]);
check('request correction', $r['status'] === 200, $r['body']);
$r = $admin->req('GET', "/admin/applications/{$appId}/files/{$photoId}");
check('admin downloads applicant file', $r['status'] === 200 && str_starts_with($r['raw'], "\x89PNG"), $r['status']);

echo "== Correction by user\n";
$r = $alice->req('GET', "/applications/{$appId}");
check('user sees correction request', ($r['body']['data']['status'] ?? '') === 'correction_required' && $r['body']['data']['editable_fields'] === ['mother_phone'], $r['body']);
check('internal note hidden from user', !str_contains($r['raw'], 'Namba haipatikani'));
$r = $alice->req('POST', "/applications/{$appId}/submit", ['data' => ['mother_phone' => '0688000111', 'full_name' => 'HACKED NAME HERE'], 'confirm' => true]);
check('resubmit ok', $r['status'] === 200, $r['body']);
$r = $alice->req('GET', "/applications/{$appId}");
check('only unlocked field changed', ($r['body']['data']['data']['mother_phone'] ?? '') === '+255688000111' && $r['body']['data']['data']['full_name'] === 'ASHA JUMA ALI', $r['body']['data']['data'] ?? null);
check('back to received', ($r['body']['data']['status'] ?? '') === 'received');

echo "== Results, payments, messaging\n";
$r = $admin->req('POST', "/admin/applications/{$appId}/status", ['status' => 'completed', 'public_message' => 'Maombi yamekamilika.', 'next_action' => 'Subiri majibu ya HESLB']);
$r = $admin->req('POST', "/admin/applications/{$appId}/results", ['title' => 'Taarifa za kuingia OLAMS', 'body' => "Username: S0101-0012-2020\nPassword: Abc!2345"]);
check('result added', $r['status'] === 201, $r['body']);
$r = $admin->req('POST', "/admin/applications/{$appId}/result-files", null, ['file' => new CURLFile(tmpPdf(), 'application/pdf', 'fomu.pdf')]);
check('result file uploaded', $r['status'] === 201, $r['body']);
$r = $admin->req('POST', "/admin/applications/{$appId}/payment", ['payment_status' => 'stationery_paid', 'amount' => 10000, 'method' => 'M-Pesa', 'transaction_ref' => 'ABC123']);
check('payment recorded', $r['status'] === 200, $r['body']);
$r = $alice->req('GET', "/applications/{$appId}");
check('user sees result credentials', str_contains($r['raw'], 'Abc!2345') && ($r['body']['data']['payment_status'] ?? '') === 'stationery_paid', $r['body']);
check('user sees result file', count($r['body']['data']['result_files'] ?? []) === 1);
$r = $bob->req('GET', '/me/notifications');
check("Bob has no notifications about Alice", ($r['body']['data']['total'] ?? -1) === 0, $r['body']);
$r = $alice->req('GET', '/me/notifications');
check('Alice got notifications', ($r['body']['data']['total'] ?? 0) >= 4, $r['body']);
$firstNotif = $r['body']['data']['items'][0]['id'] ?? 0;
$totalBefore = $r['body']['data']['total'] ?? 0;
$r = $bob->req('DELETE', "/me/notifications/{$firstNotif}");
$r = $alice->req('GET', '/me/notifications');
check("other user cannot delete Alice's notification", ($r['body']['data']['total'] ?? 0) === $totalBefore);
$alice->req('DELETE', "/me/notifications/{$firstNotif}");
$r = $alice->req('GET', '/me/notifications');
check('user deletes one notification', ($r['body']['data']['total'] ?? 0) === $totalBefore - 1, $r['body']);
$r = $alice->req('POST', '/me/conversations', ['subject' => 'Swali kuhusu mkopo', 'body' => 'Habari, nitapata majibu lini?', 'application_id' => $appId]);
check('user starts chat', $r['status'] === 201, $r['body']);
$convId = $r['body']['data']['id'] ?? 0;
$r = $admin->req('GET', '/admin/conversations?filter=unanswered');
check('admin sees unanswered chat', in_array($convId, array_column($r['body']['data']['items'] ?? [], 'id'), true), $r['body']);
$r = $admin->req('POST', "/admin/conversations/{$convId}/messages", ['body' => 'Karibu! Majibu yatatoka wiki ijayo.']);
check('admin replies', $r['status'] === 201, $r['body']);
$r = $alice->req('GET', "/me/conversations/{$convId}");
check('user sees reply', count($r['body']['data']['messages'] ?? []) === 2, $r['body']);
$r = $bob->req('GET', "/me/conversations/{$convId}");
check("other user cannot read Alice's chat", $r['status'] === 404);

echo "== Notifications & exports\n";
$r = $admin->req('POST', '/admin/notifications', ['title' => 'Tangazo', 'body' => 'Dirisha la maombi limefunguliwa.', 'audience' => ['type' => 'service', 'service' => 'HESLB']]);
check('group notification to HESLB applicants', ($r['body']['data']['recipients'] ?? 0) >= 1, $r['body']);
foreach (['xlsx' => 'PK', 'pdf' => '%PDF', 'csv' => "\xEF\xBB\xBF"] as $fmt => $magic) {
    $r = $admin->req('GET', "/admin/reports/applications?format={$fmt}&service=HESLB&columns=reference,applicant_name,status,f:bank_name,f:nida_mother_names");
    check("export {$fmt}", $r['status'] === 200 && str_starts_with($r['raw'], $magic), substr($r['raw'], 0, 200));
    if ($fmt === 'csv') {
        check('export never includes sensitive answers', !str_contains($r['raw'], 'MWANAIDI SALIM JUMA') && str_contains($r['raw'], 'CRDB'), $r['raw']);
    }
}
$r = $admin->req('GET', '/admin/reports/phones?format=csv');
check('phone list export', $r['status'] === 200 && str_contains($r['raw'], substr($userPhone, 1)), substr($r['raw'], 0, 300));

echo "== Content management\n";
$r = $admin->req('POST', '/admin/content/deadlines', ['title_sw' => 'Dirisha la HESLB', 'closes_at' => date('Y-m-d', strtotime('+10 days')), 'is_published' => true]);
check('create deadline', $r['status'] === 201, $r['body']);
$r = $anon->req('GET', '/deadlines');
check('public sees deadline', count($r['body']['data']['upcoming'] ?? []) >= 1, $r['body']);
$r = $admin->req('POST', '/admin/content/institutions', ['name' => 'Test College', 'website_url' => 'https://example.com', 'is_published' => true]);
check('institution with unverified links cannot be published', ($r['body']['error']['fields']['is_published'] ?? '') === 'links_not_verified', $r['body']);
$before = $admin->req('GET', "/admin/applications/{$appId}")['body']['data']['price'] ?? null;
$r = $admin->req('PUT', '/admin/services/1', ['price' => random_int(10, 99) * 1000]);
check('service price updated', $r['status'] === 200, $r['body']);
$r = $admin->req('GET', "/admin/applications/{$appId}");
check('price change does not alter submitted app', array_key_exists('price', $r['body']['data'] ?? []) && $r['body']['data']['price'] === $before, [$before, $r['body']['data']['price'] ?? null]);
$r = $admin->req('GET', '/admin/audit');
check('audit log records actions', ($r['body']['data']['total'] ?? 0) > 5, $r['body']);

echo "== Admin follow-up (new badges, drafts, history)\n";
$r = $alice->req('GET', '/applications/history');
check('form history offers earlier answers', in_array('ASHA JUMA ALI', $r['body']['data']['full_name'] ?? [], true), $r['body']);
$r = $alice->req('POST', '/applications', ['service_code' => 'NAPA']);
$draftId = $r['body']['data']['id'] ?? 0;
$alice->req('PUT', "/applications/{$draftId}", ['data' => ['full_name' => 'asha juma ali', 'phone_applicant' => '0755123456']]);
$r = $admin->req('GET', '/admin/applications?drafts=1');
$found = array_values(array_filter($r['body']['data']['items'] ?? [], static fn ($i) => $i['id'] === $draftId));
check('admin sees unfinished draft with progress', isset($found[0]['progress']['percent']) && $found[0]['progress']['percent'] > 0 && $found[0]['progress']['percent'] < 100, $r['body']);
$r = $admin->req('GET', '/admin/dashboard');
check('dashboard reports new applications and drafts', isset($r['body']['data']['new_applications'], $r['body']['data']['drafts']), $r['body']);
$r = $admin->req('GET', '/auth/session');
check('session reports idle timeout', ($r['body']['data']['idle']['timeout'] ?? 0) > 0 && ($r['body']['data']['idle']['remaining'] ?? -1) > 0, $r['body']);

echo "== Password recovery\n";
$r = $anon->req('POST', '/auth/forgot-password', ['phone' => $userPhone]);
check('forgot password generic response', $r['status'] === 200, $r['body']);
$r = $admin->req('POST', '/admin/users/' . ($alice->req('GET', '/auth/session')['body']['data']['user']['id'] ?? 0) . '/reset-code');
check('admin-assisted reset code issued', strlen($r['body']['data']['code'] ?? '') === 8, $r['body']);
$code = $r['body']['data']['code'] ?? '';
$r = $anon->req('POST', '/auth/reset-password', ['phone' => $userPhone, 'code' => 'WRONG123', 'password' => 'Mpya12345', 'password_confirmation' => 'Mpya12345']);
check('wrong code rejected', $r['status'] === 422, $r['body']);
$r = $anon->req('POST', '/auth/reset-password', ['phone' => $userPhone, 'code' => strtolower($code), 'password' => 'Mpya12345', 'password_confirmation' => 'Mpya12345']);
check('reset with code ok', $r['status'] === 200, $r['body']);
$r = $alice->req('GET', '/applications');
check('old sessions invalidated after reset', $r['status'] === 401, $r['status']);
$alice2 = new Client($BASE);
$r = $alice2->req('POST', '/auth/login', ['phone' => $userPhone, 'password' => 'Mpya12345']);
check('login with new password', $r['status'] === 200, $r['body']);

echo "\n{$passes} passed, {$failures} failed\n";
exit($failures === 0 ? 0 : 1);
