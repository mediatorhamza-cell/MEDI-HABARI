<?php
// Router for PHP's built-in server (local development only):
//   php -S 127.0.0.1:8000 api/tests/dev-router.php
if (str_starts_with(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH) ?: '/', '/api')) {
    require dirname(__DIR__) . '/index.php';
    return true;
}
http_response_code(404);
echo 'Frontend is served by Vite in development (npm run dev in /web).';
return true;
