# Working on Mediator

- Owner wants every requested change **live immediately**: after a change is tested and committed,
  run `bash scripts/publish.sh` — it builds and pushes `public_html` to the `production` branch,
  which Hostinger auto-deploys (Git + webhook). Never commit `.env` or anything from `storage/`.
- Before publishing: `php api/tests/api_test.php` (needs MariaDB + `php -S 127.0.0.1:8000 api/tests/dev-router.php`)
  and `cd web && npx tsc --noEmit -p . && npm run build`.
- The live site starts in "Coming Soon" mode (`site_live` setting); only staff see the full site.
- Communicate with the owner in Kiswahili.
- Android app = Trusted Web Activity in `android/` (see `android/README.md`). Rebuild only for icon/name/version changes:
  `bash scripts/build-apk.sh` → `web/public/downloads/MediatorHamza.apk`. The signing keystore is NOT in git; the owner
  keeps the backup (`android/keystore/` + `android/keystore.properties`) — never commit it.
